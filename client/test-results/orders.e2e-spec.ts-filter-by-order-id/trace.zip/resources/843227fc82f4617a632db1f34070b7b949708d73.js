import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { Utensils } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { getMonthOrdersAmount } from "/src/api/get-month-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthOrdersAmountCard() {
  _s();
  const { data: monthOrdersAmount } = useQuery({
    queryFn: getMonthOrdersAmount,
    queryKey: ["metrics", "month-orders-amount"]
  });
  return /* @__PURE__ */ jsxDEV(Card, { className: "bg-text-muted-foreground", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Pedidos (mês)" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Utensils, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold tracking-tight", children: monthOrdersAmount.amount.toLocaleString("pt-BR") }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 24,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs- text-muted-foreground", children: monthOrdersAmount.diffFromLastMonth >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-500 dark:text-emerald-400", children: [
          "+",
          monthOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
          lineNumber: 30,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 29,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500 dark:text-rose-400", children: [
          monthOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
          lineNumber: 37,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 36,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
        lineNumber: 27,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 46,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(MonthOrdersAmountCard, "eVUQBo3ayFgd2a/Lf1CXtZs2rcQ=", false, function() {
  return [useQuery];
});
_c = MonthOrdersAmountCard;
var _c;
$RefreshReg$(_c, "MonthOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRLFNBV1EsVUFYUjsyQkFqQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLDRCQUE0QjtBQUNyQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyx3QkFBd0I7QUFBQUMsS0FBQTtBQUN0QyxRQUFNLEVBQUVDLE1BQU1DLGtCQUFrQixJQUFJQyxTQUFTO0FBQUEsSUFDM0NDLFNBQVNYO0FBQUFBLElBQ1RZLFVBQVUsQ0FBQyxXQUFXLHFCQUFxQjtBQUFBLEVBQzdDLENBQUM7QUFFRCxTQUNFLHVCQUFDLFFBQUssV0FBVSw0QkFDZDtBQUFBLDJCQUFDLGNBQVcsV0FBVSx3REFDcEI7QUFBQSw2QkFBQyxhQUFVLFdBQVUsMkJBQTBCLDZCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsTUFDNUQsdUJBQUMsWUFBUyxXQUFVLG1DQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxlQUFZLFdBQVUsYUFDcEJILDhCQUNDLG1DQUNFO0FBQUEsNkJBQUMsVUFBSyxXQUFVLHFDQUNiQSw0QkFBa0JJLE9BQU9DLGVBQWUsT0FBTyxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVkwsNEJBQWtCTSxxQkFBcUIsSUFDdEMsbUNBQ0U7QUFBQSwrQkFBQyxVQUFLLFdBQVUsMENBQXdDO0FBQUE7QUFBQSxVQUNwRE4sa0JBQWtCTTtBQUFBQSxVQUFrQjtBQUFBLGFBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSxvQ0FDYk47QUFBQUEsNEJBQWtCTTtBQUFBQSxVQUFrQjtBQUFBLGFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQSxJQUVBLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUIsS0F6QnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxPQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRUo7QUFBQ1IsR0ExQ2VELHVCQUFxQjtBQUFBLFVBQ0NJLFFBQVE7QUFBQTtBQUFBTSxLQUQ5QlY7QUFBcUIsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlV0ZW5zaWxzIiwiZ2V0TW9udGhPcmRlcnNBbW91bnQiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiTWV0cmljQ2FyZFNrZWxldG9uIiwiTW9udGhPcmRlcnNBbW91bnRDYXJkIiwiX3MiLCJkYXRhIiwibW9udGhPcmRlcnNBbW91bnQiLCJ1c2VRdWVyeSIsInF1ZXJ5Rm4iLCJxdWVyeUtleSIsImFtb3VudCIsInRvTG9jYWxlU3RyaW5nIiwiZGlmZkZyb21MYXN0TW9udGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm1vbnRoLW9yZGVycy1hbW91bnQtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBVdGVuc2lscyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuaW1wb3J0IHsgZ2V0TW9udGhPcmRlcnNBbW91bnQgfSBmcm9tICdAL2FwaS9nZXQtbW9udGgtb3JkZXJzLWFtb3VudCdcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcblxuaW1wb3J0IHsgTWV0cmljQ2FyZFNrZWxldG9uIH0gZnJvbSAnLi9tZXRyaWMtY2FyZC1za2VsZXRvbidcblxuZXhwb3J0IGZ1bmN0aW9uIE1vbnRoT3JkZXJzQW1vdW50Q2FyZCgpIHtcbiAgY29uc3QgeyBkYXRhOiBtb250aE9yZGVyc0Ftb3VudCB9ID0gdXNlUXVlcnkoe1xuICAgIHF1ZXJ5Rm46IGdldE1vbnRoT3JkZXJzQW1vdW50LFxuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnbW9udGgtb3JkZXJzLWFtb3VudCddLFxuICB9KVxuXG4gIHJldHVybiAoXG4gICAgPENhcmQgY2xhc3NOYW1lPVwiYmctdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktMCBwYi0yXCI+XG4gICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIj5QZWRpZG9zIChtw6pzKTwvQ2FyZFRpdGxlPlxuICAgICAgICA8VXRlbnNpbHMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICB7bW9udGhPcmRlcnNBbW91bnQgPyAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICB7bW9udGhPcmRlcnNBbW91bnQuYW1vdW50LnRvTG9jYWxlU3RyaW5nKCdwdC1CUicpfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cy0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHttb250aE9yZGVyc0Ftb3VudC5kaWZmRnJvbUxhc3RNb250aCA+PSAwID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAre21vbnRoT3JkZXJzQW1vdW50LmRpZmZGcm9tTGFzdE1vbnRofSVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj57JyAnfVxuICAgICAgICAgICAgICAgICAgZW0gcmVsYcOnw6NvIGFvIG3DqnMgcGFzc2Fkb1xuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwIGRhcms6dGV4dC1yb3NlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7bW9udGhPcmRlcnNBbW91bnQuZGlmZkZyb21MYXN0TW9udGh9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYW8gbcOqcyBwYXNzYWRvXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPE1ldHJpY0NhcmRTa2VsZXRvbiAvPlxuICAgICAgICApfVxuICAgICAgPC9DYXJkQ29udGVudD5cbiAgICA8L0NhcmQ+XG4gIClcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVhbnBhYmxvL2lnbml0ZS9yZWFjdGpzL2Rhc2hib2FyZC9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9tb250aC1vcmRlcnMtYW1vdW50LWNhcmQudHN4In0=