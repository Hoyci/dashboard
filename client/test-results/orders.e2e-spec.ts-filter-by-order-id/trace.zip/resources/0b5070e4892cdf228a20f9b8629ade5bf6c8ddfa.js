import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-skeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { Button } from "/src/components/ui/button.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { TableCell, TableRow } from "/src/components/ui/table.tsx";
export function OrderTableSkeleton() {
  return Array.from({ length: 10 }).map((_, i) => {
    return /* @__PURE__ */ jsxDEV(TableRow, { children: [
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "xs", disabled: true, children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-3 w-3" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
          lineNumber: 13,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Detalhes do pedido" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
          lineNumber: 14,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 12,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[172px]" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 18,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 17,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[148px]" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 21,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[110px]" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 24,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[200px]" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 27,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[64px]" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[92px]" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 33,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-[92px]" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 36,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ] }, i, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx",
      lineNumber: 10,
      columnNumber: 7
    }, this);
  });
}
_c = OrderTableSkeleton;
var _c;
$RefreshReg$(_c, "OrderTableSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVk7QUFaWiwyQkFBdUI7QUFBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFckMsU0FBU0EsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBRTdCLGdCQUFTQyxxQkFBcUI7QUFDbkMsU0FBT0MsTUFBTUMsS0FBSyxFQUFFQyxRQUFRLEdBQUcsQ0FBQyxFQUFFQyxJQUFJLENBQUNDLEdBQUdDLE1BQU07QUFDOUMsV0FDRSx1QkFBQyxZQUNDO0FBQUEsNkJBQUMsYUFDQyxpQ0FBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQUssVUFBUSxNQUMxQztBQUFBLCtCQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDM0IsdUJBQUMsVUFBSyxXQUFVLFdBQVUsa0NBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxXQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsYUFDQyxpQ0FBQyxZQUFTLFdBQVUsbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxhQUNDLGlDQUFDLFlBQVMsV0FBVSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQyxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsYUFDQyxpQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxhQUNDLGlDQUFDLFlBQVMsV0FBVSxrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGFBQ0MsaUNBQUMsWUFBUyxXQUFVLGtCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBM0JhQSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxFQUVKLENBQUM7QUFDSDtBQUFDQyxLQWxDZVA7QUFBa0IsSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIlNrZWxldG9uIiwiVGFibGVDZWxsIiwiVGFibGVSb3ciLCJPcmRlclRhYmxlU2tlbGV0b24iLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJtYXAiLCJfIiwiaSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsib3JkZXItdGFibGUtc2tlbGV0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNlYXJjaCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NrZWxldG9uJ1xuaW1wb3J0IHsgVGFibGVDZWxsLCBUYWJsZVJvdyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90YWJsZSdcblxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyVGFibGVTa2VsZXRvbigpIHtcbiAgcmV0dXJuIEFycmF5LmZyb20oeyBsZW5ndGg6IDEwIH0pLm1hcCgoXywgaSkgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICA8VGFibGVSb3cga2V5PXtpfT5cbiAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInhzXCIgZGlzYWJsZWQ+XG4gICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkRldGFsaGVzIGRvIHBlZGlkbzwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVsxNzJweF1cIiAvPlxuICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctWzE0OHB4XVwiIC8+XG4gICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy1bMTEwcHhdXCIgLz5cbiAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVsyMDBweF1cIiAvPlxuICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC00IHctWzY0cHhdXCIgLz5cbiAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LVs5MnB4XVwiIC8+XG4gICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy1bOTJweF1cIiAvPlxuICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDwvVGFibGVSb3c+XG4gICAgKVxuICB9KVxufVxuIl0sImZpbGUiOiIvaG9tZS9ydWFucGFibG8vaWduaXRlL3JlYWN0anMvZGFzaGJvYXJkL3NyYy9wYWdlcy9hcHAvb3JkZXJzL29yZGVyLXRhYmxlLXNrZWxldG9uLnRzeCJ9