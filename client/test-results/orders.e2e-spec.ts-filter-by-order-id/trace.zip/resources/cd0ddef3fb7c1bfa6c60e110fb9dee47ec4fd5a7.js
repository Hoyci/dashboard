import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/global.css";
import { QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { Helmet, HelmetProvider } from "/node_modules/.vite/deps/react-helmet-async.js?v=cab43493";
import { RouterProvider } from "/node_modules/.vite/deps/react-router-dom.js?v=cab43493";
import { Toaster } from "/node_modules/.vite/deps/sonner.js?v=cab43493";
import { ThemeProvider } from "/src/components/theme/theme-provider.tsx";
import { queryClient } from "/src/lib/react-query.ts";
import { router } from "/src/routes.tsx";
export function App() {
  return /* @__PURE__ */ jsxDEV(ThemeProvider, { storageKey: "pizzashop-theme", defaultTheme: "dark", children: /* @__PURE__ */ jsxDEV(HelmetProvider, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { titleTemplate: "%s | pizza.shop" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Toaster, { richColors: true }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx",
      lineNumber: 17,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxDEV(RouterProvider, { router }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx",
      lineNumber: 19,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx",
    lineNumber: 15,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/app.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7QUFmUixPQUFPLG9CQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXJCLFNBQVNBLDJCQUEyQjtBQUNwQyxTQUFTQyxRQUFRQyxzQkFBc0I7QUFDdkMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGVBQWU7QUFFeEIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxjQUFjO0FBRWhCLGdCQUFTQyxNQUFNO0FBQ3BCLFNBQ0UsdUJBQUMsaUJBQWMsWUFBVyxtQkFBa0IsY0FBYSxRQUN2RCxpQ0FBQyxrQkFDQztBQUFBLDJCQUFDLFVBQU8sZUFBYyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLElBQ3ZDLHVCQUFDLFdBQVEsWUFBVSxRQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CO0FBQUEsSUFDbkIsdUJBQUMsdUJBQW9CLFFBQVFGLGFBQzNCLGlDQUFDLGtCQUFlLFVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0IsS0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUE7QUFFSjtBQUFDRyxLQVplRDtBQUFHLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJRdWVyeUNsaWVudFByb3ZpZGVyIiwiSGVsbWV0IiwiSGVsbWV0UHJvdmlkZXIiLCJSb3V0ZXJQcm92aWRlciIsIlRvYXN0ZXIiLCJUaGVtZVByb3ZpZGVyIiwicXVlcnlDbGllbnQiLCJyb3V0ZXIiLCJBcHAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuL2dsb2JhbC5jc3MnXG5cbmltcG9ydCB7IFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBIZWxtZXQsIEhlbG1ldFByb3ZpZGVyIH0gZnJvbSAncmVhY3QtaGVsbWV0LWFzeW5jJ1xuaW1wb3J0IHsgUm91dGVyUHJvdmlkZXIgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgVG9hc3RlciB9IGZyb20gJ3Nvbm5lcidcblxuaW1wb3J0IHsgVGhlbWVQcm92aWRlciB9IGZyb20gJy4vY29tcG9uZW50cy90aGVtZS90aGVtZS1wcm92aWRlcidcbmltcG9ydCB7IHF1ZXJ5Q2xpZW50IH0gZnJvbSAnLi9saWIvcmVhY3QtcXVlcnknXG5pbXBvcnQgeyByb3V0ZXIgfSBmcm9tICcuL3JvdXRlcydcblxuZXhwb3J0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8VGhlbWVQcm92aWRlciBzdG9yYWdlS2V5PVwicGl6emFzaG9wLXRoZW1lXCIgZGVmYXVsdFRoZW1lPVwiZGFya1wiPlxuICAgICAgPEhlbG1ldFByb3ZpZGVyPlxuICAgICAgICA8SGVsbWV0IHRpdGxlVGVtcGxhdGU9XCIlcyB8IHBpenphLnNob3BcIiAvPlxuICAgICAgICA8VG9hc3RlciByaWNoQ29sb3JzIC8+XG4gICAgICAgIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9PlxuICAgICAgICAgIDxSb3V0ZXJQcm92aWRlciByb3V0ZXI9e3JvdXRlcn0gLz5cbiAgICAgICAgPC9RdWVyeUNsaWVudFByb3ZpZGVyPlxuICAgICAgPC9IZWxtZXRQcm92aWRlcj5cbiAgICA8L1RoZW1lUHJvdmlkZXI+XG4gIClcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVhbnBhYmxvL2lnbml0ZS9yZWFjdGpzL2Rhc2hib2FyZC9zcmMvYXBwLnRzeCJ9