import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=cab43493";
export const registerRestaurantMock = http.post(
  "/restaurants",
  async ({ request }) => {
    const { restaurantName } = await request.json();
    if (restaurantName === "Pizza Shop") {
      return new HttpResponse(null, {
        status: 201
      });
    }
    return new HttpResponse(null, { status: 400 });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLXJlc3RhdXJhbnQtbW9jay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBodHRwLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdtc3cnXG5cbmltcG9ydCB7IFJlZ2lzdGVyUmVzdGF1cmFudEJvZHkgfSBmcm9tICcuLi9yZWdpc3Rlci1yZXN0YXVyYW50J1xuXG5leHBvcnQgY29uc3QgcmVnaXN0ZXJSZXN0YXVyYW50TW9jayA9IGh0dHAucG9zdDxuZXZlciwgUmVnaXN0ZXJSZXN0YXVyYW50Qm9keT4oXG4gICcvcmVzdGF1cmFudHMnLFxuICBhc3luYyAoeyByZXF1ZXN0IH0pID0+IHtcbiAgICBjb25zdCB7IHJlc3RhdXJhbnROYW1lIH0gPSBhd2FpdCByZXF1ZXN0Lmpzb24oKVxuXG4gICAgaWYgKHJlc3RhdXJhbnROYW1lID09PSAnUGl6emEgU2hvcCcpIHtcbiAgICAgIHJldHVybiBuZXcgSHR0cFJlc3BvbnNlKG51bGwsIHtcbiAgICAgICAgc3RhdHVzOiAyMDEsXG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgSHR0cFJlc3BvbnNlKG51bGwsIHsgc3RhdHVzOiA0MDAgfSlcbiAgfSxcbilcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG9CQUFvQjtBQUk1QixhQUFNLHlCQUF5QixLQUFLO0FBQUEsRUFDekM7QUFBQSxFQUNBLE9BQU8sRUFBRSxRQUFRLE1BQU07QUFDckIsVUFBTSxFQUFFLGVBQWUsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUU5QyxRQUFJLG1CQUFtQixjQUFjO0FBQ25DLGFBQU8sSUFBSSxhQUFhLE1BQU07QUFBQSxRQUM1QixRQUFRO0FBQUEsTUFDVixDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU8sSUFBSSxhQUFhLE1BQU0sRUFBRSxRQUFRLElBQUksQ0FBQztBQUFBLEVBQy9DO0FBQ0Y7IiwibmFtZXMiOltdfQ==