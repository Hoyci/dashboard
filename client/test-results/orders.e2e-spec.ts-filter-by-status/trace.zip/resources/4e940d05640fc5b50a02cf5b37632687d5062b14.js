import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/order-status.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const orderStatusMap = {
  pending: "Pendente",
  canceled: "Cancelado",
  delivered: "Entregue",
  delivering: "Em entrega",
  processing: "Em preparo"
};
export function OrderStatus({ status }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
    status === "pending" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-slate-400"
      },
      void 0,
      false,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx",
        lineNumber: 24,
        columnNumber: 7
      },
      this
    ),
    status === "canceled" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-rose-500"
      },
      void 0,
      false,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx",
        lineNumber: 30,
        columnNumber: 7
      },
      this
    ),
    status === "delivered" && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-emerald-500"
      },
      void 0,
      false,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx",
        lineNumber: 36,
        columnNumber: 7
      },
      this
    ),
    ["processing", "delivering"].includes(status) && /* @__PURE__ */ jsxDEV(
      "span",
      {
        "data-testid": "badge",
        className: "h-2 w-2 rounded-full bg-amber-400"
      },
      void 0,
      false,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx",
        lineNumber: 42,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-muted-foreground", children: orderStatusMap[status] }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx",
    lineNumber: 22,
    columnNumber: 5
  }, this);
}
_c = OrderStatus;
var _c;
$RefreshReg$(_c, "OrderStatus");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/components/order-status.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJRO0FBdkJSLE9BQU8sb0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVd2QixNQUFNQSxpQkFBOEM7QUFBQSxFQUNsREMsU0FBUztBQUFBLEVBQ1RDLFVBQVU7QUFBQSxFQUNWQyxXQUFXO0FBQUEsRUFDWEMsWUFBWTtBQUFBLEVBQ1pDLFlBQVk7QUFDZDtBQUVPLGdCQUFTQyxZQUFZLEVBQUVDLE9BQXlCLEdBQUc7QUFDeEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pBO0FBQUFBLGVBQVcsYUFDVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHQztBQUFBLElBRUZBLFdBQVcsY0FDVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHQztBQUFBLElBRUZBLFdBQVcsZUFDVjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHQztBQUFBLElBRUYsQ0FBQyxjQUFjLFlBQVksRUFBRUMsU0FBU0QsTUFBTSxLQUMzQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsZUFBWTtBQUFBLFFBQ1osV0FBVTtBQUFBO0FBQUEsTUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHQztBQUFBLElBR0gsdUJBQUMsVUFBSyxXQUFVLHFDQUNiUCx5QkFBZU8sTUFBTSxLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBO0FBRUo7QUFBQ0UsS0FqQ2VIO0FBQVcsSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIm9yZGVyU3RhdHVzTWFwIiwicGVuZGluZyIsImNhbmNlbGVkIiwiZGVsaXZlcmVkIiwiZGVsaXZlcmluZyIsInByb2Nlc3NpbmciLCJPcmRlclN0YXR1cyIsInN0YXR1cyIsImluY2x1ZGVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJvcmRlci1zdGF0dXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB0eXBlIE9yZGVyU3RhdHVzID1cbiAgfCAncGVuZGluZydcbiAgfCAnY2FuY2VsZWQnXG4gIHwgJ3Byb2Nlc3NpbmcnXG4gIHwgJ2RlbGl2ZXJpbmcnXG4gIHwgJ2RlbGl2ZXJlZCdcblxuaW50ZXJmYWNlIE9yZGVyU3RhdHVzUHJvcHMge1xuICBzdGF0dXM6IE9yZGVyU3RhdHVzXG59XG5cbmNvbnN0IG9yZGVyU3RhdHVzTWFwOiBSZWNvcmQ8T3JkZXJTdGF0dXMsIHN0cmluZz4gPSB7XG4gIHBlbmRpbmc6ICdQZW5kZW50ZScsXG4gIGNhbmNlbGVkOiAnQ2FuY2VsYWRvJyxcbiAgZGVsaXZlcmVkOiAnRW50cmVndWUnLFxuICBkZWxpdmVyaW5nOiAnRW0gZW50cmVnYScsXG4gIHByb2Nlc3Npbmc6ICdFbSBwcmVwYXJvJyxcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE9yZGVyU3RhdHVzKHsgc3RhdHVzIH06IE9yZGVyU3RhdHVzUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICB7c3RhdHVzID09PSAncGVuZGluZycgJiYgKFxuICAgICAgICA8c3BhblxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYmFkZ2VcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTQwMFwiXG4gICAgICAgID48L3NwYW4+XG4gICAgICApfVxuICAgICAge3N0YXR1cyA9PT0gJ2NhbmNlbGVkJyAmJiAoXG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJiYWRnZVwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC0yIHctMiByb3VuZGVkLWZ1bGwgYmctcm9zZS01MDBcIlxuICAgICAgICA+PC9zcGFuPlxuICAgICAgKX1cbiAgICAgIHtzdGF0dXMgPT09ICdkZWxpdmVyZWQnICYmIChcbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImJhZGdlXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMFwiXG4gICAgICAgID48L3NwYW4+XG4gICAgICApfVxuICAgICAge1sncHJvY2Vzc2luZycsICdkZWxpdmVyaW5nJ10uaW5jbHVkZXMoc3RhdHVzKSAmJiAoXG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJiYWRnZVwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC0yIHctMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNDAwXCJcbiAgICAgICAgPjwvc3Bhbj5cbiAgICAgICl9XG5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICB7b3JkZXJTdGF0dXNNYXBbc3RhdHVzXX1cbiAgICAgIDwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvaG9tZS9ydWFucGFibG8vaWduaXRlL3JlYWN0anMvZGFzaGJvYXJkL3NyYy9jb21wb25lbnRzL29yZGVyLXN0YXR1cy50c3gifQ==