import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-details-skeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow
} from "/src/components/ui/table.tsx";
export function OrderDetailsSkeleton() {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 overflow-y-scroll", children: [
    /* @__PURE__ */ jsxDEV(Table, { children: /* @__PURE__ */ jsxDEV(TableBody, { children: [
      /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Status" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 18,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-20" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 20,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 19,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 17,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Cliente" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 24,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-[164px]" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 26,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 25,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 23,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Telefone" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 30,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-[140px]" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 32,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 31,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 29,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "E-mail" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 36,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-[200px]" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 38,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 37,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 35,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Realizado há" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 42,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-[148px]" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 46,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 45,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 41,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableHead, { children: "Produto" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 55,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Quantidade" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 56,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Preço" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 57,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Subtotal" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 58,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 54,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: Array.from({ length: 2 }).map(
        (_, i) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-[140px]" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 65,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 64,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "ml-auto h-5 w-3" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 68,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 67,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "ml-auto h-5 w-12" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 71,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 70,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "ml-auto h-5 w-12" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 74,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
            lineNumber: 73,
            columnNumber: 15
          }, this)
        ] }, i, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 63,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(TableFooter, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { colSpan: 3, children: "Total do pedido" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 81,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right font-medium", children: /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-20" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 83,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
          lineNumber: 82,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 80,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
        lineNumber: 79,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
}
_c = OrderDetailsSkeleton;
var _c;
$RefreshReg$(_c, "OrderDetailsSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details-skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJZO0FBakJaLDJCQUF5QjtBQUFBLE1BQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuRDtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFQSxnQkFBU0MsdUJBQXVCO0FBQ3JDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsMkJBQUMsU0FDQyxpQ0FBQyxhQUNDO0FBQUEsNkJBQUMsWUFDQztBQUFBLCtCQUFDLGFBQVUsV0FBVSx5QkFBd0Isc0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxRQUNuRCx1QkFBQyxhQUFVLFdBQVUsb0JBQ25CLGlDQUFDLFlBQVMsV0FBVSxjQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxXQUFVLHlCQUF3Qix1QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLGFBQVUsV0FBVSxvQkFDbkIsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxXQUFVLHlCQUF3Qix3QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFFBQ3JELHVCQUFDLGFBQVUsV0FBVSxvQkFDbkIsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxXQUFVLHlCQUF3QixzQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLGFBQVUsV0FBVSxvQkFDbkIsaUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxXQUFVLHlCQUF1Qiw0QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxhQUFVLFdBQVUsb0JBQ25CLGlDQUFDLFlBQVMsV0FBVSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQyxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQ0EsS0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLElBRUEsdUJBQUMsU0FDQztBQUFBLDZCQUFDLGVBQ0MsaUNBQUMsWUFDQztBQUFBLCtCQUFDLGFBQVUsdUJBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQjtBQUFBLFFBQ2xCLHVCQUFDLGFBQVUsV0FBVSxjQUFhLDBCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsUUFDNUMsdUJBQUMsYUFBVSxXQUFVLGNBQWEscUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxRQUN2Qyx1QkFBQyxhQUFVLFdBQVUsY0FBYSx3QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFdBSjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsYUFDRUMsZ0JBQU1DLEtBQUssRUFBRUMsUUFBUSxFQUFFLENBQUMsRUFBRUM7QUFBQUEsUUFBSSxDQUFDQyxHQUFHQyxNQUNqQyx1QkFBQyxZQUNDO0FBQUEsaUNBQUMsYUFDQyxpQ0FBQyxZQUFTLFdBQVUsbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxjQUNuQixpQ0FBQyxZQUFTLFdBQVUscUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxjQUNuQixpQ0FBQyxZQUFTLFdBQVUsc0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxjQUNuQixpQ0FBQyxZQUFTLFdBQVUsc0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVphQSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLE1BQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLE1BQ0EsdUJBQUMsZUFDQyxpQ0FBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxTQUFTLEdBQUcsK0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxhQUFVLFdBQVUsMEJBQ25CLGlDQUFDLFlBQVMsV0FBVSxjQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLE9BekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwRUE7QUFFSjtBQUFDQyxLQTlFZVA7QUFBb0IsSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlRhYmxlIiwiVGFibGVCb2R5IiwiVGFibGVDZWxsIiwiVGFibGVGb290ZXIiLCJUYWJsZUhlYWQiLCJUYWJsZUhlYWRlciIsIlRhYmxlUm93IiwiT3JkZXJEZXRhaWxzU2tlbGV0b24iLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJtYXAiLCJfIiwiaSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsib3JkZXItZGV0YWlscy1za2VsZXRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2tlbGV0b24nXG5pbXBvcnQge1xuICBUYWJsZSxcbiAgVGFibGVCb2R5LFxuICBUYWJsZUNlbGwsXG4gIFRhYmxlRm9vdGVyLFxuICBUYWJsZUhlYWQsXG4gIFRhYmxlSGVhZGVyLFxuICBUYWJsZVJvdyxcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3RhYmxlJ1xuXG5leHBvcnQgZnVuY3Rpb24gT3JkZXJEZXRhaWxzU2tlbGV0b24oKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgb3ZlcmZsb3cteS1zY3JvbGxcIj5cbiAgICAgIDxUYWJsZT5cbiAgICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlN0YXR1czwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTUgdy0yMFwiIC8+XG4gICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Q2xpZW50ZTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTUgdy1bMTY0cHhdXCIgLz5cbiAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5UZWxlZm9uZTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTUgdy1bMTQwcHhdXCIgLz5cbiAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5FLW1haWw8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC01IHctWzIwMHB4XVwiIC8+XG4gICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIFJlYWxpemFkbyBow6FcbiAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTUgdy1bMTQ4cHhdXCIgLz5cbiAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgIDwvVGFibGVCb2R5PlxuICAgICAgPC9UYWJsZT5cblxuICAgICAgPFRhYmxlPlxuICAgICAgICA8VGFibGVIZWFkZXI+XG4gICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgPFRhYmxlSGVhZD5Qcm9kdXRvPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5RdWFudGlkYWRlPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5QcmXDp288L1RhYmxlSGVhZD5cbiAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlN1YnRvdGFsPC9UYWJsZUhlYWQ+XG4gICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgPC9UYWJsZUhlYWRlcj5cbiAgICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogMiB9KS5tYXAoKF8sIGkpID0+IChcbiAgICAgICAgICAgIDxUYWJsZVJvdyBrZXk9e2l9PlxuICAgICAgICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTUgdy1bMTQwcHhdXCIgLz5cbiAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJtbC1hdXRvIGgtNSB3LTNcIiAvPlxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cIm1sLWF1dG8gaC01IHctMTJcIiAvPlxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cIm1sLWF1dG8gaC01IHctMTJcIiAvPlxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvVGFibGVCb2R5PlxuICAgICAgICA8VGFibGVGb290ZXI+XG4gICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgPFRhYmxlQ2VsbCBjb2xTcGFuPXszfT5Ub3RhbCBkbyBwZWRpZG88L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1yaWdodCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC01IHctMjBcIiAvPlxuICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgPC9UYWJsZUZvb3Rlcj5cbiAgICAgIDwvVGFibGU+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVhbnBhYmxvL2lnbml0ZS9yZWFjdGpzL2Rhc2hib2FyZC9zcmMvcGFnZXMvYXBwL29yZGVycy9vcmRlci1kZXRhaWxzLXNrZWxldG9uLnRzeCJ9