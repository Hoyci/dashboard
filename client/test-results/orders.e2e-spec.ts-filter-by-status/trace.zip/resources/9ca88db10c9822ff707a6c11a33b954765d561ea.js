import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/account-menu.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { Building, ChevronDown, LogOut } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cab43493";
import { getManagedRestaurant } from "/src/api/get-managed-restaurant.ts";
import { getProfile } from "/src/api/get-profile.ts";
import { signOut } from "/src/api/sign-out.ts";
import StoreProfileDialog from "/src/components/store-profile-dialog.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogTrigger } from "/src/components/ui/dialog.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "/src/components/ui/dropdown-menu.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
export function AccountMenu() {
  _s();
  const navigate = useNavigate();
  const { data: managedRestaurant, isLoading: isManagedRestaurantLoading } = useQuery({
    queryKey: ["managed-restaurant"],
    queryFn: getManagedRestaurant,
    staleTime: Infinity
  });
  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ["profile"],
    queryFn: getProfile,
    staleTime: Infinity
  });
  const { mutateAsync: signOutFn, isPending: isSigningOut } = useMutation({
    mutationFn: signOut,
    onSuccess: () => {
      navigate("/sign-in", { replace: true });
    }
  });
  return /* @__PURE__ */ jsxDEV(Dialog, { children: [
    /* @__PURE__ */ jsxDEV(DropdownMenu, { children: [
      /* @__PURE__ */ jsxDEV(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          className: "flex select-none items-center gap-2",
          children: [
            isManagedRestaurantLoading ? /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-40" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
              lineNumber: 54,
              columnNumber: 13
            }, this) : managedRestaurant?.name,
            /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h-4 w-4" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
              lineNumber: 58,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
          lineNumber: 49,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DropdownMenuContent, { align: "end", className: "w-56", children: [
        /* @__PURE__ */ jsxDEV(DropdownMenuLabel, { className: "flex flex-col", children: isLoadingProfile ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-32" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
            lineNumber: 66,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-3 w-24" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
            lineNumber: 67,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
          lineNumber: 65,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("span", { children: profile?.name }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
            lineNumber: 71,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-normal text-muted-foreground", children: profile?.email }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
            lineNumber: 72,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
          lineNumber: 70,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
          lineNumber: 63,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
          lineNumber: 78,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(DropdownMenuItem, { children: [
          /* @__PURE__ */ jsxDEV(Building, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
            lineNumber: 81,
            columnNumber: 15
          }, this),
          "Perfil da loja"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
          lineNumber: 80,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
          lineNumber: 79,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          DropdownMenuItem,
          {
            asChild: true,
            disabled: isSigningOut,
            className: "text-rose-500 dark:text-rose-400",
            children: /* @__PURE__ */ jsxDEV("button", { onClick: () => signOutFn(), children: [
              /* @__PURE__ */ jsxDEV(LogOut, { className: "mr-2 h-4 w-4" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
                lineNumber: 91,
                columnNumber: 15
              }, this),
              "Sair"
            ] }, void 0, true, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
              lineNumber: 90,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
            lineNumber: 85,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(StoreProfileDialog, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_s(AccountMenu, "KCjixhZjmaD6qnwRZ6pei1eN108=", false, function() {
  return [useNavigate, useQuery, useQuery, useMutation];
});
_c = AccountMenu;
var _c;
$RefreshReg$(_c, "AccountMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/components/account-menu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURjLFNBZ0JBLFVBaEJBOzJCQXJEZDtBQUFvQixNQUFFQSxjQUFnQiw2QkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDN0QsU0FBU0MsVUFBVUMsYUFBYUMsY0FBYztBQUM5QyxTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxlQUFlO0FBRXhCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFFBQVFDLHFCQUFxQjtBQUN0QztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxnQkFBZ0I7QUFFbEIsZ0JBQVNDLGNBQWM7QUFBQUMsS0FBQTtBQUM1QixRQUFNQyxXQUFXakIsWUFBWTtBQUU3QixRQUFNLEVBQUVrQixNQUFNQyxtQkFBbUJDLFdBQVdDLDJCQUEyQixJQUNyRXpCLFNBQVM7QUFBQSxJQUNQMEIsVUFBVSxDQUFDLG9CQUFvQjtBQUFBLElBQy9CQyxTQUFTdEI7QUFBQUEsSUFDVHVCLFdBQVdDO0FBQUFBLEVBQ2IsQ0FBQztBQUVILFFBQU0sRUFBRVAsTUFBTVEsU0FBU04sV0FBV08saUJBQWlCLElBQUkvQixTQUFTO0FBQUEsSUFDOUQwQixVQUFVLENBQUMsU0FBUztBQUFBLElBQ3BCQyxTQUFTckI7QUFBQUEsSUFDVHNCLFdBQVdDO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU0sRUFBRUcsYUFBYUMsV0FBV0MsV0FBV0MsYUFBYSxJQUFJQyxZQUFZO0FBQUEsSUFDdEVDLFlBQVk5QjtBQUFBQSxJQUNaK0IsV0FBV0EsTUFBTTtBQUNmakIsZUFBUyxZQUFZLEVBQUVrQixTQUFTLEtBQUssQ0FBQztBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FDRSx1QkFBQyxVQUNDO0FBQUEsMkJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyx1QkFBb0IsU0FBTyxNQUMxQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsV0FBVTtBQUFBLFVBRVRkO0FBQUFBLHlDQUNDLHVCQUFDLFlBQVMsV0FBVSxjQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QixJQUU5QkYsbUJBQW1CaUI7QUFBQUEsWUFFckIsdUJBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUE7QUFBQTtBQUFBLFFBVGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyx1QkFBb0IsT0FBTSxPQUFNLFdBQVUsUUFDekM7QUFBQSwrQkFBQyxxQkFBa0IsV0FBVSxpQkFDMUJULDZCQUNDLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsWUFBUyxXQUFVLGNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsWUFBUyxXQUFVLGNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsYUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxVQUFNRCxtQkFBU1UsUUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUI7QUFBQSxVQUNyQix1QkFBQyxVQUFLLFdBQVUsNkNBQ2JWLG1CQUFTVyxTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxLQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBQ0EsdUJBQUMsMkJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQjtBQUFBLFFBQ3RCLHVCQUFDLGlCQUFjLFNBQU8sTUFDcEIsaUNBQUMsb0JBQ0M7QUFBQSxpQ0FBQyxZQUFTLFdBQVUsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUE7QUFBQSxhQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsVUFBVU47QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFFVixpQ0FBQyxZQUFPLFNBQVMsTUFBTUYsVUFBVSxHQUMvQjtBQUFBLHFDQUFDLFVBQU8sV0FBVSxrQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQTtBQUFBLGlCQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUE7QUFBQSxVQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLFNBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpREE7QUFBQSxJQUNBLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUI7QUFBQSxPQW5EckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9EQTtBQUVKO0FBQUNiLEdBOUVlRCxhQUFXO0FBQUEsVUFDUmYsYUFHZkosVUFNcURBLFVBTUtvQyxXQUFXO0FBQUE7QUFBQU0sS0FoQnpEdkI7QUFBVyxJQUFBdUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVF1ZXJ5IiwiQnVpbGRpbmciLCJDaGV2cm9uRG93biIsIkxvZ091dCIsInVzZU5hdmlnYXRlIiwiZ2V0TWFuYWdlZFJlc3RhdXJhbnQiLCJnZXRQcm9maWxlIiwic2lnbk91dCIsIlN0b3JlUHJvZmlsZURpYWxvZyIsIkJ1dHRvbiIsIkRpYWxvZyIsIkRpYWxvZ1RyaWdnZXIiLCJEcm9wZG93bk1lbnUiLCJEcm9wZG93bk1lbnVDb250ZW50IiwiRHJvcGRvd25NZW51SXRlbSIsIkRyb3Bkb3duTWVudUxhYmVsIiwiRHJvcGRvd25NZW51U2VwYXJhdG9yIiwiRHJvcGRvd25NZW51VHJpZ2dlciIsIlNrZWxldG9uIiwiQWNjb3VudE1lbnUiLCJfcyIsIm5hdmlnYXRlIiwiZGF0YSIsIm1hbmFnZWRSZXN0YXVyYW50IiwiaXNMb2FkaW5nIiwiaXNNYW5hZ2VkUmVzdGF1cmFudExvYWRpbmciLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJzdGFsZVRpbWUiLCJJbmZpbml0eSIsInByb2ZpbGUiLCJpc0xvYWRpbmdQcm9maWxlIiwibXV0YXRlQXN5bmMiLCJzaWduT3V0Rm4iLCJpc1BlbmRpbmciLCJpc1NpZ25pbmdPdXQiLCJ1c2VNdXRhdGlvbiIsIm11dGF0aW9uRm4iLCJvblN1Y2Nlc3MiLCJyZXBsYWNlIiwibmFtZSIsImVtYWlsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhY2NvdW50LW1lbnUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IEJ1aWxkaW5nLCBDaGV2cm9uRG93biwgTG9nT3V0IH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuXG5pbXBvcnQgeyBnZXRNYW5hZ2VkUmVzdGF1cmFudCB9IGZyb20gJ0AvYXBpL2dldC1tYW5hZ2VkLXJlc3RhdXJhbnQnXG5pbXBvcnQgeyBnZXRQcm9maWxlIH0gZnJvbSAnQC9hcGkvZ2V0LXByb2ZpbGUnXG5pbXBvcnQgeyBzaWduT3V0IH0gZnJvbSAnQC9hcGkvc2lnbi1vdXQnXG5cbmltcG9ydCBTdG9yZVByb2ZpbGVEaWFsb2cgZnJvbSAnLi9zdG9yZS1wcm9maWxlLWRpYWxvZydcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vdWkvYnV0dG9uJ1xuaW1wb3J0IHsgRGlhbG9nLCBEaWFsb2dUcmlnZ2VyIH0gZnJvbSAnLi91aS9kaWFsb2cnXG5pbXBvcnQge1xuICBEcm9wZG93bk1lbnUsXG4gIERyb3Bkb3duTWVudUNvbnRlbnQsXG4gIERyb3Bkb3duTWVudUl0ZW0sXG4gIERyb3Bkb3duTWVudUxhYmVsLFxuICBEcm9wZG93bk1lbnVTZXBhcmF0b3IsXG4gIERyb3Bkb3duTWVudVRyaWdnZXIsXG59IGZyb20gJy4vdWkvZHJvcGRvd24tbWVudSdcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnLi91aS9za2VsZXRvbidcblxuZXhwb3J0IGZ1bmN0aW9uIEFjY291bnRNZW51KCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcblxuICBjb25zdCB7IGRhdGE6IG1hbmFnZWRSZXN0YXVyYW50LCBpc0xvYWRpbmc6IGlzTWFuYWdlZFJlc3RhdXJhbnRMb2FkaW5nIH0gPVxuICAgIHVzZVF1ZXJ5KHtcbiAgICAgIHF1ZXJ5S2V5OiBbJ21hbmFnZWQtcmVzdGF1cmFudCddLFxuICAgICAgcXVlcnlGbjogZ2V0TWFuYWdlZFJlc3RhdXJhbnQsXG4gICAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuICAgIH0pXG5cbiAgY29uc3QgeyBkYXRhOiBwcm9maWxlLCBpc0xvYWRpbmc6IGlzTG9hZGluZ1Byb2ZpbGUgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydwcm9maWxlJ10sXG4gICAgcXVlcnlGbjogZ2V0UHJvZmlsZSxcbiAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuICB9KVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IHNpZ25PdXRGbiwgaXNQZW5kaW5nOiBpc1NpZ25pbmdPdXQgfSA9IHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiBzaWduT3V0LFxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xuICAgICAgbmF2aWdhdGUoJy9zaWduLWluJywgeyByZXBsYWNlOiB0cnVlIH0pXG4gICAgfSxcbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2c+XG4gICAgICA8RHJvcGRvd25NZW51PlxuICAgICAgICA8RHJvcGRvd25NZW51VHJpZ2dlciBhc0NoaWxkPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggc2VsZWN0LW5vbmUgaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aXNNYW5hZ2VkUmVzdGF1cmFudExvYWRpbmcgPyAoXG4gICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy00MFwiIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICBtYW5hZ2VkUmVzdGF1cmFudD8ubmFtZVxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDxDaGV2cm9uRG93biBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9Ecm9wZG93bk1lbnVUcmlnZ2VyPlxuXG4gICAgICAgIDxEcm9wZG93bk1lbnVDb250ZW50IGFsaWduPVwiZW5kXCIgY2xhc3NOYW1lPVwidy01NlwiPlxuICAgICAgICAgIDxEcm9wZG93bk1lbnVMYWJlbCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICB7aXNMb2FkaW5nUHJvZmlsZSA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQgdy0zMlwiIC8+XG4gICAgICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMyB3LTI0XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxzcGFuPntwcm9maWxlPy5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAge3Byb2ZpbGU/LmVtYWlsfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvRHJvcGRvd25NZW51TGFiZWw+XG4gICAgICAgICAgPERyb3Bkb3duTWVudVNlcGFyYXRvciAvPlxuICAgICAgICAgIDxEaWFsb2dUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICAgICAgPEJ1aWxkaW5nIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIFBlcmZpbCBkYSBsb2phXG4gICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICAgICAgPC9EaWFsb2dUcmlnZ2VyPlxuICAgICAgICAgIDxEcm9wZG93bk1lbnVJdGVtXG4gICAgICAgICAgICBhc0NoaWxkXG4gICAgICAgICAgICBkaXNhYmxlZD17aXNTaWduaW5nT3V0fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMCBkYXJrOnRleHQtcm9zZS00MDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2lnbk91dEZuKCl9PlxuICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIFNhaXJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgPC9Ecm9wZG93bk1lbnVDb250ZW50PlxuICAgICAgPC9Ecm9wZG93bk1lbnU+XG4gICAgICA8U3RvcmVQcm9maWxlRGlhbG9nIC8+XG4gICAgPC9EaWFsb2c+XG4gIClcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVhbnBhYmxvL2lnbml0ZS9yZWFjdGpzL2Rhc2hib2FyZC9zcmMvY29tcG9uZW50cy9hY2NvdW50LW1lbnUudHN4In0=