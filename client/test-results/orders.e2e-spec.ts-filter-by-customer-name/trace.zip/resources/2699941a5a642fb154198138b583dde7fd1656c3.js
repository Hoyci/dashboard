import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/popular-produts-chart.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { BarChart, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { Cell, Pie, PieChart, ResponsiveContainer } from "/node_modules/.vite/deps/recharts.js?v=cab43493";
import __vite__cjsImport6_tailwindcss_colors from "/node_modules/.vite/deps/tailwindcss_colors.js?v=cab43493"; const colors = __vite__cjsImport6_tailwindcss_colors.__esModule ? __vite__cjsImport6_tailwindcss_colors.default : __vite__cjsImport6_tailwindcss_colors;
import { getPopularProducts } from "/src/api/get-popular-products.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
const COLORS = [
  colors.sky["500"],
  colors.amber["500"],
  colors.violet["500"],
  colors.emerald["500"],
  colors.rose["500"]
];
export function PopularProductsChart() {
  _s();
  const { data: popularProducts } = useQuery({
    queryKey: ["metrics", "popular-products"],
    queryFn: getPopularProducts
  });
  return /* @__PURE__ */ jsxDEV(Card, { className: "bg-text-muted-foreground col-span-3", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "pb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-medium", children: "Produtos Populares" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(BarChart, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
        lineNumber: 29,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
      lineNumber: 25,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: popularProducts ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 240, children: /* @__PURE__ */ jsxDEV(PieChart, { style: { fontSize: 12 }, children: /* @__PURE__ */ jsxDEV(
      Pie,
      {
        data: popularProducts,
        dataKey: "amount",
        nameKey: "product",
        cx: "50%",
        cy: "50%",
        outerRadius: 86,
        innerRadius: 64,
        strokeWidth: 8,
        labelLine: false,
        label: ({
          cx,
          cy,
          midAngle,
          innerRadius,
          outerRadius,
          value,
          index
        }) => {
          const RADIAN = Math.PI / 180;
          const radius = 12 + innerRadius + (outerRadius - innerRadius);
          const x = cx + radius * Math.cos(-midAngle * RADIAN);
          const y = cy + radius * Math.sin(-midAngle * RADIAN);
          return /* @__PURE__ */ jsxDEV(
            "text",
            {
              x,
              y,
              className: "fill-muted-foreground text-xs",
              textAnchor: x > cx ? "start" : "end",
              dominantBaseline: "central",
              children: [
                popularProducts[index].product.length > 12 ? popularProducts[index].product.substring(0, 12).concat("...") : popularProducts[index].product,
                " ",
                "(",
                value,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
              lineNumber: 61,
              columnNumber: 19
            },
            this
          );
        },
        children: popularProducts.map(
          (_, i) => /* @__PURE__ */ jsxDEV(
            Cell,
            {
              fill: COLORS[i],
              className: "stroke-background hover:opacity-80"
            },
            `cell-${i}`,
            false,
            {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
              lineNumber: 79,
              columnNumber: 15
            },
            this
          )
        )
      },
      void 0,
      false,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
        lineNumber: 36,
        columnNumber: 15
      },
      this
    ) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
      lineNumber: 35,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
      lineNumber: 34,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex h-[240px] w-full items-center justify-center", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-muted-foreground" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
      lineNumber: 90,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx",
    lineNumber: 23,
    columnNumber: 5
  }, this);
}
_s(PopularProductsChart, "1VWf+RDj40U5IZM+Hb2KH8yVG/Y=", false, function() {
  return [useQuery];
});
_c = PopularProductsChart;
var _c;
$RefreshReg$(_c, "PopularProductsChart");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/popular-produts-chart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJVOzJCQXpCVjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxVQUFVQyxlQUFlO0FBQ2xDLFNBQVNDLE1BQU1DLEtBQUtDLFVBQVVDLDJCQUEyQjtBQUN6RCxPQUFPQyxZQUFZO0FBRW5CLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsTUFBTUMsU0FBUztBQUFBLEVBQ2JOLE9BQU9PLElBQUksS0FBSztBQUFBLEVBQ2hCUCxPQUFPUSxNQUFNLEtBQUs7QUFBQSxFQUNsQlIsT0FBT1MsT0FBTyxLQUFLO0FBQUEsRUFDbkJULE9BQU9VLFFBQVEsS0FBSztBQUFBLEVBQ3BCVixPQUFPVyxLQUFLLEtBQUs7QUFBQztBQUdiLGdCQUFTQyx1QkFBdUI7QUFBQUMsS0FBQTtBQUNyQyxRQUFNLEVBQUVDLE1BQU1DLGdCQUFnQixJQUFJQyxTQUFTO0FBQUEsSUFDekNDLFVBQVUsQ0FBQyxXQUFXLGtCQUFrQjtBQUFBLElBQ3hDQyxTQUFTakI7QUFBQUEsRUFDWCxDQUFDO0FBQ0QsU0FDRSx1QkFBQyxRQUFLLFdBQVUsdUNBQ2Q7QUFBQSwyQkFBQyxjQUFXLFdBQVUsUUFDcEIsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsNkJBQUMsYUFBVSxXQUFVLHlCQUF1QixrQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxZQUFTLFdBQVUsbUNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUQ7QUFBQSxTQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLGVBQ0VjLDRCQUNDLHVCQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBUSxLQUN4QyxpQ0FBQyxZQUFTLE9BQU8sRUFBRUksVUFBVSxHQUFHLEdBQzlCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNSjtBQUFBQSxRQUNOLFNBQVE7QUFBQSxRQUNSLFNBQVE7QUFBQSxRQUNSLElBQUc7QUFBQSxRQUNILElBQUc7QUFBQSxRQUNILGFBQWE7QUFBQSxRQUNiLGFBQWE7QUFBQSxRQUNiLGFBQWE7QUFBQSxRQUNiLFdBQVc7QUFBQSxRQUNYLE9BQU8sQ0FBQztBQUFBLFVBQ05LO0FBQUFBLFVBQ0FDO0FBQUFBLFVBQ0FDO0FBQUFBLFVBQ0FDO0FBQUFBLFVBQ0FDO0FBQUFBLFVBQ0FDO0FBQUFBLFVBQ0FDO0FBQUFBLFFBQ0YsTUFBTTtBQUNKLGdCQUFNQyxTQUFTQyxLQUFLQyxLQUFLO0FBQ3pCLGdCQUFNQyxTQUFTLEtBQUtQLGVBQWVDLGNBQWNEO0FBQ2pELGdCQUFNUSxJQUFJWCxLQUFLVSxTQUFTRixLQUFLSSxJQUFJLENBQUNWLFdBQVdLLE1BQU07QUFDbkQsZ0JBQU1NLElBQUlaLEtBQUtTLFNBQVNGLEtBQUtNLElBQUksQ0FBQ1osV0FBV0ssTUFBTTtBQUVuRCxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FDVixZQUFZSSxJQUFJWCxLQUFLLFVBQVU7QUFBQSxjQUMvQixrQkFBaUI7QUFBQSxjQUVoQkw7QUFBQUEsZ0NBQWdCVyxLQUFLLEVBQUVTLFFBQVFDLFNBQVMsS0FDckNyQixnQkFBZ0JXLEtBQUssRUFBRVMsUUFDcEJFLFVBQVUsR0FBRyxFQUFFLEVBQ2ZDLE9BQU8sS0FBSyxJQUNmdkIsZ0JBQWdCVyxLQUFLLEVBQUVTO0FBQUFBLGdCQUFTO0FBQUEsZ0JBQUc7QUFBQSxnQkFDckNWO0FBQUFBLGdCQUFNO0FBQUE7QUFBQTtBQUFBLFlBWlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUE7QUFBQSxRQUVKO0FBQUEsUUFFQ1YsMEJBQWdCd0I7QUFBQUEsVUFBSSxDQUFDQyxHQUFHQyxNQUN2QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBTW5DLE9BQU9tQyxDQUFDO0FBQUEsY0FDZCxXQUFVO0FBQUE7QUFBQSxZQUZKLFFBQU9BLENBQUU7QUFBQSxZQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBR2dEO0FBQUEsUUFFakQ7QUFBQTtBQUFBLE1BaERIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlEQSxLQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbURBLEtBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxREEsSUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ2IsaUNBQUMsV0FBUSxXQUFVLGdEQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkRBO0FBQUEsT0F0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVFQTtBQUVKO0FBQUM1QixHQS9FZUQsc0JBQW9CO0FBQUEsVUFDQUksUUFBUTtBQUFBO0FBQUEwQixLQUQ1QjlCO0FBQW9CLElBQUE4QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQmFyQ2hhcnQiLCJMb2FkZXIyIiwiQ2VsbCIsIlBpZSIsIlBpZUNoYXJ0IiwiUmVzcG9uc2l2ZUNvbnRhaW5lciIsImNvbG9ycyIsImdldFBvcHVsYXJQcm9kdWN0cyIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJDT0xPUlMiLCJza3kiLCJhbWJlciIsInZpb2xldCIsImVtZXJhbGQiLCJyb3NlIiwiUG9wdWxhclByb2R1Y3RzQ2hhcnQiLCJfcyIsImRhdGEiLCJwb3B1bGFyUHJvZHVjdHMiLCJ1c2VRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImZvbnRTaXplIiwiY3giLCJjeSIsIm1pZEFuZ2xlIiwiaW5uZXJSYWRpdXMiLCJvdXRlclJhZGl1cyIsInZhbHVlIiwiaW5kZXgiLCJSQURJQU4iLCJNYXRoIiwiUEkiLCJyYWRpdXMiLCJ4IiwiY29zIiwieSIsInNpbiIsInByb2R1Y3QiLCJsZW5ndGgiLCJzdWJzdHJpbmciLCJjb25jYXQiLCJtYXAiLCJfIiwiaSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsicG9wdWxhci1wcm9kdXRzLWNoYXJ0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IEJhckNoYXJ0LCBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQ2VsbCwgUGllLCBQaWVDaGFydCwgUmVzcG9uc2l2ZUNvbnRhaW5lciB9IGZyb20gJ3JlY2hhcnRzJ1xuaW1wb3J0IGNvbG9ycyBmcm9tICd0YWlsd2luZGNzcy9jb2xvcnMnXG5cbmltcG9ydCB7IGdldFBvcHVsYXJQcm9kdWN0cyB9IGZyb20gJ0AvYXBpL2dldC1wb3B1bGFyLXByb2R1Y3RzJ1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZENvbnRlbnQsIENhcmRIZWFkZXIsIENhcmRUaXRsZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYXJkJ1xuXG5jb25zdCBDT0xPUlMgPSBbXG4gIGNvbG9ycy5za3lbJzUwMCddLFxuICBjb2xvcnMuYW1iZXJbJzUwMCddLFxuICBjb2xvcnMudmlvbGV0Wyc1MDAnXSxcbiAgY29sb3JzLmVtZXJhbGRbJzUwMCddLFxuICBjb2xvcnMucm9zZVsnNTAwJ10sXG5dXG5cbmV4cG9ydCBmdW5jdGlvbiBQb3B1bGFyUHJvZHVjdHNDaGFydCgpIHtcbiAgY29uc3QgeyBkYXRhOiBwb3B1bGFyUHJvZHVjdHMgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydtZXRyaWNzJywgJ3BvcHVsYXItcHJvZHVjdHMnXSxcbiAgICBxdWVyeUZuOiBnZXRQb3B1bGFyUHJvZHVjdHMsXG4gIH0pXG4gIHJldHVybiAoXG4gICAgPENhcmQgY2xhc3NOYW1lPVwiYmctdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGNvbC1zcGFuLTNcIj5cbiAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cInBiLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgUHJvZHV0b3MgUG9wdWxhcmVzXG4gICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgPEJhckNoYXJ0IGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICA8Q2FyZENvbnRlbnQ+XG4gICAgICAgIHtwb3B1bGFyUHJvZHVjdHMgPyAoXG4gICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PXsyNDB9PlxuICAgICAgICAgICAgPFBpZUNoYXJ0IHN0eWxlPXt7IGZvbnRTaXplOiAxMiB9fT5cbiAgICAgICAgICAgICAgPFBpZVxuICAgICAgICAgICAgICAgIGRhdGE9e3BvcHVsYXJQcm9kdWN0c31cbiAgICAgICAgICAgICAgICBkYXRhS2V5PVwiYW1vdW50XCJcbiAgICAgICAgICAgICAgICBuYW1lS2V5PVwicHJvZHVjdFwiXG4gICAgICAgICAgICAgICAgY3g9XCI1MCVcIlxuICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcbiAgICAgICAgICAgICAgICBvdXRlclJhZGl1cz17ODZ9XG4gICAgICAgICAgICAgICAgaW5uZXJSYWRpdXM9ezY0fVxuICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXs4fVxuICAgICAgICAgICAgICAgIGxhYmVsTGluZT17ZmFsc2V9XG4gICAgICAgICAgICAgICAgbGFiZWw9eyh7XG4gICAgICAgICAgICAgICAgICBjeCxcbiAgICAgICAgICAgICAgICAgIGN5LFxuICAgICAgICAgICAgICAgICAgbWlkQW5nbGUsXG4gICAgICAgICAgICAgICAgICBpbm5lclJhZGl1cyxcbiAgICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzLFxuICAgICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICAgICAgICBpbmRleCxcbiAgICAgICAgICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBSQURJQU4gPSBNYXRoLlBJIC8gMTgwXG4gICAgICAgICAgICAgICAgICBjb25zdCByYWRpdXMgPSAxMiArIGlubmVyUmFkaXVzICsgKG91dGVyUmFkaXVzIC0gaW5uZXJSYWRpdXMpXG4gICAgICAgICAgICAgICAgICBjb25zdCB4ID0gY3ggKyByYWRpdXMgKiBNYXRoLmNvcygtbWlkQW5nbGUgKiBSQURJQU4pXG4gICAgICAgICAgICAgICAgICBjb25zdCB5ID0gY3kgKyByYWRpdXMgKiBNYXRoLnNpbigtbWlkQW5nbGUgKiBSQURJQU4pXG5cbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0XG4gICAgICAgICAgICAgICAgICAgICAgeD17eH1cbiAgICAgICAgICAgICAgICAgICAgICB5PXt5fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZpbGwtbXV0ZWQtZm9yZWdyb3VuZCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICB0ZXh0QW5jaG9yPXt4ID4gY3ggPyAnc3RhcnQnIDogJ2VuZCd9XG4gICAgICAgICAgICAgICAgICAgICAgZG9taW5hbnRCYXNlbGluZT1cImNlbnRyYWxcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3BvcHVsYXJQcm9kdWN0c1tpbmRleF0ucHJvZHVjdC5sZW5ndGggPiAxMlxuICAgICAgICAgICAgICAgICAgICAgICAgPyBwb3B1bGFyUHJvZHVjdHNbaW5kZXhdLnByb2R1Y3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3Vic3RyaW5nKDAsIDEyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jb25jYXQoJy4uLicpXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHBvcHVsYXJQcm9kdWN0c1tpbmRleF0ucHJvZHVjdH17JyAnfVxuICAgICAgICAgICAgICAgICAgICAgICh7dmFsdWV9KVxuICAgICAgICAgICAgICAgICAgICA8L3RleHQ+XG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtwb3B1bGFyUHJvZHVjdHMubWFwKChfLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8Q2VsbFxuICAgICAgICAgICAgICAgICAgICBrZXk9e2BjZWxsLSR7aX1gfVxuICAgICAgICAgICAgICAgICAgICBmaWxsPXtDT0xPUlNbaV19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInN0cm9rZS1iYWNrZ3JvdW5kIGhvdmVyOm9wYWNpdHktODBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9QaWU+XG4gICAgICAgICAgICA8L1BpZUNoYXJ0PlxuICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1bMjQwcHhdIHctZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtOCB3LTggYW5pbWF0ZS1zcGluIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0NhcmRDb250ZW50PlxuICAgIDwvQ2FyZD5cbiAgKVxufVxuIl0sImZpbGUiOiIvaG9tZS9ydWFucGFibG8vaWduaXRlL3JlYWN0anMvZGFzaGJvYXJkL3NyYy9wYWdlcy9hcHAvZGFzaGJvYXJkL3BvcHVsYXItcHJvZHV0cy1jaGFydC50c3gifQ==