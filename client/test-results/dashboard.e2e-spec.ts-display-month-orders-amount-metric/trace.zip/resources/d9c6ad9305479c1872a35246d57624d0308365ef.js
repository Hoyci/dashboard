import.meta.env = {"VITE_API_URL": "/", "VITE_ENABLE_API_DELAY": "false", "BASE_URL": "/", "MODE": "test", "DEV": true, "PROD": false, "SSR": false};import { z } from "/node_modules/.vite/deps/zod.js?v=cab43493";
const envSchema = z.object({
  MODE: z.enum(["production", "development", "test"]),
  VITE_API_URL: z.string(),
  VITE_ENABLE_API_DELAY: z.string().transform((value) => value === "true")
});
export const env = envSchema.parse(import.meta.env);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVudi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB6IH0gZnJvbSAnem9kJ1xuXG5jb25zdCBlbnZTY2hlbWEgPSB6Lm9iamVjdCh7XG4gIE1PREU6IHouZW51bShbJ3Byb2R1Y3Rpb24nLCAnZGV2ZWxvcG1lbnQnLCAndGVzdCddKSxcbiAgVklURV9BUElfVVJMOiB6LnN0cmluZygpLFxuICBWSVRFX0VOQUJMRV9BUElfREVMQVk6IHouc3RyaW5nKCkudHJhbnNmb3JtKCh2YWx1ZSkgPT4gdmFsdWUgPT09ICd0cnVlJyksXG59KVxuXG5leHBvcnQgY29uc3QgZW52ID0gZW52U2NoZW1hLnBhcnNlKGltcG9ydC5tZXRhLmVudilcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxTQUFTO0FBRWxCLE1BQU0sWUFBWSxFQUFFLE9BQU87QUFBQSxFQUN6QixNQUFNLEVBQUUsS0FBSyxDQUFDLGNBQWMsZUFBZSxNQUFNLENBQUM7QUFBQSxFQUNsRCxjQUFjLEVBQUUsT0FBTztBQUFBLEVBQ3ZCLHVCQUF1QixFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsVUFBVSxVQUFVLE1BQU07QUFDekUsQ0FBQztBQUVNLGFBQU0sTUFBTSxVQUFVLE1BQU0sWUFBWSxHQUFHOyIsIm5hbWVzIjpbXX0=