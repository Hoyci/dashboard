import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/date-ranger-picker.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
"use client";
import { format } from "/node_modules/.vite/deps/date-fns.js?v=cab43493";
import { Calendar as CalendarIcon } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { Button } from "/src/components/ui/button.tsx";
import { Calendar } from "/src/components/ui/calendar.tsx";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "/src/components/ui/popover.tsx";
import { cn } from "/src/lib/utils.ts";
export function DateRangePicker({
  date,
  onDateChange,
  className
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: cn("grid gap-2", className), children: /* @__PURE__ */ jsxDEV(Popover, { children: [
    /* @__PURE__ */ jsxDEV(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        id: "date",
        variant: "outline",
        className: cn(
          "w-[300px] justify-start text-left font-normal",
          !date && "text-muted-foreground"
        ),
        children: [
          /* @__PURE__ */ jsxDEV(CalendarIcon, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
            lineNumber: 39,
            columnNumber: 13
          }, this),
          date?.from ? date.to ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            format(date.from, "LLL dd, y"),
            " -",
            " ",
            format(date.to, "LLL dd, y")
          ] }, void 0, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
            lineNumber: 42,
            columnNumber: 13
          }, this) : format(date.from, "LLL dd, y") : /* @__PURE__ */ jsxDEV("span", { children: "Pick a date" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
            lineNumber: 50,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
        lineNumber: 31,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
      lineNumber: 30,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(PopoverContent, { className: "w-auto p-0", align: "start", children: /* @__PURE__ */ jsxDEV(
      Calendar,
      {
        initialFocus: true,
        mode: "range",
        defaultMonth: date?.from,
        selected: date,
        onSelect: onDateChange,
        numberOfMonths: 2
      },
      void 0,
      false,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
        lineNumber: 55,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
      lineNumber: 54,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
    lineNumber: 29,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
}
_c = DateRangePicker;
var _c;
$RefreshReg$(_c, "DateRangePicker");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/components/ui/date-ranger-picker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NZLFNBR0ksVUFISjtBQXRDWiwyQkFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVaLFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsWUFBWUMsb0JBQW9CO0FBSXpDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0YsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDRUc7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFVBQVU7QUFPWixnQkFBU0MsZ0JBQWdCO0FBQUEsRUFDOUJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ29CLEdBQUc7QUFDdkIsU0FDRSx1QkFBQyxTQUFJLFdBQVdKLEdBQUcsY0FBY0ksU0FBUyxHQUN4QyxpQ0FBQyxXQUNDO0FBQUEsMkJBQUMsa0JBQWUsU0FBTyxNQUNyQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBRztBQUFBLFFBQ0gsU0FBUztBQUFBLFFBQ1QsV0FBV0o7QUFBQUEsVUFDVDtBQUFBLFVBQ0EsQ0FBQ0UsUUFBUTtBQUFBLFFBQ1g7QUFBQSxRQUVBO0FBQUEsaUNBQUMsZ0JBQWEsV0FBVSxrQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUNyQ0EsTUFBTUcsT0FDTEgsS0FBS0ksS0FDSCxtQ0FDR2I7QUFBQUEsbUJBQU9TLEtBQUtHLE1BQU0sV0FBVztBQUFBLFlBQUU7QUFBQSxZQUFHO0FBQUEsWUFDbENaLE9BQU9TLEtBQUtJLElBQUksV0FBVztBQUFBLGVBRjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0EsSUFFQWIsT0FBT1MsS0FBS0csTUFBTSxXQUFXLElBRy9CLHVCQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQTtBQUFBO0FBQUEsTUFuQnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFDQSx1QkFBQyxrQkFBZSxXQUFVLGNBQWEsT0FBTSxTQUMzQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLE1BQUs7QUFBQSxRQUNMLGNBQWNILE1BQU1HO0FBQUFBLFFBQ3BCLFVBQVVIO0FBQUFBLFFBQ1YsVUFBVUM7QUFBQUEsUUFDVixnQkFBZ0I7QUFBQTtBQUFBLE1BTmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1vQixLQVB0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxPQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQ0E7QUFFSjtBQUFDSSxLQTdDZU47QUFBZSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiZm9ybWF0IiwiQ2FsZW5kYXIiLCJDYWxlbmRhckljb24iLCJCdXR0b24iLCJQb3BvdmVyIiwiUG9wb3ZlckNvbnRlbnQiLCJQb3BvdmVyVHJpZ2dlciIsImNuIiwiRGF0ZVJhbmdlUGlja2VyIiwiZGF0ZSIsIm9uRGF0ZUNoYW5nZSIsImNsYXNzTmFtZSIsImZyb20iLCJ0byIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiZGF0ZS1yYW5nZXItcGlja2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGNsaWVudCdcblxuaW1wb3J0IHsgZm9ybWF0IH0gZnJvbSAnZGF0ZS1mbnMnXG5pbXBvcnQgeyBDYWxlbmRhciBhcyBDYWxlbmRhckljb24gfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IERhdGVSYW5nZSB9IGZyb20gJ3JlYWN0LWRheS1waWNrZXInXG5cbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBDYWxlbmRhciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYWxlbmRhcidcbmltcG9ydCB7XG4gIFBvcG92ZXIsXG4gIFBvcG92ZXJDb250ZW50LFxuICBQb3BvdmVyVHJpZ2dlcixcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3BvcG92ZXInXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xuXG5pbnRlcmZhY2UgRGF0ZVJhbmdlUGlja2VyUHJvcHMgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnRQcm9wczwnZGl2Jz4ge1xuICBkYXRlOiBEYXRlUmFuZ2UgfCB1bmRlZmluZWRcbiAgb25EYXRlQ2hhbmdlOiAoZGF0ZTogRGF0ZVJhbmdlIHwgdW5kZWZpbmVkKSA9PiB2b2lkXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBEYXRlUmFuZ2VQaWNrZXIoe1xuICBkYXRlLFxuICBvbkRhdGVDaGFuZ2UsXG4gIGNsYXNzTmFtZSxcbn06IERhdGVSYW5nZVBpY2tlclByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2NuKCdncmlkIGdhcC0yJywgY2xhc3NOYW1lKX0+XG4gICAgICA8UG9wb3Zlcj5cbiAgICAgICAgPFBvcG92ZXJUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgaWQ9XCJkYXRlXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9eydvdXRsaW5lJ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICd3LVszMDBweF0ganVzdGlmeS1zdGFydCB0ZXh0LWxlZnQgZm9udC1ub3JtYWwnLFxuICAgICAgICAgICAgICAhZGF0ZSAmJiAndGV4dC1tdXRlZC1mb3JlZ3JvdW5kJyxcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENhbGVuZGFySWNvbiBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxuICAgICAgICAgICAge2RhdGU/LmZyb20gPyAoXG4gICAgICAgICAgICAgIGRhdGUudG8gPyAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIHtmb3JtYXQoZGF0ZS5mcm9tLCAnTExMIGRkLCB5Jyl9IC17JyAnfVxuICAgICAgICAgICAgICAgICAge2Zvcm1hdChkYXRlLnRvLCAnTExMIGRkLCB5Jyl9XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgZm9ybWF0KGRhdGUuZnJvbSwgJ0xMTCBkZCwgeScpXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxzcGFuPlBpY2sgYSBkYXRlPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9Qb3BvdmVyVHJpZ2dlcj5cbiAgICAgICAgPFBvcG92ZXJDb250ZW50IGNsYXNzTmFtZT1cInctYXV0byBwLTBcIiBhbGlnbj1cInN0YXJ0XCI+XG4gICAgICAgICAgPENhbGVuZGFyXG4gICAgICAgICAgICBpbml0aWFsRm9jdXNcbiAgICAgICAgICAgIG1vZGU9XCJyYW5nZVwiXG4gICAgICAgICAgICBkZWZhdWx0TW9udGg9e2RhdGU/LmZyb219XG4gICAgICAgICAgICBzZWxlY3RlZD17ZGF0ZX1cbiAgICAgICAgICAgIG9uU2VsZWN0PXtvbkRhdGVDaGFuZ2V9XG4gICAgICAgICAgICBudW1iZXJPZk1vbnRocz17Mn1cbiAgICAgICAgICAvPlxuICAgICAgICA8L1BvcG92ZXJDb250ZW50PlxuICAgICAgPC9Qb3BvdmVyPlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL2NvbXBvbmVudHMvdWkvZGF0ZS1yYW5nZXItcGlja2VyLnRzeCJ9