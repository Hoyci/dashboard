import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=cab43493";
export const getOrderDetailsMock = http.get("/orders/:orderId", ({ params }) => {
  return HttpResponse.json({
    id: params.orderId,
    customer: {
      name: "John Doe",
      email: "johndoe@example.com",
      phone: "5521999999999"
    },
    status: "pending",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    orderItems: [
      {
        id: "order-item-1",
        priceInCents: 2400,
        product: { name: "Pizza de Mussarela" },
        quantity: 1
      },
      {
        id: "order-item-2",
        priceInCents: 1e3,
        product: { name: "Pizza de Frango" },
        quantity: 1
      }
    ],
    totalInCents: 2500
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1vcmRlci1kZXRhaWxzLW1vY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaHR0cCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnbXN3J1xuXG5pbXBvcnQge1xuICBHZXRPcmRlckRldGFpbHNQYXJhbXMsXG4gIEdldE9yZGVyRGV0YWlsc1Jlc3BvbnNlLFxufSBmcm9tICcuLi9nZXQtb3JkZXItZGV0YWlscydcblxuZXhwb3J0IGNvbnN0IGdldE9yZGVyRGV0YWlsc01vY2sgPSBodHRwLmdldDxcbiAgR2V0T3JkZXJEZXRhaWxzUGFyYW1zLFxuICBuZXZlcixcbiAgR2V0T3JkZXJEZXRhaWxzUmVzcG9uc2Vcbj4oJy9vcmRlcnMvOm9yZGVySWQnLCAoeyBwYXJhbXMgfSkgPT4ge1xuICByZXR1cm4gSHR0cFJlc3BvbnNlLmpzb24oe1xuICAgIGlkOiBwYXJhbXMub3JkZXJJZCxcbiAgICBjdXN0b21lcjoge1xuICAgICAgbmFtZTogJ0pvaG4gRG9lJyxcbiAgICAgIGVtYWlsOiAnam9obmRvZUBleGFtcGxlLmNvbScsXG4gICAgICBwaG9uZTogJzU1MjE5OTk5OTk5OTknLFxuICAgIH0sXG4gICAgc3RhdHVzOiAncGVuZGluZycsXG4gICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgb3JkZXJJdGVtczogW1xuICAgICAge1xuICAgICAgICBpZDogJ29yZGVyLWl0ZW0tMScsXG4gICAgICAgIHByaWNlSW5DZW50czogMjQwMCxcbiAgICAgICAgcHJvZHVjdDogeyBuYW1lOiAnUGl6emEgZGUgTXVzc2FyZWxhJyB9LFxuICAgICAgICBxdWFudGl0eTogMSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiAnb3JkZXItaXRlbS0yJyxcbiAgICAgICAgcHJpY2VJbkNlbnRzOiAxMDAwLFxuICAgICAgICBwcm9kdWN0OiB7IG5hbWU6ICdQaXp6YSBkZSBGcmFuZ28nIH0sXG4gICAgICAgIHF1YW50aXR5OiAxLFxuICAgICAgfSxcbiAgICBdLFxuICAgIHRvdGFsSW5DZW50czogMjUwMCxcbiAgfSlcbn0pXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsTUFBTSxvQkFBb0I7QUFPNUIsYUFBTSxzQkFBc0IsS0FBSyxJQUl0QyxvQkFBb0IsQ0FBQyxFQUFFLE9BQU8sTUFBTTtBQUNwQyxTQUFPLGFBQWEsS0FBSztBQUFBLElBQ3ZCLElBQUksT0FBTztBQUFBLElBQ1gsVUFBVTtBQUFBLE1BQ1IsTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLFFBQVE7QUFBQSxJQUNSLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxZQUFZO0FBQUEsTUFDVjtBQUFBLFFBQ0UsSUFBSTtBQUFBLFFBQ0osY0FBYztBQUFBLFFBQ2QsU0FBUyxFQUFFLE1BQU0scUJBQXFCO0FBQUEsUUFDdEMsVUFBVTtBQUFBLE1BQ1o7QUFBQSxNQUNBO0FBQUEsUUFDRSxJQUFJO0FBQUEsUUFDSixjQUFjO0FBQUEsUUFDZCxTQUFTLEVBQUUsTUFBTSxrQkFBa0I7QUFBQSxRQUNuQyxVQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFBQSxJQUNBLGNBQWM7QUFBQSxFQUNoQixDQUFDO0FBQ0gsQ0FBQzsiLCJuYW1lcyI6W119