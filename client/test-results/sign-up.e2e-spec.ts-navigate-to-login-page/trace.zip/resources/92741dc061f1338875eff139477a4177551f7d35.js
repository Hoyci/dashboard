import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-details.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { formatDistanceToNow } from "/node_modules/.vite/deps/date-fns.js?v=cab43493";
import { ptBR } from "/node_modules/.vite/deps/date-fns_locale.js?v=cab43493";
import { getOrderDetails } from "/src/api/get-order-details.ts";
import { OrderStatus } from "/src/components/order-status.tsx";
import {
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow
} from "/src/components/ui/table.tsx";
import { OrderDetailsSkeleton } from "/src/pages/app/orders/order-details-skeleton.tsx";
export function OrderDetails({ orderId, open }) {
  _s();
  const { data: order } = useQuery({
    queryKey: ["order", orderId],
    queryFn: () => getOrderDetails({ orderId }),
    enabled: open
  });
  return /* @__PURE__ */ jsxDEV(DialogContent, { className: "h-[80vh] ", children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: [
        "Pedido: ",
        orderId
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Detalhes do pedido" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    order ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 overflow-y-scroll", children: [
      /* @__PURE__ */ jsxDEV(Table, { children: /* @__PURE__ */ jsxDEV(TableBody, { children: [
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Status" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 49,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(OrderStatus, { status: order.status }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 51,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 50,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 48,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Cliente" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 55,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: order.customer.name }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 56,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 54,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Telefone" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 61,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: order.customer.phone ?? "Não informado" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 64,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 60,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "E-mail" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 69,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: order.customer.email }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 70,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 68,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: "Realizado há" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 75,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "flex justify-end", children: formatDistanceToNow(order.createdAt, {
            locale: ptBR,
            addSuffix: true
          }) }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 78,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 74,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
        lineNumber: 47,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
        lineNumber: 46,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Table, { children: [
        /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableHead, { children: "Produto" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 91,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Quantidade" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 92,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Preço" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 93,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableHead, { className: "text-right", children: "Subtotal" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 94,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 90,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 89,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableBody, { children: order.orderItems.map(
          (item) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableCell, { children: item.product.name }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
              lineNumber: 100,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: item.quantity }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
              lineNumber: 101,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: (item.priceInCents / 100).toLocaleString("pt-BR", {
              style: "currency",
              currency: "BRL"
            }) }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
              lineNumber: 102,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: (item.priceInCents * item.quantity / 100).toLocaleString(
              "pt-BR",
              {
                style: "currency",
                currency: "BRL"
              }
            ) }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
              lineNumber: 108,
              columnNumber: 19
            }, this)
          ] }, item.id, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 99,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 97,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TableFooter, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
          /* @__PURE__ */ jsxDEV(TableCell, { colSpan: 3, children: "Total do pedido" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 122,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right font-medium", children: (order.totalInCents / 100).toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
          }) }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
            lineNumber: 123,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 121,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
          lineNumber: 120,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
        lineNumber: 88,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV(OrderDetailsSkeleton, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
      lineNumber: 134,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
}
_s(OrderDetails, "LYyi1ST3wC5wfyvY9hAfo240uP0=", false, function() {
  return [useQuery];
});
_c = OrderDetails;
var _c;
$RefreshReg$(_c, "OrderDetails");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-details.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNROzJCQXZDUjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSwyQkFBMkI7QUFDcEMsU0FBU0MsWUFBWTtBQUVyQixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLDRCQUE0QjtBQU85QixnQkFBU0MsYUFBYSxFQUFFQyxTQUFTQyxLQUF3QixHQUFHO0FBQUFDLEtBQUE7QUFDakUsUUFBTSxFQUFFQyxNQUFNQyxNQUFNLElBQUlDLFNBQVM7QUFBQSxJQUMvQkMsVUFBVSxDQUFDLFNBQVNOLE9BQU87QUFBQSxJQUMzQk8sU0FBU0EsTUFBTXRCLGdCQUFnQixFQUFFZSxRQUFRLENBQUM7QUFBQSxJQUMxQ1EsU0FBU1A7QUFBQUEsRUFDWCxDQUFDO0FBRUQsU0FDRSx1QkFBQyxpQkFBYyxXQUFVLGFBQ3ZCO0FBQUEsMkJBQUMsZ0JBQ0M7QUFBQSw2QkFBQyxlQUFZO0FBQUE7QUFBQSxRQUFTRDtBQUFBQSxXQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFDOUIsdUJBQUMscUJBQWtCLGtDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FGdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFFQ0ksUUFDQyx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxTQUNDLGlDQUFDLGFBQ0M7QUFBQSwrQkFBQyxZQUNDO0FBQUEsaUNBQUMsYUFBVSxXQUFVLHlCQUF3QixzQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxhQUFVLFdBQVUsb0JBQ25CLGlDQUFDLGVBQVksUUFBUUEsTUFBTUssVUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxZQUNDO0FBQUEsaUNBQUMsYUFBVSxXQUFVLHlCQUF3Qix1QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxhQUFVLFdBQVUsb0JBQ2xCTCxnQkFBTU0sU0FBU0MsUUFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxZQUNDO0FBQUEsaUNBQUMsYUFBVSxXQUFVLHlCQUF1Qix3QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLG9CQUNsQlAsZ0JBQU1NLFNBQVNFLFNBQVMsbUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsWUFDQztBQUFBLGlDQUFDLGFBQVUsV0FBVSx5QkFBd0Isc0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsYUFBVSxXQUFVLG9CQUNsQlIsZ0JBQU1NLFNBQVNHLFNBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsWUFDQztBQUFBLGlDQUFDLGFBQVUsV0FBVSx5QkFBdUIsNEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxvQkFDbEI5Qiw4QkFBb0JxQixNQUFNVSxXQUFXO0FBQUEsWUFDcENDLFFBQVEvQjtBQUFBQSxZQUNSZ0MsV0FBVztBQUFBLFVBQ2IsQ0FBQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0EsS0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdDQTtBQUFBLE1BRUEsdUJBQUMsU0FDQztBQUFBLCtCQUFDLGVBQ0MsaUNBQUMsWUFDQztBQUFBLGlDQUFDLGFBQVUsdUJBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0I7QUFBQSxVQUNsQix1QkFBQyxhQUFVLFdBQVUsY0FBYSwwQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxVQUM1Qyx1QkFBQyxhQUFVLFdBQVUsY0FBYSxxQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxVQUN2Qyx1QkFBQyxhQUFVLFdBQVUsY0FBYSx3QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxhQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLGFBQ0VaLGdCQUFNYSxXQUFXQztBQUFBQSxVQUFJLENBQUNDLFNBQ3JCLHVCQUFDLFlBQ0M7QUFBQSxtQ0FBQyxhQUFXQSxlQUFLQyxRQUFRVCxRQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQzlCLHVCQUFDLGFBQVUsV0FBVSxjQUFjUSxlQUFLRSxZQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFlBQ2pELHVCQUFDLGFBQVUsV0FBVSxjQUNqQkYsZ0JBQUtHLGVBQWUsS0FBS0MsZUFBZSxTQUFTO0FBQUEsY0FDakRDLE9BQU87QUFBQSxjQUNQQyxVQUFVO0FBQUEsWUFDWixDQUFDLEtBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsYUFBVSxXQUFVLGNBQ2hCTixnQkFBS0csZUFBZUgsS0FBS0UsV0FBWSxLQUFLRTtBQUFBQSxjQUMzQztBQUFBLGNBQ0E7QUFBQSxnQkFDRUMsT0FBTztBQUFBLGdCQUNQQyxVQUFVO0FBQUEsY0FDWjtBQUFBLFlBQ0YsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFqQmFOLEtBQUtPLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsUUFDRCxLQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFDQSx1QkFBQyxlQUNDLGlDQUFDLFlBQ0M7QUFBQSxpQ0FBQyxhQUFVLFNBQVMsR0FBRywrQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUN0Qyx1QkFBQyxhQUFVLFdBQVUsMEJBQ2pCdEIsaUJBQU11QixlQUFlLEtBQUtKLGVBQWUsU0FBUztBQUFBLFlBQ2xEQyxPQUFPO0FBQUEsWUFDUEMsVUFBVTtBQUFBLFVBQ1osQ0FBQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0E7QUFBQSxTQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUZBLElBRUEsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLE9BaEd6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0dBO0FBRUo7QUFBQ3ZCLEdBNUdlSCxjQUFZO0FBQUEsVUFDRk0sUUFBUTtBQUFBO0FBQUF1QixLQURsQjdCO0FBQVksSUFBQTZCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJmb3JtYXREaXN0YW5jZVRvTm93IiwicHRCUiIsImdldE9yZGVyRGV0YWlscyIsIk9yZGVyU3RhdHVzIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJUYWJsZSIsIlRhYmxlQm9keSIsIlRhYmxlQ2VsbCIsIlRhYmxlRm9vdGVyIiwiVGFibGVIZWFkIiwiVGFibGVIZWFkZXIiLCJUYWJsZVJvdyIsIk9yZGVyRGV0YWlsc1NrZWxldG9uIiwiT3JkZXJEZXRhaWxzIiwib3JkZXJJZCIsIm9wZW4iLCJfcyIsImRhdGEiLCJvcmRlciIsInVzZVF1ZXJ5IiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiZW5hYmxlZCIsInN0YXR1cyIsImN1c3RvbWVyIiwibmFtZSIsInBob25lIiwiZW1haWwiLCJjcmVhdGVkQXQiLCJsb2NhbGUiLCJhZGRTdWZmaXgiLCJvcmRlckl0ZW1zIiwibWFwIiwiaXRlbSIsInByb2R1Y3QiLCJxdWFudGl0eSIsInByaWNlSW5DZW50cyIsInRvTG9jYWxlU3RyaW5nIiwic3R5bGUiLCJjdXJyZW5jeSIsImlkIiwidG90YWxJbkNlbnRzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJvcmRlci1kZXRhaWxzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IGZvcm1hdERpc3RhbmNlVG9Ob3cgfSBmcm9tICdkYXRlLWZucydcbmltcG9ydCB7IHB0QlIgfSBmcm9tICdkYXRlLWZucy9sb2NhbGUnXG5cbmltcG9ydCB7IGdldE9yZGVyRGV0YWlscyB9IGZyb20gJ0AvYXBpL2dldC1vcmRlci1kZXRhaWxzJ1xuaW1wb3J0IHsgT3JkZXJTdGF0dXMgfSBmcm9tICdAL2NvbXBvbmVudHMvb3JkZXItc3RhdHVzJ1xuaW1wb3J0IHtcbiAgRGlhbG9nQ29udGVudCxcbiAgRGlhbG9nRGVzY3JpcHRpb24sXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9kaWFsb2cnXG5pbXBvcnQge1xuICBUYWJsZSxcbiAgVGFibGVCb2R5LFxuICBUYWJsZUNlbGwsXG4gIFRhYmxlRm9vdGVyLFxuICBUYWJsZUhlYWQsXG4gIFRhYmxlSGVhZGVyLFxuICBUYWJsZVJvdyxcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3RhYmxlJ1xuXG5pbXBvcnQgeyBPcmRlckRldGFpbHNTa2VsZXRvbiB9IGZyb20gJy4vb3JkZXItZGV0YWlscy1za2VsZXRvbidcblxuZXhwb3J0IGludGVyZmFjZSBPcmRlckRldGFpbHNQcm9wcyB7XG4gIG9yZGVySWQ6IHN0cmluZ1xuICBvcGVuOiBib29sZWFuXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBPcmRlckRldGFpbHMoeyBvcmRlcklkLCBvcGVuIH06IE9yZGVyRGV0YWlsc1Byb3BzKSB7XG4gIGNvbnN0IHsgZGF0YTogb3JkZXIgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydvcmRlcicsIG9yZGVySWRdLFxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldE9yZGVyRGV0YWlscyh7IG9yZGVySWQgfSksXG4gICAgZW5hYmxlZDogb3BlbixcbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cImgtWzgwdmhdIFwiPlxuICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgPERpYWxvZ1RpdGxlPlBlZGlkbzoge29yZGVySWR9PC9EaWFsb2dUaXRsZT5cbiAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPkRldGFsaGVzIGRvIHBlZGlkbzwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICA8L0RpYWxvZ0hlYWRlcj5cblxuICAgICAge29yZGVyID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBvdmVyZmxvdy15LXNjcm9sbFwiPlxuICAgICAgICAgIDxUYWJsZT5cbiAgICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlN0YXR1czwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAgPE9yZGVyU3RhdHVzIHN0YXR1cz17b3JkZXIuc3RhdHVzfSAvPlxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5DbGllbnRlPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgICB7b3JkZXIuY3VzdG9tZXIubmFtZX1cbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICBUZWxlZm9uZVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAge29yZGVyLmN1c3RvbWVyLnBob25lID8/ICdOw6NvIGluZm9ybWFkbyd9XG4gICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkUtbWFpbDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICAgICAge29yZGVyLmN1c3RvbWVyLmVtYWlsfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgIFJlYWxpemFkbyBow6FcbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICAgIHtmb3JtYXREaXN0YW5jZVRvTm93KG9yZGVyLmNyZWF0ZWRBdCwge1xuICAgICAgICAgICAgICAgICAgICBsb2NhbGU6IHB0QlIsXG4gICAgICAgICAgICAgICAgICAgIGFkZFN1ZmZpeDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgICAgPC9UYWJsZT5cblxuICAgICAgICAgIDxUYWJsZT5cbiAgICAgICAgICAgIDxUYWJsZUhlYWRlcj5cbiAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQ+UHJvZHV0bzwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICAgIDxUYWJsZUhlYWQgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlF1YW50aWRhZGU8L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5QcmXDp288L1RhYmxlSGVhZD5cbiAgICAgICAgICAgICAgICA8VGFibGVIZWFkIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5TdWJ0b3RhbDwvVGFibGVIZWFkPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgPC9UYWJsZUhlYWRlcj5cbiAgICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICAgIHtvcmRlci5vcmRlckl0ZW1zLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgIDxUYWJsZVJvdyBrZXk9e2l0ZW0uaWR9PlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD57aXRlbS5wcm9kdWN0Lm5hbWV9PC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj57aXRlbS5xdWFudGl0eX08L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICB7KGl0ZW0ucHJpY2VJbkNlbnRzIC8gMTAwKS50b0xvY2FsZVN0cmluZygncHQtQlInLCB7XG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdjdXJyZW5jeScsXG4gICAgICAgICAgICAgICAgICAgICAgY3VycmVuY3k6ICdCUkwnLFxuICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgIHsoKGl0ZW0ucHJpY2VJbkNlbnRzICogaXRlbS5xdWFudGl0eSkgLyAxMDApLnRvTG9jYWxlU3RyaW5nKFxuICAgICAgICAgICAgICAgICAgICAgICdwdC1CUicsXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdjdXJyZW5jeScsXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW5jeTogJ0JSTCcsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgICAgICA8VGFibGVGb290ZXI+XG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNvbFNwYW49ezN9PlRvdGFsIGRvIHBlZGlkbzwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1yaWdodCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgeyhvcmRlci50b3RhbEluQ2VudHMgLyAxMDApLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdjdXJyZW5jeScsXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbmN5OiAnQlJMJyxcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgPC9UYWJsZUZvb3Rlcj5cbiAgICAgICAgICA8L1RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxPcmRlckRldGFpbHNTa2VsZXRvbiAvPlxuICAgICAgKX1cbiAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gIClcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVhbnBhYmxvL2lnbml0ZS9yZWFjdGpzL2Rhc2hib2FyZC9zcmMvcGFnZXMvYXBwL29yZGVycy9vcmRlci1kZXRhaWxzLnRzeCJ9