import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/revenue-chart.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { subDays } from "/node_modules/.vite/deps/date-fns.js?v=cab43493";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=cab43493"; const useMemo = __vite__cjsImport6_react["useMemo"]; const useState = __vite__cjsImport6_react["useState"];
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  XAxis,
  YAxis
} from "/node_modules/.vite/deps/recharts.js?v=cab43493";
import __vite__cjsImport8_tailwindcss_colors from "/node_modules/.vite/deps/tailwindcss_colors.js?v=cab43493"; const colors = __vite__cjsImport8_tailwindcss_colors.__esModule ? __vite__cjsImport8_tailwindcss_colors.default : __vite__cjsImport8_tailwindcss_colors;
import { getDailyRevenueInPeriod } from "/src/api/get-daily-revenue-in-period.ts";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "/src/components/ui/card.tsx";
import { DateRangePicker } from "/src/components/ui/date-ranger-picker.tsx";
import { Label } from "/src/components/ui/label.tsx";
export function RevenueChart() {
  _s();
  const [dateRange, setDateRange] = useState({
    from: subDays(/* @__PURE__ */ new Date(), 7),
    to: /* @__PURE__ */ new Date()
  });
  const { data: dailyRevenueInPeriod } = useQuery({
    queryKey: ["metrics", "daily-revenue-in-period", dateRange],
    queryFn: () => getDailyRevenueInPeriod({ from: dateRange?.from, to: dateRange?.to })
  });
  const chartData = useMemo(() => {
    return dailyRevenueInPeriod?.map((chartItem) => {
      return {
        date: chartItem.date,
        receipt: chartItem.receipt / 100
      };
    });
  }, [dailyRevenueInPeriod]);
  return /* @__PURE__ */ jsxDEV(Card, { className: "bg-text-muted-foreground col-span-6", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between pb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-medium", children: "Receita no período" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(CardDescription, { children: "Receita diária no período" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 55,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(Label, { children: "Período" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 59,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(DateRangePicker, { date: dateRange, onDateChange: setDateRange }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 60,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: dailyRevenueInPeriod ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 240, children: /* @__PURE__ */ jsxDEV(LineChart, { data: chartData, style: { fontSize: 12 }, children: [
      /* @__PURE__ */ jsxDEV(
        XAxis,
        {
          dataKey: "date",
          axisLine: false,
          tickLine: false,
          dy: 16
        },
        void 0,
        false,
        {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 67,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        YAxis,
        {
          stroke: "#888",
          axisLine: false,
          tickLine: false,
          width: 80,
          tickFormatter: (value) => value.toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
          })
        },
        void 0,
        false,
        {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 73,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        Line,
        {
          type: "linear",
          strokeWidth: 2,
          dataKey: "receipt",
          stroke: colors.violet["400"]
        },
        void 0,
        false,
        {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
          lineNumber: 85,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(CartesianGrid, { vertical: false, className: "stroke-muted" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
        lineNumber: 92,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 66,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 65,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex h-[240px] w-full items-center justify-center", children: /* @__PURE__ */ jsxDEV(Loader2, { className: "h-8 w-8 animate-spin text-muted-foreground" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 97,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 96,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
}
_s(RevenueChart, "qH02GdDJkGCDHE3sPduyMNerEJw=", false, function() {
  return [useQuery];
});
_c = RevenueChart;
var _c;
$RefreshReg$(_c, "RevenueChart");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/revenue-chart.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbURVOzJCQW5EVjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsU0FBU0MsZ0JBQWdCO0FBRWxDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFlBQVk7QUFFbkIsU0FBU0MsK0JBQStCO0FBQ3hDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxhQUFhO0FBRWYsZ0JBQVNDLGVBQWU7QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSW5CLFNBQWdDO0FBQUEsSUFDaEVvQixNQUFNdkIsUUFBUSxvQkFBSXdCLEtBQUssR0FBRyxDQUFDO0FBQUEsSUFDM0JDLElBQUksb0JBQUlELEtBQUs7QUFBQSxFQUNmLENBQUM7QUFFRCxRQUFNLEVBQUVFLE1BQU1DLHFCQUFxQixJQUFJQyxTQUFTO0FBQUEsSUFDOUNDLFVBQVUsQ0FBQyxXQUFXLDJCQUEyQlIsU0FBUztBQUFBLElBQzFEUyxTQUFTQSxNQUNQbkIsd0JBQXdCLEVBQUVZLE1BQU1GLFdBQVdFLE1BQU1FLElBQUlKLFdBQVdJLEdBQUcsQ0FBQztBQUFBLEVBQ3hFLENBQUM7QUFFRCxRQUFNTSxZQUFZN0IsUUFBUSxNQUFNO0FBQzlCLFdBQU95QixzQkFBc0JLLElBQUksQ0FBQ0MsY0FBYztBQUM5QyxhQUFPO0FBQUEsUUFDTEMsTUFBTUQsVUFBVUM7QUFBQUEsUUFDaEJDLFNBQVNGLFVBQVVFLFVBQVU7QUFBQSxNQUMvQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDUixvQkFBb0IsQ0FBQztBQUV6QixTQUNFLHVCQUFDLFFBQUssV0FBVSx1Q0FDZDtBQUFBLDJCQUFDLGNBQVcsV0FBVSw4Q0FDcEI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLGFBQVUsV0FBVSx5QkFBdUIsa0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsbUJBQWdCLHlDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0FKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUFNLHVCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsbUJBQWdCLE1BQU1OLFdBQVcsY0FBY0MsZ0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxXQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0EsdUJBQUMsZUFDRUssaUNBQ0MsdUJBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLGFBQVUsTUFBTUksV0FBVyxPQUFPLEVBQUVLLFVBQVUsR0FBRyxHQUNoRDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTO0FBQUEsVUFDVCxVQUFVO0FBQUEsVUFDVixVQUFVO0FBQUEsVUFDVixJQUFJO0FBQUE7QUFBQSxRQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlTO0FBQUEsTUFFVDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsUUFBTztBQUFBLFVBQ1AsVUFBVTtBQUFBLFVBQ1YsVUFBVTtBQUFBLFVBQ1YsT0FBTztBQUFBLFVBQ1AsZUFBZSxDQUFDQyxVQUNkQSxNQUFNQyxlQUFlLFNBQVM7QUFBQSxZQUM1QkMsT0FBTztBQUFBLFlBQ1BDLFVBQVU7QUFBQSxVQUNaLENBQUM7QUFBQTtBQUFBLFFBVEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUc7QUFBQSxNQUVIO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxhQUFhO0FBQUEsVUFDYixTQUFRO0FBQUEsVUFDUixRQUFROUIsT0FBTytCLE9BQU8sS0FBSztBQUFBO0FBQUEsUUFKN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSStCO0FBQUEsTUFHL0IsdUJBQUMsaUJBQWMsVUFBVSxPQUFPLFdBQVUsa0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxTQTFCMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHFEQUNiLGlDQUFDLFdBQVEsV0FBVSxnREFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRCxLQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDQTtBQUFBLE9BbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvREE7QUFFSjtBQUFDckIsR0E1RWVELGNBQVk7QUFBQSxVQU1hUyxRQUFRO0FBQUE7QUFBQWMsS0FOakN2QjtBQUFZLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3ViRGF5cyIsIkxvYWRlcjIiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJDYXJ0ZXNpYW5HcmlkIiwiTGluZSIsIkxpbmVDaGFydCIsIlJlc3BvbnNpdmVDb250YWluZXIiLCJYQXhpcyIsIllBeGlzIiwiY29sb3JzIiwiZ2V0RGFpbHlSZXZlbnVlSW5QZXJpb2QiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkRGVzY3JpcHRpb24iLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiRGF0ZVJhbmdlUGlja2VyIiwiTGFiZWwiLCJSZXZlbnVlQ2hhcnQiLCJfcyIsImRhdGVSYW5nZSIsInNldERhdGVSYW5nZSIsImZyb20iLCJEYXRlIiwidG8iLCJkYXRhIiwiZGFpbHlSZXZlbnVlSW5QZXJpb2QiLCJ1c2VRdWVyeSIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsImNoYXJ0RGF0YSIsIm1hcCIsImNoYXJ0SXRlbSIsImRhdGUiLCJyZWNlaXB0IiwiZm9udFNpemUiLCJ2YWx1ZSIsInRvTG9jYWxlU3RyaW5nIiwic3R5bGUiLCJjdXJyZW5jeSIsInZpb2xldCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsicmV2ZW51ZS1jaGFydC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBzdWJEYXlzIH0gZnJvbSAnZGF0ZS1mbnMnXG5pbXBvcnQgeyBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IERhdGVSYW5nZSB9IGZyb20gJ3JlYWN0LWRheS1waWNrZXInXG5pbXBvcnQge1xuICBDYXJ0ZXNpYW5HcmlkLFxuICBMaW5lLFxuICBMaW5lQ2hhcnQsXG4gIFJlc3BvbnNpdmVDb250YWluZXIsXG4gIFhBeGlzLFxuICBZQXhpcyxcbn0gZnJvbSAncmVjaGFydHMnXG5pbXBvcnQgY29sb3JzIGZyb20gJ3RhaWx3aW5kY3NzL2NvbG9ycydcblxuaW1wb3J0IHsgZ2V0RGFpbHlSZXZlbnVlSW5QZXJpb2QgfSBmcm9tICdAL2FwaS9nZXQtZGFpbHktcmV2ZW51ZS1pbi1wZXJpb2QnXG5pbXBvcnQge1xuICBDYXJkLFxuICBDYXJkQ29udGVudCxcbiAgQ2FyZERlc2NyaXB0aW9uLFxuICBDYXJkSGVhZGVyLFxuICBDYXJkVGl0bGUsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYXJkJ1xuaW1wb3J0IHsgRGF0ZVJhbmdlUGlja2VyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2RhdGUtcmFuZ2VyLXBpY2tlcidcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2xhYmVsJ1xuXG5leHBvcnQgZnVuY3Rpb24gUmV2ZW51ZUNoYXJ0KCkge1xuICBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGU8RGF0ZVJhbmdlIHwgdW5kZWZpbmVkPih7XG4gICAgZnJvbTogc3ViRGF5cyhuZXcgRGF0ZSgpLCA3KSxcbiAgICB0bzogbmV3IERhdGUoKSxcbiAgfSlcblxuICBjb25zdCB7IGRhdGE6IGRhaWx5UmV2ZW51ZUluUGVyaW9kIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFsnbWV0cmljcycsICdkYWlseS1yZXZlbnVlLWluLXBlcmlvZCcsIGRhdGVSYW5nZV0sXG4gICAgcXVlcnlGbjogKCkgPT5cbiAgICAgIGdldERhaWx5UmV2ZW51ZUluUGVyaW9kKHsgZnJvbTogZGF0ZVJhbmdlPy5mcm9tLCB0bzogZGF0ZVJhbmdlPy50byB9KSxcbiAgfSlcblxuICBjb25zdCBjaGFydERhdGEgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gZGFpbHlSZXZlbnVlSW5QZXJpb2Q/Lm1hcCgoY2hhcnRJdGVtKSA9PiB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBkYXRlOiBjaGFydEl0ZW0uZGF0ZSxcbiAgICAgICAgcmVjZWlwdDogY2hhcnRJdGVtLnJlY2VpcHQgLyAxMDAsXG4gICAgICB9XG4gICAgfSlcbiAgfSwgW2RhaWx5UmV2ZW51ZUluUGVyaW9kXSlcblxuICByZXR1cm4gKFxuICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLXRleHQtbXV0ZWQtZm9yZWdyb3VuZCBjb2wtc3Bhbi02XCI+XG4gICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgUmVjZWl0YSBubyBwZXLDrW9kb1xuICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgIDxDYXJkRGVzY3JpcHRpb24+UmVjZWl0YSBkacOhcmlhIG5vIHBlcsOtb2RvPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8TGFiZWw+UGVyw61vZG88L0xhYmVsPlxuICAgICAgICAgIDxEYXRlUmFuZ2VQaWNrZXIgZGF0ZT17ZGF0ZVJhbmdlfSBvbkRhdGVDaGFuZ2U9e3NldERhdGVSYW5nZX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICA8Q2FyZENvbnRlbnQ+XG4gICAgICAgIHtkYWlseVJldmVudWVJblBlcmlvZCA/IChcbiAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezI0MH0+XG4gICAgICAgICAgICA8TGluZUNoYXJ0IGRhdGE9e2NoYXJ0RGF0YX0gc3R5bGU9e3sgZm9udFNpemU6IDEyIH19PlxuICAgICAgICAgICAgICA8WEF4aXNcbiAgICAgICAgICAgICAgICBkYXRhS2V5PXsnZGF0ZSd9XG4gICAgICAgICAgICAgICAgYXhpc0xpbmU9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIHRpY2tMaW5lPXtmYWxzZX1cbiAgICAgICAgICAgICAgICBkeT17MTZ9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxZQXhpc1xuICAgICAgICAgICAgICAgIHN0cm9rZT1cIiM4ODhcIlxuICAgICAgICAgICAgICAgIGF4aXNMaW5lPXtmYWxzZX1cbiAgICAgICAgICAgICAgICB0aWNrTGluZT17ZmFsc2V9XG4gICAgICAgICAgICAgICAgd2lkdGg9ezgwfVxuICAgICAgICAgICAgICAgIHRpY2tGb3JtYXR0ZXI9eyh2YWx1ZTogbnVtYmVyKSA9PlxuICAgICAgICAgICAgICAgICAgdmFsdWUudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJywge1xuICAgICAgICAgICAgICAgICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcbiAgICAgICAgICAgICAgICAgICAgY3VycmVuY3k6ICdCUkwnLFxuICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxMaW5lXG4gICAgICAgICAgICAgICAgdHlwZT1cImxpbmVhclwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XG4gICAgICAgICAgICAgICAgZGF0YUtleT1cInJlY2VpcHRcIlxuICAgICAgICAgICAgICAgIHN0cm9rZT17Y29sb3JzLnZpb2xldFsnNDAwJ119XG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgdmVydGljYWw9e2ZhbHNlfSBjbGFzc05hbWU9XCJzdHJva2UtbXV0ZWRcIiAvPlxuICAgICAgICAgICAgPC9MaW5lQ2hhcnQ+XG4gICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLVsyNDBweF0gdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwiaC04IHctOCBhbmltYXRlLXNwaW4gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL3BhZ2VzL2FwcC9kYXNoYm9hcmQvcmV2ZW51ZS1jaGFydC50c3gifQ==