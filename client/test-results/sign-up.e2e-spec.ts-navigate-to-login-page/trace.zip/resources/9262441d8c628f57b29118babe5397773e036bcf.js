import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-row.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { formatDistanceToNow } from "/node_modules/.vite/deps/date-fns.js?v=cab43493";
import { ptBR } from "/node_modules/.vite/deps/date-fns_locale.js?v=cab43493";
import { ArrowRight, Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=cab43493"; const useState = __vite__cjsImport7_react["useState"];
import { approveOrder } from "/src/api/approve-order.ts";
import { cancelOrder } from "/src/api/cancel-order.ts";
import { deliverOrder } from "/src/api/deliver-order.ts";
import { dispatchOrder } from "/src/api/disptach-order.ts";
import { OrderStatus } from "/src/components/order-status.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogTrigger } from "/src/components/ui/dialog.tsx";
import { TableCell, TableRow } from "/src/components/ui/table.tsx";
import { OrderDetails } from "/src/pages/app/orders/order-details.tsx";
export function OrderTableRow({ order }) {
  _s();
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const queryClient = useQueryClient();
  const updateOrderStatusOnChache = (orderId, status) => {
    const ordersListCached = queryClient.getQueriesData({
      queryKey: ["orders"]
    });
    ordersListCached.forEach(([cacheKey, cacheData]) => {
      if (!cacheData) {
        return;
      }
      queryClient.setQueryData(cacheKey, {
        ...cacheData,
        orders: cacheData.orders.map((order2) => {
          if (order2.orderId === orderId) {
            return { ...order2, status };
          }
          return order2;
        })
      });
    });
  };
  const { mutateAsync: cancelOrderFn, isPending: isApprovingOrder } = useMutation({
    mutationFn: cancelOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnChache(orderId, "canceled");
    }
  });
  const { mutateAsync: approveOrderFn, isPending: isCancelingOrder } = useMutation({
    mutationFn: approveOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnChache(orderId, "processing");
    }
  });
  const { mutateAsync: dispatchOrderFn, isPending: isDispatchingOrder } = useMutation({
    mutationFn: dispatchOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnChache(orderId, "delivering");
    }
  });
  const { mutateAsync: deliverOrderFn, isPending: isDeliveringOrder } = useMutation({
    mutationFn: deliverOrder,
    async onSuccess(_, { orderId }) {
      updateOrderStatusOnChache(orderId, "delivered");
    }
  });
  return /* @__PURE__ */ jsxDEV(TableRow, { children: [
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Dialog, { open: isDetailsOpen, onOpenChange: setIsDetailsOpen, children: [
      /* @__PURE__ */ jsxDEV(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "xs", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-3 w-3" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 94,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Detalhes do pedido" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 95,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 93,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 92,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(OrderDetails, { open: isDetailsOpen, orderId: order.orderId }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 98,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 91,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-mono text-xs font-medium", children: order.orderId }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "text-muted-foreground", children: formatDistanceToNow(order.createdAt, {
      locale: ptBR,
      addSuffix: true
    }) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 104,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(OrderStatus, { status: order.status }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 111,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium", children: order.customerName }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium", children: (order.total / 100).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL"
    }) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 114,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: [
      order.status === "pending" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => approveOrderFn({ orderId: order.orderId }),
          disabled: isApprovingOrder,
          variant: "outline",
          size: "xs",
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 128,
              columnNumber: 13
            }, this),
            "Aprovar"
          ]
        },
        void 0,
        true,
        {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 122,
          columnNumber: 9
        },
        this
      ),
      order.status === "processing" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => dispatchOrderFn({ orderId: order.orderId }),
          disabled: isDispatchingOrder,
          variant: "outline",
          size: "xs",
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 139,
              columnNumber: 13
            }, this),
            "Em entrega"
          ]
        },
        void 0,
        true,
        {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 133,
          columnNumber: 9
        },
        this
      ),
      order.status === "delivering" && /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: () => deliverOrderFn({ orderId: order.orderId }),
          disabled: isDeliveringOrder,
          variant: "outline",
          size: "xs",
          children: [
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "mr-2 h-3 w-3" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
              lineNumber: 150,
              columnNumber: 13
            }, this),
            "Entregue"
          ]
        },
        void 0,
        true,
        {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
          lineNumber: 144,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        onClick: () => cancelOrderFn({ orderId: order.orderId }),
        disabled: !["pending", "processing"].includes(order.status) || isCancelingOrder,
        variant: "ghost",
        size: "xs",
        children: [
          /* @__PURE__ */ jsxDEV(X, { className: "mr-2 h-3 w-3" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
            lineNumber: 165,
            columnNumber: 11
          }, this),
          "Cancelar"
        ]
      },
      void 0,
      true,
      {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
        lineNumber: 156,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
      lineNumber: 155,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx",
    lineNumber: 89,
    columnNumber: 5
  }, this);
}
_s(OrderTableRow, "57dTVOJpSR+fR1SpDJBOzoJAv8g=", false, function() {
  return [useQueryClient, useMutation, useMutation, useMutation, useMutation];
});
_c = OrderTableRow;
var _c;
$RefreshReg$(_c, "OrderTableRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-row.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkZjOzJCQTdGZDtBQUFvQixNQUFFQSxjQUFjLE9BQVEsc0JBQXVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ25FLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFlBQVlDLFFBQVFDLFNBQVM7QUFDdEMsU0FBU0MsZ0JBQWdCO0FBRXpCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHFCQUFxQjtBQUU5QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxRQUFRQyxxQkFBcUI7QUFDdEMsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBRXBDLFNBQVNDLG9CQUFvQjtBQVl0QixnQkFBU0MsY0FBYyxFQUFFQyxNQUEwQixHQUFHO0FBQUFDLEtBQUE7QUFDM0QsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSWhCLFNBQVMsS0FBSztBQUN4RCxRQUFNaUIsY0FBY3ZCLGVBQWU7QUFFbkMsUUFBTXdCLDRCQUE0QkEsQ0FBQ0MsU0FBaUJDLFdBQXdCO0FBQzFFLFVBQU1DLG1CQUFtQkosWUFBWUssZUFBa0M7QUFBQSxNQUNyRUMsVUFBVSxDQUFDLFFBQVE7QUFBQSxJQUNyQixDQUFDO0FBRURGLHFCQUFpQkcsUUFBUSxDQUFDLENBQUNDLFVBQVVDLFNBQVMsTUFBTTtBQUNsRCxVQUFJLENBQUNBLFdBQVc7QUFDZDtBQUFBLE1BQ0Y7QUFFQVQsa0JBQVlVLGFBQWdDRixVQUFVO0FBQUEsUUFDcEQsR0FBR0M7QUFBQUEsUUFDSEUsUUFBUUYsVUFBVUUsT0FBT0MsSUFBSSxDQUFDaEIsV0FBVTtBQUN0QyxjQUFJQSxPQUFNTSxZQUFZQSxTQUFTO0FBQzdCLG1CQUFPLEVBQUUsR0FBR04sUUFBT08sT0FBTztBQUFBLFVBQzVCO0FBRUEsaUJBQU9QO0FBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNLEVBQUVpQixhQUFhQyxlQUFlQyxXQUFXQyxpQkFBaUIsSUFDOURDLFlBQVk7QUFBQSxJQUNWQyxZQUFZakM7QUFBQUEsSUFDWixNQUFNa0MsVUFBVUMsR0FBRyxFQUFFbEIsUUFBUSxHQUFHO0FBQzlCRCxnQ0FBMEJDLFNBQVMsVUFBVTtBQUFBLElBQy9DO0FBQUEsRUFDRixDQUFDO0FBRUgsUUFBTSxFQUFFVyxhQUFhUSxnQkFBZ0JOLFdBQVdPLGlCQUFpQixJQUMvREwsWUFBWTtBQUFBLElBQ1ZDLFlBQVlsQztBQUFBQSxJQUNaLE1BQU1tQyxVQUFVQyxHQUFHLEVBQUVsQixRQUFRLEdBQUc7QUFDOUJELGdDQUEwQkMsU0FBUyxZQUFZO0FBQUEsSUFDakQ7QUFBQSxFQUNGLENBQUM7QUFFSCxRQUFNLEVBQUVXLGFBQWFVLGlCQUFpQlIsV0FBV1MsbUJBQW1CLElBQ2xFUCxZQUFZO0FBQUEsSUFDVkMsWUFBWS9CO0FBQUFBLElBQ1osTUFBTWdDLFVBQVVDLEdBQUcsRUFBRWxCLFFBQVEsR0FBRztBQUM5QkQsZ0NBQTBCQyxTQUFTLFlBQVk7QUFBQSxJQUNqRDtBQUFBLEVBQ0YsQ0FBQztBQUVILFFBQU0sRUFBRVcsYUFBYVksZ0JBQWdCVixXQUFXVyxrQkFBa0IsSUFDaEVULFlBQVk7QUFBQSxJQUNWQyxZQUFZaEM7QUFBQUEsSUFDWixNQUFNaUMsVUFBVUMsR0FBRyxFQUFFbEIsUUFBUSxHQUFHO0FBQzlCRCxnQ0FBMEJDLFNBQVMsV0FBVztBQUFBLElBQ2hEO0FBQUEsRUFDRixDQUFDO0FBRUgsU0FDRSx1QkFBQyxZQUNDO0FBQUEsMkJBQUMsYUFDQyxpQ0FBQyxVQUFPLE1BQU1KLGVBQWUsY0FBY0Msa0JBQ3pDO0FBQUEsNkJBQUMsaUJBQWMsU0FBTyxNQUNwQixpQ0FBQyxVQUFPLFNBQVEsV0FBVSxNQUFLLE1BQzdCO0FBQUEsK0JBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUMzQix1QkFBQyxVQUFLLFdBQVUsV0FBVSxrQ0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFdBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsZ0JBQWEsTUFBTUQsZUFBZSxTQUFTRixNQUFNTSxXQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsU0FQNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFDQSx1QkFBQyxhQUFVLFdBQVUsaUNBQ2xCTixnQkFBTU0sV0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLGFBQVUsV0FBVSx5QkFDbEJ4Qiw4QkFBb0JrQixNQUFNK0IsV0FBVztBQUFBLE1BQ3BDQyxRQUFRakQ7QUFBQUEsTUFDUmtELFdBQVc7QUFBQSxJQUNiLENBQUMsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGFBQ0MsaUNBQUMsZUFBWSxRQUFRakMsTUFBTU8sVUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLGFBQVUsV0FBVSxlQUFlUCxnQkFBTWtDLGdCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsSUFDdkQsdUJBQUMsYUFBVSxXQUFVLGVBQ2pCbEMsaUJBQU1tQyxRQUFRLEtBQUtDLGVBQWUsU0FBUztBQUFBLE1BQzNDQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLElBQ1osQ0FBQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsYUFDRXRDO0FBQUFBLFlBQU1PLFdBQVcsYUFDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTWtCLGVBQWUsRUFBRW5CLFNBQVNOLE1BQU1NLFFBQVEsQ0FBQztBQUFBLFVBQ3hELFVBQVVjO0FBQUFBLFVBQ1YsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBRUw7QUFBQSxtQ0FBQyxjQUFXLFdBQVUsa0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFOdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxNQUVEcEIsTUFBTU8sV0FBVyxnQkFDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTW9CLGdCQUFnQixFQUFFckIsU0FBU04sTUFBTU0sUUFBUSxDQUFDO0FBQUEsVUFDekQsVUFBVXNCO0FBQUFBLFVBQ1YsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBRUw7QUFBQSxtQ0FBQyxjQUFXLFdBQVUsa0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFOdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxNQUVENUIsTUFBTU8sV0FBVyxnQkFDaEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTXNCLGVBQWUsRUFBRXZCLFNBQVNOLE1BQU1NLFFBQVEsQ0FBQztBQUFBLFVBQ3hELFVBQVV3QjtBQUFBQSxVQUNWLFNBQVE7QUFBQSxVQUNSLE1BQUs7QUFBQSxVQUVMO0FBQUEsbUNBQUMsY0FBVyxXQUFVLGtCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsU0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLElBQ0EsdUJBQUMsYUFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUyxNQUFNWixjQUFjLEVBQUVaLFNBQVNOLE1BQU1NLFFBQVEsQ0FBQztBQUFBLFFBQ3ZELFVBQ0UsQ0FBQyxDQUFDLFdBQVcsWUFBWSxFQUFFaUMsU0FBU3ZDLE1BQU1PLE1BQU0sS0FDaERtQjtBQUFBQSxRQUVGLFNBQVE7QUFBQSxRQUNSLE1BQUs7QUFBQSxRQUVMO0FBQUEsaUNBQUMsS0FBRSxXQUFVLGtCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFUN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0ZBO0FBRUo7QUFBQ3pCLEdBOUllRixlQUFhO0FBQUEsVUFFUGxCLGdCQTBCbEJ3QyxhQVFBQSxhQVFBQSxhQVFBQSxXQUFXO0FBQUE7QUFBQW1CLEtBcERDekM7QUFBYSxJQUFBeUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVF1ZXJ5Q2xpZW50IiwiZm9ybWF0RGlzdGFuY2VUb05vdyIsInB0QlIiLCJBcnJvd1JpZ2h0IiwiU2VhcmNoIiwiWCIsInVzZVN0YXRlIiwiYXBwcm92ZU9yZGVyIiwiY2FuY2VsT3JkZXIiLCJkZWxpdmVyT3JkZXIiLCJkaXNwYXRjaE9yZGVyIiwiT3JkZXJTdGF0dXMiLCJCdXR0b24iLCJEaWFsb2ciLCJEaWFsb2dUcmlnZ2VyIiwiVGFibGVDZWxsIiwiVGFibGVSb3ciLCJPcmRlckRldGFpbHMiLCJPcmRlclRhYmxlUm93Iiwib3JkZXIiLCJfcyIsImlzRGV0YWlsc09wZW4iLCJzZXRJc0RldGFpbHNPcGVuIiwicXVlcnlDbGllbnQiLCJ1cGRhdGVPcmRlclN0YXR1c09uQ2hhY2hlIiwib3JkZXJJZCIsInN0YXR1cyIsIm9yZGVyc0xpc3RDYWNoZWQiLCJnZXRRdWVyaWVzRGF0YSIsInF1ZXJ5S2V5IiwiZm9yRWFjaCIsImNhY2hlS2V5IiwiY2FjaGVEYXRhIiwic2V0UXVlcnlEYXRhIiwib3JkZXJzIiwibWFwIiwibXV0YXRlQXN5bmMiLCJjYW5jZWxPcmRlckZuIiwiaXNQZW5kaW5nIiwiaXNBcHByb3ZpbmdPcmRlciIsInVzZU11dGF0aW9uIiwibXV0YXRpb25GbiIsIm9uU3VjY2VzcyIsIl8iLCJhcHByb3ZlT3JkZXJGbiIsImlzQ2FuY2VsaW5nT3JkZXIiLCJkaXNwYXRjaE9yZGVyRm4iLCJpc0Rpc3BhdGNoaW5nT3JkZXIiLCJkZWxpdmVyT3JkZXJGbiIsImlzRGVsaXZlcmluZ09yZGVyIiwiY3JlYXRlZEF0IiwibG9jYWxlIiwiYWRkU3VmZml4IiwiY3VzdG9tZXJOYW1lIiwidG90YWwiLCJ0b0xvY2FsZVN0cmluZyIsInN0eWxlIiwiY3VycmVuY3kiLCJpbmNsdWRlcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsib3JkZXItdGFibGUtcm93LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBmb3JtYXREaXN0YW5jZVRvTm93IH0gZnJvbSAnZGF0ZS1mbnMnXG5pbXBvcnQgeyBwdEJSIH0gZnJvbSAnZGF0ZS1mbnMvbG9jYWxlJ1xuaW1wb3J0IHsgQXJyb3dSaWdodCwgU2VhcmNoLCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuaW1wb3J0IHsgYXBwcm92ZU9yZGVyIH0gZnJvbSAnQC9hcGkvYXBwcm92ZS1vcmRlcidcbmltcG9ydCB7IGNhbmNlbE9yZGVyIH0gZnJvbSAnQC9hcGkvY2FuY2VsLW9yZGVyJ1xuaW1wb3J0IHsgZGVsaXZlck9yZGVyIH0gZnJvbSAnQC9hcGkvZGVsaXZlci1vcmRlcidcbmltcG9ydCB7IGRpc3BhdGNoT3JkZXIgfSBmcm9tICdAL2FwaS9kaXNwdGFjaC1vcmRlcidcbmltcG9ydCB7IGdldE9yZGVyc1Jlc3BvbnNlIH0gZnJvbSAnQC9hcGkvZ2V0LW9yZGVycydcbmltcG9ydCB7IE9yZGVyU3RhdHVzIH0gZnJvbSAnQC9jb21wb25lbnRzL29yZGVyLXN0YXR1cydcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ1RyaWdnZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvZGlhbG9nJ1xuaW1wb3J0IHsgVGFibGVDZWxsLCBUYWJsZVJvdyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90YWJsZSdcblxuaW1wb3J0IHsgT3JkZXJEZXRhaWxzIH0gZnJvbSAnLi9vcmRlci1kZXRhaWxzJ1xuXG5leHBvcnQgaW50ZXJmYWNlIE9yZGVyVGFibGVSb3dQcm9wcyB7XG4gIG9yZGVyOiB7XG4gICAgb3JkZXJJZDogc3RyaW5nXG4gICAgY3JlYXRlZEF0OiBzdHJpbmdcbiAgICBzdGF0dXM6ICdwZW5kaW5nJyB8ICdjYW5jZWxlZCcgfCAncHJvY2Vzc2luZycgfCAnZGVsaXZlcmluZycgfCAnZGVsaXZlcmVkJ1xuICAgIGN1c3RvbWVyTmFtZTogc3RyaW5nXG4gICAgdG90YWw6IG51bWJlclxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBPcmRlclRhYmxlUm93KHsgb3JkZXIgfTogT3JkZXJUYWJsZVJvd1Byb3BzKSB7XG4gIGNvbnN0IFtpc0RldGFpbHNPcGVuLCBzZXRJc0RldGFpbHNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcblxuICBjb25zdCB1cGRhdGVPcmRlclN0YXR1c09uQ2hhY2hlID0gKG9yZGVySWQ6IHN0cmluZywgc3RhdHVzOiBPcmRlclN0YXR1cykgPT4ge1xuICAgIGNvbnN0IG9yZGVyc0xpc3RDYWNoZWQgPSBxdWVyeUNsaWVudC5nZXRRdWVyaWVzRGF0YTxnZXRPcmRlcnNSZXNwb25zZT4oe1xuICAgICAgcXVlcnlLZXk6IFsnb3JkZXJzJ10sXG4gICAgfSlcblxuICAgIG9yZGVyc0xpc3RDYWNoZWQuZm9yRWFjaCgoW2NhY2hlS2V5LCBjYWNoZURhdGFdKSA9PiB7XG4gICAgICBpZiAoIWNhY2hlRGF0YSkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhPGdldE9yZGVyc1Jlc3BvbnNlPihjYWNoZUtleSwge1xuICAgICAgICAuLi5jYWNoZURhdGEsXG4gICAgICAgIG9yZGVyczogY2FjaGVEYXRhLm9yZGVycy5tYXAoKG9yZGVyKSA9PiB7XG4gICAgICAgICAgaWYgKG9yZGVyLm9yZGVySWQgPT09IG9yZGVySWQpIHtcbiAgICAgICAgICAgIHJldHVybiB7IC4uLm9yZGVyLCBzdGF0dXMgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBvcmRlclxuICAgICAgICB9KSxcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGNhbmNlbE9yZGVyRm4sIGlzUGVuZGluZzogaXNBcHByb3ZpbmdPcmRlciB9ID1cbiAgICB1c2VNdXRhdGlvbih7XG4gICAgICBtdXRhdGlvbkZuOiBjYW5jZWxPcmRlcixcbiAgICAgIGFzeW5jIG9uU3VjY2VzcyhfLCB7IG9yZGVySWQgfSkge1xuICAgICAgICB1cGRhdGVPcmRlclN0YXR1c09uQ2hhY2hlKG9yZGVySWQsICdjYW5jZWxlZCcpXG4gICAgICB9LFxuICAgIH0pXG5cbiAgY29uc3QgeyBtdXRhdGVBc3luYzogYXBwcm92ZU9yZGVyRm4sIGlzUGVuZGluZzogaXNDYW5jZWxpbmdPcmRlciB9ID1cbiAgICB1c2VNdXRhdGlvbih7XG4gICAgICBtdXRhdGlvbkZuOiBhcHByb3ZlT3JkZXIsXG4gICAgICBhc3luYyBvblN1Y2Nlc3MoXywgeyBvcmRlcklkIH0pIHtcbiAgICAgICAgdXBkYXRlT3JkZXJTdGF0dXNPbkNoYWNoZShvcmRlcklkLCAncHJvY2Vzc2luZycpXG4gICAgICB9LFxuICAgIH0pXG5cbiAgY29uc3QgeyBtdXRhdGVBc3luYzogZGlzcGF0Y2hPcmRlckZuLCBpc1BlbmRpbmc6IGlzRGlzcGF0Y2hpbmdPcmRlciB9ID1cbiAgICB1c2VNdXRhdGlvbih7XG4gICAgICBtdXRhdGlvbkZuOiBkaXNwYXRjaE9yZGVyLFxuICAgICAgYXN5bmMgb25TdWNjZXNzKF8sIHsgb3JkZXJJZCB9KSB7XG4gICAgICAgIHVwZGF0ZU9yZGVyU3RhdHVzT25DaGFjaGUob3JkZXJJZCwgJ2RlbGl2ZXJpbmcnKVxuICAgICAgfSxcbiAgICB9KVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IGRlbGl2ZXJPcmRlckZuLCBpc1BlbmRpbmc6IGlzRGVsaXZlcmluZ09yZGVyIH0gPVxuICAgIHVzZU11dGF0aW9uKHtcbiAgICAgIG11dGF0aW9uRm46IGRlbGl2ZXJPcmRlcixcbiAgICAgIGFzeW5jIG9uU3VjY2VzcyhfLCB7IG9yZGVySWQgfSkge1xuICAgICAgICB1cGRhdGVPcmRlclN0YXR1c09uQ2hhY2hlKG9yZGVySWQsICdkZWxpdmVyZWQnKVxuICAgICAgfSxcbiAgICB9KVxuXG4gIHJldHVybiAoXG4gICAgPFRhYmxlUm93PlxuICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgPERpYWxvZyBvcGVuPXtpc0RldGFpbHNPcGVufSBvbk9wZW5DaGFuZ2U9e3NldElzRGV0YWlsc09wZW59PlxuICAgICAgICAgIDxEaWFsb2dUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInhzXCI+XG4gICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5EZXRhbGhlcyBkbyBwZWRpZG88L3NwYW4+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L0RpYWxvZ1RyaWdnZXI+XG4gICAgICAgICAgPE9yZGVyRGV0YWlscyBvcGVuPXtpc0RldGFpbHNPcGVufSBvcmRlcklkPXtvcmRlci5vcmRlcklkfSAvPlxuICAgICAgICA8L0RpYWxvZz5cbiAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyBmb250LW1lZGl1bVwiPlxuICAgICAgICB7b3JkZXIub3JkZXJJZH1cbiAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAge2Zvcm1hdERpc3RhbmNlVG9Ob3cob3JkZXIuY3JlYXRlZEF0LCB7XG4gICAgICAgICAgbG9jYWxlOiBwdEJSLFxuICAgICAgICAgIGFkZFN1ZmZpeDogdHJ1ZSxcbiAgICAgICAgfSl9XG4gICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgIDxPcmRlclN0YXR1cyBzdGF0dXM9e29yZGVyLnN0YXR1c30gLz5cbiAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntvcmRlci5jdXN0b21lck5hbWV9PC9UYWJsZUNlbGw+XG4gICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+XG4gICAgICAgIHsob3JkZXIudG90YWwgLyAxMDApLnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcbiAgICAgICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcbiAgICAgICAgICBjdXJyZW5jeTogJ0JSTCcsXG4gICAgICAgIH0pfVxuICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICA8VGFibGVDZWxsPlxuICAgICAgICB7b3JkZXIuc3RhdHVzID09PSAncGVuZGluZycgJiYgKFxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcHJvdmVPcmRlckZuKHsgb3JkZXJJZDogb3JkZXIub3JkZXJJZCB9KX1cbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0FwcHJvdmluZ09yZGVyfVxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJtci0yIGgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgQXByb3ZhclxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICApfVxuICAgICAgICB7b3JkZXIuc3RhdHVzID09PSAncHJvY2Vzc2luZycgJiYgKFxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRpc3BhdGNoT3JkZXJGbih7IG9yZGVySWQ6IG9yZGVyLm9yZGVySWQgfSl9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNEaXNwYXRjaGluZ09yZGVyfVxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJtci0yIGgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgRW0gZW50cmVnYVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICApfVxuICAgICAgICB7b3JkZXIuc3RhdHVzID09PSAnZGVsaXZlcmluZycgJiYgKFxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRlbGl2ZXJPcmRlckZuKHsgb3JkZXJJZDogb3JkZXIub3JkZXJJZCB9KX1cbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0RlbGl2ZXJpbmdPcmRlcn1cbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgIHNpemU9XCJ4c1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwibXItMiBoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgIEVudHJlZ3VlXG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICl9XG4gICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjYW5jZWxPcmRlckZuKHsgb3JkZXJJZDogb3JkZXIub3JkZXJJZCB9KX1cbiAgICAgICAgICBkaXNhYmxlZD17XG4gICAgICAgICAgICAhWydwZW5kaW5nJywgJ3Byb2Nlc3NpbmcnXS5pbmNsdWRlcyhvcmRlci5zdGF0dXMpIHx8XG4gICAgICAgICAgICBpc0NhbmNlbGluZ09yZGVyXG4gICAgICAgICAgfVxuICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxYIGNsYXNzTmFtZT1cIm1yLTIgaC0zIHctM1wiIC8+XG4gICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgPC9CdXR0b24+XG4gICAgICA8L1RhYmxlQ2VsbD5cbiAgICA8L1RhYmxlUm93PlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL3BhZ2VzL2FwcC9vcmRlcnMvb3JkZXItdGFibGUtcm93LnRzeCJ9