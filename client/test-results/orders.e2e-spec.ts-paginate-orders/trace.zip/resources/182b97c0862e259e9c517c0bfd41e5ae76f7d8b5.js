import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { DollarSign } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { getMonthCanceledOrdersAmount } from "/src/api/get-month-canceled-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthCanceledOrdersAmountCard() {
  _s();
  const { data: monthCanceledOrdersAmount } = useQuery({
    queryFn: getMonthCanceledOrdersAmount,
    queryKey: ["metrics", "month-canceled-orders-amount"]
  });
  return /* @__PURE__ */ jsxDEV(Card, { className: "bg-text-muted-foreground", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Cancelamentos (mês)" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthCanceledOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold tracking-tight", children: monthCanceledOrdersAmount.amount.toLocaleString("pt-BR") }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs- text-muted-foreground", children: monthCanceledOrdersAmount.diffFromLastMonth < 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500 dark:text-rose-400", children: [
          monthCanceledOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
          lineNumber: 32,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 31,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-500 dark:text-emerald-400 ", children: [
          "+",
          monthCanceledOrdersAmount.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
          lineNumber: 39,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 38,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
        lineNumber: 29,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 25,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 48,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(MonthCanceledOrdersAmountCard, "8+4OTDJzpazOHlKic+kKfdz2IPM=", false, function() {
  return [useQuery];
});
_c = MonthCanceledOrdersAmountCard;
var _c;
$RefreshReg$(_c, "MonthCanceledOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-canceled-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRLFNBYVEsVUFiUjsyQkFqQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0Esa0JBQWtCO0FBRTNCLFNBQVNDLG9DQUFvQztBQUM3QyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyxnQ0FBZ0M7QUFBQUMsS0FBQTtBQUM5QyxRQUFNLEVBQUVDLE1BQU1DLDBCQUEwQixJQUFJQyxTQUFTO0FBQUEsSUFDbkRDLFNBQVNYO0FBQUFBLElBQ1RZLFVBQVUsQ0FBQyxXQUFXLDhCQUE4QjtBQUFBLEVBQ3RELENBQUM7QUFFRCxTQUNFLHVCQUFDLFFBQUssV0FBVSw0QkFDZDtBQUFBLDJCQUFDLGNBQVcsV0FBVSx3REFDcEI7QUFBQSw2QkFBQyxhQUFVLFdBQVUsMkJBQXlCLG1DQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLGNBQVcsV0FBVSxtQ0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRDtBQUFBLFNBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsZUFBWSxXQUFVLGFBQ3BCSCxzQ0FDQyxtQ0FDRTtBQUFBLDZCQUFDLFVBQUssV0FBVSxxQ0FDYkEsb0NBQTBCSSxPQUFPQyxlQUFlLE9BQU8sS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1ZMLG9DQUEwQk0sb0JBQW9CLElBQzdDLG1DQUNFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLG9DQUNiTjtBQUFBQSxvQ0FBMEJNO0FBQUFBLFVBQWtCO0FBQUEsYUFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUc7QUFBQSxXQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxJQUVBLG1DQUNFO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDJDQUF5QztBQUFBO0FBQUEsVUFDckROLDBCQUEwQk07QUFBQUEsVUFBa0I7QUFBQSxhQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUFRO0FBQUEsUUFBRztBQUFBLFdBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLEtBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkEsSUFFQSx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1CLEtBekJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBO0FBQUEsT0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1DQTtBQUVKO0FBQUNSLEdBNUNlRCwrQkFBNkI7QUFBQSxVQUNDSSxRQUFRO0FBQUE7QUFBQU0sS0FEdENWO0FBQTZCLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJEb2xsYXJTaWduIiwiZ2V0TW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudCIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJNZXRyaWNDYXJkU2tlbGV0b24iLCJNb250aENhbmNlbGVkT3JkZXJzQW1vdW50Q2FyZCIsIl9zIiwiZGF0YSIsIm1vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQiLCJ1c2VRdWVyeSIsInF1ZXJ5Rm4iLCJxdWVyeUtleSIsImFtb3VudCIsInRvTG9jYWxlU3RyaW5nIiwiZGlmZkZyb21MYXN0TW9udGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm1vbnRoLWNhbmNlbGVkLW9yZGVycy1hbW91bnQtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBEb2xsYXJTaWduIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbXBvcnQgeyBnZXRNb250aENhbmNlbGVkT3JkZXJzQW1vdW50IH0gZnJvbSAnQC9hcGkvZ2V0LW1vbnRoLWNhbmNlbGVkLW9yZGVycy1hbW91bnQnXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5cbmltcG9ydCB7IE1ldHJpY0NhcmRTa2VsZXRvbiB9IGZyb20gJy4vbWV0cmljLWNhcmQtc2tlbGV0b24nXG5cbmV4cG9ydCBmdW5jdGlvbiBNb250aENhbmNlbGVkT3JkZXJzQW1vdW50Q2FyZCgpIHtcbiAgY29uc3QgeyBkYXRhOiBtb250aENhbmNlbGVkT3JkZXJzQW1vdW50IH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlGbjogZ2V0TW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudCxcbiAgICBxdWVyeUtleTogWydtZXRyaWNzJywgJ21vbnRoLWNhbmNlbGVkLW9yZGVycy1hbW91bnQnXSxcbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLXRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzcGFjZS15LTAgcGItMlwiPlxuICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgQ2FuY2VsYW1lbnRvcyAobcOqcylcbiAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgIDxEb2xsYXJTaWduIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgIDwvQ2FyZEhlYWRlcj5cbiAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAge21vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQgPyAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICB7bW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudC5hbW91bnQudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJyl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzLSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge21vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQuZGlmZkZyb21MYXN0TW9udGggPCAwID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwIGRhcms6dGV4dC1yb3NlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7bW9udGhDYW5jZWxlZE9yZGVyc0Ftb3VudC5kaWZmRnJvbUxhc3RNb250aH0lXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+eycgJ31cbiAgICAgICAgICAgICAgICAgIGVtIHJlbGHDp8OjbyBhIG9udGVtXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC01MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIFwiPlxuICAgICAgICAgICAgICAgICAgICAre21vbnRoQ2FuY2VsZWRPcmRlcnNBbW91bnQuZGlmZkZyb21MYXN0TW9udGh9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYSBvbnRlbVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxNZXRyaWNDYXJkU2tlbGV0b24gLz5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL3BhZ2VzL2FwcC9kYXNoYm9hcmQvbW9udGgtY2FuY2VsZWQtb3JkZXJzLWFtb3VudC1jYXJkLnRzeCJ9