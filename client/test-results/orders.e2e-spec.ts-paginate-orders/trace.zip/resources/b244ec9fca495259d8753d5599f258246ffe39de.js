import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=cab43493";
export const updateProfileMock = http.put(
  "/profile",
  async ({ request }) => {
    const { name, description } = await request.json();
    if (name === "Rocket Shop") {
      return new HttpResponse(null, {
        status: 204
      });
    }
    return new HttpResponse(null, { status: 400 });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVwZGF0ZS1wcm9maWxlLW1vY2sudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaHR0cCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnbXN3J1xuXG5pbXBvcnQgeyBVcGRhdGVQcm9maWxlQm9keSB9IGZyb20gJy4uL3VwZGF0ZS1wcm9maWxlJ1xuXG5leHBvcnQgY29uc3QgdXBkYXRlUHJvZmlsZU1vY2sgPSBodHRwLnB1dDxuZXZlciwgVXBkYXRlUHJvZmlsZUJvZHk+KFxuICAnL3Byb2ZpbGUnLFxuICBhc3luYyAoeyByZXF1ZXN0IH0pID0+IHtcbiAgICBjb25zdCB7IG5hbWUsIGRlc2NyaXB0aW9uIH0gPSBhd2FpdCByZXF1ZXN0Lmpzb24oKVxuXG4gICAgaWYgKG5hbWUgPT09ICdSb2NrZXQgU2hvcCcpIHtcbiAgICAgIHJldHVybiBuZXcgSHR0cFJlc3BvbnNlKG51bGwsIHtcbiAgICAgICAgc3RhdHVzOiAyMDQsXG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgSHR0cFJlc3BvbnNlKG51bGwsIHsgc3RhdHVzOiA0MDAgfSlcbiAgfSxcbilcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG9CQUFvQjtBQUk1QixhQUFNLG9CQUFvQixLQUFLO0FBQUEsRUFDcEM7QUFBQSxFQUNBLE9BQU8sRUFBRSxRQUFRLE1BQU07QUFDckIsVUFBTSxFQUFFLE1BQU0sWUFBWSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBRWpELFFBQUksU0FBUyxlQUFlO0FBQzFCLGFBQU8sSUFBSSxhQUFhLE1BQU07QUFBQSxRQUM1QixRQUFRO0FBQUEsTUFDVixDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU8sSUFBSSxhQUFhLE1BQU0sRUFBRSxRQUFRLElBQUksQ0FBQztBQUFBLEVBQy9DO0FBQ0Y7IiwibmFtZXMiOltdfQ==