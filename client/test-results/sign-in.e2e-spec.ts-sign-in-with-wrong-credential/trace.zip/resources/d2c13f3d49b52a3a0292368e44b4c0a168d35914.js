import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/error.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useRouteError } from "/node_modules/.vite/deps/react-router-dom.js?v=cab43493";
export function Error() {
  _s();
  const error = useRouteError();
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen flex-col items-center justify-center", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold", children: "Whoops, algo aconteceu..." }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-accent-foreground", children: "Um erro aconteceu na aplicação, abaixo você encontra mais detalhes:" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("pre", { children: error?.message || JSON.stringify(error) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-accent-foreground", children: [
      "Voltar para o",
      " ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/", className: "text-sky-500 dark:text-sky-400", children: "dashboard" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx",
        lineNumber: 15,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx",
      lineNumber: 13,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx",
    lineNumber: 7,
    columnNumber: 5
  }, this);
}
_s(Error, "YDkf/bojC730qvJxOiv5VT1rhKY=", false, function() {
  return [useRouteError];
});
_c = Error;
var _c;
$RefreshReg$(_c, "Error");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/error.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007MkJBUE47QUFBZUEsb0JBQXFCLDZCQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUvQyxnQkFBU0MsUUFBUTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU1DLFFBQVFILGNBQWM7QUFFNUIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsc0JBQXFCLHlDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTREO0FBQUEsSUFDNUQsdUJBQUMsT0FBRSxXQUFVLDBCQUF3QixtRkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFLRyxpQkFBT0MsV0FBV0MsS0FBS0MsVUFBVUgsS0FBSyxLQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFDOUMsdUJBQUMsT0FBRSxXQUFVLDBCQUF3QjtBQUFBO0FBQUEsTUFDckI7QUFBQSxNQUNkLHVCQUFDLFFBQUssSUFBRyxLQUFJLFdBQVUsa0NBQWdDLHlCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBQ0QsR0FsQmVELE9BQUs7QUFBQSxVQUNMRCxhQUFhO0FBQUE7QUFBQU8sS0FEYk47QUFBSyxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlUm91dGVFcnJvciIsIkVycm9yIiwiX3MiLCJlcnJvciIsIm1lc3NhZ2UiLCJKU09OIiwic3RyaW5naWZ5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJlcnJvci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlUm91dGVFcnJvciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cbmV4cG9ydCBmdW5jdGlvbiBFcnJvcigpIHtcbiAgY29uc3QgZXJyb3IgPSB1c2VSb3V0ZUVycm9yKCkgYXMgRXJyb3JcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLXNjcmVlbiBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGRcIj5XaG9vcHMsIGFsZ28gYWNvbnRlY2V1Li4uPC9oMT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYWNjZW50LWZvcmVncm91bmRcIj5cbiAgICAgICAgVW0gZXJybyBhY29udGVjZXUgbmEgYXBsaWNhw6fDo28sIGFiYWl4byB2b2PDqiBlbmNvbnRyYSBtYWlzIGRldGFsaGVzOlxuICAgICAgPC9wPlxuICAgICAgPHByZT57ZXJyb3I/Lm1lc3NhZ2UgfHwgSlNPTi5zdHJpbmdpZnkoZXJyb3IpfTwvcHJlPlxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1hY2NlbnQtZm9yZWdyb3VuZFwiPlxuICAgICAgICBWb2x0YXIgcGFyYSBveycgJ31cbiAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPVwidGV4dC1za3ktNTAwIGRhcms6dGV4dC1za3ktNDAwXCI+XG4gICAgICAgICAgZGFzaGJvYXJkXG4gICAgICAgIDwvTGluaz5cbiAgICAgIDwvcD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvaG9tZS9ydWFucGFibG8vaWduaXRlL3JlYWN0anMvZGFzaGJvYXJkL3NyYy9wYWdlcy9lcnJvci50c3gifQ==