import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/theme/theme-provider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/components/theme/theme-provider.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=cab43493"; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
const initialState = {
  theme: "system",
  setTheme: () => null
};
const ThemeProviderContext = createContext(initialState);
export function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "vite-ui-theme",
  ...props
}) {
  _s();
  const [theme, setTheme] = useState(
    () => localStorage.getItem(storageKey) || defaultTheme
  );
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");
    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      root.classList.add(systemTheme);
      return;
    }
    root.classList.add(theme);
  }, [theme]);
  const value = {
    theme,
    setTheme: (theme2) => {
      localStorage.setItem(storageKey, theme2);
      setTheme(theme2);
    }
  };
  return /* @__PURE__ */ jsxDEV(ThemeProviderContext.Provider, { ...props, value, children }, void 0, false, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/theme/theme-provider.tsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
}
_s(ThemeProvider, "YkY4D08WntVjXLroWjAGi4sfNRs=");
_c = ThemeProvider;
export const useTheme = () => {
  _s2();
  const context = useContext(ThemeProviderContext);
  if (context === void 0)
    throw new Error("useTheme must be used within a ThemeProvider");
  return context;
};
_s2(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "ThemeProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/components/theme/theme-provider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRJOztBQTNESixvQkFBU0EsT0FBZUMsc0JBQXVCQyxlQUFnQixnQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWV0RSxNQUFNQyxlQUFtQztBQUFBLEVBQ3ZDQyxPQUFPO0FBQUEsRUFDUEMsVUFBVUEsTUFBTTtBQUNsQjtBQUVBLE1BQU1DLHVCQUF1Qk4sY0FBa0NHLFlBQVk7QUFFcEUsZ0JBQVNJLGNBQWM7QUFBQSxFQUM1QkM7QUFBQUEsRUFDQUMsZUFBZTtBQUFBLEVBQ2ZDLGFBQWE7QUFBQSxFQUNiLEdBQUdDO0FBQ2UsR0FBRztBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sQ0FBQ1IsT0FBT0MsUUFBUSxJQUFJSDtBQUFBQSxJQUN4QixNQUFPVyxhQUFhQyxRQUFRSixVQUFVLEtBQWVEO0FBQUFBLEVBQ3ZEO0FBRUFNLFlBQVUsTUFBTTtBQUNkLFVBQU1DLE9BQU9DLE9BQU9DLFNBQVNDO0FBRTdCSCxTQUFLSSxVQUFVQyxPQUFPLFNBQVMsTUFBTTtBQUVyQyxRQUFJakIsVUFBVSxVQUFVO0FBQ3RCLFlBQU1rQixjQUFjTCxPQUFPTSxXQUFXLDhCQUE4QixFQUNqRUMsVUFDQyxTQUNBO0FBRUpSLFdBQUtJLFVBQVVLLElBQUlILFdBQVc7QUFDOUI7QUFBQSxJQUNGO0FBRUFOLFNBQUtJLFVBQVVLLElBQUlyQixLQUFLO0FBQUEsRUFDMUIsR0FBRyxDQUFDQSxLQUFLLENBQUM7QUFFVixRQUFNc0IsUUFBUTtBQUFBLElBQ1p0QjtBQUFBQSxJQUNBQyxVQUFVQSxDQUFDRCxXQUFpQjtBQUMxQlMsbUJBQWFjLFFBQVFqQixZQUFZTixNQUFLO0FBQ3RDQyxlQUFTRCxNQUFLO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxxQkFBcUIsVUFBckIsRUFBOEIsR0FBSU8sT0FBTyxPQUN2Q0gsWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDSSxHQXpDZUwsZUFBYTtBQUFBcUIsS0FBYnJCO0FBMkNULGFBQU1zQixXQUFXQSxNQUFNO0FBQUFDLE1BQUE7QUFDNUIsUUFBTUMsVUFBVTlCLFdBQVdLLG9CQUFvQjtBQUUvQyxNQUFJeUIsWUFBWUM7QUFDZCxVQUFNLElBQUlDLE1BQU0sOENBQThDO0FBRWhFLFNBQU9GO0FBQ1Q7QUFBQ0QsSUFQWUQsVUFBUTtBQUFBLElBQUFEO0FBQUFNLGFBQUFOLElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZVN0YXRlIiwiaW5pdGlhbFN0YXRlIiwidGhlbWUiLCJzZXRUaGVtZSIsIlRoZW1lUHJvdmlkZXJDb250ZXh0IiwiVGhlbWVQcm92aWRlciIsImNoaWxkcmVuIiwiZGVmYXVsdFRoZW1lIiwic3RvcmFnZUtleSIsInByb3BzIiwiX3MiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlRWZmZWN0Iiwicm9vdCIsIndpbmRvdyIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiY2xhc3NMaXN0IiwicmVtb3ZlIiwic3lzdGVtVGhlbWUiLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsImFkZCIsInZhbHVlIiwic2V0SXRlbSIsIl9jIiwidXNlVGhlbWUiLCJfczIiLCJjb250ZXh0IiwidW5kZWZpbmVkIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJ0aGVtZS1wcm92aWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG50eXBlIFRoZW1lID0gJ2RhcmsnIHwgJ2xpZ2h0JyB8ICdzeXN0ZW0nXG5cbnR5cGUgVGhlbWVQcm92aWRlclByb3BzID0ge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlXG4gIGRlZmF1bHRUaGVtZT86IFRoZW1lXG4gIHN0b3JhZ2VLZXk/OiBzdHJpbmdcbn1cblxudHlwZSBUaGVtZVByb3ZpZGVyU3RhdGUgPSB7XG4gIHRoZW1lOiBUaGVtZVxuICBzZXRUaGVtZTogKHRoZW1lOiBUaGVtZSkgPT4gdm9pZFxufVxuXG5jb25zdCBpbml0aWFsU3RhdGU6IFRoZW1lUHJvdmlkZXJTdGF0ZSA9IHtcbiAgdGhlbWU6ICdzeXN0ZW0nLFxuICBzZXRUaGVtZTogKCkgPT4gbnVsbCxcbn1cblxuY29uc3QgVGhlbWVQcm92aWRlckNvbnRleHQgPSBjcmVhdGVDb250ZXh0PFRoZW1lUHJvdmlkZXJTdGF0ZT4oaW5pdGlhbFN0YXRlKVxuXG5leHBvcnQgZnVuY3Rpb24gVGhlbWVQcm92aWRlcih7XG4gIGNoaWxkcmVuLFxuICBkZWZhdWx0VGhlbWUgPSAnc3lzdGVtJyxcbiAgc3RvcmFnZUtleSA9ICd2aXRlLXVpLXRoZW1lJyxcbiAgLi4ucHJvcHNcbn06IFRoZW1lUHJvdmlkZXJQcm9wcykge1xuICBjb25zdCBbdGhlbWUsIHNldFRoZW1lXSA9IHVzZVN0YXRlPFRoZW1lPihcbiAgICAoKSA9PiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oc3RvcmFnZUtleSkgYXMgVGhlbWUpIHx8IGRlZmF1bHRUaGVtZSxcbiAgKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgcm9vdCA9IHdpbmRvdy5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnRcblxuICAgIHJvb3QuY2xhc3NMaXN0LnJlbW92ZSgnbGlnaHQnLCAnZGFyaycpXG5cbiAgICBpZiAodGhlbWUgPT09ICdzeXN0ZW0nKSB7XG4gICAgICBjb25zdCBzeXN0ZW1UaGVtZSA9IHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1jb2xvci1zY2hlbWU6IGRhcmspJylcbiAgICAgICAgLm1hdGNoZXNcbiAgICAgICAgPyAnZGFyaydcbiAgICAgICAgOiAnbGlnaHQnXG5cbiAgICAgIHJvb3QuY2xhc3NMaXN0LmFkZChzeXN0ZW1UaGVtZSlcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHJvb3QuY2xhc3NMaXN0LmFkZCh0aGVtZSlcbiAgfSwgW3RoZW1lXSlcblxuICBjb25zdCB2YWx1ZSA9IHtcbiAgICB0aGVtZSxcbiAgICBzZXRUaGVtZTogKHRoZW1lOiBUaGVtZSkgPT4ge1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oc3RvcmFnZUtleSwgdGhlbWUpXG4gICAgICBzZXRUaGVtZSh0aGVtZSlcbiAgICB9LFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8VGhlbWVQcm92aWRlckNvbnRleHQuUHJvdmlkZXIgey4uLnByb3BzfSB2YWx1ZT17dmFsdWV9PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvVGhlbWVQcm92aWRlckNvbnRleHQuUHJvdmlkZXI+XG4gIClcbn1cblxuZXhwb3J0IGNvbnN0IHVzZVRoZW1lID0gKCkgPT4ge1xuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChUaGVtZVByb3ZpZGVyQ29udGV4dClcblxuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkKVxuICAgIHRocm93IG5ldyBFcnJvcigndXNlVGhlbWUgbXVzdCBiZSB1c2VkIHdpdGhpbiBhIFRoZW1lUHJvdmlkZXInKVxuXG4gIHJldHVybiBjb250ZXh0XG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL2NvbXBvbmVudHMvdGhlbWUvdGhlbWUtcHJvdmlkZXIudHN4In0=