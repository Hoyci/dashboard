import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/_layouts/app.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/_layouts/app.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { isAxiosError } from "/node_modules/.vite/deps/axios.js?v=cab43493";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=cab43493"; const useEffect = __vite__cjsImport4_react["useEffect"];
import { Outlet, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cab43493";
import { Header } from "/src/components/header.tsx";
import { api } from "/src/lib/axios.ts";
export function AppLayout() {
  _s();
  const navigate = useNavigate();
  useEffect(() => {
    const interceptorId = api.interceptors.response.use(
      (response) => response,
      (error) => {
        if (isAxiosError(error)) {
          const status = error.response?.status;
          const code = error.response?.data.code;
          if (status === 401 && code === "UNAUTHORIZED") {
            navigate("/sign-in", { replace: true });
          } else {
            throw error;
          }
        }
      }
    );
    return () => {
      api.interceptors.response.eject(interceptorId);
    };
  }, [navigate]);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen flex-col antialiased", children: [
    /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/_layouts/app.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col gap-4 p-8 pt-6", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/_layouts/app.tsx",
      lineNumber: 36,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/_layouts/app.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/_layouts/app.tsx",
    lineNumber: 33,
    columnNumber: 5
  }, this);
}
_s(AppLayout, "0pNeyzXk/ByIxyERsdaIrG6js9s=", false, function() {
  return [useNavigate];
});
_c = AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/_layouts/app.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNNOzJCQWpDTjtBQUFxQixvQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwQyxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsUUFBUUMsbUJBQW1CO0FBRXBDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsV0FBVztBQUViLGdCQUFTQyxZQUFZO0FBQUFDLEtBQUE7QUFDMUIsUUFBTUMsV0FBV0wsWUFBWTtBQUU3QkYsWUFBVSxNQUFNO0FBQ2QsVUFBTVEsZ0JBQWdCSixJQUFJSyxhQUFhQyxTQUFTQztBQUFBQSxNQUM5QyxDQUFDRCxhQUFhQTtBQUFBQSxNQUNkLENBQUNFLFVBQVU7QUFDVCxZQUFJQyxhQUFhRCxLQUFLLEdBQUc7QUFDdkIsZ0JBQU1FLFNBQVNGLE1BQU1GLFVBQVVJO0FBQy9CLGdCQUFNQyxPQUFPSCxNQUFNRixVQUFVTSxLQUFLRDtBQUVsQyxjQUFJRCxXQUFXLE9BQU9DLFNBQVMsZ0JBQWdCO0FBQzdDUixxQkFBUyxZQUFZLEVBQUVVLFNBQVMsS0FBSyxDQUFDO0FBQUEsVUFDeEMsT0FBTztBQUNMLGtCQUFNTDtBQUFBQSxVQUNSO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsV0FBTyxNQUFNO0FBQ1hSLFVBQUlLLGFBQWFDLFNBQVNRLE1BQU1WLGFBQWE7QUFBQSxJQUMvQztBQUFBLEVBQ0YsR0FBRyxDQUFDRCxRQUFRLENBQUM7QUFDYixTQUNFLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDJCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFDUCx1QkFBQyxTQUFJLFdBQVUsdUNBQ2IsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNELEdBaENlRCxXQUFTO0FBQUEsVUFDTkgsV0FBVztBQUFBO0FBQUFpQixLQURkZDtBQUFTLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJPdXRsZXQiLCJ1c2VOYXZpZ2F0ZSIsIkhlYWRlciIsImFwaSIsIkFwcExheW91dCIsIl9zIiwibmF2aWdhdGUiLCJpbnRlcmNlcHRvcklkIiwiaW50ZXJjZXB0b3JzIiwicmVzcG9uc2UiLCJ1c2UiLCJlcnJvciIsImlzQXhpb3NFcnJvciIsInN0YXR1cyIsImNvZGUiLCJkYXRhIiwicmVwbGFjZSIsImVqZWN0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGlzQXhpb3NFcnJvciB9IGZyb20gJ2F4aW9zJ1xuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBPdXRsZXQsIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcblxuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSAnQC9jb21wb25lbnRzL2hlYWRlcidcbmltcG9ydCB7IGFwaSB9IGZyb20gJ0AvbGliL2F4aW9zJ1xuXG5leHBvcnQgZnVuY3Rpb24gQXBwTGF5b3V0KCkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGludGVyY2VwdG9ySWQgPSBhcGkuaW50ZXJjZXB0b3JzLnJlc3BvbnNlLnVzZShcbiAgICAgIChyZXNwb25zZSkgPT4gcmVzcG9uc2UsXG4gICAgICAoZXJyb3IpID0+IHtcbiAgICAgICAgaWYgKGlzQXhpb3NFcnJvcihlcnJvcikpIHtcbiAgICAgICAgICBjb25zdCBzdGF0dXMgPSBlcnJvci5yZXNwb25zZT8uc3RhdHVzXG4gICAgICAgICAgY29uc3QgY29kZSA9IGVycm9yLnJlc3BvbnNlPy5kYXRhLmNvZGVcblxuICAgICAgICAgIGlmIChzdGF0dXMgPT09IDQwMSAmJiBjb2RlID09PSAnVU5BVVRIT1JJWkVEJykge1xuICAgICAgICAgICAgbmF2aWdhdGUoJy9zaWduLWluJywgeyByZXBsYWNlOiB0cnVlIH0pXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRocm93IGVycm9yXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9LFxuICAgIClcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBhcGkuaW50ZXJjZXB0b3JzLnJlc3BvbnNlLmVqZWN0KGludGVyY2VwdG9ySWQpXG4gICAgfVxuICB9LCBbbmF2aWdhdGVdKVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gZmxleC1jb2wgYW50aWFsaWFzZWRcIj5cbiAgICAgIDxIZWFkZXIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgZ2FwLTQgcC04IHB0LTZcIj5cbiAgICAgICAgPE91dGxldCAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVhbnBhYmxvL2lnbml0ZS9yZWFjdGpzL2Rhc2hib2FyZC9zcmMvcGFnZXMvX2xheW91dHMvYXBwLnRzeCJ9