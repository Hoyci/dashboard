import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/sign-up.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=cab43493";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=cab43493";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=cab43493";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=cab43493";
import { z } from "/node_modules/.vite/deps/zod.js?v=cab43493";
import { registerRestaurant } from "/src/api/register-restaurant.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
const signUpForm = z.object({
  restaurantName: z.string(),
  managerName: z.string(),
  phone: z.string(),
  email: z.string().email()
});
export function SignUp() {
  _s();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm();
  const { mutateAsync: registerRestaurantFn } = useMutation({
    mutationFn: registerRestaurant
  });
  const handleSignUp = async (data) => {
    try {
      await registerRestaurantFn({
        restaurantName: data.restaurantName,
        managerName: data.managerName,
        email: data.email,
        phone: data.phone
      });
      console.log(data);
      toast.success("Restaurante cadastrado com sucesso!", {
        action: {
          label: "Login",
          onClick: () => navigate(`/sign-in?email=${data.email}`)
        }
      });
    } catch (error) {
      toast.error("Erro ao cadastrar restaurante.");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "Cadastro" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV(Button, { asChild: true, variant: "ghost", className: "absolute right-8 top-8", children: /* @__PURE__ */ jsxDEV(Link, { to: "/sign-in", children: "Fazer login" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
        lineNumber: 60,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex w-[350px] flex-col justify-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "tracking-title text-2xl font-semibold", children: "Criar conta grátis" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 64,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Seja um parceio e comece suas vendas!" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 67,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
          lineNumber: 63,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleSubmit(handleSignUp), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "restaurantName", children: "Nome do estabelecimento" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 73,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                id: "restaurantName",
                type: "text",
                ...register("restaurantName")
              },
              void 0,
              false,
              {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
                lineNumber: 74,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 72,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "managerName", children: "Seu nome" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 82,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                id: "managerName",
                type: "text",
                ...register("managerName")
              },
              void 0,
              false,
              {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
                lineNumber: 83,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 81,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Seu e-mail" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 91,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "email", type: "email", ...register("email") }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 92,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 90,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "phone", children: "Seu celular" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 96,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "phone", type: "tel", ...register("phone") }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 97,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 95,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: isSubmitting, className: "w-full", type: "submit", children: "Finalizar cadastrado" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 99,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "px-6 text-center text-sm leading-relaxed text-muted-foreground", children: [
            "Ao continuar, você concorda com nossos",
            " ",
            /* @__PURE__ */ jsxDEV("a", { href: "#", className: "underline underline-offset-2", children: "Termos de seviço" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 105,
              columnNumber: 15
            }, this),
            " ",
            "e",
            " ",
            /* @__PURE__ */ jsxDEV("a", { href: "#", className: "underline underline-offset-2", children: "políticas de privacidade" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
              lineNumber: 109,
              columnNumber: 15
            }, this),
            "."
          ] }, void 0, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
            lineNumber: 103,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
          lineNumber: 71,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
      lineNumber: 58,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx",
    lineNumber: 56,
    columnNumber: 5
  }, this);
}
_s(SignUp, "zTCo5ErmhzsqMvwroFEB3svgwTQ=", false, function() {
  return [useNavigate, useForm, useMutation];
});
_c = SignUp;
var _c;
$RefreshReg$(_c, "SignUp");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-up.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURJLG1CQUNFLGNBREY7MkJBdkRKO0FBQW9CLG9CQUFRLDZCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuRCxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsU0FBUztBQUVsQixTQUFTQywwQkFBMEI7QUFDbkMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFFdEIsTUFBTUMsYUFBYUwsRUFBRU0sT0FBTztBQUFBLEVBQzFCQyxnQkFBZ0JQLEVBQUVRLE9BQU87QUFBQSxFQUN6QkMsYUFBYVQsRUFBRVEsT0FBTztBQUFBLEVBQ3RCRSxPQUFPVixFQUFFUSxPQUFPO0FBQUEsRUFDaEJHLE9BQU9YLEVBQUVRLE9BQU8sRUFBRUcsTUFBTTtBQUMxQixDQUFDO0FBSU0sZ0JBQVNDLFNBQVM7QUFBQUMsS0FBQTtBQUN2QixRQUFNQyxXQUFXaEIsWUFBWTtBQUU3QixRQUFNO0FBQUEsSUFDSmlCO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVcsRUFBRUMsYUFBYTtBQUFBLEVBQzVCLElBQUl0QixRQUFvQjtBQUV4QixRQUFNLEVBQUV1QixhQUFhQyxxQkFBcUIsSUFBSUMsWUFBWTtBQUFBLElBQ3hEQyxZQUFZckI7QUFBQUEsRUFDZCxDQUFDO0FBRUQsUUFBTXNCLGVBQWUsT0FBT0MsU0FBcUI7QUFDL0MsUUFBSTtBQUNGLFlBQU1KLHFCQUFxQjtBQUFBLFFBQ3pCYixnQkFBZ0JpQixLQUFLakI7QUFBQUEsUUFDckJFLGFBQWFlLEtBQUtmO0FBQUFBLFFBQ2xCRSxPQUFPYSxLQUFLYjtBQUFBQSxRQUNaRCxPQUFPYyxLQUFLZDtBQUFBQSxNQUNkLENBQUM7QUFDRGUsY0FBUUMsSUFBSUYsSUFBSTtBQUNoQnpCLFlBQU00QixRQUFRLHVDQUF1QztBQUFBLFFBQ25EQyxRQUFRO0FBQUEsVUFDTkMsT0FBTztBQUFBLFVBQ1BDLFNBQVNBLE1BQU1oQixTQUFVLGtCQUFpQlUsS0FBS2IsS0FBTSxFQUFDO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFNBQVNvQixPQUFPO0FBQ2RoQyxZQUFNZ0MsTUFBTSxnQ0FBZ0M7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsVUFBTyxPQUFNLGNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQ3hCLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFPLE1BQUMsU0FBUSxTQUFRLFdBQVUsMEJBQ3hDLGlDQUFDLFFBQUssSUFBRyxZQUFXLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCLEtBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHlDQUF1QyxrQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGlDQUErQixxREFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVZixhQUFhTyxZQUFZLEdBQzdEO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsa0JBQWlCLHVDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBQ3ZEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTCxHQUFJUixTQUFTLGdCQUFnQjtBQUFBO0FBQUEsY0FIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR2lDO0FBQUEsZUFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsZUFBYyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUNyQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLElBQUc7QUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsR0FBSUEsU0FBUyxhQUFhO0FBQUE7QUFBQSxjQUg1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHOEI7QUFBQSxlQUxoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFNBQU0sU0FBUSxTQUFRLDBCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQ2pDLHVCQUFDLFNBQU0sSUFBRyxTQUFRLE1BQUssU0FBUSxHQUFJQSxTQUFTLE9BQU8sS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxlQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFNBQU0sU0FBUSxTQUFRLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQ2xDLHVCQUFDLFNBQU0sSUFBRyxTQUFRLE1BQUssT0FBTSxHQUFJQSxTQUFTLE9BQU8sS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxlQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFVBQVVHLGNBQWMsV0FBVSxVQUFTLE1BQUssVUFBUSxvQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsT0FBRSxXQUFVLGtFQUFnRTtBQUFBO0FBQUEsWUFDcEM7QUFBQSxZQUN2Qyx1QkFBQyxPQUFFLE1BQUssS0FBSSxXQUFVLGdDQUE4QixnQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQUs7QUFBQSxZQUFHO0FBQUEsWUFDTjtBQUFBLFlBQ0YsdUJBQUMsT0FBRSxNQUFLLEtBQUksV0FBVSxnQ0FBOEIsd0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUFHO0FBQUEsZUFSTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJDQTtBQUFBLFdBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxREE7QUFBQSxTQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsT0E1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZEQTtBQUVKO0FBQUNMLEdBakdlRCxRQUFNO0FBQUEsVUFDSGQsYUFNYkYsU0FFMEN5QixXQUFXO0FBQUE7QUFBQVcsS0FUM0NwQjtBQUFNLElBQUFvQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiSGVsbWV0IiwidXNlRm9ybSIsIkxpbmsiLCJ1c2VOYXZpZ2F0ZSIsInRvYXN0IiwieiIsInJlZ2lzdGVyUmVzdGF1cmFudCIsIkJ1dHRvbiIsIklucHV0IiwiTGFiZWwiLCJzaWduVXBGb3JtIiwib2JqZWN0IiwicmVzdGF1cmFudE5hbWUiLCJzdHJpbmciLCJtYW5hZ2VyTmFtZSIsInBob25lIiwiZW1haWwiLCJTaWduVXAiLCJfcyIsIm5hdmlnYXRlIiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJmb3JtU3RhdGUiLCJpc1N1Ym1pdHRpbmciLCJtdXRhdGVBc3luYyIsInJlZ2lzdGVyUmVzdGF1cmFudEZuIiwidXNlTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwiaGFuZGxlU2lnblVwIiwiZGF0YSIsImNvbnNvbGUiLCJsb2ciLCJzdWNjZXNzIiwiYWN0aW9uIiwibGFiZWwiLCJvbkNsaWNrIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInNpZ24tdXAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSAncmVhY3QtaGVsbWV0LWFzeW5jJ1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc29ubmVyJ1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcblxuaW1wb3J0IHsgcmVnaXN0ZXJSZXN0YXVyYW50IH0gZnJvbSAnQC9hcGkvcmVnaXN0ZXItcmVzdGF1cmFudCdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2xhYmVsJ1xuXG5jb25zdCBzaWduVXBGb3JtID0gei5vYmplY3Qoe1xuICByZXN0YXVyYW50TmFtZTogei5zdHJpbmcoKSxcbiAgbWFuYWdlck5hbWU6IHouc3RyaW5nKCksXG4gIHBob25lOiB6LnN0cmluZygpLFxuICBlbWFpbDogei5zdHJpbmcoKS5lbWFpbCgpLFxufSlcblxudHlwZSBTaWduVXBGb3JtID0gei5pbmZlcjx0eXBlb2Ygc2lnblVwRm9ybT5cblxuZXhwb3J0IGZ1bmN0aW9uIFNpZ25VcCgpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG5cbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICBmb3JtU3RhdGU6IHsgaXNTdWJtaXR0aW5nIH0sXG4gIH0gPSB1c2VGb3JtPFNpZ25VcEZvcm0+KClcblxuICBjb25zdCB7IG11dGF0ZUFzeW5jOiByZWdpc3RlclJlc3RhdXJhbnRGbiB9ID0gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IHJlZ2lzdGVyUmVzdGF1cmFudCxcbiAgfSlcblxuICBjb25zdCBoYW5kbGVTaWduVXAgPSBhc3luYyAoZGF0YTogU2lnblVwRm9ybSkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCByZWdpc3RlclJlc3RhdXJhbnRGbih7XG4gICAgICAgIHJlc3RhdXJhbnROYW1lOiBkYXRhLnJlc3RhdXJhbnROYW1lLFxuICAgICAgICBtYW5hZ2VyTmFtZTogZGF0YS5tYW5hZ2VyTmFtZSxcbiAgICAgICAgZW1haWw6IGRhdGEuZW1haWwsXG4gICAgICAgIHBob25lOiBkYXRhLnBob25lLFxuICAgICAgfSlcbiAgICAgIGNvbnNvbGUubG9nKGRhdGEpXG4gICAgICB0b2FzdC5zdWNjZXNzKCdSZXN0YXVyYW50ZSBjYWRhc3RyYWRvIGNvbSBzdWNlc3NvIScsIHtcbiAgICAgICAgYWN0aW9uOiB7XG4gICAgICAgICAgbGFiZWw6ICdMb2dpbicsXG4gICAgICAgICAgb25DbGljazogKCkgPT4gbmF2aWdhdGUoYC9zaWduLWluP2VtYWlsPSR7ZGF0YS5lbWFpbH1gKSxcbiAgICAgICAgfSxcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRvYXN0LmVycm9yKCdFcnJvIGFvIGNhZGFzdHJhciByZXN0YXVyYW50ZS4nKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxIZWxtZXQgdGl0bGU9XCJDYWRhc3Ryb1wiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOFwiPlxuICAgICAgICA8QnV0dG9uIGFzQ2hpbGQgdmFyaWFudD1cImdob3N0XCIgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtOCB0b3AtOFwiPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL3NpZ24taW5cIj5GYXplciBsb2dpbjwvTGluaz5cbiAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LVszNTBweF0gZmxleC1jb2wganVzdGlmeS1jZW50ZXIgZ2FwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0cmFja2luZy10aXRsZSB0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgIENyaWFyIGNvbnRhIGdyw6F0aXNcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICBTZWphIHVtIHBhcmNlaW8gZSBjb21lY2Ugc3VhcyB2ZW5kYXMhXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChoYW5kbGVTaWduVXApfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwicmVzdGF1cmFudE5hbWVcIj5Ob21lIGRvIGVzdGFiZWxlY2ltZW50bzwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwicmVzdGF1cmFudE5hbWVcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ3Jlc3RhdXJhbnROYW1lJyl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJtYW5hZ2VyTmFtZVwiPlNldSBub21lPC9MYWJlbD5cbiAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgaWQ9XCJtYW5hZ2VyTmFtZVwiXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcignbWFuYWdlck5hbWUnKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+U2V1IGUtbWFpbDwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dCBpZD1cImVtYWlsXCIgdHlwZT1cImVtYWlsXCIgey4uLnJlZ2lzdGVyKCdlbWFpbCcpfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwicGhvbmVcIj5TZXUgY2VsdWxhcjwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dCBpZD1cInBob25lXCIgdHlwZT1cInRlbFwiIHsuLi5yZWdpc3RlcigncGhvbmUnKX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfSBjbGFzc05hbWU9XCJ3LWZ1bGxcIiB0eXBlPVwic3VibWl0XCI+XG4gICAgICAgICAgICAgIEZpbmFsaXphciBjYWRhc3RyYWRvXG4gICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicHgtNiB0ZXh0LWNlbnRlciB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgQW8gY29udGludWFyLCB2b2PDqiBjb25jb3JkYSBjb20gbm9zc29zeycgJ31cbiAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJ1bmRlcmxpbmUgdW5kZXJsaW5lLW9mZnNldC0yXCI+XG4gICAgICAgICAgICAgICAgVGVybW9zIGRlIHNldmnDp29cbiAgICAgICAgICAgICAgPC9hPnsnICd9XG4gICAgICAgICAgICAgIGV7JyAnfVxuICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTJcIj5cbiAgICAgICAgICAgICAgICBwb2zDrXRpY2FzIGRlIHByaXZhY2lkYWRlXG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKVxufVxuIl0sImZpbGUiOiIvaG9tZS9ydWFucGFibG8vaWduaXRlL3JlYWN0anMvZGFzaGJvYXJkL3NyYy9wYWdlcy9hdXRoL3NpZ24tdXAudHN4In0=