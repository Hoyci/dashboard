import {
  require_react
} from "/node_modules/.vite/deps/chunk-KXJ7H7NM.js?v=cab43493";
import "/node_modules/.vite/deps/chunk-TIUEEL27.js?v=cab43493";
export default require_react();
//# sourceMappingURL=react.js.map
