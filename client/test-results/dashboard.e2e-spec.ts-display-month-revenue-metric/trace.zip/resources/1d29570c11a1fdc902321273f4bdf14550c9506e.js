import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/header.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Home, Pizza, UtensilsCrossed } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { AccountMenu } from "/src/components/account-menu.tsx";
import { NavLink } from "/src/components/nav-link.tsx";
import { ThemeToggle } from "/src/components/theme/theme-toggle.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
export function Header() {
  return /* @__PURE__ */ jsxDEV("div", { className: "border-b", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-16 items-center gap-6 px-6", children: [
    /* @__PURE__ */ jsxDEV(Pizza, { className: "h-6 w-6" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
      lineNumber: 12,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Separator, { orientation: "vertical", className: "h-6" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
      lineNumber: 13,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "flex items-center space-x-4 lg:space-x-6", children: [
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/", children: [
        /* @__PURE__ */ jsxDEV(Home, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
          lineNumber: 16,
          columnNumber: 13
        }, this),
        "Início"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
        lineNumber: 15,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(NavLink, { to: "/orders", children: [
        /* @__PURE__ */ jsxDEV(UtensilsCrossed, { className: "h-4 w-4" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
          lineNumber: 20,
          columnNumber: 13
        }, this),
        "Pedidos"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
        lineNumber: 19,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
      lineNumber: 14,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ml-auto flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(ThemeToggle, {}, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
        lineNumber: 25,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(AccountMenu, {}, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
        lineNumber: 26,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
      lineNumber: 24,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
    lineNumber: 11,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx",
    lineNumber: 10,
    columnNumber: 5
  }, this);
}
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/components/header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1E7QUFYUiwyQkFBc0JBO0FBQXVCLG9CQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUzRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBRW5CLGdCQUFTQyxTQUFTO0FBQ3ZCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFlBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkJBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEI7QUFBQSxJQUMxQix1QkFBQyxhQUFVLGFBQVksWUFBVyxXQUFVLFNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxJQUNqRCx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSw2QkFBQyxXQUFRLElBQUcsS0FDVjtBQUFBLCtCQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUE7QUFBQSxXQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFdBQVEsSUFBRyxXQUNWO0FBQUEsK0JBQUMsbUJBQWdCLFdBQVUsYUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBO0FBQUEsV0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLDZCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWTtBQUFBLE1BQ1osdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZO0FBQUEsU0FGZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtQkE7QUFFSjtBQUFDQyxLQXZCZUQ7QUFBTSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiVXRlbnNpbHNDcm9zc2VkIiwiQWNjb3VudE1lbnUiLCJOYXZMaW5rIiwiVGhlbWVUb2dnbGUiLCJTZXBhcmF0b3IiLCJIZWFkZXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImhlYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSG9tZSwgUGl6emEsIFV0ZW5zaWxzQ3Jvc3NlZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuaW1wb3J0IHsgQWNjb3VudE1lbnUgfSBmcm9tICcuL2FjY291bnQtbWVudSdcbmltcG9ydCB7IE5hdkxpbmsgfSBmcm9tICcuL25hdi1saW5rJ1xuaW1wb3J0IHsgVGhlbWVUb2dnbGUgfSBmcm9tICcuL3RoZW1lL3RoZW1lLXRvZ2dsZSdcbmltcG9ydCB7IFNlcGFyYXRvciB9IGZyb20gJy4vdWkvc2VwYXJhdG9yJ1xuXG5leHBvcnQgZnVuY3Rpb24gSGVhZGVyKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWJcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTE2IGl0ZW1zLWNlbnRlciBnYXAtNiBweC02XCI+XG4gICAgICAgIDxQaXp6YSBjbGFzc05hbWU9XCJoLTYgdy02XCIgLz5cbiAgICAgICAgPFNlcGFyYXRvciBvcmllbnRhdGlvbj1cInZlcnRpY2FsXCIgY2xhc3NOYW1lPVwiaC02XCIgLz5cbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTQgbGc6c3BhY2UteC02XCI+XG4gICAgICAgICAgPE5hdkxpbmsgdG89XCIvXCI+XG4gICAgICAgICAgICA8SG9tZSBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgIEluw61jaW9cbiAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgPE5hdkxpbmsgdG89XCIvb3JkZXJzXCI+XG4gICAgICAgICAgICA8VXRlbnNpbHNDcm9zc2VkIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgUGVkaWRvc1xuICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgPC9uYXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxUaGVtZVRvZ2dsZSAvPlxuICAgICAgICAgIDxBY2NvdW50TWVudSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL2NvbXBvbmVudHMvaGVhZGVyLnRzeCJ9