import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=cab43493";
const statuses = [
  "canceled",
  "delivered",
  "delivering",
  "pending",
  "processing"
];
const orders = Array.from({ length: 60 }).map((_, index) => {
  return {
    orderId: `order-${index + 1}`,
    customerName: `Customer ${index + 1}`,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    total: 2400,
    status: statuses[index % 5]
  };
});
export const getOrdersMock = http.get(
  "/orders",
  async ({ request }) => {
    const { searchParams } = new URL(request.url);
    const pageIndex = searchParams.get("pageIndex") ? Number(searchParams.get("pageIndex")) : 0;
    const customerName = searchParams.get("customerName");
    const orderId = searchParams.get("orderId");
    const status = searchParams.get("status");
    let filteredOrders = orders;
    if (customerName) {
      filteredOrders = filteredOrders.filter(
        (order) => order.customerName.includes(customerName)
      );
    }
    if (orderId) {
      filteredOrders = filteredOrders.filter(
        (order) => order.orderId.includes(orderId)
      );
    }
    if (status) {
      filteredOrders = filteredOrders.filter((order) => order.status === status);
    }
    const paginatedOrders = filteredOrders.slice(
      pageIndex * 10,
      (pageIndex + 1) * 10
    );
    return HttpResponse.json({
      orders: paginatedOrders,
      meta: { pageIndex, perPage: 10, totalCount: filteredOrders.length }
    });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdldC1vcmRlcnMtbW9jay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBodHRwLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdtc3cnXG5cbmltcG9ydCB7IHR5cGUgZ2V0T3JkZXJzUmVzcG9uc2UgfSBmcm9tICcuLi9nZXQtb3JkZXJzJ1xuXG50eXBlIE9yZGVycyA9IGdldE9yZGVyc1Jlc3BvbnNlWydvcmRlcnMnXVxudHlwZSBPcmRlclN0YXR1cyA9IGdldE9yZGVyc1Jlc3BvbnNlWydvcmRlcnMnXVtudW1iZXJdWydzdGF0dXMnXVxuXG5jb25zdCBzdGF0dXNlczogT3JkZXJTdGF0dXNbXSA9IFtcbiAgJ2NhbmNlbGVkJyxcbiAgJ2RlbGl2ZXJlZCcsXG4gICdkZWxpdmVyaW5nJyxcbiAgJ3BlbmRpbmcnLFxuICAncHJvY2Vzc2luZycsXG5dXG5cbmNvbnN0IG9yZGVyczogT3JkZXJzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogNjAgfSkubWFwKChfLCBpbmRleCkgPT4ge1xuICByZXR1cm4ge1xuICAgIG9yZGVySWQ6IGBvcmRlci0ke2luZGV4ICsgMX1gLFxuICAgIGN1c3RvbWVyTmFtZTogYEN1c3RvbWVyICR7aW5kZXggKyAxfWAsXG4gICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdG90YWw6IDI0MDAsXG4gICAgc3RhdHVzOiBzdGF0dXNlc1tpbmRleCAlIDVdLFxuICB9XG59KVxuXG5leHBvcnQgY29uc3QgZ2V0T3JkZXJzTW9jayA9IGh0dHAuZ2V0PG5ldmVyLCBuZXZlciwgZ2V0T3JkZXJzUmVzcG9uc2U+KFxuICAnL29yZGVycycsXG4gIGFzeW5jICh7IHJlcXVlc3QgfSkgPT4ge1xuICAgIGNvbnN0IHsgc2VhcmNoUGFyYW1zIH0gPSBuZXcgVVJMKHJlcXVlc3QudXJsKVxuICAgIGNvbnN0IHBhZ2VJbmRleCA9IHNlYXJjaFBhcmFtcy5nZXQoJ3BhZ2VJbmRleCcpXG4gICAgICA/IE51bWJlcihzZWFyY2hQYXJhbXMuZ2V0KCdwYWdlSW5kZXgnKSlcbiAgICAgIDogMFxuXG4gICAgY29uc3QgY3VzdG9tZXJOYW1lID0gc2VhcmNoUGFyYW1zLmdldCgnY3VzdG9tZXJOYW1lJylcbiAgICBjb25zdCBvcmRlcklkID0gc2VhcmNoUGFyYW1zLmdldCgnb3JkZXJJZCcpXG4gICAgY29uc3Qgc3RhdHVzID0gc2VhcmNoUGFyYW1zLmdldCgnc3RhdHVzJylcblxuICAgIGxldCBmaWx0ZXJlZE9yZGVycyA9IG9yZGVyc1xuXG4gICAgaWYgKGN1c3RvbWVyTmFtZSkge1xuICAgICAgZmlsdGVyZWRPcmRlcnMgPSBmaWx0ZXJlZE9yZGVycy5maWx0ZXIoKG9yZGVyKSA9PlxuICAgICAgICBvcmRlci5jdXN0b21lck5hbWUuaW5jbHVkZXMoY3VzdG9tZXJOYW1lKSxcbiAgICAgIClcbiAgICB9XG5cbiAgICBpZiAob3JkZXJJZCkge1xuICAgICAgZmlsdGVyZWRPcmRlcnMgPSBmaWx0ZXJlZE9yZGVycy5maWx0ZXIoKG9yZGVyKSA9PlxuICAgICAgICBvcmRlci5vcmRlcklkLmluY2x1ZGVzKG9yZGVySWQpLFxuICAgICAgKVxuICAgIH1cblxuICAgIGlmIChzdGF0dXMpIHtcbiAgICAgIGZpbHRlcmVkT3JkZXJzID0gZmlsdGVyZWRPcmRlcnMuZmlsdGVyKChvcmRlcikgPT4gb3JkZXIuc3RhdHVzID09PSBzdGF0dXMpXG4gICAgfVxuXG4gICAgY29uc3QgcGFnaW5hdGVkT3JkZXJzID0gZmlsdGVyZWRPcmRlcnMuc2xpY2UoXG4gICAgICBwYWdlSW5kZXggKiAxMCxcbiAgICAgIChwYWdlSW5kZXggKyAxKSAqIDEwLFxuICAgIClcblxuICAgIHJldHVybiBIdHRwUmVzcG9uc2UuanNvbih7XG4gICAgICBvcmRlcnM6IHBhZ2luYXRlZE9yZGVycyxcbiAgICAgIG1ldGE6IHsgcGFnZUluZGV4LCBwZXJQYWdlOiAxMCwgdG90YWxDb3VudDogZmlsdGVyZWRPcmRlcnMubGVuZ3RoIH0sXG4gICAgfSlcbiAgfSxcbilcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG9CQUFvQjtBQU9uQyxNQUFNLFdBQTBCO0FBQUEsRUFDOUI7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0Y7QUFFQSxNQUFNLFNBQWlCLE1BQU0sS0FBSyxFQUFFLFFBQVEsR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsVUFBVTtBQUNsRSxTQUFPO0FBQUEsSUFDTCxTQUFTLFNBQVMsUUFBUSxDQUFDO0FBQUEsSUFDM0IsY0FBYyxZQUFZLFFBQVEsQ0FBQztBQUFBLElBQ25DLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxPQUFPO0FBQUEsSUFDUCxRQUFRLFNBQVMsUUFBUSxDQUFDO0FBQUEsRUFDNUI7QUFDRixDQUFDO0FBRU0sYUFBTSxnQkFBZ0IsS0FBSztBQUFBLEVBQ2hDO0FBQUEsRUFDQSxPQUFPLEVBQUUsUUFBUSxNQUFNO0FBQ3JCLFVBQU0sRUFBRSxhQUFhLElBQUksSUFBSSxJQUFJLFFBQVEsR0FBRztBQUM1QyxVQUFNLFlBQVksYUFBYSxJQUFJLFdBQVcsSUFDMUMsT0FBTyxhQUFhLElBQUksV0FBVyxDQUFDLElBQ3BDO0FBRUosVUFBTSxlQUFlLGFBQWEsSUFBSSxjQUFjO0FBQ3BELFVBQU0sVUFBVSxhQUFhLElBQUksU0FBUztBQUMxQyxVQUFNLFNBQVMsYUFBYSxJQUFJLFFBQVE7QUFFeEMsUUFBSSxpQkFBaUI7QUFFckIsUUFBSSxjQUFjO0FBQ2hCLHVCQUFpQixlQUFlO0FBQUEsUUFBTyxDQUFDLFVBQ3RDLE1BQU0sYUFBYSxTQUFTLFlBQVk7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFFQSxRQUFJLFNBQVM7QUFDWCx1QkFBaUIsZUFBZTtBQUFBLFFBQU8sQ0FBQyxVQUN0QyxNQUFNLFFBQVEsU0FBUyxPQUFPO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBRUEsUUFBSSxRQUFRO0FBQ1YsdUJBQWlCLGVBQWUsT0FBTyxDQUFDLFVBQVUsTUFBTSxXQUFXLE1BQU07QUFBQSxJQUMzRTtBQUVBLFVBQU0sa0JBQWtCLGVBQWU7QUFBQSxNQUNyQyxZQUFZO0FBQUEsT0FDWCxZQUFZLEtBQUs7QUFBQSxJQUNwQjtBQUVBLFdBQU8sYUFBYSxLQUFLO0FBQUEsTUFDdkIsUUFBUTtBQUFBLE1BQ1IsTUFBTSxFQUFFLFdBQVcsU0FBUyxJQUFJLFlBQVksZUFBZSxPQUFPO0FBQUEsSUFDcEUsQ0FBQztBQUFBLEVBQ0g7QUFDRjsiLCJuYW1lcyI6W119