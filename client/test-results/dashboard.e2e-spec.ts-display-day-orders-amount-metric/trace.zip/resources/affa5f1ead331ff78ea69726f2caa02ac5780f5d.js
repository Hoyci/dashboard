import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/orders/order-table-filters.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=cab43493";
import { Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { Controller, useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=cab43493";
import { useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cab43493";
import { z } from "/node_modules/.vite/deps/zod.js?v=cab43493";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
const orderFiltersSchema = z.object({
  orderId: z.string().optional(),
  customerName: z.string().optional(),
  status: z.string().optional()
});
export function OrderTableFilters() {
  _s();
  const [searchParams, setSearchParams] = useSearchParams();
  const orderId = searchParams.get("orderId");
  const customerName = searchParams.get("customerName");
  const status = searchParams.get("status");
  const { register, handleSubmit, control, reset } = useForm(
    {
      resolver: zodResolver(orderFiltersSchema),
      defaultValues: {
        orderId: orderId ?? "",
        customerName: customerName ?? "",
        status: status ?? "all"
      }
    }
  );
  const handleFilter = ({
    orderId: orderId2,
    customerName: customerName2,
    status: status2
  }) => {
    setSearchParams((state) => {
      if (orderId2) {
        state.set("orderId", orderId2);
      } else {
        state.delete("orderId");
      }
      if (customerName2) {
        state.set("customerName", customerName2);
      } else {
        state.delete("customerName");
      }
      if (status2) {
        state.set("status", status2);
      } else {
        state.delete("status");
      }
      state.set("page", "1");
      console.log(state.get("customerName"));
      return state;
    });
  };
  const handleClearFilters = () => {
    setSearchParams((state) => {
      state.delete("orderId");
      state.delete("customerName");
      state.delete("status");
      state.set("page", "1");
      return state;
    });
    reset({
      orderId: "",
      customerName: "",
      status: "all"
    });
  };
  return /* @__PURE__ */ jsxDEV(
    "form",
    {
      onSubmit: handleSubmit(handleFilter),
      className: "flex items-center gap-2",
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold", children: "Filtros: " }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
          lineNumber: 97,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "ID do pedido",
            className: "h-8 w-auto",
            ...register("orderId")
          },
          void 0,
          false,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 99,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "Nome do cliente",
            className: "h-8 w-[320px]",
            ...register("customerName")
          },
          void 0,
          false,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 105,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Controller,
          {
            name: "status",
            control,
            render: ({ field: { name, onChange, value, disabled } }) => {
              return /* @__PURE__ */ jsxDEV(
                Select,
                {
                  defaultValue: "all",
                  name,
                  onValueChange: onChange,
                  value,
                  disabled,
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 w-[160px]", children: /* @__PURE__ */ jsxDEV(SelectValue, {}, void 0, false, {
                      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 124,
                      columnNumber: 17
                    }, this) }, void 0, false, {
                      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 123,
                      columnNumber: 15
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "Todos" }, void 0, false, {
                        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 127,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "pending", children: "Pendente" }, void 0, false, {
                        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 128,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "canceled", children: "Cancelado" }, void 0, false, {
                        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 129,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "processing", children: "Em preparo" }, void 0, false, {
                        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 130,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "delivering", children: "Em entrega" }, void 0, false, {
                        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 131,
                        columnNumber: 17
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "delivered", children: "Entregue" }, void 0, false, {
                        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                        lineNumber: 132,
                        columnNumber: 17
                      }, this)
                    ] }, void 0, true, {
                      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                      lineNumber: 126,
                      columnNumber: 15
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                  lineNumber: 116,
                  columnNumber: 13
                },
                this
              );
            }
          },
          void 0,
          false,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 111,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "secondary", size: "xs", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "mr-2 h-4 w-4" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 140,
            columnNumber: 9
          }, this),
          "Filtrar resultado"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
          lineNumber: 139,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: handleClearFilters,
            type: "button",
            variant: "outline",
            size: "xs",
            children: [
              /* @__PURE__ */ jsxDEV(X, { className: "mr-2 h-4 w-4" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
                lineNumber: 150,
                columnNumber: 9
              }, this),
              "Remover filtros"
            ]
          },
          void 0,
          true,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
            lineNumber: 144,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx",
      lineNumber: 93,
      columnNumber: 5
    },
    this
  );
}
_s(OrderTableFilters, "feHCo+4TPh8lpkrfrpltwU9U2Mo=", false, function() {
  return [useSearchParams, useForm];
});
_c = OrderTableFilters;
var _c;
$RefreshReg$(_c, "OrderTableFilters");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/orders/order-table-filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0dNOzJCQWhHTjtBQUFvQixvQkFBUSw2QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDckQsU0FBU0EsUUFBUUMsU0FBUztBQUMxQixTQUFTQyxZQUFZQyxlQUFlO0FBQ3BDLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxTQUFTO0FBRWxCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxxQkFBcUJSLEVBQUVTLE9BQU87QUFBQSxFQUNsQ0MsU0FBU1YsRUFBRVcsT0FBTyxFQUFFQyxTQUFTO0FBQUEsRUFDN0JDLGNBQWNiLEVBQUVXLE9BQU8sRUFBRUMsU0FBUztBQUFBLEVBQ2xDRSxRQUFRZCxFQUFFVyxPQUFPLEVBQUVDLFNBQVM7QUFDOUIsQ0FBQztBQUlNLGdCQUFTRyxvQkFBb0I7QUFBQUMsS0FBQTtBQUNsQyxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSW5CLGdCQUFnQjtBQUV4RCxRQUFNVyxVQUFVTyxhQUFhRSxJQUFJLFNBQVM7QUFDMUMsUUFBTU4sZUFBZUksYUFBYUUsSUFBSSxjQUFjO0FBQ3BELFFBQU1MLFNBQVNHLGFBQWFFLElBQUksUUFBUTtBQUV4QyxRQUFNLEVBQUVDLFVBQVVDLGNBQWNDLFNBQVNDLE1BQU0sSUFBSXpCO0FBQUFBLElBQ2pEO0FBQUEsTUFDRTBCLFVBQVVDLFlBQVlqQixrQkFBa0I7QUFBQSxNQUN4Q2tCLGVBQWU7QUFBQSxRQUNiaEIsU0FBU0EsV0FBVztBQUFBLFFBQ3BCRyxjQUFjQSxnQkFBZ0I7QUFBQSxRQUM5QkMsUUFBUUEsVUFBVTtBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNYSxlQUFlQSxDQUFDO0FBQUEsSUFDcEJqQjtBQUFBQSxJQUNBRztBQUFBQSxJQUNBQztBQUFBQSxFQUNpQixNQUFNO0FBQ3ZCSSxvQkFBZ0IsQ0FBQ1UsVUFBVTtBQUN6QixVQUFJbEIsVUFBUztBQUNYa0IsY0FBTUMsSUFBSSxXQUFXbkIsUUFBTztBQUFBLE1BQzlCLE9BQU87QUFDTGtCLGNBQU1FLE9BQU8sU0FBUztBQUFBLE1BQ3hCO0FBRUEsVUFBSWpCLGVBQWM7QUFDaEJlLGNBQU1DLElBQUksZ0JBQWdCaEIsYUFBWTtBQUFBLE1BQ3hDLE9BQU87QUFDTGUsY0FBTUUsT0FBTyxjQUFjO0FBQUEsTUFDN0I7QUFFQSxVQUFJaEIsU0FBUTtBQUNWYyxjQUFNQyxJQUFJLFVBQVVmLE9BQU07QUFBQSxNQUM1QixPQUFPO0FBQ0xjLGNBQU1FLE9BQU8sUUFBUTtBQUFBLE1BQ3ZCO0FBRUFGLFlBQU1DLElBQUksUUFBUSxHQUFHO0FBRXJCRSxjQUFRQyxJQUFJSixNQUFNVCxJQUFJLGNBQWMsQ0FBQztBQUVyQyxhQUFPUztBQUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUsscUJBQXFCQSxNQUFNO0FBQy9CZixvQkFBZ0IsQ0FBQ1UsVUFBVTtBQUN6QkEsWUFBTUUsT0FBTyxTQUFTO0FBQ3RCRixZQUFNRSxPQUFPLGNBQWM7QUFDM0JGLFlBQU1FLE9BQU8sUUFBUTtBQUNyQkYsWUFBTUMsSUFBSSxRQUFRLEdBQUc7QUFFckIsYUFBT0Q7QUFBQUEsSUFDVCxDQUFDO0FBRURMLFVBQU07QUFBQSxNQUNKYixTQUFTO0FBQUEsTUFDVEcsY0FBYztBQUFBLE1BQ2RDLFFBQVE7QUFBQSxJQUNWLENBQUM7QUFBQSxFQUNIO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsVUFBVU8sYUFBYU0sWUFBWTtBQUFBLE1BQ25DLFdBQVU7QUFBQSxNQUVWO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHlCQUF3Qix5QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBRWpEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUEsWUFDVixHQUFJUCxTQUFTLFNBQVM7QUFBQTtBQUFBLFVBSHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcwQjtBQUFBLFFBRzFCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUEsWUFDVixHQUFJQSxTQUFTLGNBQWM7QUFBQTtBQUFBLFVBSDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcrQjtBQUFBLFFBRy9CO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTDtBQUFBLFlBQ0EsUUFBUSxDQUFDLEVBQUVjLE9BQU8sRUFBRUMsTUFBTUMsVUFBVUMsT0FBT0MsU0FBUyxFQUFFLE1BQU07QUFDMUQscUJBQ0U7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsY0FBYTtBQUFBLGtCQUNiO0FBQUEsa0JBQ0EsZUFBZUY7QUFBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLGtCQUVBO0FBQUEsMkNBQUMsaUJBQWMsV0FBVSxpQkFDdkIsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxpQkFDQztBQUFBLDZDQUFDLGNBQVcsT0FBTSxPQUFNLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBLHNCQUM3Qix1QkFBQyxjQUFXLE9BQU0sV0FBVSx3QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0M7QUFBQSxzQkFDcEMsdUJBQUMsY0FBVyxPQUFNLFlBQVcseUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEsc0JBQ3RDLHVCQUFDLGNBQVcsT0FBTSxjQUFhLDBCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxjQUFXLE9BQU0sY0FBYSwwQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUM7QUFBQSxzQkFDekMsdUJBQUMsY0FBVyxPQUFNLGFBQVksd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEseUJBTnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQTtBQUFBO0FBQUEsZ0JBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWtCQTtBQUFBLFlBRUo7QUFBQTtBQUFBLFVBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXlCSTtBQUFBLFFBR0osdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxhQUFZLE1BQUssTUFDN0M7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsa0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUE7QUFBQSxhQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTSDtBQUFBQSxZQUNULE1BQUs7QUFBQSxZQUNMLFNBQVE7QUFBQSxZQUNSLE1BQUs7QUFBQSxZQUVMO0FBQUEscUNBQUMsS0FBRSxXQUFVLGtCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQTtBQUFBO0FBQUEsSUEzREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBNERBO0FBRUo7QUFBQ2pCLEdBbEllRCxtQkFBaUI7QUFBQSxVQUNTaEIsaUJBTVdELE9BQU87QUFBQTtBQUFBeUMsS0FQNUN4QjtBQUFpQixJQUFBd0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNlYXJjaCIsIlgiLCJDb250cm9sbGVyIiwidXNlRm9ybSIsInVzZVNlYXJjaFBhcmFtcyIsInoiLCJCdXR0b24iLCJJbnB1dCIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwib3JkZXJGaWx0ZXJzU2NoZW1hIiwib2JqZWN0Iiwib3JkZXJJZCIsInN0cmluZyIsIm9wdGlvbmFsIiwiY3VzdG9tZXJOYW1lIiwic3RhdHVzIiwiT3JkZXJUYWJsZUZpbHRlcnMiLCJfcyIsInNlYXJjaFBhcmFtcyIsInNldFNlYXJjaFBhcmFtcyIsImdldCIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwiY29udHJvbCIsInJlc2V0IiwicmVzb2x2ZXIiLCJ6b2RSZXNvbHZlciIsImRlZmF1bHRWYWx1ZXMiLCJoYW5kbGVGaWx0ZXIiLCJzdGF0ZSIsInNldCIsImRlbGV0ZSIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVDbGVhckZpbHRlcnMiLCJmaWVsZCIsIm5hbWUiLCJvbkNoYW5nZSIsInZhbHVlIiwiZGlzYWJsZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9yZGVyLXRhYmxlLWZpbHRlcnMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnXG5pbXBvcnQgeyBTZWFyY2gsIFggfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBDb250cm9sbGVyLCB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnXG5cbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZWxlY3QnXG5cbmNvbnN0IG9yZGVyRmlsdGVyc1NjaGVtYSA9IHoub2JqZWN0KHtcbiAgb3JkZXJJZDogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxuICBjdXN0b21lck5hbWU6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcbiAgc3RhdHVzOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXG59KVxuXG50eXBlIE9yZGVyRmlsdGVyU2NoZW1hID0gei5pbmZlcjx0eXBlb2Ygb3JkZXJGaWx0ZXJzU2NoZW1hPlxuXG5leHBvcnQgZnVuY3Rpb24gT3JkZXJUYWJsZUZpbHRlcnMoKSB7XG4gIGNvbnN0IFtzZWFyY2hQYXJhbXMsIHNldFNlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKVxuXG4gIGNvbnN0IG9yZGVySWQgPSBzZWFyY2hQYXJhbXMuZ2V0KCdvcmRlcklkJylcbiAgY29uc3QgY3VzdG9tZXJOYW1lID0gc2VhcmNoUGFyYW1zLmdldCgnY3VzdG9tZXJOYW1lJylcbiAgY29uc3Qgc3RhdHVzID0gc2VhcmNoUGFyYW1zLmdldCgnc3RhdHVzJylcblxuICBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIGNvbnRyb2wsIHJlc2V0IH0gPSB1c2VGb3JtPE9yZGVyRmlsdGVyU2NoZW1hPihcbiAgICB7XG4gICAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIob3JkZXJGaWx0ZXJzU2NoZW1hKSxcbiAgICAgIGRlZmF1bHRWYWx1ZXM6IHtcbiAgICAgICAgb3JkZXJJZDogb3JkZXJJZCA/PyAnJyxcbiAgICAgICAgY3VzdG9tZXJOYW1lOiBjdXN0b21lck5hbWUgPz8gJycsXG4gICAgICAgIHN0YXR1czogc3RhdHVzID8/ICdhbGwnLFxuICAgICAgfSxcbiAgICB9LFxuICApXG5cbiAgY29uc3QgaGFuZGxlRmlsdGVyID0gKHtcbiAgICBvcmRlcklkLFxuICAgIGN1c3RvbWVyTmFtZSxcbiAgICBzdGF0dXMsXG4gIH06IE9yZGVyRmlsdGVyU2NoZW1hKSA9PiB7XG4gICAgc2V0U2VhcmNoUGFyYW1zKChzdGF0ZSkgPT4ge1xuICAgICAgaWYgKG9yZGVySWQpIHtcbiAgICAgICAgc3RhdGUuc2V0KCdvcmRlcklkJywgb3JkZXJJZClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0YXRlLmRlbGV0ZSgnb3JkZXJJZCcpXG4gICAgICB9XG5cbiAgICAgIGlmIChjdXN0b21lck5hbWUpIHtcbiAgICAgICAgc3RhdGUuc2V0KCdjdXN0b21lck5hbWUnLCBjdXN0b21lck5hbWUpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdGF0ZS5kZWxldGUoJ2N1c3RvbWVyTmFtZScpXG4gICAgICB9XG5cbiAgICAgIGlmIChzdGF0dXMpIHtcbiAgICAgICAgc3RhdGUuc2V0KCdzdGF0dXMnLCBzdGF0dXMpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdGF0ZS5kZWxldGUoJ3N0YXR1cycpXG4gICAgICB9XG5cbiAgICAgIHN0YXRlLnNldCgncGFnZScsICcxJylcblxuICAgICAgY29uc29sZS5sb2coc3RhdGUuZ2V0KCdjdXN0b21lck5hbWUnKSlcblxuICAgICAgcmV0dXJuIHN0YXRlXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUNsZWFyRmlsdGVycyA9ICgpID0+IHtcbiAgICBzZXRTZWFyY2hQYXJhbXMoKHN0YXRlKSA9PiB7XG4gICAgICBzdGF0ZS5kZWxldGUoJ29yZGVySWQnKVxuICAgICAgc3RhdGUuZGVsZXRlKCdjdXN0b21lck5hbWUnKVxuICAgICAgc3RhdGUuZGVsZXRlKCdzdGF0dXMnKVxuICAgICAgc3RhdGUuc2V0KCdwYWdlJywgJzEnKVxuXG4gICAgICByZXR1cm4gc3RhdGVcbiAgICB9KVxuXG4gICAgcmVzZXQoe1xuICAgICAgb3JkZXJJZDogJycsXG4gICAgICBjdXN0b21lck5hbWU6ICcnLFxuICAgICAgc3RhdHVzOiAnYWxsJyxcbiAgICB9KVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9ybVxuICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChoYW5kbGVGaWx0ZXIpfVxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxuICAgID5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZFwiPkZpbHRyb3M6IDwvc3Bhbj5cblxuICAgICAgPElucHV0XG4gICAgICAgIHBsYWNlaG9sZGVyPVwiSUQgZG8gcGVkaWRvXCJcbiAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctYXV0b1wiXG4gICAgICAgIHsuLi5yZWdpc3Rlcignb3JkZXJJZCcpfVxuICAgICAgLz5cblxuICAgICAgPElucHV0XG4gICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tZSBkbyBjbGllbnRlXCJcbiAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctWzMyMHB4XVwiXG4gICAgICAgIHsuLi5yZWdpc3RlcignY3VzdG9tZXJOYW1lJyl9XG4gICAgICAvPlxuXG4gICAgICA8Q29udHJvbGxlclxuICAgICAgICBuYW1lPVwic3RhdHVzXCJcbiAgICAgICAgY29udHJvbD17Y29udHJvbH1cbiAgICAgICAgcmVuZGVyPXsoeyBmaWVsZDogeyBuYW1lLCBvbkNoYW5nZSwgdmFsdWUsIGRpc2FibGVkIH0gfSkgPT4ge1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT1cImFsbFwiXG4gICAgICAgICAgICAgIG5hbWU9e25hbWV9XG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9e29uQ2hhbmdlfVxuICAgICAgICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC04IHctWzE2MHB4XVwiPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSAvPlxuICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+VG9kb3M8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJwZW5kaW5nXCI+UGVuZGVudGU8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJjYW5jZWxlZFwiPkNhbmNlbGFkbzwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cInByb2Nlc3NpbmdcIj5FbSBwcmVwYXJvPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiZGVsaXZlcmluZ1wiPkVtIGVudHJlZ2E8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJkZWxpdmVyZWRcIj5FbnRyZWd1ZTwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgKVxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgdmFyaWFudD1cInNlY29uZGFyeVwiIHNpemU9XCJ4c1wiPlxuICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XG4gICAgICAgIEZpbHRyYXIgcmVzdWx0YWRvXG4gICAgICA8L0J1dHRvbj5cblxuICAgICAgPEJ1dHRvblxuICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhckZpbHRlcnN9XG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgIHNpemU9XCJ4c1wiXG4gICAgICA+XG4gICAgICAgIDxYIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNFwiIC8+XG4gICAgICAgIFJlbW92ZXIgZmlsdHJvc1xuICAgICAgPC9CdXR0b24+XG4gICAgPC9mb3JtPlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL3BhZ2VzL2FwcC9vcmRlcnMvb3JkZXItdGFibGUtZmlsdGVycy50c3gifQ==