import {
  RequestHandler,
  SetupApi,
  devUtils,
  executeHandlers,
  handleRequest,
  invariant,
  store,
  toPublicUrl
} from "/node_modules/.vite/deps/chunk-V3RC637G.js?v=cab43493";
import {
  __publicField
} from "/node_modules/.vite/deps/chunk-TIUEEL27.js?v=cab43493";
function checkGlobals() {
  invariant(
    typeof URL !== "undefined",
    devUtils.formatMessage(
      `Global "URL" class is not defined. This likely means that you're running MSW in an environment that doesn't support all Node.js standard API (e.g. React Native). If that's the case, please use an appropriate polyfill for the "URL" class, like "react-native-url-polyfill".`
    )
  );
}
function isStringEqual(actual, expected) {
  return actual.toLowerCase() === expected.toLowerCase();
}
var StatusCodeColor = ((StatusCodeColor2) => {
  StatusCodeColor2["Success"] = "#69AB32";
  StatusCodeColor2["Warning"] = "#F0BB4B";
  StatusCodeColor2["Danger"] = "#E95F5D";
  return StatusCodeColor2;
})(StatusCodeColor || {});
function getStatusCodeColor(status) {
  if (status < 300) {
    return "#69AB32";
  }
  if (status < 400) {
    return "#F0BB4B";
  }
  return "#E95F5D";
}
function getTimestamp() {
  const now = /* @__PURE__ */ new Date();
  return [now.getHours(), now.getMinutes(), now.getSeconds()].map(String).map((chunk) => chunk.slice(0, 2)).map((chunk) => chunk.padStart(2, "0")).join(":");
}
async function serializeRequest(request) {
  const requestClone = request.clone();
  const requestText = await requestClone.text();
  return {
    url: new URL(request.url),
    method: request.method,
    headers: Object.fromEntries(request.headers.entries()),
    body: requestText
  };
}
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_codes = __commonJS({
  "node_modules/statuses/codes.json"(exports, module) {
    module.exports = {
      "100": "Continue",
      "101": "Switching Protocols",
      "102": "Processing",
      "103": "Early Hints",
      "200": "OK",
      "201": "Created",
      "202": "Accepted",
      "203": "Non-Authoritative Information",
      "204": "No Content",
      "205": "Reset Content",
      "206": "Partial Content",
      "207": "Multi-Status",
      "208": "Already Reported",
      "226": "IM Used",
      "300": "Multiple Choices",
      "301": "Moved Permanently",
      "302": "Found",
      "303": "See Other",
      "304": "Not Modified",
      "305": "Use Proxy",
      "307": "Temporary Redirect",
      "308": "Permanent Redirect",
      "400": "Bad Request",
      "401": "Unauthorized",
      "402": "Payment Required",
      "403": "Forbidden",
      "404": "Not Found",
      "405": "Method Not Allowed",
      "406": "Not Acceptable",
      "407": "Proxy Authentication Required",
      "408": "Request Timeout",
      "409": "Conflict",
      "410": "Gone",
      "411": "Length Required",
      "412": "Precondition Failed",
      "413": "Payload Too Large",
      "414": "URI Too Long",
      "415": "Unsupported Media Type",
      "416": "Range Not Satisfiable",
      "417": "Expectation Failed",
      "418": "I'm a Teapot",
      "421": "Misdirected Request",
      "422": "Unprocessable Entity",
      "423": "Locked",
      "424": "Failed Dependency",
      "425": "Too Early",
      "426": "Upgrade Required",
      "428": "Precondition Required",
      "429": "Too Many Requests",
      "431": "Request Header Fields Too Large",
      "451": "Unavailable For Legal Reasons",
      "500": "Internal Server Error",
      "501": "Not Implemented",
      "502": "Bad Gateway",
      "503": "Service Unavailable",
      "504": "Gateway Timeout",
      "505": "HTTP Version Not Supported",
      "506": "Variant Also Negotiates",
      "507": "Insufficient Storage",
      "508": "Loop Detected",
      "509": "Bandwidth Limit Exceeded",
      "510": "Not Extended",
      "511": "Network Authentication Required"
    };
  }
});
var require_statuses = __commonJS({
  "node_modules/statuses/index.js"(exports, module) {
    "use strict";
    var codes = require_codes();
    module.exports = status2;
    status2.message = codes;
    status2.code = createMessageToStatusCodeMap(codes);
    status2.codes = createStatusCodeList(codes);
    status2.redirect = {
      300: true,
      301: true,
      302: true,
      303: true,
      305: true,
      307: true,
      308: true
    };
    status2.empty = {
      204: true,
      205: true,
      304: true
    };
    status2.retry = {
      502: true,
      503: true,
      504: true
    };
    function createMessageToStatusCodeMap(codes2) {
      var map = {};
      Object.keys(codes2).forEach(function forEachCode(code) {
        var message3 = codes2[code];
        var status3 = Number(code);
        map[message3.toLowerCase()] = status3;
      });
      return map;
    }
    function createStatusCodeList(codes2) {
      return Object.keys(codes2).map(function mapCode(code) {
        return Number(code);
      });
    }
    function getStatusCode(message3) {
      var msg = message3.toLowerCase();
      if (!Object.prototype.hasOwnProperty.call(status2.code, msg)) {
        throw new Error('invalid status message: "' + message3 + '"');
      }
      return status2.code[msg];
    }
    function getStatusMessage(code) {
      if (!Object.prototype.hasOwnProperty.call(status2.message, code)) {
        throw new Error("invalid status code: " + code);
      }
      return status2.message[code];
    }
    function status2(code) {
      if (typeof code === "number") {
        return getStatusMessage(code);
      }
      if (typeof code !== "string") {
        throw new TypeError("code must be a number or string");
      }
      var n = parseInt(code, 10);
      if (!isNaN(n)) {
        return getStatusMessage(n);
      }
      return getStatusCode(code);
    }
  }
});
var import_statuses = __toESM(require_statuses(), 1);
var source_default = import_statuses.default;
var { message } = source_default;
async function serializeResponse(response) {
  const responseClone = response.clone();
  const responseText = await responseClone.text();
  const responseStatus = responseClone.status || 200;
  const responseStatusText = responseClone.statusText || message[responseStatus] || "OK";
  return {
    status: responseStatus,
    statusText: responseStatusText,
    headers: Object.fromEntries(responseClone.headers.entries()),
    body: responseText
  };
}
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a2 = options.prefixes, prefixes = _a2 === void 0 ? "./" : _a2;
  var defaultPattern = "[^".concat(escapeString(options.delimiter || "/#?"), "]+?");
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  };
  var mustConsume = function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a3 = tokens[i], nextType = _a3.type, index = _a3.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  };
  var consumeText = function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  };
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || defaultPattern,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? defaultPattern : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a2 = options.decode, decode = _a2 === void 0 ? function(x) {
    return x;
  } : _a2;
  return function(pathname) {
    var m = re.exec(pathname);
    if (!m)
      return false;
    var path = m[0], index = m.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = function(i2) {
      if (m[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m[i2], key);
      }
    };
    for (var i = 1; i < m.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a2 = options.strict, strict = _a2 === void 0 ? false : _a2, _b2 = options.start, start = _b2 === void 0 ? true : _b2, _c2 = options.end, end = _c2 === void 0 ? true : _c2, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            route += "((?:".concat(token.pattern, ")").concat(token.modifier, ")");
          } else {
            route += "(".concat(token.pattern, ")").concat(token.modifier);
          }
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
var encoder = new TextEncoder();
var IS_PATCHED_MODULE = Symbol("isPatchedModule");
function isNodeProcess() {
  if (typeof navigator !== "undefined" && navigator.product === "ReactNative") {
    return true;
  }
  if (typeof process !== "undefined") {
    const type = process.type;
    if (type === "renderer" || type === "worker") {
      return false;
    }
    return !!(process.versions && process.versions.node);
  }
  return false;
}
var __defProp2 = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp2(target, name, { get: all[name], enumerable: true });
};
var colors_exports = {};
__export(colors_exports, {
  blue: () => blue,
  gray: () => gray,
  green: () => green,
  red: () => red,
  yellow: () => yellow
});
function yellow(text) {
  return `\x1B[33m${text}\x1B[0m`;
}
function blue(text) {
  return `\x1B[34m${text}\x1B[0m`;
}
function gray(text) {
  return `\x1B[90m${text}\x1B[0m`;
}
function red(text) {
  return `\x1B[31m${text}\x1B[0m`;
}
function green(text) {
  return `\x1B[32m${text}\x1B[0m`;
}
var IS_NODE = isNodeProcess();
var InterceptorReadyState = ((InterceptorReadyState2) => {
  InterceptorReadyState2["INACTIVE"] = "INACTIVE";
  InterceptorReadyState2["APPLYING"] = "APPLYING";
  InterceptorReadyState2["APPLIED"] = "APPLIED";
  InterceptorReadyState2["DISPOSING"] = "DISPOSING";
  InterceptorReadyState2["DISPOSED"] = "DISPOSED";
  return InterceptorReadyState2;
})(InterceptorReadyState || {});
function createRequestId() {
  return Math.random().toString(16).slice(2);
}
function getCleanUrl(url, isAbsolute = true) {
  return [isAbsolute && url.origin, url.pathname].filter(Boolean).join("");
}
var REDUNDANT_CHARACTERS_EXP = /[\?|#].*$/g;
function getSearchParams(path) {
  return new URL(`/${path}`, "http://localhost").searchParams;
}
function cleanUrl(path) {
  return path.replace(REDUNDANT_CHARACTERS_EXP, "");
}
function isAbsoluteUrl(url) {
  return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
}
function getAbsoluteUrl(path, baseUrl) {
  if (isAbsoluteUrl(path)) {
    return path;
  }
  if (path.startsWith("*")) {
    return path;
  }
  const origin = baseUrl || typeof document !== "undefined" && document.baseURI;
  return origin ? (
    // Encode and decode the path to preserve escaped characters.
    decodeURI(new URL(encodeURI(path), origin).href)
  ) : path;
}
function normalizePath(path, baseUrl) {
  if (path instanceof RegExp) {
    return path;
  }
  const maybeAbsoluteUrl = getAbsoluteUrl(path, baseUrl);
  return cleanUrl(maybeAbsoluteUrl);
}
function coercePath(path) {
  return path.replace(
    /([:a-zA-Z_-]*)(\*{1,2})+/g,
    (_, parameterName, wildcard) => {
      const expression = "(.*)";
      if (!parameterName) {
        return expression;
      }
      return parameterName.startsWith(":") ? `${parameterName}${wildcard}` : `${parameterName}${expression}`;
    }
  ).replace(/([^\/])(:)(?=\d+)/, "$1\\$2").replace(/^([^\/]+)(:)(?=\/\/)/, "$1\\$2");
}
function matchRequestUrl(url, path, baseUrl) {
  const normalizedPath = normalizePath(path, baseUrl);
  const cleanPath = typeof normalizedPath === "string" ? coercePath(normalizedPath) : normalizedPath;
  const cleanUrl2 = getCleanUrl(url);
  const result = match(cleanPath, { decode: decodeURIComponent })(cleanUrl2);
  const params = result && result.params || {};
  return {
    matches: result !== false,
    params
  };
}
var __create2 = Object.create;
var __defProp3 = Object.defineProperty;
var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
var __getOwnPropNames2 = Object.getOwnPropertyNames;
var __getProtoOf2 = Object.getPrototypeOf;
var __hasOwnProp2 = Object.prototype.hasOwnProperty;
var __commonJS2 = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames2(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps2 = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames2(from))
      if (!__hasOwnProp2.call(to, key) && key !== except)
        __defProp3(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM2 = (mod, isNodeMode, target) => (target = mod != null ? __create2(__getProtoOf2(mod)) : {}, __copyProps2(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp3(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_cookie = __commonJS2({
  "node_modules/cookie/index.js"(exports) {
    "use strict";
    exports.parse = parse3;
    exports.serialize = serialize;
    var __toString = Object.prototype.toString;
    var fieldContentRegExp = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
    function parse3(str, options) {
      if (typeof str !== "string") {
        throw new TypeError("argument str must be a string");
      }
      var obj = {};
      var opt = options || {};
      var dec = opt.decode || decode;
      var index = 0;
      while (index < str.length) {
        var eqIdx = str.indexOf("=", index);
        if (eqIdx === -1) {
          break;
        }
        var endIdx = str.indexOf(";", index);
        if (endIdx === -1) {
          endIdx = str.length;
        } else if (endIdx < eqIdx) {
          index = str.lastIndexOf(";", eqIdx - 1) + 1;
          continue;
        }
        var key = str.slice(index, eqIdx).trim();
        if (void 0 === obj[key]) {
          var val = str.slice(eqIdx + 1, endIdx).trim();
          if (val.charCodeAt(0) === 34) {
            val = val.slice(1, -1);
          }
          obj[key] = tryDecode(val, dec);
        }
        index = endIdx + 1;
      }
      return obj;
    }
    function serialize(name, val, options) {
      var opt = options || {};
      var enc = opt.encode || encode;
      if (typeof enc !== "function") {
        throw new TypeError("option encode is invalid");
      }
      if (!fieldContentRegExp.test(name)) {
        throw new TypeError("argument name is invalid");
      }
      var value = enc(val);
      if (value && !fieldContentRegExp.test(value)) {
        throw new TypeError("argument val is invalid");
      }
      var str = name + "=" + value;
      if (null != opt.maxAge) {
        var maxAge = opt.maxAge - 0;
        if (isNaN(maxAge) || !isFinite(maxAge)) {
          throw new TypeError("option maxAge is invalid");
        }
        str += "; Max-Age=" + Math.floor(maxAge);
      }
      if (opt.domain) {
        if (!fieldContentRegExp.test(opt.domain)) {
          throw new TypeError("option domain is invalid");
        }
        str += "; Domain=" + opt.domain;
      }
      if (opt.path) {
        if (!fieldContentRegExp.test(opt.path)) {
          throw new TypeError("option path is invalid");
        }
        str += "; Path=" + opt.path;
      }
      if (opt.expires) {
        var expires = opt.expires;
        if (!isDate(expires) || isNaN(expires.valueOf())) {
          throw new TypeError("option expires is invalid");
        }
        str += "; Expires=" + expires.toUTCString();
      }
      if (opt.httpOnly) {
        str += "; HttpOnly";
      }
      if (opt.secure) {
        str += "; Secure";
      }
      if (opt.priority) {
        var priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
        switch (priority) {
          case "low":
            str += "; Priority=Low";
            break;
          case "medium":
            str += "; Priority=Medium";
            break;
          case "high":
            str += "; Priority=High";
            break;
          default:
            throw new TypeError("option priority is invalid");
        }
      }
      if (opt.sameSite) {
        var sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
        switch (sameSite) {
          case true:
            str += "; SameSite=Strict";
            break;
          case "lax":
            str += "; SameSite=Lax";
            break;
          case "strict":
            str += "; SameSite=Strict";
            break;
          case "none":
            str += "; SameSite=None";
            break;
          default:
            throw new TypeError("option sameSite is invalid");
        }
      }
      return str;
    }
    function decode(str) {
      return str.indexOf("%") !== -1 ? decodeURIComponent(str) : str;
    }
    function encode(val) {
      return encodeURIComponent(val);
    }
    function isDate(val) {
      return __toString.call(val) === "[object Date]" || val instanceof Date;
    }
    function tryDecode(str, decode2) {
      try {
        return decode2(str);
      } catch (e) {
        return str;
      }
    }
  }
});
var import_cookie = __toESM2(require_cookie(), 1);
var source_default2 = import_cookie.default;
function getAllDocumentCookies() {
  return source_default2.parse(document.cookie);
}
function getRequestCookies(request) {
  if (typeof document === "undefined" || typeof location === "undefined") {
    return {};
  }
  switch (request.credentials) {
    case "same-origin": {
      const url = new URL(request.url);
      return location.origin === url.origin ? getAllDocumentCookies() : {};
    }
    case "include": {
      return getAllDocumentCookies();
    }
    default: {
      return {};
    }
  }
}
function getAllRequestCookies(request) {
  var _a2;
  const requestCookiesString = request.headers.get("cookie");
  const cookiesFromHeaders = requestCookiesString ? source_default2.parse(requestCookiesString) : {};
  store.hydrate();
  const cookiesFromStore = Array.from((_a2 = store.get(request)) == null ? void 0 : _a2.entries()).reduce((cookies, [name, { value }]) => {
    return Object.assign(cookies, { [name.trim()]: value });
  }, {});
  const cookiesFromDocument = getRequestCookies(request);
  const forwardedCookies = {
    ...cookiesFromDocument,
    ...cookiesFromStore
  };
  for (const [name, value] of Object.entries(forwardedCookies)) {
    request.headers.append("cookie", source_default2.serialize(name, value));
  }
  return {
    ...forwardedCookies,
    ...cookiesFromHeaders
  };
}
var HttpMethods = ((HttpMethods2) => {
  HttpMethods2["HEAD"] = "HEAD";
  HttpMethods2["GET"] = "GET";
  HttpMethods2["POST"] = "POST";
  HttpMethods2["PUT"] = "PUT";
  HttpMethods2["PATCH"] = "PATCH";
  HttpMethods2["OPTIONS"] = "OPTIONS";
  HttpMethods2["DELETE"] = "DELETE";
  return HttpMethods2;
})(HttpMethods || {});
var HttpHandler = class extends RequestHandler {
  constructor(method, path, resolver, options) {
    super({
      info: {
        header: `${method} ${path}`,
        path,
        method
      },
      resolver,
      options
    });
    this.checkRedundantQueryParameters();
  }
  checkRedundantQueryParameters() {
    const { method, path } = this.info;
    if (path instanceof RegExp) {
      return;
    }
    const url = cleanUrl(path);
    if (url === path) {
      return;
    }
    const searchParams = getSearchParams(path);
    const queryParams = [];
    searchParams.forEach((_, paramName) => {
      queryParams.push(paramName);
    });
    devUtils.warn(
      `Found a redundant usage of query parameters in the request handler URL for "${method} ${path}". Please match against a path instead and access query parameters using "new URL(request.url).searchParams" instead. Learn more: https://mswjs.io/docs/recipes/query-parameters`
    );
  }
  async parse(args) {
    var _a2;
    const url = new URL(args.request.url);
    const match2 = matchRequestUrl(
      url,
      this.info.path,
      (_a2 = args.resolutionContext) == null ? void 0 : _a2.baseUrl
    );
    const cookies = getAllRequestCookies(args.request);
    return {
      match: match2,
      cookies
    };
  }
  predicate(args) {
    const hasMatchingMethod = this.matchMethod(args.request.method);
    const hasMatchingUrl = args.parsedResult.match.matches;
    return hasMatchingMethod && hasMatchingUrl;
  }
  matchMethod(actualMethod) {
    return this.info.method instanceof RegExp ? this.info.method.test(actualMethod) : isStringEqual(this.info.method, actualMethod);
  }
  extendResolverArgs(args) {
    var _a2;
    return {
      params: ((_a2 = args.parsedResult.match) == null ? void 0 : _a2.params) || {},
      cookies: args.parsedResult.cookies
    };
  }
  async log(args) {
    const publicUrl = toPublicUrl(args.request.url);
    const loggedRequest = await serializeRequest(args.request);
    const loggedResponse = await serializeResponse(args.response);
    const statusColor = getStatusCodeColor(loggedResponse.status);
    console.groupCollapsed(
      devUtils.formatMessage(
        `${getTimestamp()} ${args.request.method} ${publicUrl} (%c${loggedResponse.status} ${loggedResponse.statusText}%c)`
      ),
      `color:${statusColor}`,
      "color:inherit"
    );
    console.log("Request", loggedRequest);
    console.log("Handler:", this);
    console.log("Response", loggedResponse);
    console.groupEnd();
  }
};
function createHttpHandler(method) {
  return (path, resolver, options = {}) => {
    return new HttpHandler(method, path, resolver, options);
  };
}
var http = {
  all: createHttpHandler(/.+/),
  head: createHttpHandler(HttpMethods.HEAD),
  get: createHttpHandler(HttpMethods.GET),
  post: createHttpHandler(HttpMethods.POST),
  put: createHttpHandler(HttpMethods.PUT),
  delete: createHttpHandler(HttpMethods.DELETE),
  patch: createHttpHandler(HttpMethods.PATCH),
  options: createHttpHandler(HttpMethods.OPTIONS)
};
var versionInfo = Object.freeze({
  major: 16,
  minor: 8,
  patch: 1,
  preReleaseTag: null
});
function devAssert(condition, message3) {
  const booleanCondition = Boolean(condition);
  if (!booleanCondition) {
    throw new Error(message3);
  }
}
function isObjectLike(value) {
  return typeof value == "object" && value !== null;
}
function invariant2(condition, message3) {
  const booleanCondition = Boolean(condition);
  if (!booleanCondition) {
    throw new Error(
      message3 != null ? message3 : "Unexpected invariant triggered."
    );
  }
}
var LineRegExp = /\r\n|[\n\r]/g;
function getLocation(source, position) {
  let lastLineStart = 0;
  let line = 1;
  for (const match2 of source.body.matchAll(LineRegExp)) {
    typeof match2.index === "number" || invariant2(false);
    if (match2.index >= position) {
      break;
    }
    lastLineStart = match2.index + match2[0].length;
    line += 1;
  }
  return {
    line,
    column: position + 1 - lastLineStart
  };
}
function printLocation(location2) {
  return printSourceLocation(
    location2.source,
    getLocation(location2.source, location2.start)
  );
}
function printSourceLocation(source, sourceLocation) {
  const firstLineColumnOffset = source.locationOffset.column - 1;
  const body = "".padStart(firstLineColumnOffset) + source.body;
  const lineIndex = sourceLocation.line - 1;
  const lineOffset = source.locationOffset.line - 1;
  const lineNum = sourceLocation.line + lineOffset;
  const columnOffset = sourceLocation.line === 1 ? firstLineColumnOffset : 0;
  const columnNum = sourceLocation.column + columnOffset;
  const locationStr = `${source.name}:${lineNum}:${columnNum}
`;
  const lines = body.split(/\r\n|[\n\r]/g);
  const locationLine = lines[lineIndex];
  if (locationLine.length > 120) {
    const subLineIndex = Math.floor(columnNum / 80);
    const subLineColumnNum = columnNum % 80;
    const subLines = [];
    for (let i = 0; i < locationLine.length; i += 80) {
      subLines.push(locationLine.slice(i, i + 80));
    }
    return locationStr + printPrefixedLines([
      [`${lineNum} |`, subLines[0]],
      ...subLines.slice(1, subLineIndex + 1).map((subLine) => ["|", subLine]),
      ["|", "^".padStart(subLineColumnNum)],
      ["|", subLines[subLineIndex + 1]]
    ]);
  }
  return locationStr + printPrefixedLines([
    // Lines specified like this: ["prefix", "string"],
    [`${lineNum - 1} |`, lines[lineIndex - 1]],
    [`${lineNum} |`, locationLine],
    ["|", "^".padStart(columnNum)],
    [`${lineNum + 1} |`, lines[lineIndex + 1]]
  ]);
}
function printPrefixedLines(lines) {
  const existingLines = lines.filter(([_, line]) => line !== void 0);
  const padLen = Math.max(...existingLines.map(([prefix]) => prefix.length));
  return existingLines.map(([prefix, line]) => prefix.padStart(padLen) + (line ? " " + line : "")).join("\n");
}
function toNormalizedOptions(args) {
  const firstArg = args[0];
  if (firstArg == null || "kind" in firstArg || "length" in firstArg) {
    return {
      nodes: firstArg,
      source: args[1],
      positions: args[2],
      path: args[3],
      originalError: args[4],
      extensions: args[5]
    };
  }
  return firstArg;
}
var GraphQLError = class _GraphQLError extends Error {
  /**
   * An array of `{ line, column }` locations within the source GraphQL document
   * which correspond to this error.
   *
   * Errors during validation often contain multiple locations, for example to
   * point out two things with the same name. Errors during execution include a
   * single location, the field which produced the error.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array describing the JSON-path into the execution response which
   * corresponds to this error. Only included for errors during execution.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array of GraphQL AST Nodes corresponding to this error.
   */
  /**
   * The source GraphQL document for the first location of this error.
   *
   * Note that if this Error represents more than one node, the source may not
   * represent nodes after the first node.
   */
  /**
   * An array of character offsets within the source GraphQL document
   * which correspond to this error.
   */
  /**
   * The original error thrown from a field resolver during execution.
   */
  /**
   * Extension fields to add to the formatted error.
   */
  /**
   * @deprecated Please use the `GraphQLErrorOptions` constructor overload instead.
   */
  constructor(message3, ...rawArgs) {
    var _this$nodes, _nodeLocations$, _ref;
    const { nodes, source, positions, path, originalError, extensions } = toNormalizedOptions(rawArgs);
    super(message3);
    this.name = "GraphQLError";
    this.path = path !== null && path !== void 0 ? path : void 0;
    this.originalError = originalError !== null && originalError !== void 0 ? originalError : void 0;
    this.nodes = undefinedIfEmpty(
      Array.isArray(nodes) ? nodes : nodes ? [nodes] : void 0
    );
    const nodeLocations = undefinedIfEmpty(
      (_this$nodes = this.nodes) === null || _this$nodes === void 0 ? void 0 : _this$nodes.map((node) => node.loc).filter((loc) => loc != null)
    );
    this.source = source !== null && source !== void 0 ? source : nodeLocations === null || nodeLocations === void 0 ? void 0 : (_nodeLocations$ = nodeLocations[0]) === null || _nodeLocations$ === void 0 ? void 0 : _nodeLocations$.source;
    this.positions = positions !== null && positions !== void 0 ? positions : nodeLocations === null || nodeLocations === void 0 ? void 0 : nodeLocations.map((loc) => loc.start);
    this.locations = positions && source ? positions.map((pos) => getLocation(source, pos)) : nodeLocations === null || nodeLocations === void 0 ? void 0 : nodeLocations.map((loc) => getLocation(loc.source, loc.start));
    const originalExtensions = isObjectLike(
      originalError === null || originalError === void 0 ? void 0 : originalError.extensions
    ) ? originalError === null || originalError === void 0 ? void 0 : originalError.extensions : void 0;
    this.extensions = (_ref = extensions !== null && extensions !== void 0 ? extensions : originalExtensions) !== null && _ref !== void 0 ? _ref : /* @__PURE__ */ Object.create(null);
    Object.defineProperties(this, {
      message: {
        writable: true,
        enumerable: true
      },
      name: {
        enumerable: false
      },
      nodes: {
        enumerable: false
      },
      source: {
        enumerable: false
      },
      positions: {
        enumerable: false
      },
      originalError: {
        enumerable: false
      }
    });
    if (originalError !== null && originalError !== void 0 && originalError.stack) {
      Object.defineProperty(this, "stack", {
        value: originalError.stack,
        writable: true,
        configurable: true
      });
    } else if (Error.captureStackTrace) {
      Error.captureStackTrace(this, _GraphQLError);
    } else {
      Object.defineProperty(this, "stack", {
        value: Error().stack,
        writable: true,
        configurable: true
      });
    }
  }
  get [Symbol.toStringTag]() {
    return "GraphQLError";
  }
  toString() {
    let output = this.message;
    if (this.nodes) {
      for (const node of this.nodes) {
        if (node.loc) {
          output += "\n\n" + printLocation(node.loc);
        }
      }
    } else if (this.source && this.locations) {
      for (const location2 of this.locations) {
        output += "\n\n" + printSourceLocation(this.source, location2);
      }
    }
    return output;
  }
  toJSON() {
    const formattedError = {
      message: this.message
    };
    if (this.locations != null) {
      formattedError.locations = this.locations;
    }
    if (this.path != null) {
      formattedError.path = this.path;
    }
    if (this.extensions != null && Object.keys(this.extensions).length > 0) {
      formattedError.extensions = this.extensions;
    }
    return formattedError;
  }
};
function undefinedIfEmpty(array) {
  return array === void 0 || array.length === 0 ? void 0 : array;
}
function syntaxError(source, position, description) {
  return new GraphQLError(`Syntax Error: ${description}`, {
    source,
    positions: [position]
  });
}
var Location = class {
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The Token at which this Node begins.
   */
  /**
   * The Token at which this Node ends.
   */
  /**
   * The Source document the AST represents.
   */
  constructor(startToken, endToken, source) {
    this.start = startToken.start;
    this.end = endToken.end;
    this.startToken = startToken;
    this.endToken = endToken;
    this.source = source;
  }
  get [Symbol.toStringTag]() {
    return "Location";
  }
  toJSON() {
    return {
      start: this.start,
      end: this.end
    };
  }
};
var Token = class {
  /**
   * The kind of Token.
   */
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The 1-indexed line number on which this Token appears.
   */
  /**
   * The 1-indexed column number at which this Token begins.
   */
  /**
   * For non-punctuation tokens, represents the interpreted value of the token.
   *
   * Note: is undefined for punctuation tokens, but typed as string for
   * convenience in the parser.
   */
  /**
   * Tokens exist as nodes in a double-linked-list amongst all tokens
   * including ignored tokens. <SOF> is always the first node and <EOF>
   * the last.
   */
  constructor(kind, start, end, line, column, value) {
    this.kind = kind;
    this.start = start;
    this.end = end;
    this.line = line;
    this.column = column;
    this.value = value;
    this.prev = null;
    this.next = null;
  }
  get [Symbol.toStringTag]() {
    return "Token";
  }
  toJSON() {
    return {
      kind: this.kind,
      value: this.value,
      line: this.line,
      column: this.column
    };
  }
};
var QueryDocumentKeys = {
  Name: [],
  Document: ["definitions"],
  OperationDefinition: [
    "name",
    "variableDefinitions",
    "directives",
    "selectionSet"
  ],
  VariableDefinition: ["variable", "type", "defaultValue", "directives"],
  Variable: ["name"],
  SelectionSet: ["selections"],
  Field: ["alias", "name", "arguments", "directives", "selectionSet"],
  Argument: ["name", "value"],
  FragmentSpread: ["name", "directives"],
  InlineFragment: ["typeCondition", "directives", "selectionSet"],
  FragmentDefinition: [
    "name",
    // Note: fragment variable definitions are deprecated and will removed in v17.0.0
    "variableDefinitions",
    "typeCondition",
    "directives",
    "selectionSet"
  ],
  IntValue: [],
  FloatValue: [],
  StringValue: [],
  BooleanValue: [],
  NullValue: [],
  EnumValue: [],
  ListValue: ["values"],
  ObjectValue: ["fields"],
  ObjectField: ["name", "value"],
  Directive: ["name", "arguments"],
  NamedType: ["name"],
  ListType: ["type"],
  NonNullType: ["type"],
  SchemaDefinition: ["description", "directives", "operationTypes"],
  OperationTypeDefinition: ["type"],
  ScalarTypeDefinition: ["description", "name", "directives"],
  ObjectTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  FieldDefinition: ["description", "name", "arguments", "type", "directives"],
  InputValueDefinition: [
    "description",
    "name",
    "type",
    "defaultValue",
    "directives"
  ],
  InterfaceTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  UnionTypeDefinition: ["description", "name", "directives", "types"],
  EnumTypeDefinition: ["description", "name", "directives", "values"],
  EnumValueDefinition: ["description", "name", "directives"],
  InputObjectTypeDefinition: ["description", "name", "directives", "fields"],
  DirectiveDefinition: ["description", "name", "arguments", "locations"],
  SchemaExtension: ["directives", "operationTypes"],
  ScalarTypeExtension: ["name", "directives"],
  ObjectTypeExtension: ["name", "interfaces", "directives", "fields"],
  InterfaceTypeExtension: ["name", "interfaces", "directives", "fields"],
  UnionTypeExtension: ["name", "directives", "types"],
  EnumTypeExtension: ["name", "directives", "values"],
  InputObjectTypeExtension: ["name", "directives", "fields"]
};
var kindValues = new Set(Object.keys(QueryDocumentKeys));
function isNode(maybeNode) {
  const maybeKind = maybeNode === null || maybeNode === void 0 ? void 0 : maybeNode.kind;
  return typeof maybeKind === "string" && kindValues.has(maybeKind);
}
var OperationTypeNode;
(function(OperationTypeNode2) {
  OperationTypeNode2["QUERY"] = "query";
  OperationTypeNode2["MUTATION"] = "mutation";
  OperationTypeNode2["SUBSCRIPTION"] = "subscription";
})(OperationTypeNode || (OperationTypeNode = {}));
var DirectiveLocation;
(function(DirectiveLocation2) {
  DirectiveLocation2["QUERY"] = "QUERY";
  DirectiveLocation2["MUTATION"] = "MUTATION";
  DirectiveLocation2["SUBSCRIPTION"] = "SUBSCRIPTION";
  DirectiveLocation2["FIELD"] = "FIELD";
  DirectiveLocation2["FRAGMENT_DEFINITION"] = "FRAGMENT_DEFINITION";
  DirectiveLocation2["FRAGMENT_SPREAD"] = "FRAGMENT_SPREAD";
  DirectiveLocation2["INLINE_FRAGMENT"] = "INLINE_FRAGMENT";
  DirectiveLocation2["VARIABLE_DEFINITION"] = "VARIABLE_DEFINITION";
  DirectiveLocation2["SCHEMA"] = "SCHEMA";
  DirectiveLocation2["SCALAR"] = "SCALAR";
  DirectiveLocation2["OBJECT"] = "OBJECT";
  DirectiveLocation2["FIELD_DEFINITION"] = "FIELD_DEFINITION";
  DirectiveLocation2["ARGUMENT_DEFINITION"] = "ARGUMENT_DEFINITION";
  DirectiveLocation2["INTERFACE"] = "INTERFACE";
  DirectiveLocation2["UNION"] = "UNION";
  DirectiveLocation2["ENUM"] = "ENUM";
  DirectiveLocation2["ENUM_VALUE"] = "ENUM_VALUE";
  DirectiveLocation2["INPUT_OBJECT"] = "INPUT_OBJECT";
  DirectiveLocation2["INPUT_FIELD_DEFINITION"] = "INPUT_FIELD_DEFINITION";
})(DirectiveLocation || (DirectiveLocation = {}));
var Kind;
(function(Kind2) {
  Kind2["NAME"] = "Name";
  Kind2["DOCUMENT"] = "Document";
  Kind2["OPERATION_DEFINITION"] = "OperationDefinition";
  Kind2["VARIABLE_DEFINITION"] = "VariableDefinition";
  Kind2["SELECTION_SET"] = "SelectionSet";
  Kind2["FIELD"] = "Field";
  Kind2["ARGUMENT"] = "Argument";
  Kind2["FRAGMENT_SPREAD"] = "FragmentSpread";
  Kind2["INLINE_FRAGMENT"] = "InlineFragment";
  Kind2["FRAGMENT_DEFINITION"] = "FragmentDefinition";
  Kind2["VARIABLE"] = "Variable";
  Kind2["INT"] = "IntValue";
  Kind2["FLOAT"] = "FloatValue";
  Kind2["STRING"] = "StringValue";
  Kind2["BOOLEAN"] = "BooleanValue";
  Kind2["NULL"] = "NullValue";
  Kind2["ENUM"] = "EnumValue";
  Kind2["LIST"] = "ListValue";
  Kind2["OBJECT"] = "ObjectValue";
  Kind2["OBJECT_FIELD"] = "ObjectField";
  Kind2["DIRECTIVE"] = "Directive";
  Kind2["NAMED_TYPE"] = "NamedType";
  Kind2["LIST_TYPE"] = "ListType";
  Kind2["NON_NULL_TYPE"] = "NonNullType";
  Kind2["SCHEMA_DEFINITION"] = "SchemaDefinition";
  Kind2["OPERATION_TYPE_DEFINITION"] = "OperationTypeDefinition";
  Kind2["SCALAR_TYPE_DEFINITION"] = "ScalarTypeDefinition";
  Kind2["OBJECT_TYPE_DEFINITION"] = "ObjectTypeDefinition";
  Kind2["FIELD_DEFINITION"] = "FieldDefinition";
  Kind2["INPUT_VALUE_DEFINITION"] = "InputValueDefinition";
  Kind2["INTERFACE_TYPE_DEFINITION"] = "InterfaceTypeDefinition";
  Kind2["UNION_TYPE_DEFINITION"] = "UnionTypeDefinition";
  Kind2["ENUM_TYPE_DEFINITION"] = "EnumTypeDefinition";
  Kind2["ENUM_VALUE_DEFINITION"] = "EnumValueDefinition";
  Kind2["INPUT_OBJECT_TYPE_DEFINITION"] = "InputObjectTypeDefinition";
  Kind2["DIRECTIVE_DEFINITION"] = "DirectiveDefinition";
  Kind2["SCHEMA_EXTENSION"] = "SchemaExtension";
  Kind2["SCALAR_TYPE_EXTENSION"] = "ScalarTypeExtension";
  Kind2["OBJECT_TYPE_EXTENSION"] = "ObjectTypeExtension";
  Kind2["INTERFACE_TYPE_EXTENSION"] = "InterfaceTypeExtension";
  Kind2["UNION_TYPE_EXTENSION"] = "UnionTypeExtension";
  Kind2["ENUM_TYPE_EXTENSION"] = "EnumTypeExtension";
  Kind2["INPUT_OBJECT_TYPE_EXTENSION"] = "InputObjectTypeExtension";
})(Kind || (Kind = {}));
function isWhiteSpace(code) {
  return code === 9 || code === 32;
}
function isDigit(code) {
  return code >= 48 && code <= 57;
}
function isLetter(code) {
  return code >= 97 && code <= 122 || // A-Z
  code >= 65 && code <= 90;
}
function isNameStart(code) {
  return isLetter(code) || code === 95;
}
function isNameContinue(code) {
  return isLetter(code) || isDigit(code) || code === 95;
}
function dedentBlockStringLines(lines) {
  var _firstNonEmptyLine2;
  let commonIndent = Number.MAX_SAFE_INTEGER;
  let firstNonEmptyLine = null;
  let lastNonEmptyLine = -1;
  for (let i = 0; i < lines.length; ++i) {
    var _firstNonEmptyLine;
    const line = lines[i];
    const indent2 = leadingWhitespace(line);
    if (indent2 === line.length) {
      continue;
    }
    firstNonEmptyLine = (_firstNonEmptyLine = firstNonEmptyLine) !== null && _firstNonEmptyLine !== void 0 ? _firstNonEmptyLine : i;
    lastNonEmptyLine = i;
    if (i !== 0 && indent2 < commonIndent) {
      commonIndent = indent2;
    }
  }
  return lines.map((line, i) => i === 0 ? line : line.slice(commonIndent)).slice(
    (_firstNonEmptyLine2 = firstNonEmptyLine) !== null && _firstNonEmptyLine2 !== void 0 ? _firstNonEmptyLine2 : 0,
    lastNonEmptyLine + 1
  );
}
function leadingWhitespace(str) {
  let i = 0;
  while (i < str.length && isWhiteSpace(str.charCodeAt(i))) {
    ++i;
  }
  return i;
}
function printBlockString(value, options) {
  const escapedValue = value.replace(/"""/g, '\\"""');
  const lines = escapedValue.split(/\r\n|[\n\r]/g);
  const isSingleLine = lines.length === 1;
  const forceLeadingNewLine = lines.length > 1 && lines.slice(1).every((line) => line.length === 0 || isWhiteSpace(line.charCodeAt(0)));
  const hasTrailingTripleQuotes = escapedValue.endsWith('\\"""');
  const hasTrailingQuote = value.endsWith('"') && !hasTrailingTripleQuotes;
  const hasTrailingSlash = value.endsWith("\\");
  const forceTrailingNewline = hasTrailingQuote || hasTrailingSlash;
  const printAsMultipleLines = !(options !== null && options !== void 0 && options.minimize) && // add leading and trailing new lines only if it improves readability
  (!isSingleLine || value.length > 70 || forceTrailingNewline || forceLeadingNewLine || hasTrailingTripleQuotes);
  let result = "";
  const skipLeadingNewLine = isSingleLine && isWhiteSpace(value.charCodeAt(0));
  if (printAsMultipleLines && !skipLeadingNewLine || forceLeadingNewLine) {
    result += "\n";
  }
  result += escapedValue;
  if (printAsMultipleLines || forceTrailingNewline) {
    result += "\n";
  }
  return '"""' + result + '"""';
}
var TokenKind;
(function(TokenKind2) {
  TokenKind2["SOF"] = "<SOF>";
  TokenKind2["EOF"] = "<EOF>";
  TokenKind2["BANG"] = "!";
  TokenKind2["DOLLAR"] = "$";
  TokenKind2["AMP"] = "&";
  TokenKind2["PAREN_L"] = "(";
  TokenKind2["PAREN_R"] = ")";
  TokenKind2["SPREAD"] = "...";
  TokenKind2["COLON"] = ":";
  TokenKind2["EQUALS"] = "=";
  TokenKind2["AT"] = "@";
  TokenKind2["BRACKET_L"] = "[";
  TokenKind2["BRACKET_R"] = "]";
  TokenKind2["BRACE_L"] = "{";
  TokenKind2["PIPE"] = "|";
  TokenKind2["BRACE_R"] = "}";
  TokenKind2["NAME"] = "Name";
  TokenKind2["INT"] = "Int";
  TokenKind2["FLOAT"] = "Float";
  TokenKind2["STRING"] = "String";
  TokenKind2["BLOCK_STRING"] = "BlockString";
  TokenKind2["COMMENT"] = "Comment";
})(TokenKind || (TokenKind = {}));
var Lexer = class {
  /**
   * The previously focused non-ignored token.
   */
  /**
   * The currently focused non-ignored token.
   */
  /**
   * The (1-indexed) line containing the current token.
   */
  /**
   * The character offset at which the current line begins.
   */
  constructor(source) {
    const startOfFileToken = new Token(TokenKind.SOF, 0, 0, 0, 0);
    this.source = source;
    this.lastToken = startOfFileToken;
    this.token = startOfFileToken;
    this.line = 1;
    this.lineStart = 0;
  }
  get [Symbol.toStringTag]() {
    return "Lexer";
  }
  /**
   * Advances the token stream to the next non-ignored token.
   */
  advance() {
    this.lastToken = this.token;
    const token = this.token = this.lookahead();
    return token;
  }
  /**
   * Looks ahead and returns the next non-ignored token, but does not change
   * the state of Lexer.
   */
  lookahead() {
    let token = this.token;
    if (token.kind !== TokenKind.EOF) {
      do {
        if (token.next) {
          token = token.next;
        } else {
          const nextToken = readNextToken(this, token.end);
          token.next = nextToken;
          nextToken.prev = token;
          token = nextToken;
        }
      } while (token.kind === TokenKind.COMMENT);
    }
    return token;
  }
};
function isPunctuatorTokenKind(kind) {
  return kind === TokenKind.BANG || kind === TokenKind.DOLLAR || kind === TokenKind.AMP || kind === TokenKind.PAREN_L || kind === TokenKind.PAREN_R || kind === TokenKind.SPREAD || kind === TokenKind.COLON || kind === TokenKind.EQUALS || kind === TokenKind.AT || kind === TokenKind.BRACKET_L || kind === TokenKind.BRACKET_R || kind === TokenKind.BRACE_L || kind === TokenKind.PIPE || kind === TokenKind.BRACE_R;
}
function isUnicodeScalarValue(code) {
  return code >= 0 && code <= 55295 || code >= 57344 && code <= 1114111;
}
function isSupplementaryCodePoint(body, location2) {
  return isLeadingSurrogate(body.charCodeAt(location2)) && isTrailingSurrogate(body.charCodeAt(location2 + 1));
}
function isLeadingSurrogate(code) {
  return code >= 55296 && code <= 56319;
}
function isTrailingSurrogate(code) {
  return code >= 56320 && code <= 57343;
}
function printCodePointAt(lexer2, location2) {
  const code = lexer2.source.body.codePointAt(location2);
  if (code === void 0) {
    return TokenKind.EOF;
  } else if (code >= 32 && code <= 126) {
    const char = String.fromCodePoint(code);
    return char === '"' ? `'"'` : `"${char}"`;
  }
  return "U+" + code.toString(16).toUpperCase().padStart(4, "0");
}
function createToken(lexer2, kind, start, end, value) {
  const line = lexer2.line;
  const col = 1 + start - lexer2.lineStart;
  return new Token(kind, start, end, line, col, value);
}
function readNextToken(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start;
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    switch (code) {
      case 65279:
      case 9:
      case 32:
      case 44:
        ++position;
        continue;
      case 10:
        ++position;
        ++lexer2.line;
        lexer2.lineStart = position;
        continue;
      case 13:
        if (body.charCodeAt(position + 1) === 10) {
          position += 2;
        } else {
          ++position;
        }
        ++lexer2.line;
        lexer2.lineStart = position;
        continue;
      case 35:
        return readComment(lexer2, position);
      case 33:
        return createToken(lexer2, TokenKind.BANG, position, position + 1);
      case 36:
        return createToken(lexer2, TokenKind.DOLLAR, position, position + 1);
      case 38:
        return createToken(lexer2, TokenKind.AMP, position, position + 1);
      case 40:
        return createToken(lexer2, TokenKind.PAREN_L, position, position + 1);
      case 41:
        return createToken(lexer2, TokenKind.PAREN_R, position, position + 1);
      case 46:
        if (body.charCodeAt(position + 1) === 46 && body.charCodeAt(position + 2) === 46) {
          return createToken(lexer2, TokenKind.SPREAD, position, position + 3);
        }
        break;
      case 58:
        return createToken(lexer2, TokenKind.COLON, position, position + 1);
      case 61:
        return createToken(lexer2, TokenKind.EQUALS, position, position + 1);
      case 64:
        return createToken(lexer2, TokenKind.AT, position, position + 1);
      case 91:
        return createToken(lexer2, TokenKind.BRACKET_L, position, position + 1);
      case 93:
        return createToken(lexer2, TokenKind.BRACKET_R, position, position + 1);
      case 123:
        return createToken(lexer2, TokenKind.BRACE_L, position, position + 1);
      case 124:
        return createToken(lexer2, TokenKind.PIPE, position, position + 1);
      case 125:
        return createToken(lexer2, TokenKind.BRACE_R, position, position + 1);
      case 34:
        if (body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34) {
          return readBlockString(lexer2, position);
        }
        return readString(lexer2, position);
    }
    if (isDigit(code) || code === 45) {
      return readNumber(lexer2, position, code);
    }
    if (isNameStart(code)) {
      return readName(lexer2, position);
    }
    throw syntaxError(
      lexer2.source,
      position,
      code === 39 ? `Unexpected single quote character ('), did you mean to use a double quote (")?` : isUnicodeScalarValue(code) || isSupplementaryCodePoint(body, position) ? `Unexpected character: ${printCodePointAt(lexer2, position)}.` : `Invalid character: ${printCodePointAt(lexer2, position)}.`
    );
  }
  return createToken(lexer2, TokenKind.EOF, bodyLength, bodyLength);
}
function readComment(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start + 1;
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (code === 10 || code === 13) {
      break;
    }
    if (isUnicodeScalarValue(code)) {
      ++position;
    } else if (isSupplementaryCodePoint(body, position)) {
      position += 2;
    } else {
      break;
    }
  }
  return createToken(
    lexer2,
    TokenKind.COMMENT,
    start,
    position,
    body.slice(start + 1, position)
  );
}
function readNumber(lexer2, start, firstCode) {
  const body = lexer2.source.body;
  let position = start;
  let code = firstCode;
  let isFloat = false;
  if (code === 45) {
    code = body.charCodeAt(++position);
  }
  if (code === 48) {
    code = body.charCodeAt(++position);
    if (isDigit(code)) {
      throw syntaxError(
        lexer2.source,
        position,
        `Invalid number, unexpected digit after 0: ${printCodePointAt(
          lexer2,
          position
        )}.`
      );
    }
  } else {
    position = readDigits(lexer2, position, code);
    code = body.charCodeAt(position);
  }
  if (code === 46) {
    isFloat = true;
    code = body.charCodeAt(++position);
    position = readDigits(lexer2, position, code);
    code = body.charCodeAt(position);
  }
  if (code === 69 || code === 101) {
    isFloat = true;
    code = body.charCodeAt(++position);
    if (code === 43 || code === 45) {
      code = body.charCodeAt(++position);
    }
    position = readDigits(lexer2, position, code);
    code = body.charCodeAt(position);
  }
  if (code === 46 || isNameStart(code)) {
    throw syntaxError(
      lexer2.source,
      position,
      `Invalid number, expected digit but got: ${printCodePointAt(
        lexer2,
        position
      )}.`
    );
  }
  return createToken(
    lexer2,
    isFloat ? TokenKind.FLOAT : TokenKind.INT,
    start,
    position,
    body.slice(start, position)
  );
}
function readDigits(lexer2, start, firstCode) {
  if (!isDigit(firstCode)) {
    throw syntaxError(
      lexer2.source,
      start,
      `Invalid number, expected digit but got: ${printCodePointAt(
        lexer2,
        start
      )}.`
    );
  }
  const body = lexer2.source.body;
  let position = start + 1;
  while (isDigit(body.charCodeAt(position))) {
    ++position;
  }
  return position;
}
function readString(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start + 1;
  let chunkStart = position;
  let value = "";
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (code === 34) {
      value += body.slice(chunkStart, position);
      return createToken(lexer2, TokenKind.STRING, start, position + 1, value);
    }
    if (code === 92) {
      value += body.slice(chunkStart, position);
      const escape = body.charCodeAt(position + 1) === 117 ? body.charCodeAt(position + 2) === 123 ? readEscapedUnicodeVariableWidth(lexer2, position) : readEscapedUnicodeFixedWidth(lexer2, position) : readEscapedCharacter(lexer2, position);
      value += escape.value;
      position += escape.size;
      chunkStart = position;
      continue;
    }
    if (code === 10 || code === 13) {
      break;
    }
    if (isUnicodeScalarValue(code)) {
      ++position;
    } else if (isSupplementaryCodePoint(body, position)) {
      position += 2;
    } else {
      throw syntaxError(
        lexer2.source,
        position,
        `Invalid character within String: ${printCodePointAt(
          lexer2,
          position
        )}.`
      );
    }
  }
  throw syntaxError(lexer2.source, position, "Unterminated string.");
}
function readEscapedUnicodeVariableWidth(lexer2, position) {
  const body = lexer2.source.body;
  let point = 0;
  let size = 3;
  while (size < 12) {
    const code = body.charCodeAt(position + size++);
    if (code === 125) {
      if (size < 5 || !isUnicodeScalarValue(point)) {
        break;
      }
      return {
        value: String.fromCodePoint(point),
        size
      };
    }
    point = point << 4 | readHexDigit(code);
    if (point < 0) {
      break;
    }
  }
  throw syntaxError(
    lexer2.source,
    position,
    `Invalid Unicode escape sequence: "${body.slice(
      position,
      position + size
    )}".`
  );
}
function readEscapedUnicodeFixedWidth(lexer2, position) {
  const body = lexer2.source.body;
  const code = read16BitHexCode(body, position + 2);
  if (isUnicodeScalarValue(code)) {
    return {
      value: String.fromCodePoint(code),
      size: 6
    };
  }
  if (isLeadingSurrogate(code)) {
    if (body.charCodeAt(position + 6) === 92 && body.charCodeAt(position + 7) === 117) {
      const trailingCode = read16BitHexCode(body, position + 8);
      if (isTrailingSurrogate(trailingCode)) {
        return {
          value: String.fromCodePoint(code, trailingCode),
          size: 12
        };
      }
    }
  }
  throw syntaxError(
    lexer2.source,
    position,
    `Invalid Unicode escape sequence: "${body.slice(position, position + 6)}".`
  );
}
function read16BitHexCode(body, position) {
  return readHexDigit(body.charCodeAt(position)) << 12 | readHexDigit(body.charCodeAt(position + 1)) << 8 | readHexDigit(body.charCodeAt(position + 2)) << 4 | readHexDigit(body.charCodeAt(position + 3));
}
function readHexDigit(code) {
  return code >= 48 && code <= 57 ? code - 48 : code >= 65 && code <= 70 ? code - 55 : code >= 97 && code <= 102 ? code - 87 : -1;
}
function readEscapedCharacter(lexer2, position) {
  const body = lexer2.source.body;
  const code = body.charCodeAt(position + 1);
  switch (code) {
    case 34:
      return {
        value: '"',
        size: 2
      };
    case 92:
      return {
        value: "\\",
        size: 2
      };
    case 47:
      return {
        value: "/",
        size: 2
      };
    case 98:
      return {
        value: "\b",
        size: 2
      };
    case 102:
      return {
        value: "\f",
        size: 2
      };
    case 110:
      return {
        value: "\n",
        size: 2
      };
    case 114:
      return {
        value: "\r",
        size: 2
      };
    case 116:
      return {
        value: "	",
        size: 2
      };
  }
  throw syntaxError(
    lexer2.source,
    position,
    `Invalid character escape sequence: "${body.slice(
      position,
      position + 2
    )}".`
  );
}
function readBlockString(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let lineStart = lexer2.lineStart;
  let position = start + 3;
  let chunkStart = position;
  let currentLine = "";
  const blockLines = [];
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (code === 34 && body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34) {
      currentLine += body.slice(chunkStart, position);
      blockLines.push(currentLine);
      const token = createToken(
        lexer2,
        TokenKind.BLOCK_STRING,
        start,
        position + 3,
        // Return a string of the lines joined with U+000A.
        dedentBlockStringLines(blockLines).join("\n")
      );
      lexer2.line += blockLines.length - 1;
      lexer2.lineStart = lineStart;
      return token;
    }
    if (code === 92 && body.charCodeAt(position + 1) === 34 && body.charCodeAt(position + 2) === 34 && body.charCodeAt(position + 3) === 34) {
      currentLine += body.slice(chunkStart, position);
      chunkStart = position + 1;
      position += 4;
      continue;
    }
    if (code === 10 || code === 13) {
      currentLine += body.slice(chunkStart, position);
      blockLines.push(currentLine);
      if (code === 13 && body.charCodeAt(position + 1) === 10) {
        position += 2;
      } else {
        ++position;
      }
      currentLine = "";
      chunkStart = position;
      lineStart = position;
      continue;
    }
    if (isUnicodeScalarValue(code)) {
      ++position;
    } else if (isSupplementaryCodePoint(body, position)) {
      position += 2;
    } else {
      throw syntaxError(
        lexer2.source,
        position,
        `Invalid character within String: ${printCodePointAt(
          lexer2,
          position
        )}.`
      );
    }
  }
  throw syntaxError(lexer2.source, position, "Unterminated string.");
}
function readName(lexer2, start) {
  const body = lexer2.source.body;
  const bodyLength = body.length;
  let position = start + 1;
  while (position < bodyLength) {
    const code = body.charCodeAt(position);
    if (isNameContinue(code)) {
      ++position;
    } else {
      break;
    }
  }
  return createToken(
    lexer2,
    TokenKind.NAME,
    start,
    position,
    body.slice(start, position)
  );
}
var MAX_ARRAY_LENGTH = 10;
var MAX_RECURSIVE_DEPTH = 2;
function inspect(value) {
  return formatValue(value, []);
}
function formatValue(value, seenValues) {
  switch (typeof value) {
    case "string":
      return JSON.stringify(value);
    case "function":
      return value.name ? `[function ${value.name}]` : "[function]";
    case "object":
      return formatObjectValue(value, seenValues);
    default:
      return String(value);
  }
}
function formatObjectValue(value, previouslySeenValues) {
  if (value === null) {
    return "null";
  }
  if (previouslySeenValues.includes(value)) {
    return "[Circular]";
  }
  const seenValues = [...previouslySeenValues, value];
  if (isJSONable(value)) {
    const jsonValue = value.toJSON();
    if (jsonValue !== value) {
      return typeof jsonValue === "string" ? jsonValue : formatValue(jsonValue, seenValues);
    }
  } else if (Array.isArray(value)) {
    return formatArray(value, seenValues);
  }
  return formatObject(value, seenValues);
}
function isJSONable(value) {
  return typeof value.toJSON === "function";
}
function formatObject(object, seenValues) {
  const entries = Object.entries(object);
  if (entries.length === 0) {
    return "{}";
  }
  if (seenValues.length > MAX_RECURSIVE_DEPTH) {
    return "[" + getObjectTag(object) + "]";
  }
  const properties = entries.map(
    ([key, value]) => key + ": " + formatValue(value, seenValues)
  );
  return "{ " + properties.join(", ") + " }";
}
function formatArray(array, seenValues) {
  if (array.length === 0) {
    return "[]";
  }
  if (seenValues.length > MAX_RECURSIVE_DEPTH) {
    return "[Array]";
  }
  const len = Math.min(MAX_ARRAY_LENGTH, array.length);
  const remaining = array.length - len;
  const items = [];
  for (let i = 0; i < len; ++i) {
    items.push(formatValue(array[i], seenValues));
  }
  if (remaining === 1) {
    items.push("... 1 more item");
  } else if (remaining > 1) {
    items.push(`... ${remaining} more items`);
  }
  return "[" + items.join(", ") + "]";
}
function getObjectTag(object) {
  const tag = Object.prototype.toString.call(object).replace(/^\[object /, "").replace(/]$/, "");
  if (tag === "Object" && typeof object.constructor === "function") {
    const name = object.constructor.name;
    if (typeof name === "string" && name !== "") {
      return name;
    }
  }
  return tag;
}
var instanceOf = (
  /* c8 ignore next 6 */
  // FIXME: https://github.com/graphql/graphql-js/issues/2317
  globalThis.process && false ? function instanceOf2(value, constructor) {
    return value instanceof constructor;
  } : function instanceOf3(value, constructor) {
    if (value instanceof constructor) {
      return true;
    }
    if (typeof value === "object" && value !== null) {
      var _value$constructor;
      const className = constructor.prototype[Symbol.toStringTag];
      const valueClassName = (
        // We still need to support constructor's name to detect conflicts with older versions of this library.
        Symbol.toStringTag in value ? value[Symbol.toStringTag] : (_value$constructor = value.constructor) === null || _value$constructor === void 0 ? void 0 : _value$constructor.name
      );
      if (className === valueClassName) {
        const stringifiedValue = inspect(value);
        throw new Error(`Cannot use ${className} "${stringifiedValue}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`);
      }
    }
    return false;
  }
);
var Source = class {
  constructor(body, name = "GraphQL request", locationOffset = {
    line: 1,
    column: 1
  }) {
    typeof body === "string" || devAssert(false, `Body must be a string. Received: ${inspect(body)}.`);
    this.body = body;
    this.name = name;
    this.locationOffset = locationOffset;
    this.locationOffset.line > 0 || devAssert(
      false,
      "line in locationOffset is 1-indexed and must be positive."
    );
    this.locationOffset.column > 0 || devAssert(
      false,
      "column in locationOffset is 1-indexed and must be positive."
    );
  }
  get [Symbol.toStringTag]() {
    return "Source";
  }
};
function isSource(source) {
  return instanceOf(source, Source);
}
function parse2(source, options) {
  const parser = new Parser(source, options);
  return parser.parseDocument();
}
var Parser = class {
  constructor(source, options = {}) {
    const sourceObj = isSource(source) ? source : new Source(source);
    this._lexer = new Lexer(sourceObj);
    this._options = options;
    this._tokenCounter = 0;
  }
  /**
   * Converts a name lex token into a name parse node.
   */
  parseName() {
    const token = this.expectToken(TokenKind.NAME);
    return this.node(token, {
      kind: Kind.NAME,
      value: token.value
    });
  }
  // Implements the parsing rules in the Document section.
  /**
   * Document : Definition+
   */
  parseDocument() {
    return this.node(this._lexer.token, {
      kind: Kind.DOCUMENT,
      definitions: this.many(
        TokenKind.SOF,
        this.parseDefinition,
        TokenKind.EOF
      )
    });
  }
  /**
   * Definition :
   *   - ExecutableDefinition
   *   - TypeSystemDefinition
   *   - TypeSystemExtension
   *
   * ExecutableDefinition :
   *   - OperationDefinition
   *   - FragmentDefinition
   *
   * TypeSystemDefinition :
   *   - SchemaDefinition
   *   - TypeDefinition
   *   - DirectiveDefinition
   *
   * TypeDefinition :
   *   - ScalarTypeDefinition
   *   - ObjectTypeDefinition
   *   - InterfaceTypeDefinition
   *   - UnionTypeDefinition
   *   - EnumTypeDefinition
   *   - InputObjectTypeDefinition
   */
  parseDefinition() {
    if (this.peek(TokenKind.BRACE_L)) {
      return this.parseOperationDefinition();
    }
    const hasDescription = this.peekDescription();
    const keywordToken = hasDescription ? this._lexer.lookahead() : this._lexer.token;
    if (keywordToken.kind === TokenKind.NAME) {
      switch (keywordToken.value) {
        case "schema":
          return this.parseSchemaDefinition();
        case "scalar":
          return this.parseScalarTypeDefinition();
        case "type":
          return this.parseObjectTypeDefinition();
        case "interface":
          return this.parseInterfaceTypeDefinition();
        case "union":
          return this.parseUnionTypeDefinition();
        case "enum":
          return this.parseEnumTypeDefinition();
        case "input":
          return this.parseInputObjectTypeDefinition();
        case "directive":
          return this.parseDirectiveDefinition();
      }
      if (hasDescription) {
        throw syntaxError(
          this._lexer.source,
          this._lexer.token.start,
          "Unexpected description, descriptions are supported only on type definitions."
        );
      }
      switch (keywordToken.value) {
        case "query":
        case "mutation":
        case "subscription":
          return this.parseOperationDefinition();
        case "fragment":
          return this.parseFragmentDefinition();
        case "extend":
          return this.parseTypeSystemExtension();
      }
    }
    throw this.unexpected(keywordToken);
  }
  // Implements the parsing rules in the Operations section.
  /**
   * OperationDefinition :
   *  - SelectionSet
   *  - OperationType Name? VariableDefinitions? Directives? SelectionSet
   */
  parseOperationDefinition() {
    const start = this._lexer.token;
    if (this.peek(TokenKind.BRACE_L)) {
      return this.node(start, {
        kind: Kind.OPERATION_DEFINITION,
        operation: OperationTypeNode.QUERY,
        name: void 0,
        variableDefinitions: [],
        directives: [],
        selectionSet: this.parseSelectionSet()
      });
    }
    const operation = this.parseOperationType();
    let name;
    if (this.peek(TokenKind.NAME)) {
      name = this.parseName();
    }
    return this.node(start, {
      kind: Kind.OPERATION_DEFINITION,
      operation,
      name,
      variableDefinitions: this.parseVariableDefinitions(),
      directives: this.parseDirectives(false),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * OperationType : one of query mutation subscription
   */
  parseOperationType() {
    const operationToken = this.expectToken(TokenKind.NAME);
    switch (operationToken.value) {
      case "query":
        return OperationTypeNode.QUERY;
      case "mutation":
        return OperationTypeNode.MUTATION;
      case "subscription":
        return OperationTypeNode.SUBSCRIPTION;
    }
    throw this.unexpected(operationToken);
  }
  /**
   * VariableDefinitions : ( VariableDefinition+ )
   */
  parseVariableDefinitions() {
    return this.optionalMany(
      TokenKind.PAREN_L,
      this.parseVariableDefinition,
      TokenKind.PAREN_R
    );
  }
  /**
   * VariableDefinition : Variable : Type DefaultValue? Directives[Const]?
   */
  parseVariableDefinition() {
    return this.node(this._lexer.token, {
      kind: Kind.VARIABLE_DEFINITION,
      variable: this.parseVariable(),
      type: (this.expectToken(TokenKind.COLON), this.parseTypeReference()),
      defaultValue: this.expectOptionalToken(TokenKind.EQUALS) ? this.parseConstValueLiteral() : void 0,
      directives: this.parseConstDirectives()
    });
  }
  /**
   * Variable : $ Name
   */
  parseVariable() {
    const start = this._lexer.token;
    this.expectToken(TokenKind.DOLLAR);
    return this.node(start, {
      kind: Kind.VARIABLE,
      name: this.parseName()
    });
  }
  /**
   * ```
   * SelectionSet : { Selection+ }
   * ```
   */
  parseSelectionSet() {
    return this.node(this._lexer.token, {
      kind: Kind.SELECTION_SET,
      selections: this.many(
        TokenKind.BRACE_L,
        this.parseSelection,
        TokenKind.BRACE_R
      )
    });
  }
  /**
   * Selection :
   *   - Field
   *   - FragmentSpread
   *   - InlineFragment
   */
  parseSelection() {
    return this.peek(TokenKind.SPREAD) ? this.parseFragment() : this.parseField();
  }
  /**
   * Field : Alias? Name Arguments? Directives? SelectionSet?
   *
   * Alias : Name :
   */
  parseField() {
    const start = this._lexer.token;
    const nameOrAlias = this.parseName();
    let alias;
    let name;
    if (this.expectOptionalToken(TokenKind.COLON)) {
      alias = nameOrAlias;
      name = this.parseName();
    } else {
      name = nameOrAlias;
    }
    return this.node(start, {
      kind: Kind.FIELD,
      alias,
      name,
      arguments: this.parseArguments(false),
      directives: this.parseDirectives(false),
      selectionSet: this.peek(TokenKind.BRACE_L) ? this.parseSelectionSet() : void 0
    });
  }
  /**
   * Arguments[Const] : ( Argument[?Const]+ )
   */
  parseArguments(isConst) {
    const item = isConst ? this.parseConstArgument : this.parseArgument;
    return this.optionalMany(TokenKind.PAREN_L, item, TokenKind.PAREN_R);
  }
  /**
   * Argument[Const] : Name : Value[?Const]
   */
  parseArgument(isConst = false) {
    const start = this._lexer.token;
    const name = this.parseName();
    this.expectToken(TokenKind.COLON);
    return this.node(start, {
      kind: Kind.ARGUMENT,
      name,
      value: this.parseValueLiteral(isConst)
    });
  }
  parseConstArgument() {
    return this.parseArgument(true);
  }
  // Implements the parsing rules in the Fragments section.
  /**
   * Corresponds to both FragmentSpread and InlineFragment in the spec.
   *
   * FragmentSpread : ... FragmentName Directives?
   *
   * InlineFragment : ... TypeCondition? Directives? SelectionSet
   */
  parseFragment() {
    const start = this._lexer.token;
    this.expectToken(TokenKind.SPREAD);
    const hasTypeCondition = this.expectOptionalKeyword("on");
    if (!hasTypeCondition && this.peek(TokenKind.NAME)) {
      return this.node(start, {
        kind: Kind.FRAGMENT_SPREAD,
        name: this.parseFragmentName(),
        directives: this.parseDirectives(false)
      });
    }
    return this.node(start, {
      kind: Kind.INLINE_FRAGMENT,
      typeCondition: hasTypeCondition ? this.parseNamedType() : void 0,
      directives: this.parseDirectives(false),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentDefinition :
   *   - fragment FragmentName on TypeCondition Directives? SelectionSet
   *
   * TypeCondition : NamedType
   */
  parseFragmentDefinition() {
    const start = this._lexer.token;
    this.expectKeyword("fragment");
    if (this._options.allowLegacyFragmentVariables === true) {
      return this.node(start, {
        kind: Kind.FRAGMENT_DEFINITION,
        name: this.parseFragmentName(),
        variableDefinitions: this.parseVariableDefinitions(),
        typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
        directives: this.parseDirectives(false),
        selectionSet: this.parseSelectionSet()
      });
    }
    return this.node(start, {
      kind: Kind.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(false),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentName : Name but not `on`
   */
  parseFragmentName() {
    if (this._lexer.token.value === "on") {
      throw this.unexpected();
    }
    return this.parseName();
  }
  // Implements the parsing rules in the Values section.
  /**
   * Value[Const] :
   *   - [~Const] Variable
   *   - IntValue
   *   - FloatValue
   *   - StringValue
   *   - BooleanValue
   *   - NullValue
   *   - EnumValue
   *   - ListValue[?Const]
   *   - ObjectValue[?Const]
   *
   * BooleanValue : one of `true` `false`
   *
   * NullValue : `null`
   *
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseValueLiteral(isConst) {
    const token = this._lexer.token;
    switch (token.kind) {
      case TokenKind.BRACKET_L:
        return this.parseList(isConst);
      case TokenKind.BRACE_L:
        return this.parseObject(isConst);
      case TokenKind.INT:
        this.advanceLexer();
        return this.node(token, {
          kind: Kind.INT,
          value: token.value
        });
      case TokenKind.FLOAT:
        this.advanceLexer();
        return this.node(token, {
          kind: Kind.FLOAT,
          value: token.value
        });
      case TokenKind.STRING:
      case TokenKind.BLOCK_STRING:
        return this.parseStringLiteral();
      case TokenKind.NAME:
        this.advanceLexer();
        switch (token.value) {
          case "true":
            return this.node(token, {
              kind: Kind.BOOLEAN,
              value: true
            });
          case "false":
            return this.node(token, {
              kind: Kind.BOOLEAN,
              value: false
            });
          case "null":
            return this.node(token, {
              kind: Kind.NULL
            });
          default:
            return this.node(token, {
              kind: Kind.ENUM,
              value: token.value
            });
        }
      case TokenKind.DOLLAR:
        if (isConst) {
          this.expectToken(TokenKind.DOLLAR);
          if (this._lexer.token.kind === TokenKind.NAME) {
            const varName = this._lexer.token.value;
            throw syntaxError(
              this._lexer.source,
              token.start,
              `Unexpected variable "$${varName}" in constant value.`
            );
          } else {
            throw this.unexpected(token);
          }
        }
        return this.parseVariable();
      default:
        throw this.unexpected();
    }
  }
  parseConstValueLiteral() {
    return this.parseValueLiteral(true);
  }
  parseStringLiteral() {
    const token = this._lexer.token;
    this.advanceLexer();
    return this.node(token, {
      kind: Kind.STRING,
      value: token.value,
      block: token.kind === TokenKind.BLOCK_STRING
    });
  }
  /**
   * ListValue[Const] :
   *   - [ ]
   *   - [ Value[?Const]+ ]
   */
  parseList(isConst) {
    const item = () => this.parseValueLiteral(isConst);
    return this.node(this._lexer.token, {
      kind: Kind.LIST,
      values: this.any(TokenKind.BRACKET_L, item, TokenKind.BRACKET_R)
    });
  }
  /**
   * ```
   * ObjectValue[Const] :
   *   - { }
   *   - { ObjectField[?Const]+ }
   * ```
   */
  parseObject(isConst) {
    const item = () => this.parseObjectField(isConst);
    return this.node(this._lexer.token, {
      kind: Kind.OBJECT,
      fields: this.any(TokenKind.BRACE_L, item, TokenKind.BRACE_R)
    });
  }
  /**
   * ObjectField[Const] : Name : Value[?Const]
   */
  parseObjectField(isConst) {
    const start = this._lexer.token;
    const name = this.parseName();
    this.expectToken(TokenKind.COLON);
    return this.node(start, {
      kind: Kind.OBJECT_FIELD,
      name,
      value: this.parseValueLiteral(isConst)
    });
  }
  // Implements the parsing rules in the Directives section.
  /**
   * Directives[Const] : Directive[?Const]+
   */
  parseDirectives(isConst) {
    const directives = [];
    while (this.peek(TokenKind.AT)) {
      directives.push(this.parseDirective(isConst));
    }
    return directives;
  }
  parseConstDirectives() {
    return this.parseDirectives(true);
  }
  /**
   * ```
   * Directive[Const] : @ Name Arguments[?Const]?
   * ```
   */
  parseDirective(isConst) {
    const start = this._lexer.token;
    this.expectToken(TokenKind.AT);
    return this.node(start, {
      kind: Kind.DIRECTIVE,
      name: this.parseName(),
      arguments: this.parseArguments(isConst)
    });
  }
  // Implements the parsing rules in the Types section.
  /**
   * Type :
   *   - NamedType
   *   - ListType
   *   - NonNullType
   */
  parseTypeReference() {
    const start = this._lexer.token;
    let type;
    if (this.expectOptionalToken(TokenKind.BRACKET_L)) {
      const innerType = this.parseTypeReference();
      this.expectToken(TokenKind.BRACKET_R);
      type = this.node(start, {
        kind: Kind.LIST_TYPE,
        type: innerType
      });
    } else {
      type = this.parseNamedType();
    }
    if (this.expectOptionalToken(TokenKind.BANG)) {
      return this.node(start, {
        kind: Kind.NON_NULL_TYPE,
        type
      });
    }
    return type;
  }
  /**
   * NamedType : Name
   */
  parseNamedType() {
    return this.node(this._lexer.token, {
      kind: Kind.NAMED_TYPE,
      name: this.parseName()
    });
  }
  // Implements the parsing rules in the Type Definition section.
  peekDescription() {
    return this.peek(TokenKind.STRING) || this.peek(TokenKind.BLOCK_STRING);
  }
  /**
   * Description : StringValue
   */
  parseDescription() {
    if (this.peekDescription()) {
      return this.parseStringLiteral();
    }
  }
  /**
   * ```
   * SchemaDefinition : Description? schema Directives[Const]? { OperationTypeDefinition+ }
   * ```
   */
  parseSchemaDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("schema");
    const directives = this.parseConstDirectives();
    const operationTypes = this.many(
      TokenKind.BRACE_L,
      this.parseOperationTypeDefinition,
      TokenKind.BRACE_R
    );
    return this.node(start, {
      kind: Kind.SCHEMA_DEFINITION,
      description,
      directives,
      operationTypes
    });
  }
  /**
   * OperationTypeDefinition : OperationType : NamedType
   */
  parseOperationTypeDefinition() {
    const start = this._lexer.token;
    const operation = this.parseOperationType();
    this.expectToken(TokenKind.COLON);
    const type = this.parseNamedType();
    return this.node(start, {
      kind: Kind.OPERATION_TYPE_DEFINITION,
      operation,
      type
    });
  }
  /**
   * ScalarTypeDefinition : Description? scalar Name Directives[Const]?
   */
  parseScalarTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("scalar");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.SCALAR_TYPE_DEFINITION,
      description,
      name,
      directives
    });
  }
  /**
   * ObjectTypeDefinition :
   *   Description?
   *   type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition?
   */
  parseObjectTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("type");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    return this.node(start, {
      kind: Kind.OBJECT_TYPE_DEFINITION,
      description,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * ImplementsInterfaces :
   *   - implements `&`? NamedType
   *   - ImplementsInterfaces & NamedType
   */
  parseImplementsInterfaces() {
    return this.expectOptionalKeyword("implements") ? this.delimitedMany(TokenKind.AMP, this.parseNamedType) : [];
  }
  /**
   * ```
   * FieldsDefinition : { FieldDefinition+ }
   * ```
   */
  parseFieldsDefinition() {
    return this.optionalMany(
      TokenKind.BRACE_L,
      this.parseFieldDefinition,
      TokenKind.BRACE_R
    );
  }
  /**
   * FieldDefinition :
   *   - Description? Name ArgumentsDefinition? : Type Directives[Const]?
   */
  parseFieldDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    const name = this.parseName();
    const args = this.parseArgumentDefs();
    this.expectToken(TokenKind.COLON);
    const type = this.parseTypeReference();
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.FIELD_DEFINITION,
      description,
      name,
      arguments: args,
      type,
      directives
    });
  }
  /**
   * ArgumentsDefinition : ( InputValueDefinition+ )
   */
  parseArgumentDefs() {
    return this.optionalMany(
      TokenKind.PAREN_L,
      this.parseInputValueDef,
      TokenKind.PAREN_R
    );
  }
  /**
   * InputValueDefinition :
   *   - Description? Name : Type DefaultValue? Directives[Const]?
   */
  parseInputValueDef() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    const name = this.parseName();
    this.expectToken(TokenKind.COLON);
    const type = this.parseTypeReference();
    let defaultValue;
    if (this.expectOptionalToken(TokenKind.EQUALS)) {
      defaultValue = this.parseConstValueLiteral();
    }
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.INPUT_VALUE_DEFINITION,
      description,
      name,
      type,
      defaultValue,
      directives
    });
  }
  /**
   * InterfaceTypeDefinition :
   *   - Description? interface Name Directives[Const]? FieldsDefinition?
   */
  parseInterfaceTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("interface");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    return this.node(start, {
      kind: Kind.INTERFACE_TYPE_DEFINITION,
      description,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * UnionTypeDefinition :
   *   - Description? union Name Directives[Const]? UnionMemberTypes?
   */
  parseUnionTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("union");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const types = this.parseUnionMemberTypes();
    return this.node(start, {
      kind: Kind.UNION_TYPE_DEFINITION,
      description,
      name,
      directives,
      types
    });
  }
  /**
   * UnionMemberTypes :
   *   - = `|`? NamedType
   *   - UnionMemberTypes | NamedType
   */
  parseUnionMemberTypes() {
    return this.expectOptionalToken(TokenKind.EQUALS) ? this.delimitedMany(TokenKind.PIPE, this.parseNamedType) : [];
  }
  /**
   * EnumTypeDefinition :
   *   - Description? enum Name Directives[Const]? EnumValuesDefinition?
   */
  parseEnumTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("enum");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const values = this.parseEnumValuesDefinition();
    return this.node(start, {
      kind: Kind.ENUM_TYPE_DEFINITION,
      description,
      name,
      directives,
      values
    });
  }
  /**
   * ```
   * EnumValuesDefinition : { EnumValueDefinition+ }
   * ```
   */
  parseEnumValuesDefinition() {
    return this.optionalMany(
      TokenKind.BRACE_L,
      this.parseEnumValueDefinition,
      TokenKind.BRACE_R
    );
  }
  /**
   * EnumValueDefinition : Description? EnumValue Directives[Const]?
   */
  parseEnumValueDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    const name = this.parseEnumValueName();
    const directives = this.parseConstDirectives();
    return this.node(start, {
      kind: Kind.ENUM_VALUE_DEFINITION,
      description,
      name,
      directives
    });
  }
  /**
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseEnumValueName() {
    if (this._lexer.token.value === "true" || this._lexer.token.value === "false" || this._lexer.token.value === "null") {
      throw syntaxError(
        this._lexer.source,
        this._lexer.token.start,
        `${getTokenDesc(
          this._lexer.token
        )} is reserved and cannot be used for an enum value.`
      );
    }
    return this.parseName();
  }
  /**
   * InputObjectTypeDefinition :
   *   - Description? input Name Directives[Const]? InputFieldsDefinition?
   */
  parseInputObjectTypeDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("input");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const fields = this.parseInputFieldsDefinition();
    return this.node(start, {
      kind: Kind.INPUT_OBJECT_TYPE_DEFINITION,
      description,
      name,
      directives,
      fields
    });
  }
  /**
   * ```
   * InputFieldsDefinition : { InputValueDefinition+ }
   * ```
   */
  parseInputFieldsDefinition() {
    return this.optionalMany(
      TokenKind.BRACE_L,
      this.parseInputValueDef,
      TokenKind.BRACE_R
    );
  }
  /**
   * TypeSystemExtension :
   *   - SchemaExtension
   *   - TypeExtension
   *
   * TypeExtension :
   *   - ScalarTypeExtension
   *   - ObjectTypeExtension
   *   - InterfaceTypeExtension
   *   - UnionTypeExtension
   *   - EnumTypeExtension
   *   - InputObjectTypeDefinition
   */
  parseTypeSystemExtension() {
    const keywordToken = this._lexer.lookahead();
    if (keywordToken.kind === TokenKind.NAME) {
      switch (keywordToken.value) {
        case "schema":
          return this.parseSchemaExtension();
        case "scalar":
          return this.parseScalarTypeExtension();
        case "type":
          return this.parseObjectTypeExtension();
        case "interface":
          return this.parseInterfaceTypeExtension();
        case "union":
          return this.parseUnionTypeExtension();
        case "enum":
          return this.parseEnumTypeExtension();
        case "input":
          return this.parseInputObjectTypeExtension();
      }
    }
    throw this.unexpected(keywordToken);
  }
  /**
   * ```
   * SchemaExtension :
   *  - extend schema Directives[Const]? { OperationTypeDefinition+ }
   *  - extend schema Directives[Const]
   * ```
   */
  parseSchemaExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("schema");
    const directives = this.parseConstDirectives();
    const operationTypes = this.optionalMany(
      TokenKind.BRACE_L,
      this.parseOperationTypeDefinition,
      TokenKind.BRACE_R
    );
    if (directives.length === 0 && operationTypes.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.SCHEMA_EXTENSION,
      directives,
      operationTypes
    });
  }
  /**
   * ScalarTypeExtension :
   *   - extend scalar Name Directives[Const]
   */
  parseScalarTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("scalar");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    if (directives.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.SCALAR_TYPE_EXTENSION,
      name,
      directives
    });
  }
  /**
   * ObjectTypeExtension :
   *  - extend type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend type Name ImplementsInterfaces? Directives[Const]
   *  - extend type Name ImplementsInterfaces
   */
  parseObjectTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("type");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    if (interfaces.length === 0 && directives.length === 0 && fields.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.OBJECT_TYPE_EXTENSION,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * InterfaceTypeExtension :
   *  - extend interface Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend interface Name ImplementsInterfaces? Directives[Const]
   *  - extend interface Name ImplementsInterfaces
   */
  parseInterfaceTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("interface");
    const name = this.parseName();
    const interfaces = this.parseImplementsInterfaces();
    const directives = this.parseConstDirectives();
    const fields = this.parseFieldsDefinition();
    if (interfaces.length === 0 && directives.length === 0 && fields.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.INTERFACE_TYPE_EXTENSION,
      name,
      interfaces,
      directives,
      fields
    });
  }
  /**
   * UnionTypeExtension :
   *   - extend union Name Directives[Const]? UnionMemberTypes
   *   - extend union Name Directives[Const]
   */
  parseUnionTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("union");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const types = this.parseUnionMemberTypes();
    if (directives.length === 0 && types.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.UNION_TYPE_EXTENSION,
      name,
      directives,
      types
    });
  }
  /**
   * EnumTypeExtension :
   *   - extend enum Name Directives[Const]? EnumValuesDefinition
   *   - extend enum Name Directives[Const]
   */
  parseEnumTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("enum");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const values = this.parseEnumValuesDefinition();
    if (directives.length === 0 && values.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.ENUM_TYPE_EXTENSION,
      name,
      directives,
      values
    });
  }
  /**
   * InputObjectTypeExtension :
   *   - extend input Name Directives[Const]? InputFieldsDefinition
   *   - extend input Name Directives[Const]
   */
  parseInputObjectTypeExtension() {
    const start = this._lexer.token;
    this.expectKeyword("extend");
    this.expectKeyword("input");
    const name = this.parseName();
    const directives = this.parseConstDirectives();
    const fields = this.parseInputFieldsDefinition();
    if (directives.length === 0 && fields.length === 0) {
      throw this.unexpected();
    }
    return this.node(start, {
      kind: Kind.INPUT_OBJECT_TYPE_EXTENSION,
      name,
      directives,
      fields
    });
  }
  /**
   * ```
   * DirectiveDefinition :
   *   - Description? directive @ Name ArgumentsDefinition? `repeatable`? on DirectiveLocations
   * ```
   */
  parseDirectiveDefinition() {
    const start = this._lexer.token;
    const description = this.parseDescription();
    this.expectKeyword("directive");
    this.expectToken(TokenKind.AT);
    const name = this.parseName();
    const args = this.parseArgumentDefs();
    const repeatable = this.expectOptionalKeyword("repeatable");
    this.expectKeyword("on");
    const locations = this.parseDirectiveLocations();
    return this.node(start, {
      kind: Kind.DIRECTIVE_DEFINITION,
      description,
      name,
      arguments: args,
      repeatable,
      locations
    });
  }
  /**
   * DirectiveLocations :
   *   - `|`? DirectiveLocation
   *   - DirectiveLocations | DirectiveLocation
   */
  parseDirectiveLocations() {
    return this.delimitedMany(TokenKind.PIPE, this.parseDirectiveLocation);
  }
  /*
   * DirectiveLocation :
   *   - ExecutableDirectiveLocation
   *   - TypeSystemDirectiveLocation
   *
   * ExecutableDirectiveLocation : one of
   *   `QUERY`
   *   `MUTATION`
   *   `SUBSCRIPTION`
   *   `FIELD`
   *   `FRAGMENT_DEFINITION`
   *   `FRAGMENT_SPREAD`
   *   `INLINE_FRAGMENT`
   *
   * TypeSystemDirectiveLocation : one of
   *   `SCHEMA`
   *   `SCALAR`
   *   `OBJECT`
   *   `FIELD_DEFINITION`
   *   `ARGUMENT_DEFINITION`
   *   `INTERFACE`
   *   `UNION`
   *   `ENUM`
   *   `ENUM_VALUE`
   *   `INPUT_OBJECT`
   *   `INPUT_FIELD_DEFINITION`
   */
  parseDirectiveLocation() {
    const start = this._lexer.token;
    const name = this.parseName();
    if (Object.prototype.hasOwnProperty.call(DirectiveLocation, name.value)) {
      return name;
    }
    throw this.unexpected(start);
  }
  // Core parsing utility functions
  /**
   * Returns a node that, if configured to do so, sets a "loc" field as a
   * location object, used to identify the place in the source that created a
   * given parsed object.
   */
  node(startToken, node) {
    if (this._options.noLocation !== true) {
      node.loc = new Location(
        startToken,
        this._lexer.lastToken,
        this._lexer.source
      );
    }
    return node;
  }
  /**
   * Determines if the next token is of a given kind
   */
  peek(kind) {
    return this._lexer.token.kind === kind;
  }
  /**
   * If the next token is of the given kind, return that token after advancing the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectToken(kind) {
    const token = this._lexer.token;
    if (token.kind === kind) {
      this.advanceLexer();
      return token;
    }
    throw syntaxError(
      this._lexer.source,
      token.start,
      `Expected ${getTokenKindDesc(kind)}, found ${getTokenDesc(token)}.`
    );
  }
  /**
   * If the next token is of the given kind, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalToken(kind) {
    const token = this._lexer.token;
    if (token.kind === kind) {
      this.advanceLexer();
      return true;
    }
    return false;
  }
  /**
   * If the next token is a given keyword, advance the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectKeyword(value) {
    const token = this._lexer.token;
    if (token.kind === TokenKind.NAME && token.value === value) {
      this.advanceLexer();
    } else {
      throw syntaxError(
        this._lexer.source,
        token.start,
        `Expected "${value}", found ${getTokenDesc(token)}.`
      );
    }
  }
  /**
   * If the next token is a given keyword, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalKeyword(value) {
    const token = this._lexer.token;
    if (token.kind === TokenKind.NAME && token.value === value) {
      this.advanceLexer();
      return true;
    }
    return false;
  }
  /**
   * Helper function for creating an error when an unexpected lexed token is encountered.
   */
  unexpected(atToken) {
    const token = atToken !== null && atToken !== void 0 ? atToken : this._lexer.token;
    return syntaxError(
      this._lexer.source,
      token.start,
      `Unexpected ${getTokenDesc(token)}.`
    );
  }
  /**
   * Returns a possibly empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  any(openKind, parseFn, closeKind) {
    this.expectToken(openKind);
    const nodes = [];
    while (!this.expectOptionalToken(closeKind)) {
      nodes.push(parseFn.call(this));
    }
    return nodes;
  }
  /**
   * Returns a list of parse nodes, determined by the parseFn.
   * It can be empty only if open token is missing otherwise it will always return non-empty list
   * that begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  optionalMany(openKind, parseFn, closeKind) {
    if (this.expectOptionalToken(openKind)) {
      const nodes = [];
      do {
        nodes.push(parseFn.call(this));
      } while (!this.expectOptionalToken(closeKind));
      return nodes;
    }
    return [];
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  many(openKind, parseFn, closeKind) {
    this.expectToken(openKind);
    const nodes = [];
    do {
      nodes.push(parseFn.call(this));
    } while (!this.expectOptionalToken(closeKind));
    return nodes;
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list may begin with a lex token of delimiterKind followed by items separated by lex tokens of tokenKind.
   * Advances the parser to the next lex token after last item in the list.
   */
  delimitedMany(delimiterKind, parseFn) {
    this.expectOptionalToken(delimiterKind);
    const nodes = [];
    do {
      nodes.push(parseFn.call(this));
    } while (this.expectOptionalToken(delimiterKind));
    return nodes;
  }
  advanceLexer() {
    const { maxTokens } = this._options;
    const token = this._lexer.advance();
    if (maxTokens !== void 0 && token.kind !== TokenKind.EOF) {
      ++this._tokenCounter;
      if (this._tokenCounter > maxTokens) {
        throw syntaxError(
          this._lexer.source,
          token.start,
          `Document contains more that ${maxTokens} tokens. Parsing aborted.`
        );
      }
    }
  }
};
function getTokenDesc(token) {
  const value = token.value;
  return getTokenKindDesc(token.kind) + (value != null ? ` "${value}"` : "");
}
function getTokenKindDesc(kind) {
  return isPunctuatorTokenKind(kind) ? `"${kind}"` : kind;
}
var MAX_SUGGESTIONS = 5;
function didYouMean(firstArg, secondArg) {
  const [subMessage, suggestionsArg] = secondArg ? [firstArg, secondArg] : [void 0, firstArg];
  let message3 = " Did you mean ";
  if (subMessage) {
    message3 += subMessage + " ";
  }
  const suggestions = suggestionsArg.map((x) => `"${x}"`);
  switch (suggestions.length) {
    case 0:
      return "";
    case 1:
      return message3 + suggestions[0] + "?";
    case 2:
      return message3 + suggestions[0] + " or " + suggestions[1] + "?";
  }
  const selected = suggestions.slice(0, MAX_SUGGESTIONS);
  const lastItem = selected.pop();
  return message3 + selected.join(", ") + ", or " + lastItem + "?";
}
function identityFunc(x) {
  return x;
}
function keyMap(list, keyFn) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const item of list) {
    result[keyFn(item)] = item;
  }
  return result;
}
function keyValMap(list, keyFn, valFn) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const item of list) {
    result[keyFn(item)] = valFn(item);
  }
  return result;
}
function mapValue(map, fn) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const key of Object.keys(map)) {
    result[key] = fn(map[key], key);
  }
  return result;
}
function naturalCompare(aStr, bStr) {
  let aIndex = 0;
  let bIndex = 0;
  while (aIndex < aStr.length && bIndex < bStr.length) {
    let aChar = aStr.charCodeAt(aIndex);
    let bChar = bStr.charCodeAt(bIndex);
    if (isDigit2(aChar) && isDigit2(bChar)) {
      let aNum = 0;
      do {
        ++aIndex;
        aNum = aNum * 10 + aChar - DIGIT_0;
        aChar = aStr.charCodeAt(aIndex);
      } while (isDigit2(aChar) && aNum > 0);
      let bNum = 0;
      do {
        ++bIndex;
        bNum = bNum * 10 + bChar - DIGIT_0;
        bChar = bStr.charCodeAt(bIndex);
      } while (isDigit2(bChar) && bNum > 0);
      if (aNum < bNum) {
        return -1;
      }
      if (aNum > bNum) {
        return 1;
      }
    } else {
      if (aChar < bChar) {
        return -1;
      }
      if (aChar > bChar) {
        return 1;
      }
      ++aIndex;
      ++bIndex;
    }
  }
  return aStr.length - bStr.length;
}
var DIGIT_0 = 48;
var DIGIT_9 = 57;
function isDigit2(code) {
  return !isNaN(code) && DIGIT_0 <= code && code <= DIGIT_9;
}
function suggestionList(input, options) {
  const optionsByDistance = /* @__PURE__ */ Object.create(null);
  const lexicalDistance = new LexicalDistance(input);
  const threshold = Math.floor(input.length * 0.4) + 1;
  for (const option of options) {
    const distance = lexicalDistance.measure(option, threshold);
    if (distance !== void 0) {
      optionsByDistance[option] = distance;
    }
  }
  return Object.keys(optionsByDistance).sort((a, b) => {
    const distanceDiff = optionsByDistance[a] - optionsByDistance[b];
    return distanceDiff !== 0 ? distanceDiff : naturalCompare(a, b);
  });
}
var LexicalDistance = class {
  constructor(input) {
    this._input = input;
    this._inputLowerCase = input.toLowerCase();
    this._inputArray = stringToArray(this._inputLowerCase);
    this._rows = [
      new Array(input.length + 1).fill(0),
      new Array(input.length + 1).fill(0),
      new Array(input.length + 1).fill(0)
    ];
  }
  measure(option, threshold) {
    if (this._input === option) {
      return 0;
    }
    const optionLowerCase = option.toLowerCase();
    if (this._inputLowerCase === optionLowerCase) {
      return 1;
    }
    let a = stringToArray(optionLowerCase);
    let b = this._inputArray;
    if (a.length < b.length) {
      const tmp = a;
      a = b;
      b = tmp;
    }
    const aLength = a.length;
    const bLength = b.length;
    if (aLength - bLength > threshold) {
      return void 0;
    }
    const rows = this._rows;
    for (let j = 0; j <= bLength; j++) {
      rows[0][j] = j;
    }
    for (let i = 1; i <= aLength; i++) {
      const upRow = rows[(i - 1) % 3];
      const currentRow = rows[i % 3];
      let smallestCell = currentRow[0] = i;
      for (let j = 1; j <= bLength; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        let currentCell = Math.min(
          upRow[j] + 1,
          // delete
          currentRow[j - 1] + 1,
          // insert
          upRow[j - 1] + cost
          // substitute
        );
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
          const doubleDiagonalCell = rows[(i - 2) % 3][j - 2];
          currentCell = Math.min(currentCell, doubleDiagonalCell + 1);
        }
        if (currentCell < smallestCell) {
          smallestCell = currentCell;
        }
        currentRow[j] = currentCell;
      }
      if (smallestCell > threshold) {
        return void 0;
      }
    }
    const distance = rows[aLength % 3][bLength];
    return distance <= threshold ? distance : void 0;
  }
};
function stringToArray(str) {
  const strLength = str.length;
  const array = new Array(strLength);
  for (let i = 0; i < strLength; ++i) {
    array[i] = str.charCodeAt(i);
  }
  return array;
}
function toObjMap(obj) {
  if (obj == null) {
    return /* @__PURE__ */ Object.create(null);
  }
  if (Object.getPrototypeOf(obj) === null) {
    return obj;
  }
  const map = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of Object.entries(obj)) {
    map[key] = value;
  }
  return map;
}
function printString(str) {
  return `"${str.replace(escapedRegExp, escapedReplacer)}"`;
}
var escapedRegExp = /[\x00-\x1f\x22\x5c\x7f-\x9f]/g;
function escapedReplacer(str) {
  return escapeSequences[str.charCodeAt(0)];
}
var escapeSequences = [
  "\\u0000",
  "\\u0001",
  "\\u0002",
  "\\u0003",
  "\\u0004",
  "\\u0005",
  "\\u0006",
  "\\u0007",
  "\\b",
  "\\t",
  "\\n",
  "\\u000B",
  "\\f",
  "\\r",
  "\\u000E",
  "\\u000F",
  "\\u0010",
  "\\u0011",
  "\\u0012",
  "\\u0013",
  "\\u0014",
  "\\u0015",
  "\\u0016",
  "\\u0017",
  "\\u0018",
  "\\u0019",
  "\\u001A",
  "\\u001B",
  "\\u001C",
  "\\u001D",
  "\\u001E",
  "\\u001F",
  "",
  "",
  '\\"',
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 2F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 3F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 4F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "\\\\",
  "",
  "",
  "",
  // 5F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  // 6F
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "",
  "\\u007F",
  "\\u0080",
  "\\u0081",
  "\\u0082",
  "\\u0083",
  "\\u0084",
  "\\u0085",
  "\\u0086",
  "\\u0087",
  "\\u0088",
  "\\u0089",
  "\\u008A",
  "\\u008B",
  "\\u008C",
  "\\u008D",
  "\\u008E",
  "\\u008F",
  "\\u0090",
  "\\u0091",
  "\\u0092",
  "\\u0093",
  "\\u0094",
  "\\u0095",
  "\\u0096",
  "\\u0097",
  "\\u0098",
  "\\u0099",
  "\\u009A",
  "\\u009B",
  "\\u009C",
  "\\u009D",
  "\\u009E",
  "\\u009F"
];
var BREAK = Object.freeze({});
function visit(root, visitor, visitorKeys = QueryDocumentKeys) {
  const enterLeaveMap = /* @__PURE__ */ new Map();
  for (const kind of Object.values(Kind)) {
    enterLeaveMap.set(kind, getEnterLeaveForKind(visitor, kind));
  }
  let stack = void 0;
  let inArray = Array.isArray(root);
  let keys = [root];
  let index = -1;
  let edits = [];
  let node = root;
  let key = void 0;
  let parent = void 0;
  const path = [];
  const ancestors = [];
  do {
    index++;
    const isLeaving = index === keys.length;
    const isEdited = isLeaving && edits.length !== 0;
    if (isLeaving) {
      key = ancestors.length === 0 ? void 0 : path[path.length - 1];
      node = parent;
      parent = ancestors.pop();
      if (isEdited) {
        if (inArray) {
          node = node.slice();
          let editOffset = 0;
          for (const [editKey, editValue] of edits) {
            const arrayKey = editKey - editOffset;
            if (editValue === null) {
              node.splice(arrayKey, 1);
              editOffset++;
            } else {
              node[arrayKey] = editValue;
            }
          }
        } else {
          node = Object.defineProperties(
            {},
            Object.getOwnPropertyDescriptors(node)
          );
          for (const [editKey, editValue] of edits) {
            node[editKey] = editValue;
          }
        }
      }
      index = stack.index;
      keys = stack.keys;
      edits = stack.edits;
      inArray = stack.inArray;
      stack = stack.prev;
    } else if (parent) {
      key = inArray ? index : keys[index];
      node = parent[key];
      if (node === null || node === void 0) {
        continue;
      }
      path.push(key);
    }
    let result;
    if (!Array.isArray(node)) {
      var _enterLeaveMap$get, _enterLeaveMap$get2;
      isNode(node) || devAssert(false, `Invalid AST Node: ${inspect(node)}.`);
      const visitFn = isLeaving ? (_enterLeaveMap$get = enterLeaveMap.get(node.kind)) === null || _enterLeaveMap$get === void 0 ? void 0 : _enterLeaveMap$get.leave : (_enterLeaveMap$get2 = enterLeaveMap.get(node.kind)) === null || _enterLeaveMap$get2 === void 0 ? void 0 : _enterLeaveMap$get2.enter;
      result = visitFn === null || visitFn === void 0 ? void 0 : visitFn.call(visitor, node, key, parent, path, ancestors);
      if (result === BREAK) {
        break;
      }
      if (result === false) {
        if (!isLeaving) {
          path.pop();
          continue;
        }
      } else if (result !== void 0) {
        edits.push([key, result]);
        if (!isLeaving) {
          if (isNode(result)) {
            node = result;
          } else {
            path.pop();
            continue;
          }
        }
      }
    }
    if (result === void 0 && isEdited) {
      edits.push([key, node]);
    }
    if (isLeaving) {
      path.pop();
    } else {
      var _node$kind;
      stack = {
        inArray,
        index,
        keys,
        edits,
        prev: stack
      };
      inArray = Array.isArray(node);
      keys = inArray ? node : (_node$kind = visitorKeys[node.kind]) !== null && _node$kind !== void 0 ? _node$kind : [];
      index = -1;
      edits = [];
      if (parent) {
        ancestors.push(parent);
      }
      parent = node;
    }
  } while (stack !== void 0);
  if (edits.length !== 0) {
    return edits[edits.length - 1][1];
  }
  return root;
}
function getEnterLeaveForKind(visitor, kind) {
  const kindVisitor = visitor[kind];
  if (typeof kindVisitor === "object") {
    return kindVisitor;
  } else if (typeof kindVisitor === "function") {
    return {
      enter: kindVisitor,
      leave: void 0
    };
  }
  return {
    enter: visitor.enter,
    leave: visitor.leave
  };
}
function print(ast) {
  return visit(ast, printDocASTReducer);
}
var MAX_LINE_LENGTH = 80;
var printDocASTReducer = {
  Name: {
    leave: (node) => node.value
  },
  Variable: {
    leave: (node) => "$" + node.name
  },
  // Document
  Document: {
    leave: (node) => join(node.definitions, "\n\n")
  },
  OperationDefinition: {
    leave(node) {
      const varDefs = wrap("(", join(node.variableDefinitions, ", "), ")");
      const prefix = join(
        [
          node.operation,
          join([node.name, varDefs]),
          join(node.directives, " ")
        ],
        " "
      );
      return (prefix === "query" ? "" : prefix + " ") + node.selectionSet;
    }
  },
  VariableDefinition: {
    leave: ({ variable, type, defaultValue, directives }) => variable + ": " + type + wrap(" = ", defaultValue) + wrap(" ", join(directives, " "))
  },
  SelectionSet: {
    leave: ({ selections }) => block(selections)
  },
  Field: {
    leave({ alias, name, arguments: args, directives, selectionSet }) {
      const prefix = wrap("", alias, ": ") + name;
      let argsLine = prefix + wrap("(", join(args, ", "), ")");
      if (argsLine.length > MAX_LINE_LENGTH) {
        argsLine = prefix + wrap("(\n", indent(join(args, "\n")), "\n)");
      }
      return join([argsLine, join(directives, " "), selectionSet], " ");
    }
  },
  Argument: {
    leave: ({ name, value }) => name + ": " + value
  },
  // Fragments
  FragmentSpread: {
    leave: ({ name, directives }) => "..." + name + wrap(" ", join(directives, " "))
  },
  InlineFragment: {
    leave: ({ typeCondition, directives, selectionSet }) => join(
      [
        "...",
        wrap("on ", typeCondition),
        join(directives, " "),
        selectionSet
      ],
      " "
    )
  },
  FragmentDefinition: {
    leave: ({ name, typeCondition, variableDefinitions, directives, selectionSet }) => (
      // or removed in the future.
      `fragment ${name}${wrap("(", join(variableDefinitions, ", "), ")")} on ${typeCondition} ${wrap("", join(directives, " "), " ")}` + selectionSet
    )
  },
  // Value
  IntValue: {
    leave: ({ value }) => value
  },
  FloatValue: {
    leave: ({ value }) => value
  },
  StringValue: {
    leave: ({ value, block: isBlockString }) => isBlockString ? printBlockString(value) : printString(value)
  },
  BooleanValue: {
    leave: ({ value }) => value ? "true" : "false"
  },
  NullValue: {
    leave: () => "null"
  },
  EnumValue: {
    leave: ({ value }) => value
  },
  ListValue: {
    leave: ({ values }) => "[" + join(values, ", ") + "]"
  },
  ObjectValue: {
    leave: ({ fields }) => "{" + join(fields, ", ") + "}"
  },
  ObjectField: {
    leave: ({ name, value }) => name + ": " + value
  },
  // Directive
  Directive: {
    leave: ({ name, arguments: args }) => "@" + name + wrap("(", join(args, ", "), ")")
  },
  // Type
  NamedType: {
    leave: ({ name }) => name
  },
  ListType: {
    leave: ({ type }) => "[" + type + "]"
  },
  NonNullType: {
    leave: ({ type }) => type + "!"
  },
  // Type System Definitions
  SchemaDefinition: {
    leave: ({ description, directives, operationTypes }) => wrap("", description, "\n") + join(["schema", join(directives, " "), block(operationTypes)], " ")
  },
  OperationTypeDefinition: {
    leave: ({ operation, type }) => operation + ": " + type
  },
  ScalarTypeDefinition: {
    leave: ({ description, name, directives }) => wrap("", description, "\n") + join(["scalar", name, join(directives, " ")], " ")
  },
  ObjectTypeDefinition: {
    leave: ({ description, name, interfaces, directives, fields }) => wrap("", description, "\n") + join(
      [
        "type",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  FieldDefinition: {
    leave: ({ description, name, arguments: args, type, directives }) => wrap("", description, "\n") + name + (hasMultilineItems(args) ? wrap("(\n", indent(join(args, "\n")), "\n)") : wrap("(", join(args, ", "), ")")) + ": " + type + wrap(" ", join(directives, " "))
  },
  InputValueDefinition: {
    leave: ({ description, name, type, defaultValue, directives }) => wrap("", description, "\n") + join(
      [name + ": " + type, wrap("= ", defaultValue), join(directives, " ")],
      " "
    )
  },
  InterfaceTypeDefinition: {
    leave: ({ description, name, interfaces, directives, fields }) => wrap("", description, "\n") + join(
      [
        "interface",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  UnionTypeDefinition: {
    leave: ({ description, name, directives, types }) => wrap("", description, "\n") + join(
      ["union", name, join(directives, " "), wrap("= ", join(types, " | "))],
      " "
    )
  },
  EnumTypeDefinition: {
    leave: ({ description, name, directives, values }) => wrap("", description, "\n") + join(["enum", name, join(directives, " "), block(values)], " ")
  },
  EnumValueDefinition: {
    leave: ({ description, name, directives }) => wrap("", description, "\n") + join([name, join(directives, " ")], " ")
  },
  InputObjectTypeDefinition: {
    leave: ({ description, name, directives, fields }) => wrap("", description, "\n") + join(["input", name, join(directives, " "), block(fields)], " ")
  },
  DirectiveDefinition: {
    leave: ({ description, name, arguments: args, repeatable, locations }) => wrap("", description, "\n") + "directive @" + name + (hasMultilineItems(args) ? wrap("(\n", indent(join(args, "\n")), "\n)") : wrap("(", join(args, ", "), ")")) + (repeatable ? " repeatable" : "") + " on " + join(locations, " | ")
  },
  SchemaExtension: {
    leave: ({ directives, operationTypes }) => join(
      ["extend schema", join(directives, " "), block(operationTypes)],
      " "
    )
  },
  ScalarTypeExtension: {
    leave: ({ name, directives }) => join(["extend scalar", name, join(directives, " ")], " ")
  },
  ObjectTypeExtension: {
    leave: ({ name, interfaces, directives, fields }) => join(
      [
        "extend type",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  InterfaceTypeExtension: {
    leave: ({ name, interfaces, directives, fields }) => join(
      [
        "extend interface",
        name,
        wrap("implements ", join(interfaces, " & ")),
        join(directives, " "),
        block(fields)
      ],
      " "
    )
  },
  UnionTypeExtension: {
    leave: ({ name, directives, types }) => join(
      [
        "extend union",
        name,
        join(directives, " "),
        wrap("= ", join(types, " | "))
      ],
      " "
    )
  },
  EnumTypeExtension: {
    leave: ({ name, directives, values }) => join(["extend enum", name, join(directives, " "), block(values)], " ")
  },
  InputObjectTypeExtension: {
    leave: ({ name, directives, fields }) => join(["extend input", name, join(directives, " "), block(fields)], " ")
  }
};
function join(maybeArray, separator = "") {
  var _maybeArray$filter$jo;
  return (_maybeArray$filter$jo = maybeArray === null || maybeArray === void 0 ? void 0 : maybeArray.filter((x) => x).join(separator)) !== null && _maybeArray$filter$jo !== void 0 ? _maybeArray$filter$jo : "";
}
function block(array) {
  return wrap("{\n", indent(join(array, "\n")), "\n}");
}
function wrap(start, maybeString, end = "") {
  return maybeString != null && maybeString !== "" ? start + maybeString + end : "";
}
function indent(str) {
  return wrap("  ", str.replace(/\n/g, "\n  "));
}
function hasMultilineItems(maybeArray) {
  var _maybeArray$some;
  return (_maybeArray$some = maybeArray === null || maybeArray === void 0 ? void 0 : maybeArray.some((str) => str.includes("\n"))) !== null && _maybeArray$some !== void 0 ? _maybeArray$some : false;
}
function valueFromASTUntyped(valueNode, variables) {
  switch (valueNode.kind) {
    case Kind.NULL:
      return null;
    case Kind.INT:
      return parseInt(valueNode.value, 10);
    case Kind.FLOAT:
      return parseFloat(valueNode.value);
    case Kind.STRING:
    case Kind.ENUM:
    case Kind.BOOLEAN:
      return valueNode.value;
    case Kind.LIST:
      return valueNode.values.map(
        (node) => valueFromASTUntyped(node, variables)
      );
    case Kind.OBJECT:
      return keyValMap(
        valueNode.fields,
        (field) => field.name.value,
        (field) => valueFromASTUntyped(field.value, variables)
      );
    case Kind.VARIABLE:
      return variables === null || variables === void 0 ? void 0 : variables[valueNode.name.value];
  }
}
function assertName(name) {
  name != null || devAssert(false, "Must provide name.");
  typeof name === "string" || devAssert(false, "Expected name to be a string.");
  if (name.length === 0) {
    throw new GraphQLError("Expected name to be a non-empty string.");
  }
  for (let i = 1; i < name.length; ++i) {
    if (!isNameContinue(name.charCodeAt(i))) {
      throw new GraphQLError(
        `Names must only contain [_a-zA-Z0-9] but "${name}" does not.`
      );
    }
  }
  if (!isNameStart(name.charCodeAt(0))) {
    throw new GraphQLError(
      `Names must start with [_a-zA-Z] but "${name}" does not.`
    );
  }
  return name;
}
function assertEnumValueName(name) {
  if (name === "true" || name === "false" || name === "null") {
    throw new GraphQLError(`Enum values cannot be named: ${name}`);
  }
  return assertName(name);
}
function isType(type) {
  return isScalarType(type) || isObjectType(type) || isInterfaceType(type) || isUnionType(type) || isEnumType(type) || isInputObjectType(type) || isListType(type) || isNonNullType(type);
}
function isScalarType(type) {
  return instanceOf(type, GraphQLScalarType);
}
function isObjectType(type) {
  return instanceOf(type, GraphQLObjectType);
}
function isInterfaceType(type) {
  return instanceOf(type, GraphQLInterfaceType);
}
function isUnionType(type) {
  return instanceOf(type, GraphQLUnionType);
}
function isEnumType(type) {
  return instanceOf(type, GraphQLEnumType);
}
function isInputObjectType(type) {
  return instanceOf(type, GraphQLInputObjectType);
}
function isListType(type) {
  return instanceOf(type, GraphQLList);
}
function isNonNullType(type) {
  return instanceOf(type, GraphQLNonNull);
}
function isInputType(type) {
  return isScalarType(type) || isEnumType(type) || isInputObjectType(type) || isWrappingType(type) && isInputType(type.ofType);
}
function isLeafType(type) {
  return isScalarType(type) || isEnumType(type);
}
function isCompositeType(type) {
  return isObjectType(type) || isInterfaceType(type) || isUnionType(type);
}
function isAbstractType(type) {
  return isInterfaceType(type) || isUnionType(type);
}
var GraphQLList = class {
  constructor(ofType) {
    isType(ofType) || devAssert(false, `Expected ${inspect(ofType)} to be a GraphQL type.`);
    this.ofType = ofType;
  }
  get [Symbol.toStringTag]() {
    return "GraphQLList";
  }
  toString() {
    return "[" + String(this.ofType) + "]";
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLNonNull = class {
  constructor(ofType) {
    isNullableType(ofType) || devAssert(
      false,
      `Expected ${inspect(ofType)} to be a GraphQL nullable type.`
    );
    this.ofType = ofType;
  }
  get [Symbol.toStringTag]() {
    return "GraphQLNonNull";
  }
  toString() {
    return String(this.ofType) + "!";
  }
  toJSON() {
    return this.toString();
  }
};
function isWrappingType(type) {
  return isListType(type) || isNonNullType(type);
}
function isNullableType(type) {
  return isType(type) && !isNonNullType(type);
}
function getNullableType(type) {
  if (type) {
    return isNonNullType(type) ? type.ofType : type;
  }
}
function getNamedType(type) {
  if (type) {
    let unwrappedType = type;
    while (isWrappingType(unwrappedType)) {
      unwrappedType = unwrappedType.ofType;
    }
    return unwrappedType;
  }
}
function resolveReadonlyArrayThunk(thunk) {
  return typeof thunk === "function" ? thunk() : thunk;
}
function resolveObjMapThunk(thunk) {
  return typeof thunk === "function" ? thunk() : thunk;
}
var GraphQLScalarType = class {
  constructor(config) {
    var _config$parseValue, _config$serialize, _config$parseLiteral, _config$extensionASTN;
    const parseValue2 = (_config$parseValue = config.parseValue) !== null && _config$parseValue !== void 0 ? _config$parseValue : identityFunc;
    this.name = assertName(config.name);
    this.description = config.description;
    this.specifiedByURL = config.specifiedByURL;
    this.serialize = (_config$serialize = config.serialize) !== null && _config$serialize !== void 0 ? _config$serialize : identityFunc;
    this.parseValue = parseValue2;
    this.parseLiteral = (_config$parseLiteral = config.parseLiteral) !== null && _config$parseLiteral !== void 0 ? _config$parseLiteral : (node, variables) => parseValue2(valueFromASTUntyped(node, variables));
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN = config.extensionASTNodes) !== null && _config$extensionASTN !== void 0 ? _config$extensionASTN : [];
    config.specifiedByURL == null || typeof config.specifiedByURL === "string" || devAssert(
      false,
      `${this.name} must provide "specifiedByURL" as a string, but got: ${inspect(config.specifiedByURL)}.`
    );
    config.serialize == null || typeof config.serialize === "function" || devAssert(
      false,
      `${this.name} must provide "serialize" function. If this custom Scalar is also used as an input type, ensure "parseValue" and "parseLiteral" functions are also provided.`
    );
    if (config.parseLiteral) {
      typeof config.parseValue === "function" && typeof config.parseLiteral === "function" || devAssert(
        false,
        `${this.name} must provide both "parseValue" and "parseLiteral" functions.`
      );
    }
  }
  get [Symbol.toStringTag]() {
    return "GraphQLScalarType";
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      specifiedByURL: this.specifiedByURL,
      serialize: this.serialize,
      parseValue: this.parseValue,
      parseLiteral: this.parseLiteral,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLObjectType = class {
  constructor(config) {
    var _config$extensionASTN2;
    this.name = assertName(config.name);
    this.description = config.description;
    this.isTypeOf = config.isTypeOf;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN2 = config.extensionASTNodes) !== null && _config$extensionASTN2 !== void 0 ? _config$extensionASTN2 : [];
    this._fields = () => defineFieldMap(config);
    this._interfaces = () => defineInterfaces(config);
    config.isTypeOf == null || typeof config.isTypeOf === "function" || devAssert(
      false,
      `${this.name} must provide "isTypeOf" as a function, but got: ${inspect(config.isTypeOf)}.`
    );
  }
  get [Symbol.toStringTag]() {
    return "GraphQLObjectType";
  }
  getFields() {
    if (typeof this._fields === "function") {
      this._fields = this._fields();
    }
    return this._fields;
  }
  getInterfaces() {
    if (typeof this._interfaces === "function") {
      this._interfaces = this._interfaces();
    }
    return this._interfaces;
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      interfaces: this.getInterfaces(),
      fields: fieldsToFieldsConfig(this.getFields()),
      isTypeOf: this.isTypeOf,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function defineInterfaces(config) {
  var _config$interfaces;
  const interfaces = resolveReadonlyArrayThunk(
    (_config$interfaces = config.interfaces) !== null && _config$interfaces !== void 0 ? _config$interfaces : []
  );
  Array.isArray(interfaces) || devAssert(
    false,
    `${config.name} interfaces must be an Array or a function which returns an Array.`
  );
  return interfaces;
}
function defineFieldMap(config) {
  const fieldMap = resolveObjMapThunk(config.fields);
  isPlainObj(fieldMap) || devAssert(
    false,
    `${config.name} fields must be an object with field names as keys or a function which returns such an object.`
  );
  return mapValue(fieldMap, (fieldConfig, fieldName) => {
    var _fieldConfig$args;
    isPlainObj(fieldConfig) || devAssert(
      false,
      `${config.name}.${fieldName} field config must be an object.`
    );
    fieldConfig.resolve == null || typeof fieldConfig.resolve === "function" || devAssert(
      false,
      `${config.name}.${fieldName} field resolver must be a function if provided, but got: ${inspect(fieldConfig.resolve)}.`
    );
    const argsConfig = (_fieldConfig$args = fieldConfig.args) !== null && _fieldConfig$args !== void 0 ? _fieldConfig$args : {};
    isPlainObj(argsConfig) || devAssert(
      false,
      `${config.name}.${fieldName} args must be an object with argument names as keys.`
    );
    return {
      name: assertName(fieldName),
      description: fieldConfig.description,
      type: fieldConfig.type,
      args: defineArguments(argsConfig),
      resolve: fieldConfig.resolve,
      subscribe: fieldConfig.subscribe,
      deprecationReason: fieldConfig.deprecationReason,
      extensions: toObjMap(fieldConfig.extensions),
      astNode: fieldConfig.astNode
    };
  });
}
function defineArguments(config) {
  return Object.entries(config).map(([argName, argConfig]) => ({
    name: assertName(argName),
    description: argConfig.description,
    type: argConfig.type,
    defaultValue: argConfig.defaultValue,
    deprecationReason: argConfig.deprecationReason,
    extensions: toObjMap(argConfig.extensions),
    astNode: argConfig.astNode
  }));
}
function isPlainObj(obj) {
  return isObjectLike(obj) && !Array.isArray(obj);
}
function fieldsToFieldsConfig(fields) {
  return mapValue(fields, (field) => ({
    description: field.description,
    type: field.type,
    args: argsToArgsConfig(field.args),
    resolve: field.resolve,
    subscribe: field.subscribe,
    deprecationReason: field.deprecationReason,
    extensions: field.extensions,
    astNode: field.astNode
  }));
}
function argsToArgsConfig(args) {
  return keyValMap(
    args,
    (arg) => arg.name,
    (arg) => ({
      description: arg.description,
      type: arg.type,
      defaultValue: arg.defaultValue,
      deprecationReason: arg.deprecationReason,
      extensions: arg.extensions,
      astNode: arg.astNode
    })
  );
}
function isRequiredArgument(arg) {
  return isNonNullType(arg.type) && arg.defaultValue === void 0;
}
var GraphQLInterfaceType = class {
  constructor(config) {
    var _config$extensionASTN3;
    this.name = assertName(config.name);
    this.description = config.description;
    this.resolveType = config.resolveType;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN3 = config.extensionASTNodes) !== null && _config$extensionASTN3 !== void 0 ? _config$extensionASTN3 : [];
    this._fields = defineFieldMap.bind(void 0, config);
    this._interfaces = defineInterfaces.bind(void 0, config);
    config.resolveType == null || typeof config.resolveType === "function" || devAssert(
      false,
      `${this.name} must provide "resolveType" as a function, but got: ${inspect(config.resolveType)}.`
    );
  }
  get [Symbol.toStringTag]() {
    return "GraphQLInterfaceType";
  }
  getFields() {
    if (typeof this._fields === "function") {
      this._fields = this._fields();
    }
    return this._fields;
  }
  getInterfaces() {
    if (typeof this._interfaces === "function") {
      this._interfaces = this._interfaces();
    }
    return this._interfaces;
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      interfaces: this.getInterfaces(),
      fields: fieldsToFieldsConfig(this.getFields()),
      resolveType: this.resolveType,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLUnionType = class {
  constructor(config) {
    var _config$extensionASTN4;
    this.name = assertName(config.name);
    this.description = config.description;
    this.resolveType = config.resolveType;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN4 = config.extensionASTNodes) !== null && _config$extensionASTN4 !== void 0 ? _config$extensionASTN4 : [];
    this._types = defineTypes.bind(void 0, config);
    config.resolveType == null || typeof config.resolveType === "function" || devAssert(
      false,
      `${this.name} must provide "resolveType" as a function, but got: ${inspect(config.resolveType)}.`
    );
  }
  get [Symbol.toStringTag]() {
    return "GraphQLUnionType";
  }
  getTypes() {
    if (typeof this._types === "function") {
      this._types = this._types();
    }
    return this._types;
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      types: this.getTypes(),
      resolveType: this.resolveType,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function defineTypes(config) {
  const types = resolveReadonlyArrayThunk(config.types);
  Array.isArray(types) || devAssert(
    false,
    `Must provide Array of types or a function which returns such an array for Union ${config.name}.`
  );
  return types;
}
var GraphQLEnumType = class {
  /* <T> */
  constructor(config) {
    var _config$extensionASTN5;
    this.name = assertName(config.name);
    this.description = config.description;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN5 = config.extensionASTNodes) !== null && _config$extensionASTN5 !== void 0 ? _config$extensionASTN5 : [];
    this._values = defineEnumValues(this.name, config.values);
    this._valueLookup = new Map(
      this._values.map((enumValue) => [enumValue.value, enumValue])
    );
    this._nameLookup = keyMap(this._values, (value) => value.name);
  }
  get [Symbol.toStringTag]() {
    return "GraphQLEnumType";
  }
  getValues() {
    return this._values;
  }
  getValue(name) {
    return this._nameLookup[name];
  }
  serialize(outputValue) {
    const enumValue = this._valueLookup.get(outputValue);
    if (enumValue === void 0) {
      throw new GraphQLError(
        `Enum "${this.name}" cannot represent value: ${inspect(outputValue)}`
      );
    }
    return enumValue.name;
  }
  parseValue(inputValue) {
    if (typeof inputValue !== "string") {
      const valueStr = inspect(inputValue);
      throw new GraphQLError(
        `Enum "${this.name}" cannot represent non-string value: ${valueStr}.` + didYouMeanEnumValue(this, valueStr)
      );
    }
    const enumValue = this.getValue(inputValue);
    if (enumValue == null) {
      throw new GraphQLError(
        `Value "${inputValue}" does not exist in "${this.name}" enum.` + didYouMeanEnumValue(this, inputValue)
      );
    }
    return enumValue.value;
  }
  parseLiteral(valueNode, _variables) {
    if (valueNode.kind !== Kind.ENUM) {
      const valueStr = print(valueNode);
      throw new GraphQLError(
        `Enum "${this.name}" cannot represent non-enum value: ${valueStr}.` + didYouMeanEnumValue(this, valueStr),
        {
          nodes: valueNode
        }
      );
    }
    const enumValue = this.getValue(valueNode.value);
    if (enumValue == null) {
      const valueStr = print(valueNode);
      throw new GraphQLError(
        `Value "${valueStr}" does not exist in "${this.name}" enum.` + didYouMeanEnumValue(this, valueStr),
        {
          nodes: valueNode
        }
      );
    }
    return enumValue.value;
  }
  toConfig() {
    const values = keyValMap(
      this.getValues(),
      (value) => value.name,
      (value) => ({
        description: value.description,
        value: value.value,
        deprecationReason: value.deprecationReason,
        extensions: value.extensions,
        astNode: value.astNode
      })
    );
    return {
      name: this.name,
      description: this.description,
      values,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function didYouMeanEnumValue(enumType, unknownValueStr) {
  const allNames = enumType.getValues().map((value) => value.name);
  const suggestedValues = suggestionList(unknownValueStr, allNames);
  return didYouMean("the enum value", suggestedValues);
}
function defineEnumValues(typeName, valueMap) {
  isPlainObj(valueMap) || devAssert(
    false,
    `${typeName} values must be an object with value names as keys.`
  );
  return Object.entries(valueMap).map(([valueName, valueConfig]) => {
    isPlainObj(valueConfig) || devAssert(
      false,
      `${typeName}.${valueName} must refer to an object with a "value" key representing an internal value but got: ${inspect(valueConfig)}.`
    );
    return {
      name: assertEnumValueName(valueName),
      description: valueConfig.description,
      value: valueConfig.value !== void 0 ? valueConfig.value : valueName,
      deprecationReason: valueConfig.deprecationReason,
      extensions: toObjMap(valueConfig.extensions),
      astNode: valueConfig.astNode
    };
  });
}
var GraphQLInputObjectType = class {
  constructor(config) {
    var _config$extensionASTN6;
    this.name = assertName(config.name);
    this.description = config.description;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    this.extensionASTNodes = (_config$extensionASTN6 = config.extensionASTNodes) !== null && _config$extensionASTN6 !== void 0 ? _config$extensionASTN6 : [];
    this._fields = defineInputFieldMap.bind(void 0, config);
  }
  get [Symbol.toStringTag]() {
    return "GraphQLInputObjectType";
  }
  getFields() {
    if (typeof this._fields === "function") {
      this._fields = this._fields();
    }
    return this._fields;
  }
  toConfig() {
    const fields = mapValue(this.getFields(), (field) => ({
      description: field.description,
      type: field.type,
      defaultValue: field.defaultValue,
      deprecationReason: field.deprecationReason,
      extensions: field.extensions,
      astNode: field.astNode
    }));
    return {
      name: this.name,
      description: this.description,
      fields,
      extensions: this.extensions,
      astNode: this.astNode,
      extensionASTNodes: this.extensionASTNodes
    };
  }
  toString() {
    return this.name;
  }
  toJSON() {
    return this.toString();
  }
};
function defineInputFieldMap(config) {
  const fieldMap = resolveObjMapThunk(config.fields);
  isPlainObj(fieldMap) || devAssert(
    false,
    `${config.name} fields must be an object with field names as keys or a function which returns such an object.`
  );
  return mapValue(fieldMap, (fieldConfig, fieldName) => {
    !("resolve" in fieldConfig) || devAssert(
      false,
      `${config.name}.${fieldName} field has a resolve property, but Input Types cannot define resolvers.`
    );
    return {
      name: assertName(fieldName),
      description: fieldConfig.description,
      type: fieldConfig.type,
      defaultValue: fieldConfig.defaultValue,
      deprecationReason: fieldConfig.deprecationReason,
      extensions: toObjMap(fieldConfig.extensions),
      astNode: fieldConfig.astNode
    };
  });
}
function isRequiredInputField(field) {
  return isNonNullType(field.type) && field.defaultValue === void 0;
}
function isTypeSubTypeOf(schema, maybeSubType, superType) {
  if (maybeSubType === superType) {
    return true;
  }
  if (isNonNullType(superType)) {
    if (isNonNullType(maybeSubType)) {
      return isTypeSubTypeOf(schema, maybeSubType.ofType, superType.ofType);
    }
    return false;
  }
  if (isNonNullType(maybeSubType)) {
    return isTypeSubTypeOf(schema, maybeSubType.ofType, superType);
  }
  if (isListType(superType)) {
    if (isListType(maybeSubType)) {
      return isTypeSubTypeOf(schema, maybeSubType.ofType, superType.ofType);
    }
    return false;
  }
  if (isListType(maybeSubType)) {
    return false;
  }
  return isAbstractType(superType) && (isInterfaceType(maybeSubType) || isObjectType(maybeSubType)) && schema.isSubType(superType, maybeSubType);
}
function doTypesOverlap(schema, typeA, typeB) {
  if (typeA === typeB) {
    return true;
  }
  if (isAbstractType(typeA)) {
    if (isAbstractType(typeB)) {
      return schema.getPossibleTypes(typeA).some((type) => schema.isSubType(typeB, type));
    }
    return schema.isSubType(typeA, typeB);
  }
  if (isAbstractType(typeB)) {
    return schema.isSubType(typeB, typeA);
  }
  return false;
}
var GRAPHQL_MAX_INT = 2147483647;
var GRAPHQL_MIN_INT = -2147483648;
var GraphQLInt = new GraphQLScalarType({
  name: "Int",
  description: "The `Int` scalar type represents non-fractional signed whole numeric values. Int can represent values between -(2^31) and 2^31 - 1.",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "boolean") {
      return coercedValue ? 1 : 0;
    }
    let num = coercedValue;
    if (typeof coercedValue === "string" && coercedValue !== "") {
      num = Number(coercedValue);
    }
    if (typeof num !== "number" || !Number.isInteger(num)) {
      throw new GraphQLError(
        `Int cannot represent non-integer value: ${inspect(coercedValue)}`
      );
    }
    if (num > GRAPHQL_MAX_INT || num < GRAPHQL_MIN_INT) {
      throw new GraphQLError(
        "Int cannot represent non 32-bit signed integer value: " + inspect(coercedValue)
      );
    }
    return num;
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "number" || !Number.isInteger(inputValue)) {
      throw new GraphQLError(
        `Int cannot represent non-integer value: ${inspect(inputValue)}`
      );
    }
    if (inputValue > GRAPHQL_MAX_INT || inputValue < GRAPHQL_MIN_INT) {
      throw new GraphQLError(
        `Int cannot represent non 32-bit signed integer value: ${inputValue}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.INT) {
      throw new GraphQLError(
        `Int cannot represent non-integer value: ${print(valueNode)}`,
        {
          nodes: valueNode
        }
      );
    }
    const num = parseInt(valueNode.value, 10);
    if (num > GRAPHQL_MAX_INT || num < GRAPHQL_MIN_INT) {
      throw new GraphQLError(
        `Int cannot represent non 32-bit signed integer value: ${valueNode.value}`,
        {
          nodes: valueNode
        }
      );
    }
    return num;
  }
});
var GraphQLFloat = new GraphQLScalarType({
  name: "Float",
  description: "The `Float` scalar type represents signed double-precision fractional values as specified by [IEEE 754](https://en.wikipedia.org/wiki/IEEE_floating_point).",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "boolean") {
      return coercedValue ? 1 : 0;
    }
    let num = coercedValue;
    if (typeof coercedValue === "string" && coercedValue !== "") {
      num = Number(coercedValue);
    }
    if (typeof num !== "number" || !Number.isFinite(num)) {
      throw new GraphQLError(
        `Float cannot represent non numeric value: ${inspect(coercedValue)}`
      );
    }
    return num;
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "number" || !Number.isFinite(inputValue)) {
      throw new GraphQLError(
        `Float cannot represent non numeric value: ${inspect(inputValue)}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.FLOAT && valueNode.kind !== Kind.INT) {
      throw new GraphQLError(
        `Float cannot represent non numeric value: ${print(valueNode)}`,
        valueNode
      );
    }
    return parseFloat(valueNode.value);
  }
});
var GraphQLString = new GraphQLScalarType({
  name: "String",
  description: "The `String` scalar type represents textual data, represented as UTF-8 character sequences. The String type is most often used by GraphQL to represent free-form human-readable text.",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "string") {
      return coercedValue;
    }
    if (typeof coercedValue === "boolean") {
      return coercedValue ? "true" : "false";
    }
    if (typeof coercedValue === "number" && Number.isFinite(coercedValue)) {
      return coercedValue.toString();
    }
    throw new GraphQLError(
      `String cannot represent value: ${inspect(outputValue)}`
    );
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "string") {
      throw new GraphQLError(
        `String cannot represent a non string value: ${inspect(inputValue)}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.STRING) {
      throw new GraphQLError(
        `String cannot represent a non string value: ${print(valueNode)}`,
        {
          nodes: valueNode
        }
      );
    }
    return valueNode.value;
  }
});
var GraphQLBoolean = new GraphQLScalarType({
  name: "Boolean",
  description: "The `Boolean` scalar type represents `true` or `false`.",
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "boolean") {
      return coercedValue;
    }
    if (Number.isFinite(coercedValue)) {
      return coercedValue !== 0;
    }
    throw new GraphQLError(
      `Boolean cannot represent a non boolean value: ${inspect(coercedValue)}`
    );
  },
  parseValue(inputValue) {
    if (typeof inputValue !== "boolean") {
      throw new GraphQLError(
        `Boolean cannot represent a non boolean value: ${inspect(inputValue)}`
      );
    }
    return inputValue;
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.BOOLEAN) {
      throw new GraphQLError(
        `Boolean cannot represent a non boolean value: ${print(valueNode)}`,
        {
          nodes: valueNode
        }
      );
    }
    return valueNode.value;
  }
});
var GraphQLID = new GraphQLScalarType({
  name: "ID",
  description: 'The `ID` scalar type represents a unique identifier, often used to refetch an object or as key for a cache. The ID type appears in a JSON response as a String; however, it is not intended to be human-readable. When expected as an input type, any string (such as `"4"`) or integer (such as `4`) input value will be accepted as an ID.',
  serialize(outputValue) {
    const coercedValue = serializeObject(outputValue);
    if (typeof coercedValue === "string") {
      return coercedValue;
    }
    if (Number.isInteger(coercedValue)) {
      return String(coercedValue);
    }
    throw new GraphQLError(
      `ID cannot represent value: ${inspect(outputValue)}`
    );
  },
  parseValue(inputValue) {
    if (typeof inputValue === "string") {
      return inputValue;
    }
    if (typeof inputValue === "number" && Number.isInteger(inputValue)) {
      return inputValue.toString();
    }
    throw new GraphQLError(`ID cannot represent value: ${inspect(inputValue)}`);
  },
  parseLiteral(valueNode) {
    if (valueNode.kind !== Kind.STRING && valueNode.kind !== Kind.INT) {
      throw new GraphQLError(
        "ID cannot represent a non-string and non-integer value: " + print(valueNode),
        {
          nodes: valueNode
        }
      );
    }
    return valueNode.value;
  }
});
var specifiedScalarTypes = Object.freeze([
  GraphQLString,
  GraphQLInt,
  GraphQLFloat,
  GraphQLBoolean,
  GraphQLID
]);
function serializeObject(outputValue) {
  if (isObjectLike(outputValue)) {
    if (typeof outputValue.valueOf === "function") {
      const valueOfResult = outputValue.valueOf();
      if (!isObjectLike(valueOfResult)) {
        return valueOfResult;
      }
    }
    if (typeof outputValue.toJSON === "function") {
      return outputValue.toJSON();
    }
  }
  return outputValue;
}
var GraphQLDirective = class {
  constructor(config) {
    var _config$isRepeatable, _config$args;
    this.name = assertName(config.name);
    this.description = config.description;
    this.locations = config.locations;
    this.isRepeatable = (_config$isRepeatable = config.isRepeatable) !== null && _config$isRepeatable !== void 0 ? _config$isRepeatable : false;
    this.extensions = toObjMap(config.extensions);
    this.astNode = config.astNode;
    Array.isArray(config.locations) || devAssert(false, `@${config.name} locations must be an Array.`);
    const args = (_config$args = config.args) !== null && _config$args !== void 0 ? _config$args : {};
    isObjectLike(args) && !Array.isArray(args) || devAssert(
      false,
      `@${config.name} args must be an object with argument names as keys.`
    );
    this.args = defineArguments(args);
  }
  get [Symbol.toStringTag]() {
    return "GraphQLDirective";
  }
  toConfig() {
    return {
      name: this.name,
      description: this.description,
      locations: this.locations,
      args: argsToArgsConfig(this.args),
      isRepeatable: this.isRepeatable,
      extensions: this.extensions,
      astNode: this.astNode
    };
  }
  toString() {
    return "@" + this.name;
  }
  toJSON() {
    return this.toString();
  }
};
var GraphQLIncludeDirective = new GraphQLDirective({
  name: "include",
  description: "Directs the executor to include this field or fragment only when the `if` argument is true.",
  locations: [
    DirectiveLocation.FIELD,
    DirectiveLocation.FRAGMENT_SPREAD,
    DirectiveLocation.INLINE_FRAGMENT
  ],
  args: {
    if: {
      type: new GraphQLNonNull(GraphQLBoolean),
      description: "Included when true."
    }
  }
});
var GraphQLSkipDirective = new GraphQLDirective({
  name: "skip",
  description: "Directs the executor to skip this field or fragment when the `if` argument is true.",
  locations: [
    DirectiveLocation.FIELD,
    DirectiveLocation.FRAGMENT_SPREAD,
    DirectiveLocation.INLINE_FRAGMENT
  ],
  args: {
    if: {
      type: new GraphQLNonNull(GraphQLBoolean),
      description: "Skipped when true."
    }
  }
});
var DEFAULT_DEPRECATION_REASON = "No longer supported";
var GraphQLDeprecatedDirective = new GraphQLDirective({
  name: "deprecated",
  description: "Marks an element of a GraphQL schema as no longer supported.",
  locations: [
    DirectiveLocation.FIELD_DEFINITION,
    DirectiveLocation.ARGUMENT_DEFINITION,
    DirectiveLocation.INPUT_FIELD_DEFINITION,
    DirectiveLocation.ENUM_VALUE
  ],
  args: {
    reason: {
      type: GraphQLString,
      description: "Explains why this element was deprecated, usually also including a suggestion for how to access supported similar data. Formatted using the Markdown syntax, as specified by [CommonMark](https://commonmark.org/).",
      defaultValue: DEFAULT_DEPRECATION_REASON
    }
  }
});
var GraphQLSpecifiedByDirective = new GraphQLDirective({
  name: "specifiedBy",
  description: "Exposes a URL that specifies the behavior of this scalar.",
  locations: [DirectiveLocation.SCALAR],
  args: {
    url: {
      type: new GraphQLNonNull(GraphQLString),
      description: "The URL that specifies the behavior of this scalar."
    }
  }
});
var specifiedDirectives = Object.freeze([
  GraphQLIncludeDirective,
  GraphQLSkipDirective,
  GraphQLDeprecatedDirective,
  GraphQLSpecifiedByDirective
]);
function isIterableObject(maybeIterable) {
  return typeof maybeIterable === "object" && typeof (maybeIterable === null || maybeIterable === void 0 ? void 0 : maybeIterable[Symbol.iterator]) === "function";
}
function astFromValue(value, type) {
  if (isNonNullType(type)) {
    const astValue = astFromValue(value, type.ofType);
    if ((astValue === null || astValue === void 0 ? void 0 : astValue.kind) === Kind.NULL) {
      return null;
    }
    return astValue;
  }
  if (value === null) {
    return {
      kind: Kind.NULL
    };
  }
  if (value === void 0) {
    return null;
  }
  if (isListType(type)) {
    const itemType = type.ofType;
    if (isIterableObject(value)) {
      const valuesNodes = [];
      for (const item of value) {
        const itemNode = astFromValue(item, itemType);
        if (itemNode != null) {
          valuesNodes.push(itemNode);
        }
      }
      return {
        kind: Kind.LIST,
        values: valuesNodes
      };
    }
    return astFromValue(value, itemType);
  }
  if (isInputObjectType(type)) {
    if (!isObjectLike(value)) {
      return null;
    }
    const fieldNodes = [];
    for (const field of Object.values(type.getFields())) {
      const fieldValue = astFromValue(value[field.name], field.type);
      if (fieldValue) {
        fieldNodes.push({
          kind: Kind.OBJECT_FIELD,
          name: {
            kind: Kind.NAME,
            value: field.name
          },
          value: fieldValue
        });
      }
    }
    return {
      kind: Kind.OBJECT,
      fields: fieldNodes
    };
  }
  if (isLeafType(type)) {
    const serialized = type.serialize(value);
    if (serialized == null) {
      return null;
    }
    if (typeof serialized === "boolean") {
      return {
        kind: Kind.BOOLEAN,
        value: serialized
      };
    }
    if (typeof serialized === "number" && Number.isFinite(serialized)) {
      const stringNum = String(serialized);
      return integerStringRegExp.test(stringNum) ? {
        kind: Kind.INT,
        value: stringNum
      } : {
        kind: Kind.FLOAT,
        value: stringNum
      };
    }
    if (typeof serialized === "string") {
      if (isEnumType(type)) {
        return {
          kind: Kind.ENUM,
          value: serialized
        };
      }
      if (type === GraphQLID && integerStringRegExp.test(serialized)) {
        return {
          kind: Kind.INT,
          value: serialized
        };
      }
      return {
        kind: Kind.STRING,
        value: serialized
      };
    }
    throw new TypeError(`Cannot convert value to AST: ${inspect(serialized)}.`);
  }
  invariant2(false, "Unexpected input type: " + inspect(type));
}
var integerStringRegExp = /^-?(?:0|[1-9][0-9]*)$/;
var __Schema = new GraphQLObjectType({
  name: "__Schema",
  description: "A GraphQL Schema defines the capabilities of a GraphQL server. It exposes all available types and directives on the server, as well as the entry points for query, mutation, and subscription operations.",
  fields: () => ({
    description: {
      type: GraphQLString,
      resolve: (schema) => schema.description
    },
    types: {
      description: "A list of all types supported by this server.",
      type: new GraphQLNonNull(new GraphQLList(new GraphQLNonNull(__Type))),
      resolve(schema) {
        return Object.values(schema.getTypeMap());
      }
    },
    queryType: {
      description: "The type that query operations will be rooted at.",
      type: new GraphQLNonNull(__Type),
      resolve: (schema) => schema.getQueryType()
    },
    mutationType: {
      description: "If this server supports mutation, the type that mutation operations will be rooted at.",
      type: __Type,
      resolve: (schema) => schema.getMutationType()
    },
    subscriptionType: {
      description: "If this server support subscription, the type that subscription operations will be rooted at.",
      type: __Type,
      resolve: (schema) => schema.getSubscriptionType()
    },
    directives: {
      description: "A list of all directives supported by this server.",
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__Directive))
      ),
      resolve: (schema) => schema.getDirectives()
    }
  })
});
var __Directive = new GraphQLObjectType({
  name: "__Directive",
  description: "A Directive provides a way to describe alternate runtime execution and type validation behavior in a GraphQL document.\n\nIn some cases, you need to provide options to alter GraphQL's execution behavior in ways field arguments will not suffice, such as conditionally including or skipping a field. Directives provide this by describing additional information to the executor.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (directive) => directive.name
    },
    description: {
      type: GraphQLString,
      resolve: (directive) => directive.description
    },
    isRepeatable: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (directive) => directive.isRepeatable
    },
    locations: {
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__DirectiveLocation))
      ),
      resolve: (directive) => directive.locations
    },
    args: {
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__InputValue))
      ),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(field, { includeDeprecated }) {
        return includeDeprecated ? field.args : field.args.filter((arg) => arg.deprecationReason == null);
      }
    }
  })
});
var __DirectiveLocation = new GraphQLEnumType({
  name: "__DirectiveLocation",
  description: "A Directive can be adjacent to many parts of the GraphQL language, a __DirectiveLocation describes one such possible adjacencies.",
  values: {
    QUERY: {
      value: DirectiveLocation.QUERY,
      description: "Location adjacent to a query operation."
    },
    MUTATION: {
      value: DirectiveLocation.MUTATION,
      description: "Location adjacent to a mutation operation."
    },
    SUBSCRIPTION: {
      value: DirectiveLocation.SUBSCRIPTION,
      description: "Location adjacent to a subscription operation."
    },
    FIELD: {
      value: DirectiveLocation.FIELD,
      description: "Location adjacent to a field."
    },
    FRAGMENT_DEFINITION: {
      value: DirectiveLocation.FRAGMENT_DEFINITION,
      description: "Location adjacent to a fragment definition."
    },
    FRAGMENT_SPREAD: {
      value: DirectiveLocation.FRAGMENT_SPREAD,
      description: "Location adjacent to a fragment spread."
    },
    INLINE_FRAGMENT: {
      value: DirectiveLocation.INLINE_FRAGMENT,
      description: "Location adjacent to an inline fragment."
    },
    VARIABLE_DEFINITION: {
      value: DirectiveLocation.VARIABLE_DEFINITION,
      description: "Location adjacent to a variable definition."
    },
    SCHEMA: {
      value: DirectiveLocation.SCHEMA,
      description: "Location adjacent to a schema definition."
    },
    SCALAR: {
      value: DirectiveLocation.SCALAR,
      description: "Location adjacent to a scalar definition."
    },
    OBJECT: {
      value: DirectiveLocation.OBJECT,
      description: "Location adjacent to an object type definition."
    },
    FIELD_DEFINITION: {
      value: DirectiveLocation.FIELD_DEFINITION,
      description: "Location adjacent to a field definition."
    },
    ARGUMENT_DEFINITION: {
      value: DirectiveLocation.ARGUMENT_DEFINITION,
      description: "Location adjacent to an argument definition."
    },
    INTERFACE: {
      value: DirectiveLocation.INTERFACE,
      description: "Location adjacent to an interface definition."
    },
    UNION: {
      value: DirectiveLocation.UNION,
      description: "Location adjacent to a union definition."
    },
    ENUM: {
      value: DirectiveLocation.ENUM,
      description: "Location adjacent to an enum definition."
    },
    ENUM_VALUE: {
      value: DirectiveLocation.ENUM_VALUE,
      description: "Location adjacent to an enum value definition."
    },
    INPUT_OBJECT: {
      value: DirectiveLocation.INPUT_OBJECT,
      description: "Location adjacent to an input object type definition."
    },
    INPUT_FIELD_DEFINITION: {
      value: DirectiveLocation.INPUT_FIELD_DEFINITION,
      description: "Location adjacent to an input object field definition."
    }
  }
});
var __Type = new GraphQLObjectType({
  name: "__Type",
  description: "The fundamental unit of any GraphQL Schema is the type. There are many kinds of types in GraphQL as represented by the `__TypeKind` enum.\n\nDepending on the kind of a type, certain fields describe information about that type. Scalar types provide no information beyond a name, description and optional `specifiedByURL`, while Enum types provide their values. Object and Interface types provide the fields they describe. Abstract types, Union and Interface, provide the Object types possible at runtime. List and NonNull types compose other types.",
  fields: () => ({
    kind: {
      type: new GraphQLNonNull(__TypeKind),
      resolve(type) {
        if (isScalarType(type)) {
          return TypeKind.SCALAR;
        }
        if (isObjectType(type)) {
          return TypeKind.OBJECT;
        }
        if (isInterfaceType(type)) {
          return TypeKind.INTERFACE;
        }
        if (isUnionType(type)) {
          return TypeKind.UNION;
        }
        if (isEnumType(type)) {
          return TypeKind.ENUM;
        }
        if (isInputObjectType(type)) {
          return TypeKind.INPUT_OBJECT;
        }
        if (isListType(type)) {
          return TypeKind.LIST;
        }
        if (isNonNullType(type)) {
          return TypeKind.NON_NULL;
        }
        invariant2(false, `Unexpected type: "${inspect(type)}".`);
      }
    },
    name: {
      type: GraphQLString,
      resolve: (type) => "name" in type ? type.name : void 0
    },
    description: {
      type: GraphQLString,
      resolve: (type) => (
        /* c8 ignore next */
        "description" in type ? type.description : void 0
      )
    },
    specifiedByURL: {
      type: GraphQLString,
      resolve: (obj) => "specifiedByURL" in obj ? obj.specifiedByURL : void 0
    },
    fields: {
      type: new GraphQLList(new GraphQLNonNull(__Field)),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(type, { includeDeprecated }) {
        if (isObjectType(type) || isInterfaceType(type)) {
          const fields = Object.values(type.getFields());
          return includeDeprecated ? fields : fields.filter((field) => field.deprecationReason == null);
        }
      }
    },
    interfaces: {
      type: new GraphQLList(new GraphQLNonNull(__Type)),
      resolve(type) {
        if (isObjectType(type) || isInterfaceType(type)) {
          return type.getInterfaces();
        }
      }
    },
    possibleTypes: {
      type: new GraphQLList(new GraphQLNonNull(__Type)),
      resolve(type, _args, _context, { schema }) {
        if (isAbstractType(type)) {
          return schema.getPossibleTypes(type);
        }
      }
    },
    enumValues: {
      type: new GraphQLList(new GraphQLNonNull(__EnumValue)),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(type, { includeDeprecated }) {
        if (isEnumType(type)) {
          const values = type.getValues();
          return includeDeprecated ? values : values.filter((field) => field.deprecationReason == null);
        }
      }
    },
    inputFields: {
      type: new GraphQLList(new GraphQLNonNull(__InputValue)),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(type, { includeDeprecated }) {
        if (isInputObjectType(type)) {
          const values = Object.values(type.getFields());
          return includeDeprecated ? values : values.filter((field) => field.deprecationReason == null);
        }
      }
    },
    ofType: {
      type: __Type,
      resolve: (type) => "ofType" in type ? type.ofType : void 0
    }
  })
});
var __Field = new GraphQLObjectType({
  name: "__Field",
  description: "Object and Interface types are described by a list of Fields, each of which has a name, potentially a list of arguments, and a return type.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (field) => field.name
    },
    description: {
      type: GraphQLString,
      resolve: (field) => field.description
    },
    args: {
      type: new GraphQLNonNull(
        new GraphQLList(new GraphQLNonNull(__InputValue))
      ),
      args: {
        includeDeprecated: {
          type: GraphQLBoolean,
          defaultValue: false
        }
      },
      resolve(field, { includeDeprecated }) {
        return includeDeprecated ? field.args : field.args.filter((arg) => arg.deprecationReason == null);
      }
    },
    type: {
      type: new GraphQLNonNull(__Type),
      resolve: (field) => field.type
    },
    isDeprecated: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (field) => field.deprecationReason != null
    },
    deprecationReason: {
      type: GraphQLString,
      resolve: (field) => field.deprecationReason
    }
  })
});
var __InputValue = new GraphQLObjectType({
  name: "__InputValue",
  description: "Arguments provided to Fields or Directives and the input fields of an InputObject are represented as Input Values which describe their type and optionally a default value.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (inputValue) => inputValue.name
    },
    description: {
      type: GraphQLString,
      resolve: (inputValue) => inputValue.description
    },
    type: {
      type: new GraphQLNonNull(__Type),
      resolve: (inputValue) => inputValue.type
    },
    defaultValue: {
      type: GraphQLString,
      description: "A GraphQL-formatted string representing the default value for this input value.",
      resolve(inputValue) {
        const { type, defaultValue } = inputValue;
        const valueAST = astFromValue(defaultValue, type);
        return valueAST ? print(valueAST) : null;
      }
    },
    isDeprecated: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (field) => field.deprecationReason != null
    },
    deprecationReason: {
      type: GraphQLString,
      resolve: (obj) => obj.deprecationReason
    }
  })
});
var __EnumValue = new GraphQLObjectType({
  name: "__EnumValue",
  description: "One possible value for a given Enum. Enum values are unique values, not a placeholder for a string or numeric value. However an Enum value is returned in a JSON response as a string.",
  fields: () => ({
    name: {
      type: new GraphQLNonNull(GraphQLString),
      resolve: (enumValue) => enumValue.name
    },
    description: {
      type: GraphQLString,
      resolve: (enumValue) => enumValue.description
    },
    isDeprecated: {
      type: new GraphQLNonNull(GraphQLBoolean),
      resolve: (enumValue) => enumValue.deprecationReason != null
    },
    deprecationReason: {
      type: GraphQLString,
      resolve: (enumValue) => enumValue.deprecationReason
    }
  })
});
var TypeKind;
(function(TypeKind2) {
  TypeKind2["SCALAR"] = "SCALAR";
  TypeKind2["OBJECT"] = "OBJECT";
  TypeKind2["INTERFACE"] = "INTERFACE";
  TypeKind2["UNION"] = "UNION";
  TypeKind2["ENUM"] = "ENUM";
  TypeKind2["INPUT_OBJECT"] = "INPUT_OBJECT";
  TypeKind2["LIST"] = "LIST";
  TypeKind2["NON_NULL"] = "NON_NULL";
})(TypeKind || (TypeKind = {}));
var __TypeKind = new GraphQLEnumType({
  name: "__TypeKind",
  description: "An enum describing what kind of type a given `__Type` is.",
  values: {
    SCALAR: {
      value: TypeKind.SCALAR,
      description: "Indicates this type is a scalar."
    },
    OBJECT: {
      value: TypeKind.OBJECT,
      description: "Indicates this type is an object. `fields` and `interfaces` are valid fields."
    },
    INTERFACE: {
      value: TypeKind.INTERFACE,
      description: "Indicates this type is an interface. `fields`, `interfaces`, and `possibleTypes` are valid fields."
    },
    UNION: {
      value: TypeKind.UNION,
      description: "Indicates this type is a union. `possibleTypes` is a valid field."
    },
    ENUM: {
      value: TypeKind.ENUM,
      description: "Indicates this type is an enum. `enumValues` is a valid field."
    },
    INPUT_OBJECT: {
      value: TypeKind.INPUT_OBJECT,
      description: "Indicates this type is an input object. `inputFields` is a valid field."
    },
    LIST: {
      value: TypeKind.LIST,
      description: "Indicates this type is a list. `ofType` is a valid field."
    },
    NON_NULL: {
      value: TypeKind.NON_NULL,
      description: "Indicates this type is a non-null. `ofType` is a valid field."
    }
  }
});
var SchemaMetaFieldDef = {
  name: "__schema",
  type: new GraphQLNonNull(__Schema),
  description: "Access the current type schema of this server.",
  args: [],
  resolve: (_source, _args, _context, { schema }) => schema,
  deprecationReason: void 0,
  extensions: /* @__PURE__ */ Object.create(null),
  astNode: void 0
};
var TypeMetaFieldDef = {
  name: "__type",
  type: __Type,
  description: "Request the type information of a single type.",
  args: [
    {
      name: "name",
      description: void 0,
      type: new GraphQLNonNull(GraphQLString),
      defaultValue: void 0,
      deprecationReason: void 0,
      extensions: /* @__PURE__ */ Object.create(null),
      astNode: void 0
    }
  ],
  resolve: (_source, { name }, _context, { schema }) => schema.getType(name),
  deprecationReason: void 0,
  extensions: /* @__PURE__ */ Object.create(null),
  astNode: void 0
};
var TypeNameMetaFieldDef = {
  name: "__typename",
  type: new GraphQLNonNull(GraphQLString),
  description: "The name of the current Object type at runtime.",
  args: [],
  resolve: (_source, _args, _context, { parentType }) => parentType.name,
  deprecationReason: void 0,
  extensions: /* @__PURE__ */ Object.create(null),
  astNode: void 0
};
var introspectionTypes = Object.freeze([
  __Schema,
  __Directive,
  __DirectiveLocation,
  __Type,
  __Field,
  __InputValue,
  __EnumValue,
  __TypeKind
]);
function typeFromAST(schema, typeNode) {
  switch (typeNode.kind) {
    case Kind.LIST_TYPE: {
      const innerType = typeFromAST(schema, typeNode.type);
      return innerType && new GraphQLList(innerType);
    }
    case Kind.NON_NULL_TYPE: {
      const innerType = typeFromAST(schema, typeNode.type);
      return innerType && new GraphQLNonNull(innerType);
    }
    case Kind.NAMED_TYPE:
      return schema.getType(typeNode.name.value);
  }
}
function isExecutableDefinitionNode(node) {
  return node.kind === Kind.OPERATION_DEFINITION || node.kind === Kind.FRAGMENT_DEFINITION;
}
function isTypeSystemDefinitionNode(node) {
  return node.kind === Kind.SCHEMA_DEFINITION || isTypeDefinitionNode(node) || node.kind === Kind.DIRECTIVE_DEFINITION;
}
function isTypeDefinitionNode(node) {
  return node.kind === Kind.SCALAR_TYPE_DEFINITION || node.kind === Kind.OBJECT_TYPE_DEFINITION || node.kind === Kind.INTERFACE_TYPE_DEFINITION || node.kind === Kind.UNION_TYPE_DEFINITION || node.kind === Kind.ENUM_TYPE_DEFINITION || node.kind === Kind.INPUT_OBJECT_TYPE_DEFINITION;
}
function isTypeSystemExtensionNode(node) {
  return node.kind === Kind.SCHEMA_EXTENSION || isTypeExtensionNode(node);
}
function isTypeExtensionNode(node) {
  return node.kind === Kind.SCALAR_TYPE_EXTENSION || node.kind === Kind.OBJECT_TYPE_EXTENSION || node.kind === Kind.INTERFACE_TYPE_EXTENSION || node.kind === Kind.UNION_TYPE_EXTENSION || node.kind === Kind.ENUM_TYPE_EXTENSION || node.kind === Kind.INPUT_OBJECT_TYPE_EXTENSION;
}
function ExecutableDefinitionsRule(context) {
  return {
    Document(node) {
      for (const definition of node.definitions) {
        if (!isExecutableDefinitionNode(definition)) {
          const defName = definition.kind === Kind.SCHEMA_DEFINITION || definition.kind === Kind.SCHEMA_EXTENSION ? "schema" : '"' + definition.name.value + '"';
          context.reportError(
            new GraphQLError(`The ${defName} definition is not executable.`, {
              nodes: definition
            })
          );
        }
      }
      return false;
    }
  };
}
function FieldsOnCorrectTypeRule(context) {
  return {
    Field(node) {
      const type = context.getParentType();
      if (type) {
        const fieldDef = context.getFieldDef();
        if (!fieldDef) {
          const schema = context.getSchema();
          const fieldName = node.name.value;
          let suggestion = didYouMean(
            "to use an inline fragment on",
            getSuggestedTypeNames(schema, type, fieldName)
          );
          if (suggestion === "") {
            suggestion = didYouMean(getSuggestedFieldNames(type, fieldName));
          }
          context.reportError(
            new GraphQLError(
              `Cannot query field "${fieldName}" on type "${type.name}".` + suggestion,
              {
                nodes: node
              }
            )
          );
        }
      }
    }
  };
}
function getSuggestedTypeNames(schema, type, fieldName) {
  if (!isAbstractType(type)) {
    return [];
  }
  const suggestedTypes = /* @__PURE__ */ new Set();
  const usageCount = /* @__PURE__ */ Object.create(null);
  for (const possibleType of schema.getPossibleTypes(type)) {
    if (!possibleType.getFields()[fieldName]) {
      continue;
    }
    suggestedTypes.add(possibleType);
    usageCount[possibleType.name] = 1;
    for (const possibleInterface of possibleType.getInterfaces()) {
      var _usageCount$possibleI;
      if (!possibleInterface.getFields()[fieldName]) {
        continue;
      }
      suggestedTypes.add(possibleInterface);
      usageCount[possibleInterface.name] = ((_usageCount$possibleI = usageCount[possibleInterface.name]) !== null && _usageCount$possibleI !== void 0 ? _usageCount$possibleI : 0) + 1;
    }
  }
  return [...suggestedTypes].sort((typeA, typeB) => {
    const usageCountDiff = usageCount[typeB.name] - usageCount[typeA.name];
    if (usageCountDiff !== 0) {
      return usageCountDiff;
    }
    if (isInterfaceType(typeA) && schema.isSubType(typeA, typeB)) {
      return -1;
    }
    if (isInterfaceType(typeB) && schema.isSubType(typeB, typeA)) {
      return 1;
    }
    return naturalCompare(typeA.name, typeB.name);
  }).map((x) => x.name);
}
function getSuggestedFieldNames(type, fieldName) {
  if (isObjectType(type) || isInterfaceType(type)) {
    const possibleFieldNames = Object.keys(type.getFields());
    return suggestionList(fieldName, possibleFieldNames);
  }
  return [];
}
function FragmentsOnCompositeTypesRule(context) {
  return {
    InlineFragment(node) {
      const typeCondition = node.typeCondition;
      if (typeCondition) {
        const type = typeFromAST(context.getSchema(), typeCondition);
        if (type && !isCompositeType(type)) {
          const typeStr = print(typeCondition);
          context.reportError(
            new GraphQLError(
              `Fragment cannot condition on non composite type "${typeStr}".`,
              {
                nodes: typeCondition
              }
            )
          );
        }
      }
    },
    FragmentDefinition(node) {
      const type = typeFromAST(context.getSchema(), node.typeCondition);
      if (type && !isCompositeType(type)) {
        const typeStr = print(node.typeCondition);
        context.reportError(
          new GraphQLError(
            `Fragment "${node.name.value}" cannot condition on non composite type "${typeStr}".`,
            {
              nodes: node.typeCondition
            }
          )
        );
      }
    }
  };
}
function KnownArgumentNamesRule(context) {
  return {
    // eslint-disable-next-line new-cap
    ...KnownArgumentNamesOnDirectivesRule(context),
    Argument(argNode) {
      const argDef = context.getArgument();
      const fieldDef = context.getFieldDef();
      const parentType = context.getParentType();
      if (!argDef && fieldDef && parentType) {
        const argName = argNode.name.value;
        const knownArgsNames = fieldDef.args.map((arg) => arg.name);
        const suggestions = suggestionList(argName, knownArgsNames);
        context.reportError(
          new GraphQLError(
            `Unknown argument "${argName}" on field "${parentType.name}.${fieldDef.name}".` + didYouMean(suggestions),
            {
              nodes: argNode
            }
          )
        );
      }
    }
  };
}
function KnownArgumentNamesOnDirectivesRule(context) {
  const directiveArgs = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = schema ? schema.getDirectives() : specifiedDirectives;
  for (const directive of definedDirectives) {
    directiveArgs[directive.name] = directive.args.map((arg) => arg.name);
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      var _def$arguments;
      const argsNodes = (_def$arguments = def.arguments) !== null && _def$arguments !== void 0 ? _def$arguments : [];
      directiveArgs[def.name.value] = argsNodes.map((arg) => arg.name.value);
    }
  }
  return {
    Directive(directiveNode) {
      const directiveName = directiveNode.name.value;
      const knownArgs = directiveArgs[directiveName];
      if (directiveNode.arguments && knownArgs) {
        for (const argNode of directiveNode.arguments) {
          const argName = argNode.name.value;
          if (!knownArgs.includes(argName)) {
            const suggestions = suggestionList(argName, knownArgs);
            context.reportError(
              new GraphQLError(
                `Unknown argument "${argName}" on directive "@${directiveName}".` + didYouMean(suggestions),
                {
                  nodes: argNode
                }
              )
            );
          }
        }
      }
      return false;
    }
  };
}
function KnownDirectivesRule(context) {
  const locationsMap = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = schema ? schema.getDirectives() : specifiedDirectives;
  for (const directive of definedDirectives) {
    locationsMap[directive.name] = directive.locations;
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      locationsMap[def.name.value] = def.locations.map((name) => name.value);
    }
  }
  return {
    Directive(node, _key, _parent, _path, ancestors) {
      const name = node.name.value;
      const locations = locationsMap[name];
      if (!locations) {
        context.reportError(
          new GraphQLError(`Unknown directive "@${name}".`, {
            nodes: node
          })
        );
        return;
      }
      const candidateLocation = getDirectiveLocationForASTPath(ancestors);
      if (candidateLocation && !locations.includes(candidateLocation)) {
        context.reportError(
          new GraphQLError(
            `Directive "@${name}" may not be used on ${candidateLocation}.`,
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
function getDirectiveLocationForASTPath(ancestors) {
  const appliedTo = ancestors[ancestors.length - 1];
  "kind" in appliedTo || invariant2(false);
  switch (appliedTo.kind) {
    case Kind.OPERATION_DEFINITION:
      return getDirectiveLocationForOperation(appliedTo.operation);
    case Kind.FIELD:
      return DirectiveLocation.FIELD;
    case Kind.FRAGMENT_SPREAD:
      return DirectiveLocation.FRAGMENT_SPREAD;
    case Kind.INLINE_FRAGMENT:
      return DirectiveLocation.INLINE_FRAGMENT;
    case Kind.FRAGMENT_DEFINITION:
      return DirectiveLocation.FRAGMENT_DEFINITION;
    case Kind.VARIABLE_DEFINITION:
      return DirectiveLocation.VARIABLE_DEFINITION;
    case Kind.SCHEMA_DEFINITION:
    case Kind.SCHEMA_EXTENSION:
      return DirectiveLocation.SCHEMA;
    case Kind.SCALAR_TYPE_DEFINITION:
    case Kind.SCALAR_TYPE_EXTENSION:
      return DirectiveLocation.SCALAR;
    case Kind.OBJECT_TYPE_DEFINITION:
    case Kind.OBJECT_TYPE_EXTENSION:
      return DirectiveLocation.OBJECT;
    case Kind.FIELD_DEFINITION:
      return DirectiveLocation.FIELD_DEFINITION;
    case Kind.INTERFACE_TYPE_DEFINITION:
    case Kind.INTERFACE_TYPE_EXTENSION:
      return DirectiveLocation.INTERFACE;
    case Kind.UNION_TYPE_DEFINITION:
    case Kind.UNION_TYPE_EXTENSION:
      return DirectiveLocation.UNION;
    case Kind.ENUM_TYPE_DEFINITION:
    case Kind.ENUM_TYPE_EXTENSION:
      return DirectiveLocation.ENUM;
    case Kind.ENUM_VALUE_DEFINITION:
      return DirectiveLocation.ENUM_VALUE;
    case Kind.INPUT_OBJECT_TYPE_DEFINITION:
    case Kind.INPUT_OBJECT_TYPE_EXTENSION:
      return DirectiveLocation.INPUT_OBJECT;
    case Kind.INPUT_VALUE_DEFINITION: {
      const parentNode = ancestors[ancestors.length - 3];
      "kind" in parentNode || invariant2(false);
      return parentNode.kind === Kind.INPUT_OBJECT_TYPE_DEFINITION ? DirectiveLocation.INPUT_FIELD_DEFINITION : DirectiveLocation.ARGUMENT_DEFINITION;
    }
    default:
      invariant2(false, "Unexpected kind: " + inspect(appliedTo.kind));
  }
}
function getDirectiveLocationForOperation(operation) {
  switch (operation) {
    case OperationTypeNode.QUERY:
      return DirectiveLocation.QUERY;
    case OperationTypeNode.MUTATION:
      return DirectiveLocation.MUTATION;
    case OperationTypeNode.SUBSCRIPTION:
      return DirectiveLocation.SUBSCRIPTION;
  }
}
function KnownFragmentNamesRule(context) {
  return {
    FragmentSpread(node) {
      const fragmentName = node.name.value;
      const fragment = context.getFragment(fragmentName);
      if (!fragment) {
        context.reportError(
          new GraphQLError(`Unknown fragment "${fragmentName}".`, {
            nodes: node.name
          })
        );
      }
    }
  };
}
function KnownTypeNamesRule(context) {
  const schema = context.getSchema();
  const existingTypesMap = schema ? schema.getTypeMap() : /* @__PURE__ */ Object.create(null);
  const definedTypes = /* @__PURE__ */ Object.create(null);
  for (const def of context.getDocument().definitions) {
    if (isTypeDefinitionNode(def)) {
      definedTypes[def.name.value] = true;
    }
  }
  const typeNames = [
    ...Object.keys(existingTypesMap),
    ...Object.keys(definedTypes)
  ];
  return {
    NamedType(node, _1, parent, _2, ancestors) {
      const typeName = node.name.value;
      if (!existingTypesMap[typeName] && !definedTypes[typeName]) {
        var _ancestors$;
        const definitionNode = (_ancestors$ = ancestors[2]) !== null && _ancestors$ !== void 0 ? _ancestors$ : parent;
        const isSDL = definitionNode != null && isSDLNode(definitionNode);
        if (isSDL && standardTypeNames.includes(typeName)) {
          return;
        }
        const suggestedTypes = suggestionList(
          typeName,
          isSDL ? standardTypeNames.concat(typeNames) : typeNames
        );
        context.reportError(
          new GraphQLError(
            `Unknown type "${typeName}".` + didYouMean(suggestedTypes),
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
var standardTypeNames = [...specifiedScalarTypes, ...introspectionTypes].map(
  (type) => type.name
);
function isSDLNode(value) {
  return "kind" in value && (isTypeSystemDefinitionNode(value) || isTypeSystemExtensionNode(value));
}
function LoneAnonymousOperationRule(context) {
  let operationCount = 0;
  return {
    Document(node) {
      operationCount = node.definitions.filter(
        (definition) => definition.kind === Kind.OPERATION_DEFINITION
      ).length;
    },
    OperationDefinition(node) {
      if (!node.name && operationCount > 1) {
        context.reportError(
          new GraphQLError(
            "This anonymous operation must be the only defined operation.",
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
function LoneSchemaDefinitionRule(context) {
  var _ref, _ref2, _oldSchema$astNode;
  const oldSchema = context.getSchema();
  const alreadyDefined = (_ref = (_ref2 = (_oldSchema$astNode = oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.astNode) !== null && _oldSchema$astNode !== void 0 ? _oldSchema$astNode : oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.getQueryType()) !== null && _ref2 !== void 0 ? _ref2 : oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.getMutationType()) !== null && _ref !== void 0 ? _ref : oldSchema === null || oldSchema === void 0 ? void 0 : oldSchema.getSubscriptionType();
  let schemaDefinitionsCount = 0;
  return {
    SchemaDefinition(node) {
      if (alreadyDefined) {
        context.reportError(
          new GraphQLError(
            "Cannot define a new schema within a schema extension.",
            {
              nodes: node
            }
          )
        );
        return;
      }
      if (schemaDefinitionsCount > 0) {
        context.reportError(
          new GraphQLError("Must provide only one schema definition.", {
            nodes: node
          })
        );
      }
      ++schemaDefinitionsCount;
    }
  };
}
function NoFragmentCyclesRule(context) {
  const visitedFrags = /* @__PURE__ */ Object.create(null);
  const spreadPath = [];
  const spreadPathIndexByName = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: () => false,
    FragmentDefinition(node) {
      detectCycleRecursive(node);
      return false;
    }
  };
  function detectCycleRecursive(fragment) {
    if (visitedFrags[fragment.name.value]) {
      return;
    }
    const fragmentName = fragment.name.value;
    visitedFrags[fragmentName] = true;
    const spreadNodes = context.getFragmentSpreads(fragment.selectionSet);
    if (spreadNodes.length === 0) {
      return;
    }
    spreadPathIndexByName[fragmentName] = spreadPath.length;
    for (const spreadNode of spreadNodes) {
      const spreadName = spreadNode.name.value;
      const cycleIndex = spreadPathIndexByName[spreadName];
      spreadPath.push(spreadNode);
      if (cycleIndex === void 0) {
        const spreadFragment = context.getFragment(spreadName);
        if (spreadFragment) {
          detectCycleRecursive(spreadFragment);
        }
      } else {
        const cyclePath = spreadPath.slice(cycleIndex);
        const viaPath = cyclePath.slice(0, -1).map((s) => '"' + s.name.value + '"').join(", ");
        context.reportError(
          new GraphQLError(
            `Cannot spread fragment "${spreadName}" within itself` + (viaPath !== "" ? ` via ${viaPath}.` : "."),
            {
              nodes: cyclePath
            }
          )
        );
      }
      spreadPath.pop();
    }
    spreadPathIndexByName[fragmentName] = void 0;
  }
}
function NoUndefinedVariablesRule(context) {
  let variableNameDefined = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: {
      enter() {
        variableNameDefined = /* @__PURE__ */ Object.create(null);
      },
      leave(operation) {
        const usages = context.getRecursiveVariableUsages(operation);
        for (const { node } of usages) {
          const varName = node.name.value;
          if (variableNameDefined[varName] !== true) {
            context.reportError(
              new GraphQLError(
                operation.name ? `Variable "$${varName}" is not defined by operation "${operation.name.value}".` : `Variable "$${varName}" is not defined.`,
                {
                  nodes: [node, operation]
                }
              )
            );
          }
        }
      }
    },
    VariableDefinition(node) {
      variableNameDefined[node.variable.name.value] = true;
    }
  };
}
function NoUnusedFragmentsRule(context) {
  const operationDefs = [];
  const fragmentDefs = [];
  return {
    OperationDefinition(node) {
      operationDefs.push(node);
      return false;
    },
    FragmentDefinition(node) {
      fragmentDefs.push(node);
      return false;
    },
    Document: {
      leave() {
        const fragmentNameUsed = /* @__PURE__ */ Object.create(null);
        for (const operation of operationDefs) {
          for (const fragment of context.getRecursivelyReferencedFragments(
            operation
          )) {
            fragmentNameUsed[fragment.name.value] = true;
          }
        }
        for (const fragmentDef of fragmentDefs) {
          const fragName = fragmentDef.name.value;
          if (fragmentNameUsed[fragName] !== true) {
            context.reportError(
              new GraphQLError(`Fragment "${fragName}" is never used.`, {
                nodes: fragmentDef
              })
            );
          }
        }
      }
    }
  };
}
function NoUnusedVariablesRule(context) {
  let variableDefs = [];
  return {
    OperationDefinition: {
      enter() {
        variableDefs = [];
      },
      leave(operation) {
        const variableNameUsed = /* @__PURE__ */ Object.create(null);
        const usages = context.getRecursiveVariableUsages(operation);
        for (const { node } of usages) {
          variableNameUsed[node.name.value] = true;
        }
        for (const variableDef of variableDefs) {
          const variableName = variableDef.variable.name.value;
          if (variableNameUsed[variableName] !== true) {
            context.reportError(
              new GraphQLError(
                operation.name ? `Variable "$${variableName}" is never used in operation "${operation.name.value}".` : `Variable "$${variableName}" is never used.`,
                {
                  nodes: variableDef
                }
              )
            );
          }
        }
      }
    },
    VariableDefinition(def) {
      variableDefs.push(def);
    }
  };
}
function sortValueNode(valueNode) {
  switch (valueNode.kind) {
    case Kind.OBJECT:
      return { ...valueNode, fields: sortFields(valueNode.fields) };
    case Kind.LIST:
      return { ...valueNode, values: valueNode.values.map(sortValueNode) };
    case Kind.INT:
    case Kind.FLOAT:
    case Kind.STRING:
    case Kind.BOOLEAN:
    case Kind.NULL:
    case Kind.ENUM:
    case Kind.VARIABLE:
      return valueNode;
  }
}
function sortFields(fields) {
  return fields.map((fieldNode) => ({
    ...fieldNode,
    value: sortValueNode(fieldNode.value)
  })).sort(
    (fieldA, fieldB) => naturalCompare(fieldA.name.value, fieldB.name.value)
  );
}
function reasonMessage(reason) {
  if (Array.isArray(reason)) {
    return reason.map(
      ([responseName, subReason]) => `subfields "${responseName}" conflict because ` + reasonMessage(subReason)
    ).join(" and ");
  }
  return reason;
}
function OverlappingFieldsCanBeMergedRule(context) {
  const comparedFragmentPairs = new PairSet();
  const cachedFieldsAndFragmentNames = /* @__PURE__ */ new Map();
  return {
    SelectionSet(selectionSet) {
      const conflicts = findConflictsWithinSelectionSet(
        context,
        cachedFieldsAndFragmentNames,
        comparedFragmentPairs,
        context.getParentType(),
        selectionSet
      );
      for (const [[responseName, reason], fields1, fields2] of conflicts) {
        const reasonMsg = reasonMessage(reason);
        context.reportError(
          new GraphQLError(
            `Fields "${responseName}" conflict because ${reasonMsg}. Use different aliases on the fields to fetch both if this was intentional.`,
            {
              nodes: fields1.concat(fields2)
            }
          )
        );
      }
    }
  };
}
function findConflictsWithinSelectionSet(context, cachedFieldsAndFragmentNames, comparedFragmentPairs, parentType, selectionSet) {
  const conflicts = [];
  const [fieldMap, fragmentNames] = getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    parentType,
    selectionSet
  );
  collectConflictsWithin(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    fieldMap
  );
  if (fragmentNames.length !== 0) {
    for (let i = 0; i < fragmentNames.length; i++) {
      collectConflictsBetweenFieldsAndFragment(
        context,
        conflicts,
        cachedFieldsAndFragmentNames,
        comparedFragmentPairs,
        false,
        fieldMap,
        fragmentNames[i]
      );
      for (let j = i + 1; j < fragmentNames.length; j++) {
        collectConflictsBetweenFragments(
          context,
          conflicts,
          cachedFieldsAndFragmentNames,
          comparedFragmentPairs,
          false,
          fragmentNames[i],
          fragmentNames[j]
        );
      }
    }
  }
  return conflicts;
}
function collectConflictsBetweenFieldsAndFragment(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, areMutuallyExclusive, fieldMap, fragmentName) {
  const fragment = context.getFragment(fragmentName);
  if (!fragment) {
    return;
  }
  const [fieldMap2, referencedFragmentNames] = getReferencedFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragment
  );
  if (fieldMap === fieldMap2) {
    return;
  }
  collectConflictsBetween(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    areMutuallyExclusive,
    fieldMap,
    fieldMap2
  );
  for (const referencedFragmentName of referencedFragmentNames) {
    if (comparedFragmentPairs.has(
      referencedFragmentName,
      fragmentName,
      areMutuallyExclusive
    )) {
      continue;
    }
    comparedFragmentPairs.add(
      referencedFragmentName,
      fragmentName,
      areMutuallyExclusive
    );
    collectConflictsBetweenFieldsAndFragment(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fieldMap,
      referencedFragmentName
    );
  }
}
function collectConflictsBetweenFragments(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, areMutuallyExclusive, fragmentName1, fragmentName2) {
  if (fragmentName1 === fragmentName2) {
    return;
  }
  if (comparedFragmentPairs.has(
    fragmentName1,
    fragmentName2,
    areMutuallyExclusive
  )) {
    return;
  }
  comparedFragmentPairs.add(fragmentName1, fragmentName2, areMutuallyExclusive);
  const fragment1 = context.getFragment(fragmentName1);
  const fragment2 = context.getFragment(fragmentName2);
  if (!fragment1 || !fragment2) {
    return;
  }
  const [fieldMap1, referencedFragmentNames1] = getReferencedFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragment1
  );
  const [fieldMap2, referencedFragmentNames2] = getReferencedFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragment2
  );
  collectConflictsBetween(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    areMutuallyExclusive,
    fieldMap1,
    fieldMap2
  );
  for (const referencedFragmentName2 of referencedFragmentNames2) {
    collectConflictsBetweenFragments(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fragmentName1,
      referencedFragmentName2
    );
  }
  for (const referencedFragmentName1 of referencedFragmentNames1) {
    collectConflictsBetweenFragments(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      referencedFragmentName1,
      fragmentName2
    );
  }
}
function findConflictsBetweenSubSelectionSets(context, cachedFieldsAndFragmentNames, comparedFragmentPairs, areMutuallyExclusive, parentType1, selectionSet1, parentType2, selectionSet2) {
  const conflicts = [];
  const [fieldMap1, fragmentNames1] = getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    parentType1,
    selectionSet1
  );
  const [fieldMap2, fragmentNames2] = getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    parentType2,
    selectionSet2
  );
  collectConflictsBetween(
    context,
    conflicts,
    cachedFieldsAndFragmentNames,
    comparedFragmentPairs,
    areMutuallyExclusive,
    fieldMap1,
    fieldMap2
  );
  for (const fragmentName2 of fragmentNames2) {
    collectConflictsBetweenFieldsAndFragment(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fieldMap1,
      fragmentName2
    );
  }
  for (const fragmentName1 of fragmentNames1) {
    collectConflictsBetweenFieldsAndFragment(
      context,
      conflicts,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      fieldMap2,
      fragmentName1
    );
  }
  for (const fragmentName1 of fragmentNames1) {
    for (const fragmentName2 of fragmentNames2) {
      collectConflictsBetweenFragments(
        context,
        conflicts,
        cachedFieldsAndFragmentNames,
        comparedFragmentPairs,
        areMutuallyExclusive,
        fragmentName1,
        fragmentName2
      );
    }
  }
  return conflicts;
}
function collectConflictsWithin(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, fieldMap) {
  for (const [responseName, fields] of Object.entries(fieldMap)) {
    if (fields.length > 1) {
      for (let i = 0; i < fields.length; i++) {
        for (let j = i + 1; j < fields.length; j++) {
          const conflict = findConflict(
            context,
            cachedFieldsAndFragmentNames,
            comparedFragmentPairs,
            false,
            // within one collection is never mutually exclusive
            responseName,
            fields[i],
            fields[j]
          );
          if (conflict) {
            conflicts.push(conflict);
          }
        }
      }
    }
  }
}
function collectConflictsBetween(context, conflicts, cachedFieldsAndFragmentNames, comparedFragmentPairs, parentFieldsAreMutuallyExclusive, fieldMap1, fieldMap2) {
  for (const [responseName, fields1] of Object.entries(fieldMap1)) {
    const fields2 = fieldMap2[responseName];
    if (fields2) {
      for (const field1 of fields1) {
        for (const field2 of fields2) {
          const conflict = findConflict(
            context,
            cachedFieldsAndFragmentNames,
            comparedFragmentPairs,
            parentFieldsAreMutuallyExclusive,
            responseName,
            field1,
            field2
          );
          if (conflict) {
            conflicts.push(conflict);
          }
        }
      }
    }
  }
}
function findConflict(context, cachedFieldsAndFragmentNames, comparedFragmentPairs, parentFieldsAreMutuallyExclusive, responseName, field1, field2) {
  const [parentType1, node1, def1] = field1;
  const [parentType2, node2, def2] = field2;
  const areMutuallyExclusive = parentFieldsAreMutuallyExclusive || parentType1 !== parentType2 && isObjectType(parentType1) && isObjectType(parentType2);
  if (!areMutuallyExclusive) {
    const name1 = node1.name.value;
    const name2 = node2.name.value;
    if (name1 !== name2) {
      return [
        [responseName, `"${name1}" and "${name2}" are different fields`],
        [node1],
        [node2]
      ];
    }
    if (!sameArguments(node1, node2)) {
      return [
        [responseName, "they have differing arguments"],
        [node1],
        [node2]
      ];
    }
  }
  const type1 = def1 === null || def1 === void 0 ? void 0 : def1.type;
  const type2 = def2 === null || def2 === void 0 ? void 0 : def2.type;
  if (type1 && type2 && doTypesConflict(type1, type2)) {
    return [
      [
        responseName,
        `they return conflicting types "${inspect(type1)}" and "${inspect(
          type2
        )}"`
      ],
      [node1],
      [node2]
    ];
  }
  const selectionSet1 = node1.selectionSet;
  const selectionSet2 = node2.selectionSet;
  if (selectionSet1 && selectionSet2) {
    const conflicts = findConflictsBetweenSubSelectionSets(
      context,
      cachedFieldsAndFragmentNames,
      comparedFragmentPairs,
      areMutuallyExclusive,
      getNamedType(type1),
      selectionSet1,
      getNamedType(type2),
      selectionSet2
    );
    return subfieldConflicts(conflicts, responseName, node1, node2);
  }
}
function sameArguments(node1, node2) {
  const args1 = node1.arguments;
  const args2 = node2.arguments;
  if (args1 === void 0 || args1.length === 0) {
    return args2 === void 0 || args2.length === 0;
  }
  if (args2 === void 0 || args2.length === 0) {
    return false;
  }
  if (args1.length !== args2.length) {
    return false;
  }
  const values2 = new Map(args2.map(({ name, value }) => [name.value, value]));
  return args1.every((arg1) => {
    const value1 = arg1.value;
    const value2 = values2.get(arg1.name.value);
    if (value2 === void 0) {
      return false;
    }
    return stringifyValue(value1) === stringifyValue(value2);
  });
}
function stringifyValue(value) {
  return print(sortValueNode(value));
}
function doTypesConflict(type1, type2) {
  if (isListType(type1)) {
    return isListType(type2) ? doTypesConflict(type1.ofType, type2.ofType) : true;
  }
  if (isListType(type2)) {
    return true;
  }
  if (isNonNullType(type1)) {
    return isNonNullType(type2) ? doTypesConflict(type1.ofType, type2.ofType) : true;
  }
  if (isNonNullType(type2)) {
    return true;
  }
  if (isLeafType(type1) || isLeafType(type2)) {
    return type1 !== type2;
  }
  return false;
}
function getFieldsAndFragmentNames(context, cachedFieldsAndFragmentNames, parentType, selectionSet) {
  const cached = cachedFieldsAndFragmentNames.get(selectionSet);
  if (cached) {
    return cached;
  }
  const nodeAndDefs = /* @__PURE__ */ Object.create(null);
  const fragmentNames = /* @__PURE__ */ Object.create(null);
  _collectFieldsAndFragmentNames(
    context,
    parentType,
    selectionSet,
    nodeAndDefs,
    fragmentNames
  );
  const result = [nodeAndDefs, Object.keys(fragmentNames)];
  cachedFieldsAndFragmentNames.set(selectionSet, result);
  return result;
}
function getReferencedFieldsAndFragmentNames(context, cachedFieldsAndFragmentNames, fragment) {
  const cached = cachedFieldsAndFragmentNames.get(fragment.selectionSet);
  if (cached) {
    return cached;
  }
  const fragmentType = typeFromAST(context.getSchema(), fragment.typeCondition);
  return getFieldsAndFragmentNames(
    context,
    cachedFieldsAndFragmentNames,
    fragmentType,
    fragment.selectionSet
  );
}
function _collectFieldsAndFragmentNames(context, parentType, selectionSet, nodeAndDefs, fragmentNames) {
  for (const selection of selectionSet.selections) {
    switch (selection.kind) {
      case Kind.FIELD: {
        const fieldName = selection.name.value;
        let fieldDef;
        if (isObjectType(parentType) || isInterfaceType(parentType)) {
          fieldDef = parentType.getFields()[fieldName];
        }
        const responseName = selection.alias ? selection.alias.value : fieldName;
        if (!nodeAndDefs[responseName]) {
          nodeAndDefs[responseName] = [];
        }
        nodeAndDefs[responseName].push([parentType, selection, fieldDef]);
        break;
      }
      case Kind.FRAGMENT_SPREAD:
        fragmentNames[selection.name.value] = true;
        break;
      case Kind.INLINE_FRAGMENT: {
        const typeCondition = selection.typeCondition;
        const inlineFragmentType = typeCondition ? typeFromAST(context.getSchema(), typeCondition) : parentType;
        _collectFieldsAndFragmentNames(
          context,
          inlineFragmentType,
          selection.selectionSet,
          nodeAndDefs,
          fragmentNames
        );
        break;
      }
    }
  }
}
function subfieldConflicts(conflicts, responseName, node1, node2) {
  if (conflicts.length > 0) {
    return [
      [responseName, conflicts.map(([reason]) => reason)],
      [node1, ...conflicts.map(([, fields1]) => fields1).flat()],
      [node2, ...conflicts.map(([, , fields2]) => fields2).flat()]
    ];
  }
}
var PairSet = class {
  constructor() {
    this._data = /* @__PURE__ */ new Map();
  }
  has(a, b, areMutuallyExclusive) {
    var _this$_data$get;
    const [key1, key2] = a < b ? [a, b] : [b, a];
    const result = (_this$_data$get = this._data.get(key1)) === null || _this$_data$get === void 0 ? void 0 : _this$_data$get.get(key2);
    if (result === void 0) {
      return false;
    }
    return areMutuallyExclusive ? true : areMutuallyExclusive === result;
  }
  add(a, b, areMutuallyExclusive) {
    const [key1, key2] = a < b ? [a, b] : [b, a];
    const map = this._data.get(key1);
    if (map === void 0) {
      this._data.set(key1, /* @__PURE__ */ new Map([[key2, areMutuallyExclusive]]));
    } else {
      map.set(key2, areMutuallyExclusive);
    }
  }
};
function PossibleFragmentSpreadsRule(context) {
  return {
    InlineFragment(node) {
      const fragType = context.getType();
      const parentType = context.getParentType();
      if (isCompositeType(fragType) && isCompositeType(parentType) && !doTypesOverlap(context.getSchema(), fragType, parentType)) {
        const parentTypeStr = inspect(parentType);
        const fragTypeStr = inspect(fragType);
        context.reportError(
          new GraphQLError(
            `Fragment cannot be spread here as objects of type "${parentTypeStr}" can never be of type "${fragTypeStr}".`,
            {
              nodes: node
            }
          )
        );
      }
    },
    FragmentSpread(node) {
      const fragName = node.name.value;
      const fragType = getFragmentType(context, fragName);
      const parentType = context.getParentType();
      if (fragType && parentType && !doTypesOverlap(context.getSchema(), fragType, parentType)) {
        const parentTypeStr = inspect(parentType);
        const fragTypeStr = inspect(fragType);
        context.reportError(
          new GraphQLError(
            `Fragment "${fragName}" cannot be spread here as objects of type "${parentTypeStr}" can never be of type "${fragTypeStr}".`,
            {
              nodes: node
            }
          )
        );
      }
    }
  };
}
function getFragmentType(context, name) {
  const frag = context.getFragment(name);
  if (frag) {
    const type = typeFromAST(context.getSchema(), frag.typeCondition);
    if (isCompositeType(type)) {
      return type;
    }
  }
}
function PossibleTypeExtensionsRule(context) {
  const schema = context.getSchema();
  const definedTypes = /* @__PURE__ */ Object.create(null);
  for (const def of context.getDocument().definitions) {
    if (isTypeDefinitionNode(def)) {
      definedTypes[def.name.value] = def;
    }
  }
  return {
    ScalarTypeExtension: checkExtension,
    ObjectTypeExtension: checkExtension,
    InterfaceTypeExtension: checkExtension,
    UnionTypeExtension: checkExtension,
    EnumTypeExtension: checkExtension,
    InputObjectTypeExtension: checkExtension
  };
  function checkExtension(node) {
    const typeName = node.name.value;
    const defNode = definedTypes[typeName];
    const existingType = schema === null || schema === void 0 ? void 0 : schema.getType(typeName);
    let expectedKind;
    if (defNode) {
      expectedKind = defKindToExtKind[defNode.kind];
    } else if (existingType) {
      expectedKind = typeToExtKind(existingType);
    }
    if (expectedKind) {
      if (expectedKind !== node.kind) {
        const kindStr = extensionKindToTypeName(node.kind);
        context.reportError(
          new GraphQLError(`Cannot extend non-${kindStr} type "${typeName}".`, {
            nodes: defNode ? [defNode, node] : node
          })
        );
      }
    } else {
      const allTypeNames = Object.keys({
        ...definedTypes,
        ...schema === null || schema === void 0 ? void 0 : schema.getTypeMap()
      });
      const suggestedTypes = suggestionList(typeName, allTypeNames);
      context.reportError(
        new GraphQLError(
          `Cannot extend type "${typeName}" because it is not defined.` + didYouMean(suggestedTypes),
          {
            nodes: node.name
          }
        )
      );
    }
  }
}
var defKindToExtKind = {
  [Kind.SCALAR_TYPE_DEFINITION]: Kind.SCALAR_TYPE_EXTENSION,
  [Kind.OBJECT_TYPE_DEFINITION]: Kind.OBJECT_TYPE_EXTENSION,
  [Kind.INTERFACE_TYPE_DEFINITION]: Kind.INTERFACE_TYPE_EXTENSION,
  [Kind.UNION_TYPE_DEFINITION]: Kind.UNION_TYPE_EXTENSION,
  [Kind.ENUM_TYPE_DEFINITION]: Kind.ENUM_TYPE_EXTENSION,
  [Kind.INPUT_OBJECT_TYPE_DEFINITION]: Kind.INPUT_OBJECT_TYPE_EXTENSION
};
function typeToExtKind(type) {
  if (isScalarType(type)) {
    return Kind.SCALAR_TYPE_EXTENSION;
  }
  if (isObjectType(type)) {
    return Kind.OBJECT_TYPE_EXTENSION;
  }
  if (isInterfaceType(type)) {
    return Kind.INTERFACE_TYPE_EXTENSION;
  }
  if (isUnionType(type)) {
    return Kind.UNION_TYPE_EXTENSION;
  }
  if (isEnumType(type)) {
    return Kind.ENUM_TYPE_EXTENSION;
  }
  if (isInputObjectType(type)) {
    return Kind.INPUT_OBJECT_TYPE_EXTENSION;
  }
  invariant2(false, "Unexpected type: " + inspect(type));
}
function extensionKindToTypeName(kind) {
  switch (kind) {
    case Kind.SCALAR_TYPE_EXTENSION:
      return "scalar";
    case Kind.OBJECT_TYPE_EXTENSION:
      return "object";
    case Kind.INTERFACE_TYPE_EXTENSION:
      return "interface";
    case Kind.UNION_TYPE_EXTENSION:
      return "union";
    case Kind.ENUM_TYPE_EXTENSION:
      return "enum";
    case Kind.INPUT_OBJECT_TYPE_EXTENSION:
      return "input object";
    default:
      invariant2(false, "Unexpected kind: " + inspect(kind));
  }
}
function ProvidedRequiredArgumentsRule(context) {
  return {
    // eslint-disable-next-line new-cap
    ...ProvidedRequiredArgumentsOnDirectivesRule(context),
    Field: {
      // Validate on leave to allow for deeper errors to appear first.
      leave(fieldNode) {
        var _fieldNode$arguments;
        const fieldDef = context.getFieldDef();
        if (!fieldDef) {
          return false;
        }
        const providedArgs = new Set(
          // FIXME: https://github.com/graphql/graphql-js/issues/2203
          /* c8 ignore next */
          (_fieldNode$arguments = fieldNode.arguments) === null || _fieldNode$arguments === void 0 ? void 0 : _fieldNode$arguments.map((arg) => arg.name.value)
        );
        for (const argDef of fieldDef.args) {
          if (!providedArgs.has(argDef.name) && isRequiredArgument(argDef)) {
            const argTypeStr = inspect(argDef.type);
            context.reportError(
              new GraphQLError(
                `Field "${fieldDef.name}" argument "${argDef.name}" of type "${argTypeStr}" is required, but it was not provided.`,
                {
                  nodes: fieldNode
                }
              )
            );
          }
        }
      }
    }
  };
}
function ProvidedRequiredArgumentsOnDirectivesRule(context) {
  var _schema$getDirectives;
  const requiredArgsMap = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = (_schema$getDirectives = schema === null || schema === void 0 ? void 0 : schema.getDirectives()) !== null && _schema$getDirectives !== void 0 ? _schema$getDirectives : specifiedDirectives;
  for (const directive of definedDirectives) {
    requiredArgsMap[directive.name] = keyMap(
      directive.args.filter(isRequiredArgument),
      (arg) => arg.name
    );
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      var _def$arguments;
      const argNodes = (_def$arguments = def.arguments) !== null && _def$arguments !== void 0 ? _def$arguments : [];
      requiredArgsMap[def.name.value] = keyMap(
        argNodes.filter(isRequiredArgumentNode),
        (arg) => arg.name.value
      );
    }
  }
  return {
    Directive: {
      // Validate on leave to allow for deeper errors to appear first.
      leave(directiveNode) {
        const directiveName = directiveNode.name.value;
        const requiredArgs = requiredArgsMap[directiveName];
        if (requiredArgs) {
          var _directiveNode$argume;
          const argNodes = (_directiveNode$argume = directiveNode.arguments) !== null && _directiveNode$argume !== void 0 ? _directiveNode$argume : [];
          const argNodeMap = new Set(argNodes.map((arg) => arg.name.value));
          for (const [argName, argDef] of Object.entries(requiredArgs)) {
            if (!argNodeMap.has(argName)) {
              const argType = isType(argDef.type) ? inspect(argDef.type) : print(argDef.type);
              context.reportError(
                new GraphQLError(
                  `Directive "@${directiveName}" argument "${argName}" of type "${argType}" is required, but it was not provided.`,
                  {
                    nodes: directiveNode
                  }
                )
              );
            }
          }
        }
      }
    }
  };
}
function isRequiredArgumentNode(arg) {
  return arg.type.kind === Kind.NON_NULL_TYPE && arg.defaultValue == null;
}
function ScalarLeafsRule(context) {
  return {
    Field(node) {
      const type = context.getType();
      const selectionSet = node.selectionSet;
      if (type) {
        if (isLeafType(getNamedType(type))) {
          if (selectionSet) {
            const fieldName = node.name.value;
            const typeStr = inspect(type);
            context.reportError(
              new GraphQLError(
                `Field "${fieldName}" must not have a selection since type "${typeStr}" has no subfields.`,
                {
                  nodes: selectionSet
                }
              )
            );
          }
        } else if (!selectionSet) {
          const fieldName = node.name.value;
          const typeStr = inspect(type);
          context.reportError(
            new GraphQLError(
              `Field "${fieldName}" of type "${typeStr}" must have a selection of subfields. Did you mean "${fieldName} { ... }"?`,
              {
                nodes: node
              }
            )
          );
        }
      }
    }
  };
}
function valueFromAST(valueNode, type, variables) {
  if (!valueNode) {
    return;
  }
  if (valueNode.kind === Kind.VARIABLE) {
    const variableName = valueNode.name.value;
    if (variables == null || variables[variableName] === void 0) {
      return;
    }
    const variableValue = variables[variableName];
    if (variableValue === null && isNonNullType(type)) {
      return;
    }
    return variableValue;
  }
  if (isNonNullType(type)) {
    if (valueNode.kind === Kind.NULL) {
      return;
    }
    return valueFromAST(valueNode, type.ofType, variables);
  }
  if (valueNode.kind === Kind.NULL) {
    return null;
  }
  if (isListType(type)) {
    const itemType = type.ofType;
    if (valueNode.kind === Kind.LIST) {
      const coercedValues = [];
      for (const itemNode of valueNode.values) {
        if (isMissingVariable(itemNode, variables)) {
          if (isNonNullType(itemType)) {
            return;
          }
          coercedValues.push(null);
        } else {
          const itemValue = valueFromAST(itemNode, itemType, variables);
          if (itemValue === void 0) {
            return;
          }
          coercedValues.push(itemValue);
        }
      }
      return coercedValues;
    }
    const coercedValue = valueFromAST(valueNode, itemType, variables);
    if (coercedValue === void 0) {
      return;
    }
    return [coercedValue];
  }
  if (isInputObjectType(type)) {
    if (valueNode.kind !== Kind.OBJECT) {
      return;
    }
    const coercedObj = /* @__PURE__ */ Object.create(null);
    const fieldNodes = keyMap(valueNode.fields, (field) => field.name.value);
    for (const field of Object.values(type.getFields())) {
      const fieldNode = fieldNodes[field.name];
      if (!fieldNode || isMissingVariable(fieldNode.value, variables)) {
        if (field.defaultValue !== void 0) {
          coercedObj[field.name] = field.defaultValue;
        } else if (isNonNullType(field.type)) {
          return;
        }
        continue;
      }
      const fieldValue = valueFromAST(fieldNode.value, field.type, variables);
      if (fieldValue === void 0) {
        return;
      }
      coercedObj[field.name] = fieldValue;
    }
    return coercedObj;
  }
  if (isLeafType(type)) {
    let result;
    try {
      result = type.parseLiteral(valueNode, variables);
    } catch (_error) {
      return;
    }
    if (result === void 0) {
      return;
    }
    return result;
  }
  invariant2(false, "Unexpected input type: " + inspect(type));
}
function isMissingVariable(valueNode, variables) {
  return valueNode.kind === Kind.VARIABLE && (variables == null || variables[valueNode.name.value] === void 0);
}
function getArgumentValues(def, node, variableValues) {
  var _node$arguments;
  const coercedValues = {};
  const argumentNodes = (_node$arguments = node.arguments) !== null && _node$arguments !== void 0 ? _node$arguments : [];
  const argNodeMap = keyMap(argumentNodes, (arg) => arg.name.value);
  for (const argDef of def.args) {
    const name = argDef.name;
    const argType = argDef.type;
    const argumentNode = argNodeMap[name];
    if (!argumentNode) {
      if (argDef.defaultValue !== void 0) {
        coercedValues[name] = argDef.defaultValue;
      } else if (isNonNullType(argType)) {
        throw new GraphQLError(
          `Argument "${name}" of required type "${inspect(argType)}" was not provided.`,
          {
            nodes: node
          }
        );
      }
      continue;
    }
    const valueNode = argumentNode.value;
    let isNull = valueNode.kind === Kind.NULL;
    if (valueNode.kind === Kind.VARIABLE) {
      const variableName = valueNode.name.value;
      if (variableValues == null || !hasOwnProperty(variableValues, variableName)) {
        if (argDef.defaultValue !== void 0) {
          coercedValues[name] = argDef.defaultValue;
        } else if (isNonNullType(argType)) {
          throw new GraphQLError(
            `Argument "${name}" of required type "${inspect(argType)}" was provided the variable "$${variableName}" which was not provided a runtime value.`,
            {
              nodes: valueNode
            }
          );
        }
        continue;
      }
      isNull = variableValues[variableName] == null;
    }
    if (isNull && isNonNullType(argType)) {
      throw new GraphQLError(
        `Argument "${name}" of non-null type "${inspect(argType)}" must not be null.`,
        {
          nodes: valueNode
        }
      );
    }
    const coercedValue = valueFromAST(valueNode, argType, variableValues);
    if (coercedValue === void 0) {
      throw new GraphQLError(
        `Argument "${name}" has invalid value ${print(valueNode)}.`,
        {
          nodes: valueNode
        }
      );
    }
    coercedValues[name] = coercedValue;
  }
  return coercedValues;
}
function getDirectiveValues(directiveDef, node, variableValues) {
  var _node$directives;
  const directiveNode = (_node$directives = node.directives) === null || _node$directives === void 0 ? void 0 : _node$directives.find(
    (directive) => directive.name.value === directiveDef.name
  );
  if (directiveNode) {
    return getArgumentValues(directiveDef, directiveNode, variableValues);
  }
}
function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}
function collectFields(schema, fragments, variableValues, runtimeType, selectionSet) {
  const fields = /* @__PURE__ */ new Map();
  collectFieldsImpl(
    schema,
    fragments,
    variableValues,
    runtimeType,
    selectionSet,
    fields,
    /* @__PURE__ */ new Set()
  );
  return fields;
}
function collectSubfields(schema, fragments, variableValues, returnType, fieldNodes) {
  const subFieldNodes = /* @__PURE__ */ new Map();
  const visitedFragmentNames = /* @__PURE__ */ new Set();
  for (const node of fieldNodes) {
    if (node.selectionSet) {
      collectFieldsImpl(
        schema,
        fragments,
        variableValues,
        returnType,
        node.selectionSet,
        subFieldNodes,
        visitedFragmentNames
      );
    }
  }
  return subFieldNodes;
}
function collectFieldsImpl(schema, fragments, variableValues, runtimeType, selectionSet, fields, visitedFragmentNames) {
  for (const selection of selectionSet.selections) {
    switch (selection.kind) {
      case Kind.FIELD: {
        if (!shouldIncludeNode(variableValues, selection)) {
          continue;
        }
        const name = getFieldEntryKey(selection);
        const fieldList = fields.get(name);
        if (fieldList !== void 0) {
          fieldList.push(selection);
        } else {
          fields.set(name, [selection]);
        }
        break;
      }
      case Kind.INLINE_FRAGMENT: {
        if (!shouldIncludeNode(variableValues, selection) || !doesFragmentConditionMatch(schema, selection, runtimeType)) {
          continue;
        }
        collectFieldsImpl(
          schema,
          fragments,
          variableValues,
          runtimeType,
          selection.selectionSet,
          fields,
          visitedFragmentNames
        );
        break;
      }
      case Kind.FRAGMENT_SPREAD: {
        const fragName = selection.name.value;
        if (visitedFragmentNames.has(fragName) || !shouldIncludeNode(variableValues, selection)) {
          continue;
        }
        visitedFragmentNames.add(fragName);
        const fragment = fragments[fragName];
        if (!fragment || !doesFragmentConditionMatch(schema, fragment, runtimeType)) {
          continue;
        }
        collectFieldsImpl(
          schema,
          fragments,
          variableValues,
          runtimeType,
          fragment.selectionSet,
          fields,
          visitedFragmentNames
        );
        break;
      }
    }
  }
}
function shouldIncludeNode(variableValues, node) {
  const skip = getDirectiveValues(GraphQLSkipDirective, node, variableValues);
  if ((skip === null || skip === void 0 ? void 0 : skip.if) === true) {
    return false;
  }
  const include = getDirectiveValues(
    GraphQLIncludeDirective,
    node,
    variableValues
  );
  if ((include === null || include === void 0 ? void 0 : include.if) === false) {
    return false;
  }
  return true;
}
function doesFragmentConditionMatch(schema, fragment, type) {
  const typeConditionNode = fragment.typeCondition;
  if (!typeConditionNode) {
    return true;
  }
  const conditionalType = typeFromAST(schema, typeConditionNode);
  if (conditionalType === type) {
    return true;
  }
  if (isAbstractType(conditionalType)) {
    return schema.isSubType(conditionalType, type);
  }
  return false;
}
function getFieldEntryKey(node) {
  return node.alias ? node.alias.value : node.name.value;
}
function SingleFieldSubscriptionsRule(context) {
  return {
    OperationDefinition(node) {
      if (node.operation === "subscription") {
        const schema = context.getSchema();
        const subscriptionType = schema.getSubscriptionType();
        if (subscriptionType) {
          const operationName = node.name ? node.name.value : null;
          const variableValues = /* @__PURE__ */ Object.create(null);
          const document2 = context.getDocument();
          const fragments = /* @__PURE__ */ Object.create(null);
          for (const definition of document2.definitions) {
            if (definition.kind === Kind.FRAGMENT_DEFINITION) {
              fragments[definition.name.value] = definition;
            }
          }
          const fields = collectFields(
            schema,
            fragments,
            variableValues,
            subscriptionType,
            node.selectionSet
          );
          if (fields.size > 1) {
            const fieldSelectionLists = [...fields.values()];
            const extraFieldSelectionLists = fieldSelectionLists.slice(1);
            const extraFieldSelections = extraFieldSelectionLists.flat();
            context.reportError(
              new GraphQLError(
                operationName != null ? `Subscription "${operationName}" must select only one top level field.` : "Anonymous Subscription must select only one top level field.",
                {
                  nodes: extraFieldSelections
                }
              )
            );
          }
          for (const fieldNodes of fields.values()) {
            const field = fieldNodes[0];
            const fieldName = field.name.value;
            if (fieldName.startsWith("__")) {
              context.reportError(
                new GraphQLError(
                  operationName != null ? `Subscription "${operationName}" must not select an introspection top level field.` : "Anonymous Subscription must not select an introspection top level field.",
                  {
                    nodes: fieldNodes
                  }
                )
              );
            }
          }
        }
      }
    }
  };
}
function groupBy(list, keyFn) {
  const result = /* @__PURE__ */ new Map();
  for (const item of list) {
    const key = keyFn(item);
    const group = result.get(key);
    if (group === void 0) {
      result.set(key, [item]);
    } else {
      group.push(item);
    }
  }
  return result;
}
function UniqueArgumentDefinitionNamesRule(context) {
  return {
    DirectiveDefinition(directiveNode) {
      var _directiveNode$argume;
      const argumentNodes = (_directiveNode$argume = directiveNode.arguments) !== null && _directiveNode$argume !== void 0 ? _directiveNode$argume : [];
      return checkArgUniqueness(`@${directiveNode.name.value}`, argumentNodes);
    },
    InterfaceTypeDefinition: checkArgUniquenessPerField,
    InterfaceTypeExtension: checkArgUniquenessPerField,
    ObjectTypeDefinition: checkArgUniquenessPerField,
    ObjectTypeExtension: checkArgUniquenessPerField
  };
  function checkArgUniquenessPerField(typeNode) {
    var _typeNode$fields;
    const typeName = typeNode.name.value;
    const fieldNodes = (_typeNode$fields = typeNode.fields) !== null && _typeNode$fields !== void 0 ? _typeNode$fields : [];
    for (const fieldDef of fieldNodes) {
      var _fieldDef$arguments;
      const fieldName = fieldDef.name.value;
      const argumentNodes = (_fieldDef$arguments = fieldDef.arguments) !== null && _fieldDef$arguments !== void 0 ? _fieldDef$arguments : [];
      checkArgUniqueness(`${typeName}.${fieldName}`, argumentNodes);
    }
    return false;
  }
  function checkArgUniqueness(parentName, argumentNodes) {
    const seenArgs = groupBy(argumentNodes, (arg) => arg.name.value);
    for (const [argName, argNodes] of seenArgs) {
      if (argNodes.length > 1) {
        context.reportError(
          new GraphQLError(
            `Argument "${parentName}(${argName}:)" can only be defined once.`,
            {
              nodes: argNodes.map((node) => node.name)
            }
          )
        );
      }
    }
    return false;
  }
}
function UniqueArgumentNamesRule(context) {
  return {
    Field: checkArgUniqueness,
    Directive: checkArgUniqueness
  };
  function checkArgUniqueness(parentNode) {
    var _parentNode$arguments;
    const argumentNodes = (_parentNode$arguments = parentNode.arguments) !== null && _parentNode$arguments !== void 0 ? _parentNode$arguments : [];
    const seenArgs = groupBy(argumentNodes, (arg) => arg.name.value);
    for (const [argName, argNodes] of seenArgs) {
      if (argNodes.length > 1) {
        context.reportError(
          new GraphQLError(
            `There can be only one argument named "${argName}".`,
            {
              nodes: argNodes.map((node) => node.name)
            }
          )
        );
      }
    }
  }
}
function UniqueDirectiveNamesRule(context) {
  const knownDirectiveNames = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  return {
    DirectiveDefinition(node) {
      const directiveName = node.name.value;
      if (schema !== null && schema !== void 0 && schema.getDirective(directiveName)) {
        context.reportError(
          new GraphQLError(
            `Directive "@${directiveName}" already exists in the schema. It cannot be redefined.`,
            {
              nodes: node.name
            }
          )
        );
        return;
      }
      if (knownDirectiveNames[directiveName]) {
        context.reportError(
          new GraphQLError(
            `There can be only one directive named "@${directiveName}".`,
            {
              nodes: [knownDirectiveNames[directiveName], node.name]
            }
          )
        );
      } else {
        knownDirectiveNames[directiveName] = node.name;
      }
      return false;
    }
  };
}
function UniqueDirectivesPerLocationRule(context) {
  const uniqueDirectiveMap = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  const definedDirectives = schema ? schema.getDirectives() : specifiedDirectives;
  for (const directive of definedDirectives) {
    uniqueDirectiveMap[directive.name] = !directive.isRepeatable;
  }
  const astDefinitions = context.getDocument().definitions;
  for (const def of astDefinitions) {
    if (def.kind === Kind.DIRECTIVE_DEFINITION) {
      uniqueDirectiveMap[def.name.value] = !def.repeatable;
    }
  }
  const schemaDirectives = /* @__PURE__ */ Object.create(null);
  const typeDirectivesMap = /* @__PURE__ */ Object.create(null);
  return {
    // Many different AST nodes may contain directives. Rather than listing
    // them all, just listen for entering any node, and check to see if it
    // defines any directives.
    enter(node) {
      if (!("directives" in node) || !node.directives) {
        return;
      }
      let seenDirectives;
      if (node.kind === Kind.SCHEMA_DEFINITION || node.kind === Kind.SCHEMA_EXTENSION) {
        seenDirectives = schemaDirectives;
      } else if (isTypeDefinitionNode(node) || isTypeExtensionNode(node)) {
        const typeName = node.name.value;
        seenDirectives = typeDirectivesMap[typeName];
        if (seenDirectives === void 0) {
          typeDirectivesMap[typeName] = seenDirectives = /* @__PURE__ */ Object.create(null);
        }
      } else {
        seenDirectives = /* @__PURE__ */ Object.create(null);
      }
      for (const directive of node.directives) {
        const directiveName = directive.name.value;
        if (uniqueDirectiveMap[directiveName]) {
          if (seenDirectives[directiveName]) {
            context.reportError(
              new GraphQLError(
                `The directive "@${directiveName}" can only be used once at this location.`,
                {
                  nodes: [seenDirectives[directiveName], directive]
                }
              )
            );
          } else {
            seenDirectives[directiveName] = directive;
          }
        }
      }
    }
  };
}
function UniqueEnumValueNamesRule(context) {
  const schema = context.getSchema();
  const existingTypeMap = schema ? schema.getTypeMap() : /* @__PURE__ */ Object.create(null);
  const knownValueNames = /* @__PURE__ */ Object.create(null);
  return {
    EnumTypeDefinition: checkValueUniqueness,
    EnumTypeExtension: checkValueUniqueness
  };
  function checkValueUniqueness(node) {
    var _node$values;
    const typeName = node.name.value;
    if (!knownValueNames[typeName]) {
      knownValueNames[typeName] = /* @__PURE__ */ Object.create(null);
    }
    const valueNodes = (_node$values = node.values) !== null && _node$values !== void 0 ? _node$values : [];
    const valueNames = knownValueNames[typeName];
    for (const valueDef of valueNodes) {
      const valueName = valueDef.name.value;
      const existingType = existingTypeMap[typeName];
      if (isEnumType(existingType) && existingType.getValue(valueName)) {
        context.reportError(
          new GraphQLError(
            `Enum value "${typeName}.${valueName}" already exists in the schema. It cannot also be defined in this type extension.`,
            {
              nodes: valueDef.name
            }
          )
        );
      } else if (valueNames[valueName]) {
        context.reportError(
          new GraphQLError(
            `Enum value "${typeName}.${valueName}" can only be defined once.`,
            {
              nodes: [valueNames[valueName], valueDef.name]
            }
          )
        );
      } else {
        valueNames[valueName] = valueDef.name;
      }
    }
    return false;
  }
}
function UniqueFieldDefinitionNamesRule(context) {
  const schema = context.getSchema();
  const existingTypeMap = schema ? schema.getTypeMap() : /* @__PURE__ */ Object.create(null);
  const knownFieldNames = /* @__PURE__ */ Object.create(null);
  return {
    InputObjectTypeDefinition: checkFieldUniqueness,
    InputObjectTypeExtension: checkFieldUniqueness,
    InterfaceTypeDefinition: checkFieldUniqueness,
    InterfaceTypeExtension: checkFieldUniqueness,
    ObjectTypeDefinition: checkFieldUniqueness,
    ObjectTypeExtension: checkFieldUniqueness
  };
  function checkFieldUniqueness(node) {
    var _node$fields;
    const typeName = node.name.value;
    if (!knownFieldNames[typeName]) {
      knownFieldNames[typeName] = /* @__PURE__ */ Object.create(null);
    }
    const fieldNodes = (_node$fields = node.fields) !== null && _node$fields !== void 0 ? _node$fields : [];
    const fieldNames = knownFieldNames[typeName];
    for (const fieldDef of fieldNodes) {
      const fieldName = fieldDef.name.value;
      if (hasField(existingTypeMap[typeName], fieldName)) {
        context.reportError(
          new GraphQLError(
            `Field "${typeName}.${fieldName}" already exists in the schema. It cannot also be defined in this type extension.`,
            {
              nodes: fieldDef.name
            }
          )
        );
      } else if (fieldNames[fieldName]) {
        context.reportError(
          new GraphQLError(
            `Field "${typeName}.${fieldName}" can only be defined once.`,
            {
              nodes: [fieldNames[fieldName], fieldDef.name]
            }
          )
        );
      } else {
        fieldNames[fieldName] = fieldDef.name;
      }
    }
    return false;
  }
}
function hasField(type, fieldName) {
  if (isObjectType(type) || isInterfaceType(type) || isInputObjectType(type)) {
    return type.getFields()[fieldName] != null;
  }
  return false;
}
function UniqueFragmentNamesRule(context) {
  const knownFragmentNames = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: () => false,
    FragmentDefinition(node) {
      const fragmentName = node.name.value;
      if (knownFragmentNames[fragmentName]) {
        context.reportError(
          new GraphQLError(
            `There can be only one fragment named "${fragmentName}".`,
            {
              nodes: [knownFragmentNames[fragmentName], node.name]
            }
          )
        );
      } else {
        knownFragmentNames[fragmentName] = node.name;
      }
      return false;
    }
  };
}
function UniqueInputFieldNamesRule(context) {
  const knownNameStack = [];
  let knownNames = /* @__PURE__ */ Object.create(null);
  return {
    ObjectValue: {
      enter() {
        knownNameStack.push(knownNames);
        knownNames = /* @__PURE__ */ Object.create(null);
      },
      leave() {
        const prevKnownNames = knownNameStack.pop();
        prevKnownNames || invariant2(false);
        knownNames = prevKnownNames;
      }
    },
    ObjectField(node) {
      const fieldName = node.name.value;
      if (knownNames[fieldName]) {
        context.reportError(
          new GraphQLError(
            `There can be only one input field named "${fieldName}".`,
            {
              nodes: [knownNames[fieldName], node.name]
            }
          )
        );
      } else {
        knownNames[fieldName] = node.name;
      }
    }
  };
}
function UniqueOperationNamesRule(context) {
  const knownOperationNames = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition(node) {
      const operationName = node.name;
      if (operationName) {
        if (knownOperationNames[operationName.value]) {
          context.reportError(
            new GraphQLError(
              `There can be only one operation named "${operationName.value}".`,
              {
                nodes: [
                  knownOperationNames[operationName.value],
                  operationName
                ]
              }
            )
          );
        } else {
          knownOperationNames[operationName.value] = operationName;
        }
      }
      return false;
    },
    FragmentDefinition: () => false
  };
}
function UniqueOperationTypesRule(context) {
  const schema = context.getSchema();
  const definedOperationTypes = /* @__PURE__ */ Object.create(null);
  const existingOperationTypes = schema ? {
    query: schema.getQueryType(),
    mutation: schema.getMutationType(),
    subscription: schema.getSubscriptionType()
  } : {};
  return {
    SchemaDefinition: checkOperationTypes,
    SchemaExtension: checkOperationTypes
  };
  function checkOperationTypes(node) {
    var _node$operationTypes;
    const operationTypesNodes = (_node$operationTypes = node.operationTypes) !== null && _node$operationTypes !== void 0 ? _node$operationTypes : [];
    for (const operationType of operationTypesNodes) {
      const operation = operationType.operation;
      const alreadyDefinedOperationType = definedOperationTypes[operation];
      if (existingOperationTypes[operation]) {
        context.reportError(
          new GraphQLError(
            `Type for ${operation} already defined in the schema. It cannot be redefined.`,
            {
              nodes: operationType
            }
          )
        );
      } else if (alreadyDefinedOperationType) {
        context.reportError(
          new GraphQLError(
            `There can be only one ${operation} type in schema.`,
            {
              nodes: [alreadyDefinedOperationType, operationType]
            }
          )
        );
      } else {
        definedOperationTypes[operation] = operationType;
      }
    }
    return false;
  }
}
function UniqueTypeNamesRule(context) {
  const knownTypeNames = /* @__PURE__ */ Object.create(null);
  const schema = context.getSchema();
  return {
    ScalarTypeDefinition: checkTypeName,
    ObjectTypeDefinition: checkTypeName,
    InterfaceTypeDefinition: checkTypeName,
    UnionTypeDefinition: checkTypeName,
    EnumTypeDefinition: checkTypeName,
    InputObjectTypeDefinition: checkTypeName
  };
  function checkTypeName(node) {
    const typeName = node.name.value;
    if (schema !== null && schema !== void 0 && schema.getType(typeName)) {
      context.reportError(
        new GraphQLError(
          `Type "${typeName}" already exists in the schema. It cannot also be defined in this type definition.`,
          {
            nodes: node.name
          }
        )
      );
      return;
    }
    if (knownTypeNames[typeName]) {
      context.reportError(
        new GraphQLError(`There can be only one type named "${typeName}".`, {
          nodes: [knownTypeNames[typeName], node.name]
        })
      );
    } else {
      knownTypeNames[typeName] = node.name;
    }
    return false;
  }
}
function UniqueVariableNamesRule(context) {
  return {
    OperationDefinition(operationNode) {
      var _operationNode$variab;
      const variableDefinitions = (_operationNode$variab = operationNode.variableDefinitions) !== null && _operationNode$variab !== void 0 ? _operationNode$variab : [];
      const seenVariableDefinitions = groupBy(
        variableDefinitions,
        (node) => node.variable.name.value
      );
      for (const [variableName, variableNodes] of seenVariableDefinitions) {
        if (variableNodes.length > 1) {
          context.reportError(
            new GraphQLError(
              `There can be only one variable named "$${variableName}".`,
              {
                nodes: variableNodes.map((node) => node.variable.name)
              }
            )
          );
        }
      }
    }
  };
}
function ValuesOfCorrectTypeRule(context) {
  return {
    ListValue(node) {
      const type = getNullableType(context.getParentInputType());
      if (!isListType(type)) {
        isValidValueNode(context, node);
        return false;
      }
    },
    ObjectValue(node) {
      const type = getNamedType(context.getInputType());
      if (!isInputObjectType(type)) {
        isValidValueNode(context, node);
        return false;
      }
      const fieldNodeMap = keyMap(node.fields, (field) => field.name.value);
      for (const fieldDef of Object.values(type.getFields())) {
        const fieldNode = fieldNodeMap[fieldDef.name];
        if (!fieldNode && isRequiredInputField(fieldDef)) {
          const typeStr = inspect(fieldDef.type);
          context.reportError(
            new GraphQLError(
              `Field "${type.name}.${fieldDef.name}" of required type "${typeStr}" was not provided.`,
              {
                nodes: node
              }
            )
          );
        }
      }
    },
    ObjectField(node) {
      const parentType = getNamedType(context.getParentInputType());
      const fieldType = context.getInputType();
      if (!fieldType && isInputObjectType(parentType)) {
        const suggestions = suggestionList(
          node.name.value,
          Object.keys(parentType.getFields())
        );
        context.reportError(
          new GraphQLError(
            `Field "${node.name.value}" is not defined by type "${parentType.name}".` + didYouMean(suggestions),
            {
              nodes: node
            }
          )
        );
      }
    },
    NullValue(node) {
      const type = context.getInputType();
      if (isNonNullType(type)) {
        context.reportError(
          new GraphQLError(
            `Expected value of type "${inspect(type)}", found ${print(node)}.`,
            {
              nodes: node
            }
          )
        );
      }
    },
    EnumValue: (node) => isValidValueNode(context, node),
    IntValue: (node) => isValidValueNode(context, node),
    FloatValue: (node) => isValidValueNode(context, node),
    StringValue: (node) => isValidValueNode(context, node),
    BooleanValue: (node) => isValidValueNode(context, node)
  };
}
function isValidValueNode(context, node) {
  const locationType = context.getInputType();
  if (!locationType) {
    return;
  }
  const type = getNamedType(locationType);
  if (!isLeafType(type)) {
    const typeStr = inspect(locationType);
    context.reportError(
      new GraphQLError(
        `Expected value of type "${typeStr}", found ${print(node)}.`,
        {
          nodes: node
        }
      )
    );
    return;
  }
  try {
    const parseResult = type.parseLiteral(
      node,
      void 0
      /* variables */
    );
    if (parseResult === void 0) {
      const typeStr = inspect(locationType);
      context.reportError(
        new GraphQLError(
          `Expected value of type "${typeStr}", found ${print(node)}.`,
          {
            nodes: node
          }
        )
      );
    }
  } catch (error) {
    const typeStr = inspect(locationType);
    if (error instanceof GraphQLError) {
      context.reportError(error);
    } else {
      context.reportError(
        new GraphQLError(
          `Expected value of type "${typeStr}", found ${print(node)}; ` + error.message,
          {
            nodes: node,
            originalError: error
          }
        )
      );
    }
  }
}
function VariablesAreInputTypesRule(context) {
  return {
    VariableDefinition(node) {
      const type = typeFromAST(context.getSchema(), node.type);
      if (type !== void 0 && !isInputType(type)) {
        const variableName = node.variable.name.value;
        const typeName = print(node.type);
        context.reportError(
          new GraphQLError(
            `Variable "$${variableName}" cannot be non-input type "${typeName}".`,
            {
              nodes: node.type
            }
          )
        );
      }
    }
  };
}
function VariablesInAllowedPositionRule(context) {
  let varDefMap = /* @__PURE__ */ Object.create(null);
  return {
    OperationDefinition: {
      enter() {
        varDefMap = /* @__PURE__ */ Object.create(null);
      },
      leave(operation) {
        const usages = context.getRecursiveVariableUsages(operation);
        for (const { node, type, defaultValue } of usages) {
          const varName = node.name.value;
          const varDef = varDefMap[varName];
          if (varDef && type) {
            const schema = context.getSchema();
            const varType = typeFromAST(schema, varDef.type);
            if (varType && !allowedVariableUsage(
              schema,
              varType,
              varDef.defaultValue,
              type,
              defaultValue
            )) {
              const varTypeStr = inspect(varType);
              const typeStr = inspect(type);
              context.reportError(
                new GraphQLError(
                  `Variable "$${varName}" of type "${varTypeStr}" used in position expecting type "${typeStr}".`,
                  {
                    nodes: [varDef, node]
                  }
                )
              );
            }
          }
        }
      }
    },
    VariableDefinition(node) {
      varDefMap[node.variable.name.value] = node;
    }
  };
}
function allowedVariableUsage(schema, varType, varDefaultValue, locationType, locationDefaultValue) {
  if (isNonNullType(locationType) && !isNonNullType(varType)) {
    const hasNonNullVariableDefaultValue = varDefaultValue != null && varDefaultValue.kind !== Kind.NULL;
    const hasLocationDefaultValue = locationDefaultValue !== void 0;
    if (!hasNonNullVariableDefaultValue && !hasLocationDefaultValue) {
      return false;
    }
    const nullableLocationType = locationType.ofType;
    return isTypeSubTypeOf(schema, varType, nullableLocationType);
  }
  return isTypeSubTypeOf(schema, varType, locationType);
}
var specifiedRules = Object.freeze([
  ExecutableDefinitionsRule,
  UniqueOperationNamesRule,
  LoneAnonymousOperationRule,
  SingleFieldSubscriptionsRule,
  KnownTypeNamesRule,
  FragmentsOnCompositeTypesRule,
  VariablesAreInputTypesRule,
  ScalarLeafsRule,
  FieldsOnCorrectTypeRule,
  UniqueFragmentNamesRule,
  KnownFragmentNamesRule,
  NoUnusedFragmentsRule,
  PossibleFragmentSpreadsRule,
  NoFragmentCyclesRule,
  UniqueVariableNamesRule,
  NoUndefinedVariablesRule,
  NoUnusedVariablesRule,
  KnownDirectivesRule,
  UniqueDirectivesPerLocationRule,
  KnownArgumentNamesRule,
  UniqueArgumentNamesRule,
  ValuesOfCorrectTypeRule,
  ProvidedRequiredArgumentsRule,
  VariablesInAllowedPositionRule,
  OverlappingFieldsCanBeMergedRule,
  UniqueInputFieldNamesRule
]);
var specifiedSDLRules = Object.freeze([
  LoneSchemaDefinitionRule,
  UniqueOperationTypesRule,
  UniqueTypeNamesRule,
  UniqueEnumValueNamesRule,
  UniqueFieldDefinitionNamesRule,
  UniqueArgumentDefinitionNamesRule,
  UniqueDirectiveNamesRule,
  KnownTypeNamesRule,
  KnownDirectivesRule,
  UniqueDirectivesPerLocationRule,
  PossibleTypeExtensionsRule,
  KnownArgumentNamesOnDirectivesRule,
  UniqueArgumentNamesRule,
  UniqueInputFieldNamesRule,
  ProvidedRequiredArgumentsOnDirectivesRule
]);
function memoize3(fn) {
  let cache0;
  return function memoized(a1, a2, a3) {
    if (cache0 === void 0) {
      cache0 = /* @__PURE__ */ new WeakMap();
    }
    let cache1 = cache0.get(a1);
    if (cache1 === void 0) {
      cache1 = /* @__PURE__ */ new WeakMap();
      cache0.set(a1, cache1);
    }
    let cache2 = cache1.get(a2);
    if (cache2 === void 0) {
      cache2 = /* @__PURE__ */ new WeakMap();
      cache1.set(a2, cache2);
    }
    let fnResult = cache2.get(a3);
    if (fnResult === void 0) {
      fnResult = fn(a1, a2, a3);
      cache2.set(a3, fnResult);
    }
    return fnResult;
  };
}
var collectSubfields2 = memoize3(
  (exeContext, returnType, fieldNodes) => collectSubfields(
    exeContext.schema,
    exeContext.fragments,
    exeContext.variableValues,
    returnType,
    fieldNodes
  )
);
var stdTypeMap = keyMap(
  [...specifiedScalarTypes, ...introspectionTypes],
  (type) => type.name
);
var BreakingChangeType;
(function(BreakingChangeType2) {
  BreakingChangeType2["TYPE_REMOVED"] = "TYPE_REMOVED";
  BreakingChangeType2["TYPE_CHANGED_KIND"] = "TYPE_CHANGED_KIND";
  BreakingChangeType2["TYPE_REMOVED_FROM_UNION"] = "TYPE_REMOVED_FROM_UNION";
  BreakingChangeType2["VALUE_REMOVED_FROM_ENUM"] = "VALUE_REMOVED_FROM_ENUM";
  BreakingChangeType2["REQUIRED_INPUT_FIELD_ADDED"] = "REQUIRED_INPUT_FIELD_ADDED";
  BreakingChangeType2["IMPLEMENTED_INTERFACE_REMOVED"] = "IMPLEMENTED_INTERFACE_REMOVED";
  BreakingChangeType2["FIELD_REMOVED"] = "FIELD_REMOVED";
  BreakingChangeType2["FIELD_CHANGED_KIND"] = "FIELD_CHANGED_KIND";
  BreakingChangeType2["REQUIRED_ARG_ADDED"] = "REQUIRED_ARG_ADDED";
  BreakingChangeType2["ARG_REMOVED"] = "ARG_REMOVED";
  BreakingChangeType2["ARG_CHANGED_KIND"] = "ARG_CHANGED_KIND";
  BreakingChangeType2["DIRECTIVE_REMOVED"] = "DIRECTIVE_REMOVED";
  BreakingChangeType2["DIRECTIVE_ARG_REMOVED"] = "DIRECTIVE_ARG_REMOVED";
  BreakingChangeType2["REQUIRED_DIRECTIVE_ARG_ADDED"] = "REQUIRED_DIRECTIVE_ARG_ADDED";
  BreakingChangeType2["DIRECTIVE_REPEATABLE_REMOVED"] = "DIRECTIVE_REPEATABLE_REMOVED";
  BreakingChangeType2["DIRECTIVE_LOCATION_REMOVED"] = "DIRECTIVE_LOCATION_REMOVED";
})(BreakingChangeType || (BreakingChangeType = {}));
var DangerousChangeType;
(function(DangerousChangeType2) {
  DangerousChangeType2["VALUE_ADDED_TO_ENUM"] = "VALUE_ADDED_TO_ENUM";
  DangerousChangeType2["TYPE_ADDED_TO_UNION"] = "TYPE_ADDED_TO_UNION";
  DangerousChangeType2["OPTIONAL_INPUT_FIELD_ADDED"] = "OPTIONAL_INPUT_FIELD_ADDED";
  DangerousChangeType2["OPTIONAL_ARG_ADDED"] = "OPTIONAL_ARG_ADDED";
  DangerousChangeType2["IMPLEMENTED_INTERFACE_ADDED"] = "IMPLEMENTED_INTERFACE_ADDED";
  DangerousChangeType2["ARG_DEFAULT_VALUE_CHANGE"] = "ARG_DEFAULT_VALUE_CHANGE";
})(DangerousChangeType || (DangerousChangeType = {}));
function jsonParse(value) {
  try {
    return JSON.parse(value);
  } catch (error) {
    return void 0;
  }
}
var __create3 = Object.create;
var __defProp4 = Object.defineProperty;
var __getOwnPropDesc3 = Object.getOwnPropertyDescriptor;
var __getOwnPropNames3 = Object.getOwnPropertyNames;
var __getProtoOf3 = Object.getPrototypeOf;
var __hasOwnProp3 = Object.prototype.hasOwnProperty;
var __commonJS3 = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames3(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps3 = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames3(from))
      if (!__hasOwnProp3.call(to, key) && key !== except)
        __defProp4(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc3(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM3 = (mod, isNodeMode, target) => (target = mod != null ? __create3(__getProtoOf3(mod)) : {}, __copyProps3(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp4(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_set_cookie = __commonJS3({
  "node_modules/set-cookie-parser/lib/set-cookie.js"(exports, module) {
    "use strict";
    var defaultParseOptions = {
      decodeValues: true,
      map: false,
      silent: false
    };
    function isNonEmptyString(str) {
      return typeof str === "string" && !!str.trim();
    }
    function parseString(setCookieValue, options) {
      var parts = setCookieValue.split(";").filter(isNonEmptyString);
      var nameValuePairStr = parts.shift();
      var parsed = parseNameValuePair(nameValuePairStr);
      var name = parsed.name;
      var value = parsed.value;
      options = options ? Object.assign({}, defaultParseOptions, options) : defaultParseOptions;
      try {
        value = options.decodeValues ? decodeURIComponent(value) : value;
      } catch (e) {
        console.error(
          "set-cookie-parser encountered an error while decoding a cookie with value '" + value + "'. Set options.decodeValues to false to disable this feature.",
          e
        );
      }
      var cookie = {
        name,
        value
      };
      parts.forEach(function(part) {
        var sides = part.split("=");
        var key = sides.shift().trimLeft().toLowerCase();
        var value2 = sides.join("=");
        if (key === "expires") {
          cookie.expires = new Date(value2);
        } else if (key === "max-age") {
          cookie.maxAge = parseInt(value2, 10);
        } else if (key === "secure") {
          cookie.secure = true;
        } else if (key === "httponly") {
          cookie.httpOnly = true;
        } else if (key === "samesite") {
          cookie.sameSite = value2;
        } else {
          cookie[key] = value2;
        }
      });
      return cookie;
    }
    function parseNameValuePair(nameValuePairStr) {
      var name = "";
      var value = "";
      var nameValueArr = nameValuePairStr.split("=");
      if (nameValueArr.length > 1) {
        name = nameValueArr.shift();
        value = nameValueArr.join("=");
      } else {
        value = nameValuePairStr;
      }
      return { name, value };
    }
    function parse3(input, options) {
      options = options ? Object.assign({}, defaultParseOptions, options) : defaultParseOptions;
      if (!input) {
        if (!options.map) {
          return [];
        } else {
          return {};
        }
      }
      if (input.headers) {
        if (typeof input.headers.getSetCookie === "function") {
          input = input.headers.getSetCookie();
        } else if (input.headers["set-cookie"]) {
          input = input.headers["set-cookie"];
        } else {
          var sch = input.headers[Object.keys(input.headers).find(function(key) {
            return key.toLowerCase() === "set-cookie";
          })];
          if (!sch && input.headers.cookie && !options.silent) {
            console.warn(
              "Warning: set-cookie-parser appears to have been called on a request object. It is designed to parse Set-Cookie headers from responses, not Cookie headers from requests. Set the option {silent: true} to suppress this warning."
            );
          }
          input = sch;
        }
      }
      if (!Array.isArray(input)) {
        input = [input];
      }
      options = options ? Object.assign({}, defaultParseOptions, options) : defaultParseOptions;
      if (!options.map) {
        return input.filter(isNonEmptyString).map(function(str) {
          return parseString(str, options);
        });
      } else {
        var cookies = {};
        return input.filter(isNonEmptyString).reduce(function(cookies2, str) {
          var cookie = parseString(str, options);
          cookies2[cookie.name] = cookie;
          return cookies2;
        }, cookies);
      }
    }
    function splitCookiesString2(cookiesString) {
      if (Array.isArray(cookiesString)) {
        return cookiesString;
      }
      if (typeof cookiesString !== "string") {
        return [];
      }
      var cookiesStrings = [];
      var pos = 0;
      var start;
      var ch;
      var lastComma;
      var nextStart;
      var cookiesSeparatorFound;
      function skipWhitespace() {
        while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
          pos += 1;
        }
        return pos < cookiesString.length;
      }
      function notSpecialChar() {
        ch = cookiesString.charAt(pos);
        return ch !== "=" && ch !== ";" && ch !== ",";
      }
      while (pos < cookiesString.length) {
        start = pos;
        cookiesSeparatorFound = false;
        while (skipWhitespace()) {
          ch = cookiesString.charAt(pos);
          if (ch === ",") {
            lastComma = pos;
            pos += 1;
            skipWhitespace();
            nextStart = pos;
            while (pos < cookiesString.length && notSpecialChar()) {
              pos += 1;
            }
            if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
              cookiesSeparatorFound = true;
              pos = nextStart;
              cookiesStrings.push(cookiesString.substring(start, lastComma));
              start = pos;
            } else {
              pos = lastComma + 1;
            }
          } else {
            pos += 1;
          }
        }
        if (!cookiesSeparatorFound || pos >= cookiesString.length) {
          cookiesStrings.push(cookiesString.substring(start, cookiesString.length));
        }
      }
      return cookiesStrings;
    }
    module.exports = parse3;
    module.exports.parse = parse3;
    module.exports.parseString = parseString;
    module.exports.splitCookiesString = splitCookiesString2;
  }
});
var import_set_cookie_parser = __toESM3(require_set_cookie());
var HEADERS_INVALID_CHARACTERS = /[^a-z0-9\-#$%&'*+.^_`|~]/i;
function normalizeHeaderName(name) {
  if (HEADERS_INVALID_CHARACTERS.test(name) || name.trim() === "") {
    throw new TypeError("Invalid character in header field name");
  }
  return name.trim().toLowerCase();
}
var charCodesToRemove = [
  String.fromCharCode(10),
  String.fromCharCode(13),
  String.fromCharCode(9),
  String.fromCharCode(32)
];
var HEADER_VALUE_REMOVE_REGEXP = new RegExp(
  `(^[${charCodesToRemove.join("")}]|$[${charCodesToRemove.join("")}])`,
  "g"
);
function normalizeHeaderValue(value) {
  const nextValue = value.replace(HEADER_VALUE_REMOVE_REGEXP, "");
  return nextValue;
}
function isValidHeaderName(value) {
  if (typeof value !== "string") {
    return false;
  }
  if (value.length === 0) {
    return false;
  }
  for (let i = 0; i < value.length; i++) {
    const character = value.charCodeAt(i);
    if (character > 127 || !isToken(character)) {
      return false;
    }
  }
  return true;
}
function isToken(value) {
  return ![
    127,
    32,
    "(",
    ")",
    "<",
    ">",
    "@",
    ",",
    ";",
    ":",
    "\\",
    '"',
    "/",
    "[",
    "]",
    "?",
    "=",
    "{",
    "}"
  ].includes(value);
}
function isValidHeaderValue(value) {
  if (typeof value !== "string") {
    return false;
  }
  if (value.trim() !== value) {
    return false;
  }
  for (let i = 0; i < value.length; i++) {
    const character = value.charCodeAt(i);
    if (
      // NUL.
      character === 0 || // HTTP newline bytes.
      character === 10 || character === 13
    ) {
      return false;
    }
  }
  return true;
}
var NORMALIZED_HEADERS = Symbol("normalizedHeaders");
var RAW_HEADER_NAMES = Symbol("rawHeaderNames");
var HEADER_VALUE_DELIMITER = ", ";
var _a;
var _b;
var _c;
var Headers2 = class _Headers {
  constructor(init) {
    this[_a] = {};
    this[_b] = /* @__PURE__ */ new Map();
    this[_c] = "Headers";
    if (["Headers", "HeadersPolyfill"].includes(init == null ? void 0 : init.constructor.name) || init instanceof _Headers || typeof globalThis.Headers !== "undefined" && init instanceof globalThis.Headers) {
      const initialHeaders = init;
      initialHeaders.forEach((value, name) => {
        this.append(name, value);
      }, this);
    } else if (Array.isArray(init)) {
      init.forEach(([name, value]) => {
        this.append(
          name,
          Array.isArray(value) ? value.join(HEADER_VALUE_DELIMITER) : value
        );
      });
    } else if (init) {
      Object.getOwnPropertyNames(init).forEach((name) => {
        const value = init[name];
        this.append(
          name,
          Array.isArray(value) ? value.join(HEADER_VALUE_DELIMITER) : value
        );
      });
    }
  }
  [(_a = NORMALIZED_HEADERS, _b = RAW_HEADER_NAMES, _c = Symbol.toStringTag, Symbol.iterator)]() {
    return this.entries();
  }
  *keys() {
    for (const [name] of this.entries()) {
      yield name;
    }
  }
  *values() {
    for (const [, value] of this.entries()) {
      yield value;
    }
  }
  *entries() {
    let sortedKeys = Object.keys(this[NORMALIZED_HEADERS]).sort(
      (a, b) => a.localeCompare(b)
    );
    for (const name of sortedKeys) {
      if (name === "set-cookie") {
        for (const value of this.getSetCookie()) {
          yield [name, value];
        }
      } else {
        yield [name, this.get(name)];
      }
    }
  }
  /**
   * Returns a boolean stating whether a `Headers` object contains a certain header.
   */
  has(name) {
    if (!isValidHeaderName(name)) {
      throw new TypeError(`Invalid header name "${name}"`);
    }
    return this[NORMALIZED_HEADERS].hasOwnProperty(normalizeHeaderName(name));
  }
  /**
   * Returns a `ByteString` sequence of all the values of a header with a given name.
   */
  get(name) {
    if (!isValidHeaderName(name)) {
      throw TypeError(`Invalid header name "${name}"`);
    }
    return this[NORMALIZED_HEADERS][normalizeHeaderName(name)] ?? null;
  }
  /**
   * Sets a new value for an existing header inside a `Headers` object, or adds the header if it does not already exist.
   */
  set(name, value) {
    if (!isValidHeaderName(name) || !isValidHeaderValue(value)) {
      return;
    }
    const normalizedName = normalizeHeaderName(name);
    const normalizedValue = normalizeHeaderValue(value);
    this[NORMALIZED_HEADERS][normalizedName] = normalizeHeaderValue(normalizedValue);
    this[RAW_HEADER_NAMES].set(normalizedName, name);
  }
  /**
   * Appends a new value onto an existing header inside a `Headers` object, or adds the header if it does not already exist.
   */
  append(name, value) {
    if (!isValidHeaderName(name) || !isValidHeaderValue(value)) {
      return;
    }
    const normalizedName = normalizeHeaderName(name);
    const normalizedValue = normalizeHeaderValue(value);
    let resolvedValue = this.has(normalizedName) ? `${this.get(normalizedName)}, ${normalizedValue}` : normalizedValue;
    this.set(name, resolvedValue);
  }
  /**
   * Deletes a header from the `Headers` object.
   */
  delete(name) {
    if (!isValidHeaderName(name)) {
      return;
    }
    if (!this.has(name)) {
      return;
    }
    const normalizedName = normalizeHeaderName(name);
    delete this[NORMALIZED_HEADERS][normalizedName];
    this[RAW_HEADER_NAMES].delete(normalizedName);
  }
  /**
   * Traverses the `Headers` object,
   * calling the given callback for each header.
   */
  forEach(callback, thisArg) {
    for (const [name, value] of this.entries()) {
      callback.call(thisArg, value, name, this);
    }
  }
  /**
   * Returns an array containing the values
   * of all Set-Cookie headers associated
   * with a response
   */
  getSetCookie() {
    const setCookieHeader = this.get("set-cookie");
    if (setCookieHeader === null) {
      return [];
    }
    if (setCookieHeader === "") {
      return [""];
    }
    return (0, import_set_cookie_parser.splitCookiesString)(setCookieHeader);
  }
};
function stringToHeaders(str) {
  const lines = str.trim().split(/[\r\n]+/);
  return lines.reduce((headers, line) => {
    if (line.trim() === "") {
      return headers;
    }
    const parts = line.split(": ");
    const name = parts.shift();
    const value = parts.join(": ");
    headers.append(name, value);
    return headers;
  }, new Headers2());
}
function parseContentHeaders(headersString) {
  var _a2, _b2;
  const headers = stringToHeaders(headersString);
  const contentType = headers.get("content-type") || "text/plain";
  const disposition = headers.get("content-disposition");
  if (!disposition) {
    throw new Error('"Content-Disposition" header is required.');
  }
  const directives = disposition.split(";").reduce((acc, chunk) => {
    const [name2, ...rest] = chunk.trim().split("=");
    acc[name2] = rest.join("=");
    return acc;
  }, {});
  const name = (_a2 = directives.name) == null ? void 0 : _a2.slice(1, -1);
  const filename = (_b2 = directives.filename) == null ? void 0 : _b2.slice(1, -1);
  return {
    name,
    filename,
    contentType
  };
}
function parseMultipartData(data, headers) {
  const contentType = headers == null ? void 0 : headers.get("content-type");
  if (!contentType) {
    return void 0;
  }
  const [, ...directives] = contentType.split(/; */);
  const boundary = directives.filter((d) => d.startsWith("boundary=")).map((s) => s.replace(/^boundary=/, ""))[0];
  if (!boundary) {
    return void 0;
  }
  const boundaryRegExp = new RegExp(`--+${boundary}`);
  const fields = data.split(boundaryRegExp).filter((chunk) => chunk.startsWith("\r\n") && chunk.endsWith("\r\n")).map((chunk) => chunk.trimStart().replace(/\r\n$/, ""));
  if (!fields.length) {
    return void 0;
  }
  const parsedBody = {};
  try {
    for (const field of fields) {
      const [contentHeaders, ...rest] = field.split("\r\n\r\n");
      const contentBody = rest.join("\r\n\r\n");
      const { contentType: contentType2, filename, name } = parseContentHeaders(contentHeaders);
      const value = filename === void 0 ? contentBody : new File([contentBody], filename, { type: contentType2 });
      const parsedValue = parsedBody[name];
      if (parsedValue === void 0) {
        parsedBody[name] = value;
      } else if (Array.isArray(parsedValue)) {
        parsedBody[name] = [...parsedValue, value];
      } else {
        parsedBody[name] = [parsedValue, value];
      }
    }
    return parsedBody;
  } catch (error) {
    return void 0;
  }
}
function parseDocumentNode(node) {
  var _a2;
  const operationDef = node.definitions.find((definition) => {
    return definition.kind === "OperationDefinition";
  });
  return {
    operationType: operationDef == null ? void 0 : operationDef.operation,
    operationName: (_a2 = operationDef == null ? void 0 : operationDef.name) == null ? void 0 : _a2.value
  };
}
function parseQuery(query) {
  try {
    const ast = parse2(query);
    return parseDocumentNode(ast);
  } catch (error) {
    return error;
  }
}
function extractMultipartVariables(variables, map, files) {
  const operations = { variables };
  for (const [key, pathArray] of Object.entries(map)) {
    if (!(key in files)) {
      throw new Error(`Given files do not have a key '${key}' .`);
    }
    for (const dotPath of pathArray) {
      const [lastPath, ...reversedPaths] = dotPath.split(".").reverse();
      const paths = reversedPaths.reverse();
      let target = operations;
      for (const path of paths) {
        if (!(path in target)) {
          throw new Error(`Property '${paths}' is not in operations.`);
        }
        target = target[path];
      }
      target[lastPath] = files[key];
    }
  }
  return operations.variables;
}
async function getGraphQLInput(request) {
  var _a2;
  switch (request.method) {
    case "GET": {
      const url = new URL(request.url);
      const query = url.searchParams.get("query");
      const variables = url.searchParams.get("variables") || "";
      return {
        query,
        variables: jsonParse(variables)
      };
    }
    case "POST": {
      const requestClone = request.clone();
      if ((_a2 = request.headers.get("content-type")) == null ? void 0 : _a2.includes("multipart/form-data")) {
        const responseJson = parseMultipartData(
          await requestClone.text(),
          request.headers
        );
        if (!responseJson) {
          return null;
        }
        const { operations, map, ...files } = responseJson;
        const parsedOperations = jsonParse(
          operations
        ) || {};
        if (!parsedOperations.query) {
          return null;
        }
        const parsedMap = jsonParse(map || "") || {};
        const variables = parsedOperations.variables ? extractMultipartVariables(
          parsedOperations.variables,
          parsedMap,
          files
        ) : {};
        return {
          query: parsedOperations.query,
          variables
        };
      }
      const requestJson = await requestClone.json().catch(() => null);
      if (requestJson == null ? void 0 : requestJson.query) {
        const { query, variables } = requestJson;
        return {
          query,
          variables
        };
      }
    }
    default:
      return null;
  }
}
async function parseGraphQLRequest(request) {
  const input = await getGraphQLInput(request);
  if (!input || !input.query) {
    return;
  }
  const { query, variables } = input;
  const parsedResult = parseQuery(query);
  if (parsedResult instanceof Error) {
    const requestPublicUrl = toPublicUrl(request.url);
    throw new Error(
      devUtils.formatMessage(
        'Failed to intercept a GraphQL request to "%s %s": cannot parse query. See the error message from the parser below.\n\n%s',
        request.method,
        requestPublicUrl,
        parsedResult.message
      )
    );
  }
  return {
    query: input.query,
    operationType: parsedResult.operationType,
    operationName: parsedResult.operationName,
    variables
  };
}
function isDocumentNode(value) {
  if (value == null) {
    return false;
  }
  return typeof value === "object" && "kind" in value && "definitions" in value;
}
var _GraphQLHandler = class _GraphQLHandler2 extends RequestHandler {
  constructor(operationType, operationName, endpoint, resolver, options) {
    let resolvedOperationName = operationName;
    if (isDocumentNode(operationName)) {
      const parsedNode = parseDocumentNode(operationName);
      if (parsedNode.operationType !== operationType) {
        throw new Error(
          `Failed to create a GraphQL handler: provided a DocumentNode with a mismatched operation type (expected "${operationType}", but got "${parsedNode.operationType}").`
        );
      }
      if (!parsedNode.operationName) {
        throw new Error(
          `Failed to create a GraphQL handler: provided a DocumentNode with no operation name.`
        );
      }
      resolvedOperationName = parsedNode.operationName;
    }
    const header = operationType === "all" ? `${operationType} (origin: ${endpoint.toString()})` : `${operationType} ${resolvedOperationName} (origin: ${endpoint.toString()})`;
    super({
      info: {
        header,
        operationType,
        operationName: resolvedOperationName
      },
      resolver,
      options
    });
    __publicField(this, "endpoint");
    this.endpoint = endpoint;
  }
  /**
   * Parses the request body, once per request, cached across all
   * GraphQL handlers. This is done to avoid multiple parsing of the
   * request body, which each requires a clone of the request.
   */
  async parseGraphQLRequestOrGetFromCache(request) {
    if (!_GraphQLHandler2.parsedRequestCache.has(request)) {
      _GraphQLHandler2.parsedRequestCache.set(
        request,
        await parseGraphQLRequest(request).catch((error) => {
          console.error(error);
          return void 0;
        })
      );
    }
    return _GraphQLHandler2.parsedRequestCache.get(request);
  }
  async parse(args) {
    const match2 = matchRequestUrl(new URL(args.request.url), this.endpoint);
    const cookies = getAllRequestCookies(args.request);
    if (!match2.matches) {
      return { match: match2, cookies };
    }
    const parsedResult = await this.parseGraphQLRequestOrGetFromCache(
      args.request
    );
    if (typeof parsedResult === "undefined") {
      return { match: match2, cookies };
    }
    return {
      match: match2,
      cookies,
      query: parsedResult.query,
      operationType: parsedResult.operationType,
      operationName: parsedResult.operationName,
      variables: parsedResult.variables
    };
  }
  predicate(args) {
    if (args.parsedResult.operationType === void 0) {
      return false;
    }
    if (!args.parsedResult.operationName && this.info.operationType !== "all") {
      const publicUrl = toPublicUrl(args.request.url);
      devUtils.warn(`Failed to intercept a GraphQL request at "${args.request.method} ${publicUrl}": anonymous GraphQL operations are not supported.

Consider naming this operation or using "graphql.operation()" request handler to intercept GraphQL requests regardless of their operation name/type. Read more: https://mswjs.io/docs/api/graphql/#graphqloperationresolver`);
      return false;
    }
    const hasMatchingOperationType = this.info.operationType === "all" || args.parsedResult.operationType === this.info.operationType;
    const hasMatchingOperationName = this.info.operationName instanceof RegExp ? this.info.operationName.test(args.parsedResult.operationName || "") : args.parsedResult.operationName === this.info.operationName;
    return args.parsedResult.match.matches && hasMatchingOperationType && hasMatchingOperationName;
  }
  extendResolverArgs(args) {
    return {
      query: args.parsedResult.query || "",
      operationName: args.parsedResult.operationName || "",
      variables: args.parsedResult.variables || {},
      cookies: args.parsedResult.cookies
    };
  }
  async log(args) {
    const loggedRequest = await serializeRequest(args.request);
    const loggedResponse = await serializeResponse(args.response);
    const statusColor = getStatusCodeColor(loggedResponse.status);
    const requestInfo = args.parsedResult.operationName ? `${args.parsedResult.operationType} ${args.parsedResult.operationName}` : `anonymous ${args.parsedResult.operationType}`;
    console.groupCollapsed(
      devUtils.formatMessage(
        `${getTimestamp()} ${requestInfo} (%c${loggedResponse.status} ${loggedResponse.statusText}%c)`
      ),
      `color:${statusColor}`,
      "color:inherit"
    );
    console.log("Request:", loggedRequest);
    console.log("Handler:", this);
    console.log("Response:", loggedResponse);
    console.groupEnd();
  }
};
__publicField(_GraphQLHandler, "parsedRequestCache", /* @__PURE__ */ new WeakMap());
var GraphQLHandler = _GraphQLHandler;
function createScopedGraphQLHandler(operationType, url) {
  return (operationName, resolver, options = {}) => {
    return new GraphQLHandler(
      operationType,
      operationName,
      url,
      resolver,
      options
    );
  };
}
function createGraphQLOperationHandler(url) {
  return (resolver) => {
    return new GraphQLHandler("all", new RegExp(".*"), url, resolver);
  };
}
var standardGraphQLHandlers = {
  /**
   * Intercepts a GraphQL query by a given name.
   *
   * @example
   * graphql.query('GetUser', () => {
   *   return HttpResponse.json({ data: { user: { name: 'John' } } })
   * })
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphqlqueryqueryname-resolver `graphql.query()` API reference}
   */
  query: createScopedGraphQLHandler("query", "*"),
  /**
   * Intercepts a GraphQL mutation by its name.
   *
   * @example
   * graphql.mutation('SavePost', () => {
   *   return HttpResponse.json({ data: { post: { id: 'abc-123 } } })
   * })
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphqlmutationmutationname-resolver `graphql.query()` API reference}
   *
   */
  mutation: createScopedGraphQLHandler("mutation", "*"),
  /**
   * Intercepts any GraphQL operation, regardless of its type or name.
   *
   * @example
   * graphql.operation(() => {
   *   return HttpResponse.json({ data: { name: 'John' } })
   * })
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphloperationresolver `graphql.operation()` API reference}
   */
  operation: createGraphQLOperationHandler("*")
};
function createGraphQLLink(url) {
  return {
    operation: createGraphQLOperationHandler(url),
    query: createScopedGraphQLHandler("query", url),
    mutation: createScopedGraphQLHandler("mutation", url)
  };
}
var graphql2 = {
  ...standardGraphQLHandlers,
  /**
   * Intercepts GraphQL operations scoped by the given URL.
   *
   * @example
   * const github = graphql.link('https://api.github.com/graphql')
   * github.query('GetRepo', resolver)
   *
   * @see {@link https://mswjs.io/docs/api/graphql#graphqllinkurl `graphql.link()` API reference}
   */
  link: createGraphQLLink
};
var getResponse = async (handlers, request) => {
  const result = await executeHandlers({
    request,
    requestId: createRequestId(),
    handlers
  });
  return result == null ? void 0 : result.response;
};
var { message: message2 } = source_default;
function normalizeResponseInit(init = {}) {
  const status = (init == null ? void 0 : init.status) || 200;
  const statusText = (init == null ? void 0 : init.statusText) || message2[status] || "";
  const headers = new Headers(init == null ? void 0 : init.headers);
  return {
    ...init,
    headers,
    status,
    statusText
  };
}
function decorateResponse(response, init) {
  if (init.type) {
    Object.defineProperty(response, "type", {
      value: init.type,
      enumerable: true,
      writable: false
    });
  }
  if (typeof document !== "undefined") {
    const responseCookies = Headers2.prototype.getSetCookie.call(
      init.headers
    );
    for (const cookieString of responseCookies) {
      document.cookie = cookieString;
    }
  }
  return response;
}
var HttpResponse = class _HttpResponse extends Response {
  constructor(body, init) {
    const responseInit = normalizeResponseInit(init);
    super(body, responseInit);
    decorateResponse(this, responseInit);
  }
  /**
   * Create a `Response` with a `Content-Type: "text/plain"` body.
   * @example
   * HttpResponse.text('hello world')
   * HttpResponse.text('Error', { status: 500 })
   */
  static text(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (!responseInit.headers.has("Content-Type")) {
      responseInit.headers.set("Content-Type", "text/plain");
    }
    if (!responseInit.headers.has("Content-Length")) {
      responseInit.headers.set(
        "Content-Length",
        body ? new Blob([body]).size.toString() : "0"
      );
    }
    return new _HttpResponse(body, responseInit);
  }
  /**
   * Create a `Response` with a `Content-Type: "application/json"` body.
   * @example
   * HttpResponse.json({ firstName: 'John' })
   * HttpResponse.json({ error: 'Not Authorized' }, { status: 401 })
   */
  static json(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (!responseInit.headers.has("Content-Type")) {
      responseInit.headers.set("Content-Type", "application/json");
    }
    const responseText = JSON.stringify(body);
    if (!responseInit.headers.has("Content-Length")) {
      responseInit.headers.set(
        "Content-Length",
        responseText ? new Blob([responseText]).size.toString() : "0"
      );
    }
    return new _HttpResponse(
      responseText,
      responseInit
    );
  }
  /**
   * Create a `Response` with a `Content-Type: "application/xml"` body.
   * @example
   * HttpResponse.xml(`<user name="John" />`)
   * HttpResponse.xml(`<article id="abc-123" />`, { status: 201 })
   */
  static xml(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (!responseInit.headers.has("Content-Type")) {
      responseInit.headers.set("Content-Type", "text/xml");
    }
    return new _HttpResponse(body, responseInit);
  }
  /**
   * Create a `Response` with an `ArrayBuffer` body.
   * @example
   * const buffer = new ArrayBuffer(3)
   * const view = new Uint8Array(buffer)
   * view.set([1, 2, 3])
   *
   * HttpResponse.arrayBuffer(buffer)
   */
  static arrayBuffer(body, init) {
    const responseInit = normalizeResponseInit(init);
    if (body) {
      responseInit.headers.set("Content-Length", body.byteLength.toString());
    }
    return new _HttpResponse(body, responseInit);
  }
  /**
   * Create a `Response` with a `FormData` body.
   * @example
   * const data = new FormData()
   * data.set('name', 'Alice')
   *
   * HttpResponse.formData(data)
   */
  static formData(body, init) {
    return new _HttpResponse(body, normalizeResponseInit(init));
  }
};
var SET_TIMEOUT_MAX_ALLOWED_INT = 2147483647;
var MIN_SERVER_RESPONSE_TIME = 100;
var MAX_SERVER_RESPONSE_TIME = 400;
var NODE_SERVER_RESPONSE_TIME = 5;
function getRealisticResponseTime() {
  if (isNodeProcess()) {
    return NODE_SERVER_RESPONSE_TIME;
  }
  return Math.floor(
    Math.random() * (MAX_SERVER_RESPONSE_TIME - MIN_SERVER_RESPONSE_TIME) + MIN_SERVER_RESPONSE_TIME
  );
}
async function delay(durationOrMode) {
  let delayTime;
  if (typeof durationOrMode === "string") {
    switch (durationOrMode) {
      case "infinite": {
        delayTime = SET_TIMEOUT_MAX_ALLOWED_INT;
        break;
      }
      case "real": {
        delayTime = getRealisticResponseTime();
        break;
      }
      default: {
        throw new Error(
          `Failed to delay a response: unknown delay mode "${durationOrMode}". Please make sure you provide one of the supported modes ("real", "infinite") or a number.`
        );
      }
    }
  } else if (typeof durationOrMode === "undefined") {
    delayTime = getRealisticResponseTime();
  } else {
    if (durationOrMode > SET_TIMEOUT_MAX_ALLOWED_INT) {
      throw new Error(
        `Failed to delay a response: provided delay duration (${durationOrMode}) exceeds the maximum allowed duration for "setTimeout" (${SET_TIMEOUT_MAX_ALLOWED_INT}). This will cause the response to be returned immediately. Please use a number within the allowed range to delay the response by exact duration, or consider the "infinite" delay mode to delay the response indefinitely.`
      );
    }
    delayTime = durationOrMode;
  }
  return new Promise((resolve) => setTimeout(resolve, delayTime));
}
function bypass(input, init) {
  const request = new Request(
    // If given a Request instance, clone it not to exhaust
    // the original request's body.
    input instanceof Request ? input.clone() : input,
    init
  );
  invariant(
    !request.bodyUsed,
    'Failed to create a bypassed request to "%s %s": given request instance already has its body read. Make sure to clone the intercepted request if you wish to read its body before bypassing it.',
    request.method,
    request.url
  );
  const requestClone = request.clone();
  requestClone.headers.set("x-msw-intention", "bypass");
  return requestClone;
}
function passthrough() {
  return new Response(null, {
    status: 302,
    statusText: "Passthrough",
    headers: {
      "x-msw-intention": "passthrough"
    }
  });
}
checkGlobals();
export {
  GraphQLHandler,
  HttpHandler,
  HttpMethods,
  HttpResponse,
  MAX_SERVER_RESPONSE_TIME,
  MIN_SERVER_RESPONSE_TIME,
  NODE_SERVER_RESPONSE_TIME,
  RequestHandler,
  SET_TIMEOUT_MAX_ALLOWED_INT,
  SetupApi,
  bypass,
  cleanUrl,
  delay,
  getResponse,
  graphql2 as graphql,
  handleRequest,
  http,
  matchRequestUrl,
  passthrough
};
/*! Bundled license information:

@bundled-es-modules/statuses/index-esm.js:
  (*! Bundled license information:
  
  statuses/index.js:
    (*!
     * statuses
     * Copyright(c) 2014 Jonathan Ong
     * Copyright(c) 2016 Douglas Christopher Wilson
     * MIT Licensed
     *)
  *)

@bundled-es-modules/cookie/index-esm.js:
  (*! Bundled license information:
  
  cookie/index.js:
    (*!
     * cookie
     * Copyright(c) 2012-2014 Roman Shtylman
     * Copyright(c) 2015 Douglas Christopher Wilson
     * MIT Licensed
     *)
  *)
*/

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1zdy5qcz92PWNhYjQzNDkzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIFJlcXVlc3RIYW5kbGVyLFxuICBTZXR1cEFwaSxcbiAgZGV2VXRpbHMsXG4gIGV4ZWN1dGVIYW5kbGVycyxcbiAgaGFuZGxlUmVxdWVzdCxcbiAgaW52YXJpYW50LFxuICBzdG9yZSxcbiAgdG9QdWJsaWNVcmxcbn0gZnJvbSBcIi4vY2h1bmstVjNSQzYzN0cuanNcIjtcbmltcG9ydCB7XG4gIF9fcHVibGljRmllbGRcbn0gZnJvbSBcIi4vY2h1bmstVElVRUVMMjcuanNcIjtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL2ludGVybmFsL2NoZWNrR2xvYmFscy5tanNcbmZ1bmN0aW9uIGNoZWNrR2xvYmFscygpIHtcbiAgaW52YXJpYW50KFxuICAgIHR5cGVvZiBVUkwgIT09IFwidW5kZWZpbmVkXCIsXG4gICAgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcbiAgICAgIGBHbG9iYWwgXCJVUkxcIiBjbGFzcyBpcyBub3QgZGVmaW5lZC4gVGhpcyBsaWtlbHkgbWVhbnMgdGhhdCB5b3UncmUgcnVubmluZyBNU1cgaW4gYW4gZW52aXJvbm1lbnQgdGhhdCBkb2Vzbid0IHN1cHBvcnQgYWxsIE5vZGUuanMgc3RhbmRhcmQgQVBJIChlLmcuIFJlYWN0IE5hdGl2ZSkuIElmIHRoYXQncyB0aGUgY2FzZSwgcGxlYXNlIHVzZSBhbiBhcHByb3ByaWF0ZSBwb2x5ZmlsbCBmb3IgdGhlIFwiVVJMXCIgY2xhc3MsIGxpa2UgXCJyZWFjdC1uYXRpdmUtdXJsLXBvbHlmaWxsXCIuYFxuICAgIClcbiAgKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL2ludGVybmFsL2lzU3RyaW5nRXF1YWwubWpzXG5mdW5jdGlvbiBpc1N0cmluZ0VxdWFsKGFjdHVhbCwgZXhwZWN0ZWQpIHtcbiAgcmV0dXJuIGFjdHVhbC50b0xvd2VyQ2FzZSgpID09PSBleHBlY3RlZC50b0xvd2VyQ2FzZSgpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvbG9nZ2luZy9nZXRTdGF0dXNDb2RlQ29sb3IubWpzXG52YXIgU3RhdHVzQ29kZUNvbG9yID0gKChTdGF0dXNDb2RlQ29sb3IyKSA9PiB7XG4gIFN0YXR1c0NvZGVDb2xvcjJbXCJTdWNjZXNzXCJdID0gXCIjNjlBQjMyXCI7XG4gIFN0YXR1c0NvZGVDb2xvcjJbXCJXYXJuaW5nXCJdID0gXCIjRjBCQjRCXCI7XG4gIFN0YXR1c0NvZGVDb2xvcjJbXCJEYW5nZXJcIl0gPSBcIiNFOTVGNURcIjtcbiAgcmV0dXJuIFN0YXR1c0NvZGVDb2xvcjI7XG59KShTdGF0dXNDb2RlQ29sb3IgfHwge30pO1xuZnVuY3Rpb24gZ2V0U3RhdHVzQ29kZUNvbG9yKHN0YXR1cykge1xuICBpZiAoc3RhdHVzIDwgMzAwKSB7XG4gICAgcmV0dXJuIFwiIzY5QUIzMlwiO1xuICB9XG4gIGlmIChzdGF0dXMgPCA0MDApIHtcbiAgICByZXR1cm4gXCIjRjBCQjRCXCI7XG4gIH1cbiAgcmV0dXJuIFwiI0U5NUY1RFwiO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvbG9nZ2luZy9nZXRUaW1lc3RhbXAubWpzXG5mdW5jdGlvbiBnZXRUaW1lc3RhbXAoKSB7XG4gIGNvbnN0IG5vdyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgRGF0ZSgpO1xuICByZXR1cm4gW25vdy5nZXRIb3VycygpLCBub3cuZ2V0TWludXRlcygpLCBub3cuZ2V0U2Vjb25kcygpXS5tYXAoU3RyaW5nKS5tYXAoKGNodW5rKSA9PiBjaHVuay5zbGljZSgwLCAyKSkubWFwKChjaHVuaykgPT4gY2h1bmsucGFkU3RhcnQoMiwgXCIwXCIpKS5qb2luKFwiOlwiKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL2xvZ2dpbmcvc2VyaWFsaXplUmVxdWVzdC5tanNcbmFzeW5jIGZ1bmN0aW9uIHNlcmlhbGl6ZVJlcXVlc3QocmVxdWVzdCkge1xuICBjb25zdCByZXF1ZXN0Q2xvbmUgPSByZXF1ZXN0LmNsb25lKCk7XG4gIGNvbnN0IHJlcXVlc3RUZXh0ID0gYXdhaXQgcmVxdWVzdENsb25lLnRleHQoKTtcbiAgcmV0dXJuIHtcbiAgICB1cmw6IG5ldyBVUkwocmVxdWVzdC51cmwpLFxuICAgIG1ldGhvZDogcmVxdWVzdC5tZXRob2QsXG4gICAgaGVhZGVyczogT2JqZWN0LmZyb21FbnRyaWVzKHJlcXVlc3QuaGVhZGVycy5lbnRyaWVzKCkpLFxuICAgIGJvZHk6IHJlcXVlc3RUZXh0XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9AYnVuZGxlZC1lcy1tb2R1bGVzK3N0YXR1c2VzQDEuMC4xL25vZGVfbW9kdWxlcy9AYnVuZGxlZC1lcy1tb2R1bGVzL3N0YXR1c2VzL2luZGV4LWVzbS5qc1xudmFyIF9fY3JlYXRlID0gT2JqZWN0LmNyZWF0ZTtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19nZXRPd25Qcm9wRGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgX19nZXRPd25Qcm9wTmFtZXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcztcbnZhciBfX2dldFByb3RvT2YgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG52YXIgX19oYXNPd25Qcm9wID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbnZhciBfX2NvbW1vbkpTID0gKGNiLCBtb2QpID0+IGZ1bmN0aW9uIF9fcmVxdWlyZSgpIHtcbiAgcmV0dXJuIG1vZCB8fCAoMCwgY2JbX19nZXRPd25Qcm9wTmFtZXMoY2IpWzBdXSkoKG1vZCA9IHsgZXhwb3J0czoge30gfSkuZXhwb3J0cywgbW9kKSwgbW9kLmV4cG9ydHM7XG59O1xudmFyIF9fY29weVByb3BzID0gKHRvLCBmcm9tLCBleGNlcHQsIGRlc2MpID0+IHtcbiAgaWYgKGZyb20gJiYgdHlwZW9mIGZyb20gPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGZyb20gPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGZvciAobGV0IGtleSBvZiBfX2dldE93blByb3BOYW1lcyhmcm9tKSlcbiAgICAgIGlmICghX19oYXNPd25Qcm9wLmNhbGwodG8sIGtleSkgJiYga2V5ICE9PSBleGNlcHQpXG4gICAgICAgIF9fZGVmUHJvcCh0bywga2V5LCB7IGdldDogKCkgPT4gZnJvbVtrZXldLCBlbnVtZXJhYmxlOiAhKGRlc2MgPSBfX2dldE93blByb3BEZXNjKGZyb20sIGtleSkpIHx8IGRlc2MuZW51bWVyYWJsZSB9KTtcbiAgfVxuICByZXR1cm4gdG87XG59O1xudmFyIF9fdG9FU00gPSAobW9kLCBpc05vZGVNb2RlLCB0YXJnZXQpID0+ICh0YXJnZXQgPSBtb2QgIT0gbnVsbCA/IF9fY3JlYXRlKF9fZ2V0UHJvdG9PZihtb2QpKSA6IHt9LCBfX2NvcHlQcm9wcyhcbiAgLy8gSWYgdGhlIGltcG9ydGVyIGlzIGluIG5vZGUgY29tcGF0aWJpbGl0eSBtb2RlIG9yIHRoaXMgaXMgbm90IGFuIEVTTVxuICAvLyBmaWxlIHRoYXQgaGFzIGJlZW4gY29udmVydGVkIHRvIGEgQ29tbW9uSlMgZmlsZSB1c2luZyBhIEJhYmVsLVxuICAvLyBjb21wYXRpYmxlIHRyYW5zZm9ybSAoaS5lLiBcIl9fZXNNb2R1bGVcIiBoYXMgbm90IGJlZW4gc2V0KSwgdGhlbiBzZXRcbiAgLy8gXCJkZWZhdWx0XCIgdG8gdGhlIENvbW1vbkpTIFwibW9kdWxlLmV4cG9ydHNcIiBmb3Igbm9kZSBjb21wYXRpYmlsaXR5LlxuICBpc05vZGVNb2RlIHx8ICFtb2QgfHwgIW1vZC5fX2VzTW9kdWxlID8gX19kZWZQcm9wKHRhcmdldCwgXCJkZWZhdWx0XCIsIHsgdmFsdWU6IG1vZCwgZW51bWVyYWJsZTogdHJ1ZSB9KSA6IHRhcmdldCxcbiAgbW9kXG4pKTtcbnZhciByZXF1aXJlX2NvZGVzID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3N0YXR1c2VzL2NvZGVzLmpzb25cIihleHBvcnRzLCBtb2R1bGUpIHtcbiAgICBtb2R1bGUuZXhwb3J0cyA9IHtcbiAgICAgIFwiMTAwXCI6IFwiQ29udGludWVcIixcbiAgICAgIFwiMTAxXCI6IFwiU3dpdGNoaW5nIFByb3RvY29sc1wiLFxuICAgICAgXCIxMDJcIjogXCJQcm9jZXNzaW5nXCIsXG4gICAgICBcIjEwM1wiOiBcIkVhcmx5IEhpbnRzXCIsXG4gICAgICBcIjIwMFwiOiBcIk9LXCIsXG4gICAgICBcIjIwMVwiOiBcIkNyZWF0ZWRcIixcbiAgICAgIFwiMjAyXCI6IFwiQWNjZXB0ZWRcIixcbiAgICAgIFwiMjAzXCI6IFwiTm9uLUF1dGhvcml0YXRpdmUgSW5mb3JtYXRpb25cIixcbiAgICAgIFwiMjA0XCI6IFwiTm8gQ29udGVudFwiLFxuICAgICAgXCIyMDVcIjogXCJSZXNldCBDb250ZW50XCIsXG4gICAgICBcIjIwNlwiOiBcIlBhcnRpYWwgQ29udGVudFwiLFxuICAgICAgXCIyMDdcIjogXCJNdWx0aS1TdGF0dXNcIixcbiAgICAgIFwiMjA4XCI6IFwiQWxyZWFkeSBSZXBvcnRlZFwiLFxuICAgICAgXCIyMjZcIjogXCJJTSBVc2VkXCIsXG4gICAgICBcIjMwMFwiOiBcIk11bHRpcGxlIENob2ljZXNcIixcbiAgICAgIFwiMzAxXCI6IFwiTW92ZWQgUGVybWFuZW50bHlcIixcbiAgICAgIFwiMzAyXCI6IFwiRm91bmRcIixcbiAgICAgIFwiMzAzXCI6IFwiU2VlIE90aGVyXCIsXG4gICAgICBcIjMwNFwiOiBcIk5vdCBNb2RpZmllZFwiLFxuICAgICAgXCIzMDVcIjogXCJVc2UgUHJveHlcIixcbiAgICAgIFwiMzA3XCI6IFwiVGVtcG9yYXJ5IFJlZGlyZWN0XCIsXG4gICAgICBcIjMwOFwiOiBcIlBlcm1hbmVudCBSZWRpcmVjdFwiLFxuICAgICAgXCI0MDBcIjogXCJCYWQgUmVxdWVzdFwiLFxuICAgICAgXCI0MDFcIjogXCJVbmF1dGhvcml6ZWRcIixcbiAgICAgIFwiNDAyXCI6IFwiUGF5bWVudCBSZXF1aXJlZFwiLFxuICAgICAgXCI0MDNcIjogXCJGb3JiaWRkZW5cIixcbiAgICAgIFwiNDA0XCI6IFwiTm90IEZvdW5kXCIsXG4gICAgICBcIjQwNVwiOiBcIk1ldGhvZCBOb3QgQWxsb3dlZFwiLFxuICAgICAgXCI0MDZcIjogXCJOb3QgQWNjZXB0YWJsZVwiLFxuICAgICAgXCI0MDdcIjogXCJQcm94eSBBdXRoZW50aWNhdGlvbiBSZXF1aXJlZFwiLFxuICAgICAgXCI0MDhcIjogXCJSZXF1ZXN0IFRpbWVvdXRcIixcbiAgICAgIFwiNDA5XCI6IFwiQ29uZmxpY3RcIixcbiAgICAgIFwiNDEwXCI6IFwiR29uZVwiLFxuICAgICAgXCI0MTFcIjogXCJMZW5ndGggUmVxdWlyZWRcIixcbiAgICAgIFwiNDEyXCI6IFwiUHJlY29uZGl0aW9uIEZhaWxlZFwiLFxuICAgICAgXCI0MTNcIjogXCJQYXlsb2FkIFRvbyBMYXJnZVwiLFxuICAgICAgXCI0MTRcIjogXCJVUkkgVG9vIExvbmdcIixcbiAgICAgIFwiNDE1XCI6IFwiVW5zdXBwb3J0ZWQgTWVkaWEgVHlwZVwiLFxuICAgICAgXCI0MTZcIjogXCJSYW5nZSBOb3QgU2F0aXNmaWFibGVcIixcbiAgICAgIFwiNDE3XCI6IFwiRXhwZWN0YXRpb24gRmFpbGVkXCIsXG4gICAgICBcIjQxOFwiOiBcIkknbSBhIFRlYXBvdFwiLFxuICAgICAgXCI0MjFcIjogXCJNaXNkaXJlY3RlZCBSZXF1ZXN0XCIsXG4gICAgICBcIjQyMlwiOiBcIlVucHJvY2Vzc2FibGUgRW50aXR5XCIsXG4gICAgICBcIjQyM1wiOiBcIkxvY2tlZFwiLFxuICAgICAgXCI0MjRcIjogXCJGYWlsZWQgRGVwZW5kZW5jeVwiLFxuICAgICAgXCI0MjVcIjogXCJUb28gRWFybHlcIixcbiAgICAgIFwiNDI2XCI6IFwiVXBncmFkZSBSZXF1aXJlZFwiLFxuICAgICAgXCI0MjhcIjogXCJQcmVjb25kaXRpb24gUmVxdWlyZWRcIixcbiAgICAgIFwiNDI5XCI6IFwiVG9vIE1hbnkgUmVxdWVzdHNcIixcbiAgICAgIFwiNDMxXCI6IFwiUmVxdWVzdCBIZWFkZXIgRmllbGRzIFRvbyBMYXJnZVwiLFxuICAgICAgXCI0NTFcIjogXCJVbmF2YWlsYWJsZSBGb3IgTGVnYWwgUmVhc29uc1wiLFxuICAgICAgXCI1MDBcIjogXCJJbnRlcm5hbCBTZXJ2ZXIgRXJyb3JcIixcbiAgICAgIFwiNTAxXCI6IFwiTm90IEltcGxlbWVudGVkXCIsXG4gICAgICBcIjUwMlwiOiBcIkJhZCBHYXRld2F5XCIsXG4gICAgICBcIjUwM1wiOiBcIlNlcnZpY2UgVW5hdmFpbGFibGVcIixcbiAgICAgIFwiNTA0XCI6IFwiR2F0ZXdheSBUaW1lb3V0XCIsXG4gICAgICBcIjUwNVwiOiBcIkhUVFAgVmVyc2lvbiBOb3QgU3VwcG9ydGVkXCIsXG4gICAgICBcIjUwNlwiOiBcIlZhcmlhbnQgQWxzbyBOZWdvdGlhdGVzXCIsXG4gICAgICBcIjUwN1wiOiBcIkluc3VmZmljaWVudCBTdG9yYWdlXCIsXG4gICAgICBcIjUwOFwiOiBcIkxvb3AgRGV0ZWN0ZWRcIixcbiAgICAgIFwiNTA5XCI6IFwiQmFuZHdpZHRoIExpbWl0IEV4Y2VlZGVkXCIsXG4gICAgICBcIjUxMFwiOiBcIk5vdCBFeHRlbmRlZFwiLFxuICAgICAgXCI1MTFcIjogXCJOZXR3b3JrIEF1dGhlbnRpY2F0aW9uIFJlcXVpcmVkXCJcbiAgICB9O1xuICB9XG59KTtcbnZhciByZXF1aXJlX3N0YXR1c2VzID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3N0YXR1c2VzL2luZGV4LmpzXCIoZXhwb3J0cywgbW9kdWxlKSB7XG4gICAgXCJ1c2Ugc3RyaWN0XCI7XG4gICAgdmFyIGNvZGVzID0gcmVxdWlyZV9jb2RlcygpO1xuICAgIG1vZHVsZS5leHBvcnRzID0gc3RhdHVzMjtcbiAgICBzdGF0dXMyLm1lc3NhZ2UgPSBjb2RlcztcbiAgICBzdGF0dXMyLmNvZGUgPSBjcmVhdGVNZXNzYWdlVG9TdGF0dXNDb2RlTWFwKGNvZGVzKTtcbiAgICBzdGF0dXMyLmNvZGVzID0gY3JlYXRlU3RhdHVzQ29kZUxpc3QoY29kZXMpO1xuICAgIHN0YXR1czIucmVkaXJlY3QgPSB7XG4gICAgICAzMDA6IHRydWUsXG4gICAgICAzMDE6IHRydWUsXG4gICAgICAzMDI6IHRydWUsXG4gICAgICAzMDM6IHRydWUsXG4gICAgICAzMDU6IHRydWUsXG4gICAgICAzMDc6IHRydWUsXG4gICAgICAzMDg6IHRydWVcbiAgICB9O1xuICAgIHN0YXR1czIuZW1wdHkgPSB7XG4gICAgICAyMDQ6IHRydWUsXG4gICAgICAyMDU6IHRydWUsXG4gICAgICAzMDQ6IHRydWVcbiAgICB9O1xuICAgIHN0YXR1czIucmV0cnkgPSB7XG4gICAgICA1MDI6IHRydWUsXG4gICAgICA1MDM6IHRydWUsXG4gICAgICA1MDQ6IHRydWVcbiAgICB9O1xuICAgIGZ1bmN0aW9uIGNyZWF0ZU1lc3NhZ2VUb1N0YXR1c0NvZGVNYXAoY29kZXMyKSB7XG4gICAgICB2YXIgbWFwID0ge307XG4gICAgICBPYmplY3Qua2V5cyhjb2RlczIpLmZvckVhY2goZnVuY3Rpb24gZm9yRWFjaENvZGUoY29kZSkge1xuICAgICAgICB2YXIgbWVzc2FnZTMgPSBjb2RlczJbY29kZV07XG4gICAgICAgIHZhciBzdGF0dXMzID0gTnVtYmVyKGNvZGUpO1xuICAgICAgICBtYXBbbWVzc2FnZTMudG9Mb3dlckNhc2UoKV0gPSBzdGF0dXMzO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gbWFwO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjcmVhdGVTdGF0dXNDb2RlTGlzdChjb2RlczIpIHtcbiAgICAgIHJldHVybiBPYmplY3Qua2V5cyhjb2RlczIpLm1hcChmdW5jdGlvbiBtYXBDb2RlKGNvZGUpIHtcbiAgICAgICAgcmV0dXJuIE51bWJlcihjb2RlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRTdGF0dXNDb2RlKG1lc3NhZ2UzKSB7XG4gICAgICB2YXIgbXNnID0gbWVzc2FnZTMudG9Mb3dlckNhc2UoKTtcbiAgICAgIGlmICghT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHN0YXR1czIuY29kZSwgbXNnKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgc3RhdHVzIG1lc3NhZ2U6IFwiJyArIG1lc3NhZ2UzICsgJ1wiJyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gc3RhdHVzMi5jb2RlW21zZ107XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldFN0YXR1c01lc3NhZ2UoY29kZSkge1xuICAgICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc3RhdHVzMi5tZXNzYWdlLCBjb2RlKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJpbnZhbGlkIHN0YXR1cyBjb2RlOiBcIiArIGNvZGUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0YXR1czIubWVzc2FnZVtjb2RlXTtcbiAgICB9XG4gICAgZnVuY3Rpb24gc3RhdHVzMihjb2RlKSB7XG4gICAgICBpZiAodHlwZW9mIGNvZGUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgcmV0dXJuIGdldFN0YXR1c01lc3NhZ2UoY29kZSk7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIGNvZGUgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcImNvZGUgbXVzdCBiZSBhIG51bWJlciBvciBzdHJpbmdcIik7XG4gICAgICB9XG4gICAgICB2YXIgbiA9IHBhcnNlSW50KGNvZGUsIDEwKTtcbiAgICAgIGlmICghaXNOYU4obikpIHtcbiAgICAgICAgcmV0dXJuIGdldFN0YXR1c01lc3NhZ2Uobik7XG4gICAgICB9XG4gICAgICByZXR1cm4gZ2V0U3RhdHVzQ29kZShjb2RlKTtcbiAgICB9XG4gIH1cbn0pO1xudmFyIGltcG9ydF9zdGF0dXNlcyA9IF9fdG9FU00ocmVxdWlyZV9zdGF0dXNlcygpLCAxKTtcbnZhciBzb3VyY2VfZGVmYXVsdCA9IGltcG9ydF9zdGF0dXNlcy5kZWZhdWx0O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvbG9nZ2luZy9zZXJpYWxpemVSZXNwb25zZS5tanNcbnZhciB7IG1lc3NhZ2UgfSA9IHNvdXJjZV9kZWZhdWx0O1xuYXN5bmMgZnVuY3Rpb24gc2VyaWFsaXplUmVzcG9uc2UocmVzcG9uc2UpIHtcbiAgY29uc3QgcmVzcG9uc2VDbG9uZSA9IHJlc3BvbnNlLmNsb25lKCk7XG4gIGNvbnN0IHJlc3BvbnNlVGV4dCA9IGF3YWl0IHJlc3BvbnNlQ2xvbmUudGV4dCgpO1xuICBjb25zdCByZXNwb25zZVN0YXR1cyA9IHJlc3BvbnNlQ2xvbmUuc3RhdHVzIHx8IDIwMDtcbiAgY29uc3QgcmVzcG9uc2VTdGF0dXNUZXh0ID0gcmVzcG9uc2VDbG9uZS5zdGF0dXNUZXh0IHx8IG1lc3NhZ2VbcmVzcG9uc2VTdGF0dXNdIHx8IFwiT0tcIjtcbiAgcmV0dXJuIHtcbiAgICBzdGF0dXM6IHJlc3BvbnNlU3RhdHVzLFxuICAgIHN0YXR1c1RleHQ6IHJlc3BvbnNlU3RhdHVzVGV4dCxcbiAgICBoZWFkZXJzOiBPYmplY3QuZnJvbUVudHJpZXMocmVzcG9uc2VDbG9uZS5oZWFkZXJzLmVudHJpZXMoKSksXG4gICAgYm9keTogcmVzcG9uc2VUZXh0XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9wYXRoLXRvLXJlZ2V4cEA2LjIuMS9ub2RlX21vZHVsZXMvcGF0aC10by1yZWdleHAvZGlzdC5lczIwMTUvaW5kZXguanNcbmZ1bmN0aW9uIGxleGVyKHN0cikge1xuICB2YXIgdG9rZW5zID0gW107XG4gIHZhciBpID0gMDtcbiAgd2hpbGUgKGkgPCBzdHIubGVuZ3RoKSB7XG4gICAgdmFyIGNoYXIgPSBzdHJbaV07XG4gICAgaWYgKGNoYXIgPT09IFwiKlwiIHx8IGNoYXIgPT09IFwiK1wiIHx8IGNoYXIgPT09IFwiP1wiKSB7XG4gICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiTU9ESUZJRVJcIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY2hhciA9PT0gXCJcXFxcXCIpIHtcbiAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJFU0NBUEVEX0NIQVJcIiwgaW5kZXg6IGkrKywgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjaGFyID09PSBcIntcIikge1xuICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIk9QRU5cIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY2hhciA9PT0gXCJ9XCIpIHtcbiAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJDTE9TRVwiLCBpbmRleDogaSwgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjaGFyID09PSBcIjpcIikge1xuICAgICAgdmFyIG5hbWUgPSBcIlwiO1xuICAgICAgdmFyIGogPSBpICsgMTtcbiAgICAgIHdoaWxlIChqIDwgc3RyLmxlbmd0aCkge1xuICAgICAgICB2YXIgY29kZSA9IHN0ci5jaGFyQ29kZUF0KGopO1xuICAgICAgICBpZiAoXG4gICAgICAgICAgLy8gYDAtOWBcbiAgICAgICAgICBjb2RlID49IDQ4ICYmIGNvZGUgPD0gNTcgfHwgLy8gYEEtWmBcbiAgICAgICAgICBjb2RlID49IDY1ICYmIGNvZGUgPD0gOTAgfHwgLy8gYGEtemBcbiAgICAgICAgICBjb2RlID49IDk3ICYmIGNvZGUgPD0gMTIyIHx8IC8vIGBfYFxuICAgICAgICAgIGNvZGUgPT09IDk1XG4gICAgICAgICkge1xuICAgICAgICAgIG5hbWUgKz0gc3RyW2orK107XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBpZiAoIW5hbWUpXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJNaXNzaW5nIHBhcmFtZXRlciBuYW1lIGF0IFwiLmNvbmNhdChpKSk7XG4gICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiTkFNRVwiLCBpbmRleDogaSwgdmFsdWU6IG5hbWUgfSk7XG4gICAgICBpID0gajtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY2hhciA9PT0gXCIoXCIpIHtcbiAgICAgIHZhciBjb3VudCA9IDE7XG4gICAgICB2YXIgcGF0dGVybiA9IFwiXCI7XG4gICAgICB2YXIgaiA9IGkgKyAxO1xuICAgICAgaWYgKHN0cltqXSA9PT0gXCI/XCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignUGF0dGVybiBjYW5ub3Qgc3RhcnQgd2l0aCBcIj9cIiBhdCAnLmNvbmNhdChqKSk7XG4gICAgICB9XG4gICAgICB3aGlsZSAoaiA8IHN0ci5sZW5ndGgpIHtcbiAgICAgICAgaWYgKHN0cltqXSA9PT0gXCJcXFxcXCIpIHtcbiAgICAgICAgICBwYXR0ZXJuICs9IHN0cltqKytdICsgc3RyW2orK107XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0cltqXSA9PT0gXCIpXCIpIHtcbiAgICAgICAgICBjb3VudC0tO1xuICAgICAgICAgIGlmIChjb3VudCA9PT0gMCkge1xuICAgICAgICAgICAgaisrO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHN0cltqXSA9PT0gXCIoXCIpIHtcbiAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgIGlmIChzdHJbaiArIDFdICE9PSBcIj9cIikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhcHR1cmluZyBncm91cHMgYXJlIG5vdCBhbGxvd2VkIGF0IFwiLmNvbmNhdChqKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHBhdHRlcm4gKz0gc3RyW2orK107XG4gICAgICB9XG4gICAgICBpZiAoY291bnQpXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJVbmJhbGFuY2VkIHBhdHRlcm4gYXQgXCIuY29uY2F0KGkpKTtcbiAgICAgIGlmICghcGF0dGVybilcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk1pc3NpbmcgcGF0dGVybiBhdCBcIi5jb25jYXQoaSkpO1xuICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIlBBVFRFUk5cIiwgaW5kZXg6IGksIHZhbHVlOiBwYXR0ZXJuIH0pO1xuICAgICAgaSA9IGo7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIkNIQVJcIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgfVxuICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiRU5EXCIsIGluZGV4OiBpLCB2YWx1ZTogXCJcIiB9KTtcbiAgcmV0dXJuIHRva2Vucztcbn1cbmZ1bmN0aW9uIHBhcnNlKHN0ciwgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHZhciB0b2tlbnMgPSBsZXhlcihzdHIpO1xuICB2YXIgX2EyID0gb3B0aW9ucy5wcmVmaXhlcywgcHJlZml4ZXMgPSBfYTIgPT09IHZvaWQgMCA/IFwiLi9cIiA6IF9hMjtcbiAgdmFyIGRlZmF1bHRQYXR0ZXJuID0gXCJbXlwiLmNvbmNhdChlc2NhcGVTdHJpbmcob3B0aW9ucy5kZWxpbWl0ZXIgfHwgXCIvIz9cIiksIFwiXSs/XCIpO1xuICB2YXIgcmVzdWx0ID0gW107XG4gIHZhciBrZXkgPSAwO1xuICB2YXIgaSA9IDA7XG4gIHZhciBwYXRoID0gXCJcIjtcbiAgdmFyIHRyeUNvbnN1bWUgPSBmdW5jdGlvbih0eXBlKSB7XG4gICAgaWYgKGkgPCB0b2tlbnMubGVuZ3RoICYmIHRva2Vuc1tpXS50eXBlID09PSB0eXBlKVxuICAgICAgcmV0dXJuIHRva2Vuc1tpKytdLnZhbHVlO1xuICB9O1xuICB2YXIgbXVzdENvbnN1bWUgPSBmdW5jdGlvbih0eXBlKSB7XG4gICAgdmFyIHZhbHVlMiA9IHRyeUNvbnN1bWUodHlwZSk7XG4gICAgaWYgKHZhbHVlMiAhPT0gdm9pZCAwKVxuICAgICAgcmV0dXJuIHZhbHVlMjtcbiAgICB2YXIgX2EzID0gdG9rZW5zW2ldLCBuZXh0VHlwZSA9IF9hMy50eXBlLCBpbmRleCA9IF9hMy5pbmRleDtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiVW5leHBlY3RlZCBcIi5jb25jYXQobmV4dFR5cGUsIFwiIGF0IFwiKS5jb25jYXQoaW5kZXgsIFwiLCBleHBlY3RlZCBcIikuY29uY2F0KHR5cGUpKTtcbiAgfTtcbiAgdmFyIGNvbnN1bWVUZXh0ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIHJlc3VsdDIgPSBcIlwiO1xuICAgIHZhciB2YWx1ZTI7XG4gICAgd2hpbGUgKHZhbHVlMiA9IHRyeUNvbnN1bWUoXCJDSEFSXCIpIHx8IHRyeUNvbnN1bWUoXCJFU0NBUEVEX0NIQVJcIikpIHtcbiAgICAgIHJlc3VsdDIgKz0gdmFsdWUyO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0MjtcbiAgfTtcbiAgd2hpbGUgKGkgPCB0b2tlbnMubGVuZ3RoKSB7XG4gICAgdmFyIGNoYXIgPSB0cnlDb25zdW1lKFwiQ0hBUlwiKTtcbiAgICB2YXIgbmFtZSA9IHRyeUNvbnN1bWUoXCJOQU1FXCIpO1xuICAgIHZhciBwYXR0ZXJuID0gdHJ5Q29uc3VtZShcIlBBVFRFUk5cIik7XG4gICAgaWYgKG5hbWUgfHwgcGF0dGVybikge1xuICAgICAgdmFyIHByZWZpeCA9IGNoYXIgfHwgXCJcIjtcbiAgICAgIGlmIChwcmVmaXhlcy5pbmRleE9mKHByZWZpeCkgPT09IC0xKSB7XG4gICAgICAgIHBhdGggKz0gcHJlZml4O1xuICAgICAgICBwcmVmaXggPSBcIlwiO1xuICAgICAgfVxuICAgICAgaWYgKHBhdGgpIHtcbiAgICAgICAgcmVzdWx0LnB1c2gocGF0aCk7XG4gICAgICAgIHBhdGggPSBcIlwiO1xuICAgICAgfVxuICAgICAgcmVzdWx0LnB1c2goe1xuICAgICAgICBuYW1lOiBuYW1lIHx8IGtleSsrLFxuICAgICAgICBwcmVmaXgsXG4gICAgICAgIHN1ZmZpeDogXCJcIixcbiAgICAgICAgcGF0dGVybjogcGF0dGVybiB8fCBkZWZhdWx0UGF0dGVybixcbiAgICAgICAgbW9kaWZpZXI6IHRyeUNvbnN1bWUoXCJNT0RJRklFUlwiKSB8fCBcIlwiXG4gICAgICB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICB2YXIgdmFsdWUgPSBjaGFyIHx8IHRyeUNvbnN1bWUoXCJFU0NBUEVEX0NIQVJcIik7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICBwYXRoICs9IHZhbHVlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChwYXRoKSB7XG4gICAgICByZXN1bHQucHVzaChwYXRoKTtcbiAgICAgIHBhdGggPSBcIlwiO1xuICAgIH1cbiAgICB2YXIgb3BlbiA9IHRyeUNvbnN1bWUoXCJPUEVOXCIpO1xuICAgIGlmIChvcGVuKSB7XG4gICAgICB2YXIgcHJlZml4ID0gY29uc3VtZVRleHQoKTtcbiAgICAgIHZhciBuYW1lXzEgPSB0cnlDb25zdW1lKFwiTkFNRVwiKSB8fCBcIlwiO1xuICAgICAgdmFyIHBhdHRlcm5fMSA9IHRyeUNvbnN1bWUoXCJQQVRURVJOXCIpIHx8IFwiXCI7XG4gICAgICB2YXIgc3VmZml4ID0gY29uc3VtZVRleHQoKTtcbiAgICAgIG11c3RDb25zdW1lKFwiQ0xPU0VcIik7XG4gICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgIG5hbWU6IG5hbWVfMSB8fCAocGF0dGVybl8xID8ga2V5KysgOiBcIlwiKSxcbiAgICAgICAgcGF0dGVybjogbmFtZV8xICYmICFwYXR0ZXJuXzEgPyBkZWZhdWx0UGF0dGVybiA6IHBhdHRlcm5fMSxcbiAgICAgICAgcHJlZml4LFxuICAgICAgICBzdWZmaXgsXG4gICAgICAgIG1vZGlmaWVyOiB0cnlDb25zdW1lKFwiTU9ESUZJRVJcIikgfHwgXCJcIlxuICAgICAgfSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgbXVzdENvbnN1bWUoXCJFTkRcIik7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIG1hdGNoKHN0ciwgb3B0aW9ucykge1xuICB2YXIga2V5cyA9IFtdO1xuICB2YXIgcmUgPSBwYXRoVG9SZWdleHAoc3RyLCBrZXlzLCBvcHRpb25zKTtcbiAgcmV0dXJuIHJlZ2V4cFRvRnVuY3Rpb24ocmUsIGtleXMsIG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gcmVnZXhwVG9GdW5jdGlvbihyZSwga2V5cywgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHZhciBfYTIgPSBvcHRpb25zLmRlY29kZSwgZGVjb2RlID0gX2EyID09PSB2b2lkIDAgPyBmdW5jdGlvbih4KSB7XG4gICAgcmV0dXJuIHg7XG4gIH0gOiBfYTI7XG4gIHJldHVybiBmdW5jdGlvbihwYXRobmFtZSkge1xuICAgIHZhciBtID0gcmUuZXhlYyhwYXRobmFtZSk7XG4gICAgaWYgKCFtKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIHZhciBwYXRoID0gbVswXSwgaW5kZXggPSBtLmluZGV4O1xuICAgIHZhciBwYXJhbXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uKGkyKSB7XG4gICAgICBpZiAobVtpMl0gPT09IHZvaWQgMClcbiAgICAgICAgcmV0dXJuIFwiY29udGludWVcIjtcbiAgICAgIHZhciBrZXkgPSBrZXlzW2kyIC0gMV07XG4gICAgICBpZiAoa2V5Lm1vZGlmaWVyID09PSBcIipcIiB8fCBrZXkubW9kaWZpZXIgPT09IFwiK1wiKSB7XG4gICAgICAgIHBhcmFtc1trZXkubmFtZV0gPSBtW2kyXS5zcGxpdChrZXkucHJlZml4ICsga2V5LnN1ZmZpeCkubWFwKGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgICAgICAgcmV0dXJuIGRlY29kZSh2YWx1ZSwga2V5KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJhbXNba2V5Lm5hbWVdID0gZGVjb2RlKG1baTJdLCBrZXkpO1xuICAgICAgfVxuICAgIH07XG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPCBtLmxlbmd0aDsgaSsrKSB7XG4gICAgICBfbG9vcF8xKGkpO1xuICAgIH1cbiAgICByZXR1cm4geyBwYXRoLCBpbmRleCwgcGFyYW1zIH07XG4gIH07XG59XG5mdW5jdGlvbiBlc2NhcGVTdHJpbmcoc3RyKSB7XG4gIHJldHVybiBzdHIucmVwbGFjZSgvKFsuKyo/PV4hOiR7fSgpW1xcXXwvXFxcXF0pL2csIFwiXFxcXCQxXCIpO1xufVxuZnVuY3Rpb24gZmxhZ3Mob3B0aW9ucykge1xuICByZXR1cm4gb3B0aW9ucyAmJiBvcHRpb25zLnNlbnNpdGl2ZSA/IFwiXCIgOiBcImlcIjtcbn1cbmZ1bmN0aW9uIHJlZ2V4cFRvUmVnZXhwKHBhdGgsIGtleXMpIHtcbiAgaWYgKCFrZXlzKVxuICAgIHJldHVybiBwYXRoO1xuICB2YXIgZ3JvdXBzUmVnZXggPSAvXFwoKD86XFw/PCguKj8pPik/KD8hXFw/KS9nO1xuICB2YXIgaW5kZXggPSAwO1xuICB2YXIgZXhlY1Jlc3VsdCA9IGdyb3Vwc1JlZ2V4LmV4ZWMocGF0aC5zb3VyY2UpO1xuICB3aGlsZSAoZXhlY1Jlc3VsdCkge1xuICAgIGtleXMucHVzaCh7XG4gICAgICAvLyBVc2UgcGFyZW50aGVzaXplZCBzdWJzdHJpbmcgbWF0Y2ggaWYgYXZhaWxhYmxlLCBpbmRleCBvdGhlcndpc2VcbiAgICAgIG5hbWU6IGV4ZWNSZXN1bHRbMV0gfHwgaW5kZXgrKyxcbiAgICAgIHByZWZpeDogXCJcIixcbiAgICAgIHN1ZmZpeDogXCJcIixcbiAgICAgIG1vZGlmaWVyOiBcIlwiLFxuICAgICAgcGF0dGVybjogXCJcIlxuICAgIH0pO1xuICAgIGV4ZWNSZXN1bHQgPSBncm91cHNSZWdleC5leGVjKHBhdGguc291cmNlKTtcbiAgfVxuICByZXR1cm4gcGF0aDtcbn1cbmZ1bmN0aW9uIGFycmF5VG9SZWdleHAocGF0aHMsIGtleXMsIG9wdGlvbnMpIHtcbiAgdmFyIHBhcnRzID0gcGF0aHMubWFwKGZ1bmN0aW9uKHBhdGgpIHtcbiAgICByZXR1cm4gcGF0aFRvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpLnNvdXJjZTtcbiAgfSk7XG4gIHJldHVybiBuZXcgUmVnRXhwKFwiKD86XCIuY29uY2F0KHBhcnRzLmpvaW4oXCJ8XCIpLCBcIilcIiksIGZsYWdzKG9wdGlvbnMpKTtcbn1cbmZ1bmN0aW9uIHN0cmluZ1RvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHRva2Vuc1RvUmVnZXhwKHBhcnNlKHBhdGgsIG9wdGlvbnMpLCBrZXlzLCBvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIHRva2Vuc1RvUmVnZXhwKHRva2Vucywga2V5cywgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHZhciBfYTIgPSBvcHRpb25zLnN0cmljdCwgc3RyaWN0ID0gX2EyID09PSB2b2lkIDAgPyBmYWxzZSA6IF9hMiwgX2IyID0gb3B0aW9ucy5zdGFydCwgc3RhcnQgPSBfYjIgPT09IHZvaWQgMCA/IHRydWUgOiBfYjIsIF9jMiA9IG9wdGlvbnMuZW5kLCBlbmQgPSBfYzIgPT09IHZvaWQgMCA/IHRydWUgOiBfYzIsIF9kID0gb3B0aW9ucy5lbmNvZGUsIGVuY29kZSA9IF9kID09PSB2b2lkIDAgPyBmdW5jdGlvbih4KSB7XG4gICAgcmV0dXJuIHg7XG4gIH0gOiBfZCwgX2UgPSBvcHRpb25zLmRlbGltaXRlciwgZGVsaW1pdGVyID0gX2UgPT09IHZvaWQgMCA/IFwiLyM/XCIgOiBfZSwgX2YgPSBvcHRpb25zLmVuZHNXaXRoLCBlbmRzV2l0aCA9IF9mID09PSB2b2lkIDAgPyBcIlwiIDogX2Y7XG4gIHZhciBlbmRzV2l0aFJlID0gXCJbXCIuY29uY2F0KGVzY2FwZVN0cmluZyhlbmRzV2l0aCksIFwiXXwkXCIpO1xuICB2YXIgZGVsaW1pdGVyUmUgPSBcIltcIi5jb25jYXQoZXNjYXBlU3RyaW5nKGRlbGltaXRlciksIFwiXVwiKTtcbiAgdmFyIHJvdXRlID0gc3RhcnQgPyBcIl5cIiA6IFwiXCI7XG4gIGZvciAodmFyIF9pID0gMCwgdG9rZW5zXzEgPSB0b2tlbnM7IF9pIDwgdG9rZW5zXzEubGVuZ3RoOyBfaSsrKSB7XG4gICAgdmFyIHRva2VuID0gdG9rZW5zXzFbX2ldO1xuICAgIGlmICh0eXBlb2YgdG9rZW4gPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJvdXRlICs9IGVzY2FwZVN0cmluZyhlbmNvZGUodG9rZW4pKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIHByZWZpeCA9IGVzY2FwZVN0cmluZyhlbmNvZGUodG9rZW4ucHJlZml4KSk7XG4gICAgICB2YXIgc3VmZml4ID0gZXNjYXBlU3RyaW5nKGVuY29kZSh0b2tlbi5zdWZmaXgpKTtcbiAgICAgIGlmICh0b2tlbi5wYXR0ZXJuKSB7XG4gICAgICAgIGlmIChrZXlzKVxuICAgICAgICAgIGtleXMucHVzaCh0b2tlbik7XG4gICAgICAgIGlmIChwcmVmaXggfHwgc3VmZml4KSB7XG4gICAgICAgICAgaWYgKHRva2VuLm1vZGlmaWVyID09PSBcIitcIiB8fCB0b2tlbi5tb2RpZmllciA9PT0gXCIqXCIpIHtcbiAgICAgICAgICAgIHZhciBtb2QgPSB0b2tlbi5tb2RpZmllciA9PT0gXCIqXCIgPyBcIj9cIiA6IFwiXCI7XG4gICAgICAgICAgICByb3V0ZSArPSBcIig/OlwiLmNvbmNhdChwcmVmaXgsIFwiKCg/OlwiKS5jb25jYXQodG9rZW4ucGF0dGVybiwgXCIpKD86XCIpLmNvbmNhdChzdWZmaXgpLmNvbmNhdChwcmVmaXgsIFwiKD86XCIpLmNvbmNhdCh0b2tlbi5wYXR0ZXJuLCBcIikpKilcIikuY29uY2F0KHN1ZmZpeCwgXCIpXCIpLmNvbmNhdChtb2QpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByb3V0ZSArPSBcIig/OlwiLmNvbmNhdChwcmVmaXgsIFwiKFwiKS5jb25jYXQodG9rZW4ucGF0dGVybiwgXCIpXCIpLmNvbmNhdChzdWZmaXgsIFwiKVwiKS5jb25jYXQodG9rZW4ubW9kaWZpZXIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAodG9rZW4ubW9kaWZpZXIgPT09IFwiK1wiIHx8IHRva2VuLm1vZGlmaWVyID09PSBcIipcIikge1xuICAgICAgICAgICAgcm91dGUgKz0gXCIoKD86XCIuY29uY2F0KHRva2VuLnBhdHRlcm4sIFwiKVwiKS5jb25jYXQodG9rZW4ubW9kaWZpZXIsIFwiKVwiKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcm91dGUgKz0gXCIoXCIuY29uY2F0KHRva2VuLnBhdHRlcm4sIFwiKVwiKS5jb25jYXQodG9rZW4ubW9kaWZpZXIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcm91dGUgKz0gXCIoPzpcIi5jb25jYXQocHJlZml4KS5jb25jYXQoc3VmZml4LCBcIilcIikuY29uY2F0KHRva2VuLm1vZGlmaWVyKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGVuZCkge1xuICAgIGlmICghc3RyaWN0KVxuICAgICAgcm91dGUgKz0gXCJcIi5jb25jYXQoZGVsaW1pdGVyUmUsIFwiP1wiKTtcbiAgICByb3V0ZSArPSAhb3B0aW9ucy5lbmRzV2l0aCA/IFwiJFwiIDogXCIoPz1cIi5jb25jYXQoZW5kc1dpdGhSZSwgXCIpXCIpO1xuICB9IGVsc2Uge1xuICAgIHZhciBlbmRUb2tlbiA9IHRva2Vuc1t0b2tlbnMubGVuZ3RoIC0gMV07XG4gICAgdmFyIGlzRW5kRGVsaW1pdGVkID0gdHlwZW9mIGVuZFRva2VuID09PSBcInN0cmluZ1wiID8gZGVsaW1pdGVyUmUuaW5kZXhPZihlbmRUb2tlbltlbmRUb2tlbi5sZW5ndGggLSAxXSkgPiAtMSA6IGVuZFRva2VuID09PSB2b2lkIDA7XG4gICAgaWYgKCFzdHJpY3QpIHtcbiAgICAgIHJvdXRlICs9IFwiKD86XCIuY29uY2F0KGRlbGltaXRlclJlLCBcIig/PVwiKS5jb25jYXQoZW5kc1dpdGhSZSwgXCIpKT9cIik7XG4gICAgfVxuICAgIGlmICghaXNFbmREZWxpbWl0ZWQpIHtcbiAgICAgIHJvdXRlICs9IFwiKD89XCIuY29uY2F0KGRlbGltaXRlclJlLCBcInxcIikuY29uY2F0KGVuZHNXaXRoUmUsIFwiKVwiKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG5ldyBSZWdFeHAocm91dGUsIGZsYWdzKG9wdGlvbnMpKTtcbn1cbmZ1bmN0aW9uIHBhdGhUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKSB7XG4gIGlmIChwYXRoIGluc3RhbmNlb2YgUmVnRXhwKVxuICAgIHJldHVybiByZWdleHBUb1JlZ2V4cChwYXRoLCBrZXlzKTtcbiAgaWYgKEFycmF5LmlzQXJyYXkocGF0aCkpXG4gICAgcmV0dXJuIGFycmF5VG9SZWdleHAocGF0aCwga2V5cywgb3B0aW9ucyk7XG4gIHJldHVybiBzdHJpbmdUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC4yNi4xNS9ub2RlX21vZHVsZXMvQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci9jaHVuay1VSlpPSlNNUC5tanNcbnZhciBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9AbXN3anMraW50ZXJjZXB0b3JzQDAuMjYuMTUvbm9kZV9tb2R1bGVzL0Btc3dqcy9pbnRlcmNlcHRvcnMvbGliL2Jyb3dzZXIvY2h1bmstSEFHVzIyQU4ubWpzXG52YXIgSVNfUEFUQ0hFRF9NT0RVTEUgPSBTeW1ib2woXCJpc1BhdGNoZWRNb2R1bGVcIik7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9pcy1ub2RlLXByb2Nlc3NAMS4yLjAvbm9kZV9tb2R1bGVzL2lzLW5vZGUtcHJvY2Vzcy9saWIvaW5kZXgubWpzXG5mdW5jdGlvbiBpc05vZGVQcm9jZXNzKCkge1xuICBpZiAodHlwZW9mIG5hdmlnYXRvciAhPT0gXCJ1bmRlZmluZWRcIiAmJiBuYXZpZ2F0b3IucHJvZHVjdCA9PT0gXCJSZWFjdE5hdGl2ZVwiKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgY29uc3QgdHlwZSA9IHByb2Nlc3MudHlwZTtcbiAgICBpZiAodHlwZSA9PT0gXCJyZW5kZXJlclwiIHx8IHR5cGUgPT09IFwid29ya2VyXCIpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuICEhKHByb2Nlc3MudmVyc2lvbnMgJiYgcHJvY2Vzcy52ZXJzaW9ucy5ub2RlKTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9Ab3Blbi1kcmFmdCtsb2dnZXJAMC4zLjAvbm9kZV9tb2R1bGVzL0BvcGVuLWRyYWZ0L2xvZ2dlci9saWIvaW5kZXgubWpzXG52YXIgX19kZWZQcm9wMiA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX2V4cG9ydCA9ICh0YXJnZXQsIGFsbCkgPT4ge1xuICBmb3IgKHZhciBuYW1lIGluIGFsbClcbiAgICBfX2RlZlByb3AyKHRhcmdldCwgbmFtZSwgeyBnZXQ6IGFsbFtuYW1lXSwgZW51bWVyYWJsZTogdHJ1ZSB9KTtcbn07XG52YXIgY29sb3JzX2V4cG9ydHMgPSB7fTtcbl9fZXhwb3J0KGNvbG9yc19leHBvcnRzLCB7XG4gIGJsdWU6ICgpID0+IGJsdWUsXG4gIGdyYXk6ICgpID0+IGdyYXksXG4gIGdyZWVuOiAoKSA9PiBncmVlbixcbiAgcmVkOiAoKSA9PiByZWQsXG4gIHllbGxvdzogKCkgPT4geWVsbG93XG59KTtcbmZ1bmN0aW9uIHllbGxvdyh0ZXh0KSB7XG4gIHJldHVybiBgXFx4MUJbMzNtJHt0ZXh0fVxceDFCWzBtYDtcbn1cbmZ1bmN0aW9uIGJsdWUodGV4dCkge1xuICByZXR1cm4gYFxceDFCWzM0bSR7dGV4dH1cXHgxQlswbWA7XG59XG5mdW5jdGlvbiBncmF5KHRleHQpIHtcbiAgcmV0dXJuIGBcXHgxQls5MG0ke3RleHR9XFx4MUJbMG1gO1xufVxuZnVuY3Rpb24gcmVkKHRleHQpIHtcbiAgcmV0dXJuIGBcXHgxQlszMW0ke3RleHR9XFx4MUJbMG1gO1xufVxuZnVuY3Rpb24gZ3JlZW4odGV4dCkge1xuICByZXR1cm4gYFxceDFCWzMybSR7dGV4dH1cXHgxQlswbWA7XG59XG52YXIgSVNfTk9ERSA9IGlzTm9kZVByb2Nlc3MoKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0Btc3dqcytpbnRlcmNlcHRvcnNAMC4yNi4xNS9ub2RlX21vZHVsZXMvQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci9jaHVuay1RRUQzUTZaMi5tanNcbnZhciBJbnRlcmNlcHRvclJlYWR5U3RhdGUgPSAoKEludGVyY2VwdG9yUmVhZHlTdGF0ZTIpID0+IHtcbiAgSW50ZXJjZXB0b3JSZWFkeVN0YXRlMltcIklOQUNUSVZFXCJdID0gXCJJTkFDVElWRVwiO1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUyW1wiQVBQTFlJTkdcIl0gPSBcIkFQUExZSU5HXCI7XG4gIEludGVyY2VwdG9yUmVhZHlTdGF0ZTJbXCJBUFBMSUVEXCJdID0gXCJBUFBMSUVEXCI7XG4gIEludGVyY2VwdG9yUmVhZHlTdGF0ZTJbXCJESVNQT1NJTkdcIl0gPSBcIkRJU1BPU0lOR1wiO1xuICBJbnRlcmNlcHRvclJlYWR5U3RhdGUyW1wiRElTUE9TRURcIl0gPSBcIkRJU1BPU0VEXCI7XG4gIHJldHVybiBJbnRlcmNlcHRvclJlYWR5U3RhdGUyO1xufSkoSW50ZXJjZXB0b3JSZWFkeVN0YXRlIHx8IHt9KTtcbmZ1bmN0aW9uIGNyZWF0ZVJlcXVlc3RJZCgpIHtcbiAgcmV0dXJuIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMTYpLnNsaWNlKDIpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vQG1zd2pzK2ludGVyY2VwdG9yc0AwLjI2LjE1L25vZGVfbW9kdWxlcy9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2luZGV4Lm1qc1xuZnVuY3Rpb24gZ2V0Q2xlYW5VcmwodXJsLCBpc0Fic29sdXRlID0gdHJ1ZSkge1xuICByZXR1cm4gW2lzQWJzb2x1dGUgJiYgdXJsLm9yaWdpbiwgdXJsLnBhdGhuYW1lXS5maWx0ZXIoQm9vbGVhbikuam9pbihcIlwiKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL3VybC9jbGVhblVybC5tanNcbnZhciBSRURVTkRBTlRfQ0hBUkFDVEVSU19FWFAgPSAvW1xcP3wjXS4qJC9nO1xuZnVuY3Rpb24gZ2V0U2VhcmNoUGFyYW1zKHBhdGgpIHtcbiAgcmV0dXJuIG5ldyBVUkwoYC8ke3BhdGh9YCwgXCJodHRwOi8vbG9jYWxob3N0XCIpLnNlYXJjaFBhcmFtcztcbn1cbmZ1bmN0aW9uIGNsZWFuVXJsKHBhdGgpIHtcbiAgcmV0dXJuIHBhdGgucmVwbGFjZShSRURVTkRBTlRfQ0hBUkFDVEVSU19FWFAsIFwiXCIpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvdXJsL2lzQWJzb2x1dGVVcmwubWpzXG5mdW5jdGlvbiBpc0Fic29sdXRlVXJsKHVybCkge1xuICByZXR1cm4gL14oW2Etel1bYS16XFxkXFwrXFwtXFwuXSo6KT9cXC9cXC8vaS50ZXN0KHVybCk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjEzX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy91cmwvZ2V0QWJzb2x1dGVVcmwubWpzXG5mdW5jdGlvbiBnZXRBYnNvbHV0ZVVybChwYXRoLCBiYXNlVXJsKSB7XG4gIGlmIChpc0Fic29sdXRlVXJsKHBhdGgpKSB7XG4gICAgcmV0dXJuIHBhdGg7XG4gIH1cbiAgaWYgKHBhdGguc3RhcnRzV2l0aChcIipcIikpIHtcbiAgICByZXR1cm4gcGF0aDtcbiAgfVxuICBjb25zdCBvcmlnaW4gPSBiYXNlVXJsIHx8IHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBkb2N1bWVudC5iYXNlVVJJO1xuICByZXR1cm4gb3JpZ2luID8gKFxuICAgIC8vIEVuY29kZSBhbmQgZGVjb2RlIHRoZSBwYXRoIHRvIHByZXNlcnZlIGVzY2FwZWQgY2hhcmFjdGVycy5cbiAgICBkZWNvZGVVUkkobmV3IFVSTChlbmNvZGVVUkkocGF0aCksIG9yaWdpbikuaHJlZilcbiAgKSA6IHBhdGg7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjEzX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9tYXRjaGluZy9ub3JtYWxpemVQYXRoLm1qc1xuZnVuY3Rpb24gbm9ybWFsaXplUGF0aChwYXRoLCBiYXNlVXJsKSB7XG4gIGlmIChwYXRoIGluc3RhbmNlb2YgUmVnRXhwKSB7XG4gICAgcmV0dXJuIHBhdGg7XG4gIH1cbiAgY29uc3QgbWF5YmVBYnNvbHV0ZVVybCA9IGdldEFic29sdXRlVXJsKHBhdGgsIGJhc2VVcmwpO1xuICByZXR1cm4gY2xlYW5VcmwobWF5YmVBYnNvbHV0ZVVybCk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjEzX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9tYXRjaGluZy9tYXRjaFJlcXVlc3RVcmwubWpzXG5mdW5jdGlvbiBjb2VyY2VQYXRoKHBhdGgpIHtcbiAgcmV0dXJuIHBhdGgucmVwbGFjZShcbiAgICAvKFs6YS16QS1aXy1dKikoXFwqezEsMn0pKy9nLFxuICAgIChfLCBwYXJhbWV0ZXJOYW1lLCB3aWxkY2FyZCkgPT4ge1xuICAgICAgY29uc3QgZXhwcmVzc2lvbiA9IFwiKC4qKVwiO1xuICAgICAgaWYgKCFwYXJhbWV0ZXJOYW1lKSB7XG4gICAgICAgIHJldHVybiBleHByZXNzaW9uO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHBhcmFtZXRlck5hbWUuc3RhcnRzV2l0aChcIjpcIikgPyBgJHtwYXJhbWV0ZXJOYW1lfSR7d2lsZGNhcmR9YCA6IGAke3BhcmFtZXRlck5hbWV9JHtleHByZXNzaW9ufWA7XG4gICAgfVxuICApLnJlcGxhY2UoLyhbXlxcL10pKDopKD89XFxkKykvLCBcIiQxXFxcXCQyXCIpLnJlcGxhY2UoL14oW15cXC9dKykoOikoPz1cXC9cXC8pLywgXCIkMVxcXFwkMlwiKTtcbn1cbmZ1bmN0aW9uIG1hdGNoUmVxdWVzdFVybCh1cmwsIHBhdGgsIGJhc2VVcmwpIHtcbiAgY29uc3Qgbm9ybWFsaXplZFBhdGggPSBub3JtYWxpemVQYXRoKHBhdGgsIGJhc2VVcmwpO1xuICBjb25zdCBjbGVhblBhdGggPSB0eXBlb2Ygbm9ybWFsaXplZFBhdGggPT09IFwic3RyaW5nXCIgPyBjb2VyY2VQYXRoKG5vcm1hbGl6ZWRQYXRoKSA6IG5vcm1hbGl6ZWRQYXRoO1xuICBjb25zdCBjbGVhblVybDIgPSBnZXRDbGVhblVybCh1cmwpO1xuICBjb25zdCByZXN1bHQgPSBtYXRjaChjbGVhblBhdGgsIHsgZGVjb2RlOiBkZWNvZGVVUklDb21wb25lbnQgfSkoY2xlYW5VcmwyKTtcbiAgY29uc3QgcGFyYW1zID0gcmVzdWx0ICYmIHJlc3VsdC5wYXJhbXMgfHwge307XG4gIHJldHVybiB7XG4gICAgbWF0Y2hlczogcmVzdWx0ICE9PSBmYWxzZSxcbiAgICBwYXJhbXNcbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL0BidW5kbGVkLWVzLW1vZHVsZXMrY29va2llQDIuMC4wL25vZGVfbW9kdWxlcy9AYnVuZGxlZC1lcy1tb2R1bGVzL2Nvb2tpZS9pbmRleC1lc20uanNcbnZhciBfX2NyZWF0ZTIgPSBPYmplY3QuY3JlYXRlO1xudmFyIF9fZGVmUHJvcDMgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19nZXRPd25Qcm9wRGVzYzIgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xudmFyIF9fZ2V0T3duUHJvcE5hbWVzMiA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzO1xudmFyIF9fZ2V0UHJvdG9PZjIgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG52YXIgX19oYXNPd25Qcm9wMiA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG52YXIgX19jb21tb25KUzIgPSAoY2IsIG1vZCkgPT4gZnVuY3Rpb24gX19yZXF1aXJlKCkge1xuICByZXR1cm4gbW9kIHx8ICgwLCBjYltfX2dldE93blByb3BOYW1lczIoY2IpWzBdXSkoKG1vZCA9IHsgZXhwb3J0czoge30gfSkuZXhwb3J0cywgbW9kKSwgbW9kLmV4cG9ydHM7XG59O1xudmFyIF9fY29weVByb3BzMiA9ICh0bywgZnJvbSwgZXhjZXB0LCBkZXNjKSA9PiB7XG4gIGlmIChmcm9tICYmIHR5cGVvZiBmcm9tID09PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBmcm9tID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICBmb3IgKGxldCBrZXkgb2YgX19nZXRPd25Qcm9wTmFtZXMyKGZyb20pKVxuICAgICAgaWYgKCFfX2hhc093blByb3AyLmNhbGwodG8sIGtleSkgJiYga2V5ICE9PSBleGNlcHQpXG4gICAgICAgIF9fZGVmUHJvcDModG8sIGtleSwgeyBnZXQ6ICgpID0+IGZyb21ba2V5XSwgZW51bWVyYWJsZTogIShkZXNjID0gX19nZXRPd25Qcm9wRGVzYzIoZnJvbSwga2V5KSkgfHwgZGVzYy5lbnVtZXJhYmxlIH0pO1xuICB9XG4gIHJldHVybiB0bztcbn07XG52YXIgX190b0VTTTIgPSAobW9kLCBpc05vZGVNb2RlLCB0YXJnZXQpID0+ICh0YXJnZXQgPSBtb2QgIT0gbnVsbCA/IF9fY3JlYXRlMihfX2dldFByb3RvT2YyKG1vZCkpIDoge30sIF9fY29weVByb3BzMihcbiAgLy8gSWYgdGhlIGltcG9ydGVyIGlzIGluIG5vZGUgY29tcGF0aWJpbGl0eSBtb2RlIG9yIHRoaXMgaXMgbm90IGFuIEVTTVxuICAvLyBmaWxlIHRoYXQgaGFzIGJlZW4gY29udmVydGVkIHRvIGEgQ29tbW9uSlMgZmlsZSB1c2luZyBhIEJhYmVsLVxuICAvLyBjb21wYXRpYmxlIHRyYW5zZm9ybSAoaS5lLiBcIl9fZXNNb2R1bGVcIiBoYXMgbm90IGJlZW4gc2V0KSwgdGhlbiBzZXRcbiAgLy8gXCJkZWZhdWx0XCIgdG8gdGhlIENvbW1vbkpTIFwibW9kdWxlLmV4cG9ydHNcIiBmb3Igbm9kZSBjb21wYXRpYmlsaXR5LlxuICBpc05vZGVNb2RlIHx8ICFtb2QgfHwgIW1vZC5fX2VzTW9kdWxlID8gX19kZWZQcm9wMyh0YXJnZXQsIFwiZGVmYXVsdFwiLCB7IHZhbHVlOiBtb2QsIGVudW1lcmFibGU6IHRydWUgfSkgOiB0YXJnZXQsXG4gIG1vZFxuKSk7XG52YXIgcmVxdWlyZV9jb29raWUgPSBfX2NvbW1vbkpTMih7XG4gIFwibm9kZV9tb2R1bGVzL2Nvb2tpZS9pbmRleC5qc1wiKGV4cG9ydHMpIHtcbiAgICBcInVzZSBzdHJpY3RcIjtcbiAgICBleHBvcnRzLnBhcnNlID0gcGFyc2UzO1xuICAgIGV4cG9ydHMuc2VyaWFsaXplID0gc2VyaWFsaXplO1xuICAgIHZhciBfX3RvU3RyaW5nID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbiAgICB2YXIgZmllbGRDb250ZW50UmVnRXhwID0gL15bXFx1MDAwOVxcdTAwMjAtXFx1MDA3ZVxcdTAwODAtXFx1MDBmZl0rJC87XG4gICAgZnVuY3Rpb24gcGFyc2UzKHN0ciwgb3B0aW9ucykge1xuICAgICAgaWYgKHR5cGVvZiBzdHIgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcImFyZ3VtZW50IHN0ciBtdXN0IGJlIGEgc3RyaW5nXCIpO1xuICAgICAgfVxuICAgICAgdmFyIG9iaiA9IHt9O1xuICAgICAgdmFyIG9wdCA9IG9wdGlvbnMgfHwge307XG4gICAgICB2YXIgZGVjID0gb3B0LmRlY29kZSB8fCBkZWNvZGU7XG4gICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgd2hpbGUgKGluZGV4IDwgc3RyLmxlbmd0aCkge1xuICAgICAgICB2YXIgZXFJZHggPSBzdHIuaW5kZXhPZihcIj1cIiwgaW5kZXgpO1xuICAgICAgICBpZiAoZXFJZHggPT09IC0xKSB7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGVuZElkeCA9IHN0ci5pbmRleE9mKFwiO1wiLCBpbmRleCk7XG4gICAgICAgIGlmIChlbmRJZHggPT09IC0xKSB7XG4gICAgICAgICAgZW5kSWR4ID0gc3RyLmxlbmd0aDtcbiAgICAgICAgfSBlbHNlIGlmIChlbmRJZHggPCBlcUlkeCkge1xuICAgICAgICAgIGluZGV4ID0gc3RyLmxhc3RJbmRleE9mKFwiO1wiLCBlcUlkeCAtIDEpICsgMTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIga2V5ID0gc3RyLnNsaWNlKGluZGV4LCBlcUlkeCkudHJpbSgpO1xuICAgICAgICBpZiAodm9pZCAwID09PSBvYmpba2V5XSkge1xuICAgICAgICAgIHZhciB2YWwgPSBzdHIuc2xpY2UoZXFJZHggKyAxLCBlbmRJZHgpLnRyaW0oKTtcbiAgICAgICAgICBpZiAodmFsLmNoYXJDb2RlQXQoMCkgPT09IDM0KSB7XG4gICAgICAgICAgICB2YWwgPSB2YWwuc2xpY2UoMSwgLTEpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBvYmpba2V5XSA9IHRyeURlY29kZSh2YWwsIGRlYyk7XG4gICAgICAgIH1cbiAgICAgICAgaW5kZXggPSBlbmRJZHggKyAxO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG9iajtcbiAgICB9XG4gICAgZnVuY3Rpb24gc2VyaWFsaXplKG5hbWUsIHZhbCwgb3B0aW9ucykge1xuICAgICAgdmFyIG9wdCA9IG9wdGlvbnMgfHwge307XG4gICAgICB2YXIgZW5jID0gb3B0LmVuY29kZSB8fCBlbmNvZGU7XG4gICAgICBpZiAodHlwZW9mIGVuYyAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJvcHRpb24gZW5jb2RlIGlzIGludmFsaWRcIik7XG4gICAgICB9XG4gICAgICBpZiAoIWZpZWxkQ29udGVudFJlZ0V4cC50ZXN0KG5hbWUpKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJhcmd1bWVudCBuYW1lIGlzIGludmFsaWRcIik7XG4gICAgICB9XG4gICAgICB2YXIgdmFsdWUgPSBlbmModmFsKTtcbiAgICAgIGlmICh2YWx1ZSAmJiAhZmllbGRDb250ZW50UmVnRXhwLnRlc3QodmFsdWUpKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJhcmd1bWVudCB2YWwgaXMgaW52YWxpZFwiKTtcbiAgICAgIH1cbiAgICAgIHZhciBzdHIgPSBuYW1lICsgXCI9XCIgKyB2YWx1ZTtcbiAgICAgIGlmIChudWxsICE9IG9wdC5tYXhBZ2UpIHtcbiAgICAgICAgdmFyIG1heEFnZSA9IG9wdC5tYXhBZ2UgLSAwO1xuICAgICAgICBpZiAoaXNOYU4obWF4QWdlKSB8fCAhaXNGaW5pdGUobWF4QWdlKSkge1xuICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJvcHRpb24gbWF4QWdlIGlzIGludmFsaWRcIik7XG4gICAgICAgIH1cbiAgICAgICAgc3RyICs9IFwiOyBNYXgtQWdlPVwiICsgTWF0aC5mbG9vcihtYXhBZ2UpO1xuICAgICAgfVxuICAgICAgaWYgKG9wdC5kb21haW4pIHtcbiAgICAgICAgaWYgKCFmaWVsZENvbnRlbnRSZWdFeHAudGVzdChvcHQuZG9tYWluKSkge1xuICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJvcHRpb24gZG9tYWluIGlzIGludmFsaWRcIik7XG4gICAgICAgIH1cbiAgICAgICAgc3RyICs9IFwiOyBEb21haW49XCIgKyBvcHQuZG9tYWluO1xuICAgICAgfVxuICAgICAgaWYgKG9wdC5wYXRoKSB7XG4gICAgICAgIGlmICghZmllbGRDb250ZW50UmVnRXhwLnRlc3Qob3B0LnBhdGgpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIm9wdGlvbiBwYXRoIGlzIGludmFsaWRcIik7XG4gICAgICAgIH1cbiAgICAgICAgc3RyICs9IFwiOyBQYXRoPVwiICsgb3B0LnBhdGg7XG4gICAgICB9XG4gICAgICBpZiAob3B0LmV4cGlyZXMpIHtcbiAgICAgICAgdmFyIGV4cGlyZXMgPSBvcHQuZXhwaXJlcztcbiAgICAgICAgaWYgKCFpc0RhdGUoZXhwaXJlcykgfHwgaXNOYU4oZXhwaXJlcy52YWx1ZU9mKCkpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIm9wdGlvbiBleHBpcmVzIGlzIGludmFsaWRcIik7XG4gICAgICAgIH1cbiAgICAgICAgc3RyICs9IFwiOyBFeHBpcmVzPVwiICsgZXhwaXJlcy50b1VUQ1N0cmluZygpO1xuICAgICAgfVxuICAgICAgaWYgKG9wdC5odHRwT25seSkge1xuICAgICAgICBzdHIgKz0gXCI7IEh0dHBPbmx5XCI7XG4gICAgICB9XG4gICAgICBpZiAob3B0LnNlY3VyZSkge1xuICAgICAgICBzdHIgKz0gXCI7IFNlY3VyZVwiO1xuICAgICAgfVxuICAgICAgaWYgKG9wdC5wcmlvcml0eSkge1xuICAgICAgICB2YXIgcHJpb3JpdHkgPSB0eXBlb2Ygb3B0LnByaW9yaXR5ID09PSBcInN0cmluZ1wiID8gb3B0LnByaW9yaXR5LnRvTG93ZXJDYXNlKCkgOiBvcHQucHJpb3JpdHk7XG4gICAgICAgIHN3aXRjaCAocHJpb3JpdHkpIHtcbiAgICAgICAgICBjYXNlIFwibG93XCI6XG4gICAgICAgICAgICBzdHIgKz0gXCI7IFByaW9yaXR5PUxvd1wiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSBcIm1lZGl1bVwiOlxuICAgICAgICAgICAgc3RyICs9IFwiOyBQcmlvcml0eT1NZWRpdW1cIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgXCJoaWdoXCI6XG4gICAgICAgICAgICBzdHIgKz0gXCI7IFByaW9yaXR5PUhpZ2hcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwib3B0aW9uIHByaW9yaXR5IGlzIGludmFsaWRcIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChvcHQuc2FtZVNpdGUpIHtcbiAgICAgICAgdmFyIHNhbWVTaXRlID0gdHlwZW9mIG9wdC5zYW1lU2l0ZSA9PT0gXCJzdHJpbmdcIiA/IG9wdC5zYW1lU2l0ZS50b0xvd2VyQ2FzZSgpIDogb3B0LnNhbWVTaXRlO1xuICAgICAgICBzd2l0Y2ggKHNhbWVTaXRlKSB7XG4gICAgICAgICAgY2FzZSB0cnVlOlxuICAgICAgICAgICAgc3RyICs9IFwiOyBTYW1lU2l0ZT1TdHJpY3RcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgXCJsYXhcIjpcbiAgICAgICAgICAgIHN0ciArPSBcIjsgU2FtZVNpdGU9TGF4XCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlIFwic3RyaWN0XCI6XG4gICAgICAgICAgICBzdHIgKz0gXCI7IFNhbWVTaXRlPVN0cmljdFwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSBcIm5vbmVcIjpcbiAgICAgICAgICAgIHN0ciArPSBcIjsgU2FtZVNpdGU9Tm9uZVwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJvcHRpb24gc2FtZVNpdGUgaXMgaW52YWxpZFwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHN0cjtcbiAgICB9XG4gICAgZnVuY3Rpb24gZGVjb2RlKHN0cikge1xuICAgICAgcmV0dXJuIHN0ci5pbmRleE9mKFwiJVwiKSAhPT0gLTEgPyBkZWNvZGVVUklDb21wb25lbnQoc3RyKSA6IHN0cjtcbiAgICB9XG4gICAgZnVuY3Rpb24gZW5jb2RlKHZhbCkge1xuICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudCh2YWwpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0RhdGUodmFsKSB7XG4gICAgICByZXR1cm4gX190b1N0cmluZy5jYWxsKHZhbCkgPT09IFwiW29iamVjdCBEYXRlXVwiIHx8IHZhbCBpbnN0YW5jZW9mIERhdGU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHRyeURlY29kZShzdHIsIGRlY29kZTIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBkZWNvZGUyKHN0cik7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBzdHI7XG4gICAgICB9XG4gICAgfVxuICB9XG59KTtcbnZhciBpbXBvcnRfY29va2llID0gX190b0VTTTIocmVxdWlyZV9jb29raWUoKSwgMSk7XG52YXIgc291cmNlX2RlZmF1bHQyID0gaW1wb3J0X2Nvb2tpZS5kZWZhdWx0O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvcmVxdWVzdC9nZXRSZXF1ZXN0Q29va2llcy5tanNcbmZ1bmN0aW9uIGdldEFsbERvY3VtZW50Q29va2llcygpIHtcbiAgcmV0dXJuIHNvdXJjZV9kZWZhdWx0Mi5wYXJzZShkb2N1bWVudC5jb29raWUpO1xufVxuZnVuY3Rpb24gZ2V0UmVxdWVzdENvb2tpZXMocmVxdWVzdCkge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiIHx8IHR5cGVvZiBsb2NhdGlvbiA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHJldHVybiB7fTtcbiAgfVxuICBzd2l0Y2ggKHJlcXVlc3QuY3JlZGVudGlhbHMpIHtcbiAgICBjYXNlIFwic2FtZS1vcmlnaW5cIjoge1xuICAgICAgY29uc3QgdXJsID0gbmV3IFVSTChyZXF1ZXN0LnVybCk7XG4gICAgICByZXR1cm4gbG9jYXRpb24ub3JpZ2luID09PSB1cmwub3JpZ2luID8gZ2V0QWxsRG9jdW1lbnRDb29raWVzKCkgOiB7fTtcbiAgICB9XG4gICAgY2FzZSBcImluY2x1ZGVcIjoge1xuICAgICAgcmV0dXJuIGdldEFsbERvY3VtZW50Q29va2llcygpO1xuICAgIH1cbiAgICBkZWZhdWx0OiB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBnZXRBbGxSZXF1ZXN0Q29va2llcyhyZXF1ZXN0KSB7XG4gIHZhciBfYTI7XG4gIGNvbnN0IHJlcXVlc3RDb29raWVzU3RyaW5nID0gcmVxdWVzdC5oZWFkZXJzLmdldChcImNvb2tpZVwiKTtcbiAgY29uc3QgY29va2llc0Zyb21IZWFkZXJzID0gcmVxdWVzdENvb2tpZXNTdHJpbmcgPyBzb3VyY2VfZGVmYXVsdDIucGFyc2UocmVxdWVzdENvb2tpZXNTdHJpbmcpIDoge307XG4gIHN0b3JlLmh5ZHJhdGUoKTtcbiAgY29uc3QgY29va2llc0Zyb21TdG9yZSA9IEFycmF5LmZyb20oKF9hMiA9IHN0b3JlLmdldChyZXF1ZXN0KSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5lbnRyaWVzKCkpLnJlZHVjZSgoY29va2llcywgW25hbWUsIHsgdmFsdWUgfV0pID0+IHtcbiAgICByZXR1cm4gT2JqZWN0LmFzc2lnbihjb29raWVzLCB7IFtuYW1lLnRyaW0oKV06IHZhbHVlIH0pO1xuICB9LCB7fSk7XG4gIGNvbnN0IGNvb2tpZXNGcm9tRG9jdW1lbnQgPSBnZXRSZXF1ZXN0Q29va2llcyhyZXF1ZXN0KTtcbiAgY29uc3QgZm9yd2FyZGVkQ29va2llcyA9IHtcbiAgICAuLi5jb29raWVzRnJvbURvY3VtZW50LFxuICAgIC4uLmNvb2tpZXNGcm9tU3RvcmVcbiAgfTtcbiAgZm9yIChjb25zdCBbbmFtZSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGZvcndhcmRlZENvb2tpZXMpKSB7XG4gICAgcmVxdWVzdC5oZWFkZXJzLmFwcGVuZChcImNvb2tpZVwiLCBzb3VyY2VfZGVmYXVsdDIuc2VyaWFsaXplKG5hbWUsIHZhbHVlKSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICAuLi5mb3J3YXJkZWRDb29raWVzLFxuICAgIC4uLmNvb2tpZXNGcm9tSGVhZGVyc1xuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvaGFuZGxlcnMvSHR0cEhhbmRsZXIubWpzXG52YXIgSHR0cE1ldGhvZHMgPSAoKEh0dHBNZXRob2RzMikgPT4ge1xuICBIdHRwTWV0aG9kczJbXCJIRUFEXCJdID0gXCJIRUFEXCI7XG4gIEh0dHBNZXRob2RzMltcIkdFVFwiXSA9IFwiR0VUXCI7XG4gIEh0dHBNZXRob2RzMltcIlBPU1RcIl0gPSBcIlBPU1RcIjtcbiAgSHR0cE1ldGhvZHMyW1wiUFVUXCJdID0gXCJQVVRcIjtcbiAgSHR0cE1ldGhvZHMyW1wiUEFUQ0hcIl0gPSBcIlBBVENIXCI7XG4gIEh0dHBNZXRob2RzMltcIk9QVElPTlNcIl0gPSBcIk9QVElPTlNcIjtcbiAgSHR0cE1ldGhvZHMyW1wiREVMRVRFXCJdID0gXCJERUxFVEVcIjtcbiAgcmV0dXJuIEh0dHBNZXRob2RzMjtcbn0pKEh0dHBNZXRob2RzIHx8IHt9KTtcbnZhciBIdHRwSGFuZGxlciA9IGNsYXNzIGV4dGVuZHMgUmVxdWVzdEhhbmRsZXIge1xuICBjb25zdHJ1Y3RvcihtZXRob2QsIHBhdGgsIHJlc29sdmVyLCBvcHRpb25zKSB7XG4gICAgc3VwZXIoe1xuICAgICAgaW5mbzoge1xuICAgICAgICBoZWFkZXI6IGAke21ldGhvZH0gJHtwYXRofWAsXG4gICAgICAgIHBhdGgsXG4gICAgICAgIG1ldGhvZFxuICAgICAgfSxcbiAgICAgIHJlc29sdmVyLFxuICAgICAgb3B0aW9uc1xuICAgIH0pO1xuICAgIHRoaXMuY2hlY2tSZWR1bmRhbnRRdWVyeVBhcmFtZXRlcnMoKTtcbiAgfVxuICBjaGVja1JlZHVuZGFudFF1ZXJ5UGFyYW1ldGVycygpIHtcbiAgICBjb25zdCB7IG1ldGhvZCwgcGF0aCB9ID0gdGhpcy5pbmZvO1xuICAgIGlmIChwYXRoIGluc3RhbmNlb2YgUmVnRXhwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHVybCA9IGNsZWFuVXJsKHBhdGgpO1xuICAgIGlmICh1cmwgPT09IHBhdGgpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc2VhcmNoUGFyYW1zID0gZ2V0U2VhcmNoUGFyYW1zKHBhdGgpO1xuICAgIGNvbnN0IHF1ZXJ5UGFyYW1zID0gW107XG4gICAgc2VhcmNoUGFyYW1zLmZvckVhY2goKF8sIHBhcmFtTmFtZSkgPT4ge1xuICAgICAgcXVlcnlQYXJhbXMucHVzaChwYXJhbU5hbWUpO1xuICAgIH0pO1xuICAgIGRldlV0aWxzLndhcm4oXG4gICAgICBgRm91bmQgYSByZWR1bmRhbnQgdXNhZ2Ugb2YgcXVlcnkgcGFyYW1ldGVycyBpbiB0aGUgcmVxdWVzdCBoYW5kbGVyIFVSTCBmb3IgXCIke21ldGhvZH0gJHtwYXRofVwiLiBQbGVhc2UgbWF0Y2ggYWdhaW5zdCBhIHBhdGggaW5zdGVhZCBhbmQgYWNjZXNzIHF1ZXJ5IHBhcmFtZXRlcnMgdXNpbmcgXCJuZXcgVVJMKHJlcXVlc3QudXJsKS5zZWFyY2hQYXJhbXNcIiBpbnN0ZWFkLiBMZWFybiBtb3JlOiBodHRwczovL21zd2pzLmlvL2RvY3MvcmVjaXBlcy9xdWVyeS1wYXJhbWV0ZXJzYFxuICAgICk7XG4gIH1cbiAgYXN5bmMgcGFyc2UoYXJncykge1xuICAgIHZhciBfYTI7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChhcmdzLnJlcXVlc3QudXJsKTtcbiAgICBjb25zdCBtYXRjaDIgPSBtYXRjaFJlcXVlc3RVcmwoXG4gICAgICB1cmwsXG4gICAgICB0aGlzLmluZm8ucGF0aCxcbiAgICAgIChfYTIgPSBhcmdzLnJlc29sdXRpb25Db250ZXh0KSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmJhc2VVcmxcbiAgICApO1xuICAgIGNvbnN0IGNvb2tpZXMgPSBnZXRBbGxSZXF1ZXN0Q29va2llcyhhcmdzLnJlcXVlc3QpO1xuICAgIHJldHVybiB7XG4gICAgICBtYXRjaDogbWF0Y2gyLFxuICAgICAgY29va2llc1xuICAgIH07XG4gIH1cbiAgcHJlZGljYXRlKGFyZ3MpIHtcbiAgICBjb25zdCBoYXNNYXRjaGluZ01ldGhvZCA9IHRoaXMubWF0Y2hNZXRob2QoYXJncy5yZXF1ZXN0Lm1ldGhvZCk7XG4gICAgY29uc3QgaGFzTWF0Y2hpbmdVcmwgPSBhcmdzLnBhcnNlZFJlc3VsdC5tYXRjaC5tYXRjaGVzO1xuICAgIHJldHVybiBoYXNNYXRjaGluZ01ldGhvZCAmJiBoYXNNYXRjaGluZ1VybDtcbiAgfVxuICBtYXRjaE1ldGhvZChhY3R1YWxNZXRob2QpIHtcbiAgICByZXR1cm4gdGhpcy5pbmZvLm1ldGhvZCBpbnN0YW5jZW9mIFJlZ0V4cCA/IHRoaXMuaW5mby5tZXRob2QudGVzdChhY3R1YWxNZXRob2QpIDogaXNTdHJpbmdFcXVhbCh0aGlzLmluZm8ubWV0aG9kLCBhY3R1YWxNZXRob2QpO1xuICB9XG4gIGV4dGVuZFJlc29sdmVyQXJncyhhcmdzKSB7XG4gICAgdmFyIF9hMjtcbiAgICByZXR1cm4ge1xuICAgICAgcGFyYW1zOiAoKF9hMiA9IGFyZ3MucGFyc2VkUmVzdWx0Lm1hdGNoKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLnBhcmFtcykgfHwge30sXG4gICAgICBjb29raWVzOiBhcmdzLnBhcnNlZFJlc3VsdC5jb29raWVzXG4gICAgfTtcbiAgfVxuICBhc3luYyBsb2coYXJncykge1xuICAgIGNvbnN0IHB1YmxpY1VybCA9IHRvUHVibGljVXJsKGFyZ3MucmVxdWVzdC51cmwpO1xuICAgIGNvbnN0IGxvZ2dlZFJlcXVlc3QgPSBhd2FpdCBzZXJpYWxpemVSZXF1ZXN0KGFyZ3MucmVxdWVzdCk7XG4gICAgY29uc3QgbG9nZ2VkUmVzcG9uc2UgPSBhd2FpdCBzZXJpYWxpemVSZXNwb25zZShhcmdzLnJlc3BvbnNlKTtcbiAgICBjb25zdCBzdGF0dXNDb2xvciA9IGdldFN0YXR1c0NvZGVDb2xvcihsb2dnZWRSZXNwb25zZS5zdGF0dXMpO1xuICAgIGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQoXG4gICAgICBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFxuICAgICAgICBgJHtnZXRUaW1lc3RhbXAoKX0gJHthcmdzLnJlcXVlc3QubWV0aG9kfSAke3B1YmxpY1VybH0gKCVjJHtsb2dnZWRSZXNwb25zZS5zdGF0dXN9ICR7bG9nZ2VkUmVzcG9uc2Uuc3RhdHVzVGV4dH0lYylgXG4gICAgICApLFxuICAgICAgYGNvbG9yOiR7c3RhdHVzQ29sb3J9YCxcbiAgICAgIFwiY29sb3I6aW5oZXJpdFwiXG4gICAgKTtcbiAgICBjb25zb2xlLmxvZyhcIlJlcXVlc3RcIiwgbG9nZ2VkUmVxdWVzdCk7XG4gICAgY29uc29sZS5sb2coXCJIYW5kbGVyOlwiLCB0aGlzKTtcbiAgICBjb25zb2xlLmxvZyhcIlJlc3BvbnNlXCIsIGxvZ2dlZFJlc3BvbnNlKTtcbiAgICBjb25zb2xlLmdyb3VwRW5kKCk7XG4gIH1cbn07XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjEzX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS9odHRwLm1qc1xuZnVuY3Rpb24gY3JlYXRlSHR0cEhhbmRsZXIobWV0aG9kKSB7XG4gIHJldHVybiAocGF0aCwgcmVzb2x2ZXIsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgIHJldHVybiBuZXcgSHR0cEhhbmRsZXIobWV0aG9kLCBwYXRoLCByZXNvbHZlciwgb3B0aW9ucyk7XG4gIH07XG59XG52YXIgaHR0cCA9IHtcbiAgYWxsOiBjcmVhdGVIdHRwSGFuZGxlcigvLisvKSxcbiAgaGVhZDogY3JlYXRlSHR0cEhhbmRsZXIoSHR0cE1ldGhvZHMuSEVBRCksXG4gIGdldDogY3JlYXRlSHR0cEhhbmRsZXIoSHR0cE1ldGhvZHMuR0VUKSxcbiAgcG9zdDogY3JlYXRlSHR0cEhhbmRsZXIoSHR0cE1ldGhvZHMuUE9TVCksXG4gIHB1dDogY3JlYXRlSHR0cEhhbmRsZXIoSHR0cE1ldGhvZHMuUFVUKSxcbiAgZGVsZXRlOiBjcmVhdGVIdHRwSGFuZGxlcihIdHRwTWV0aG9kcy5ERUxFVEUpLFxuICBwYXRjaDogY3JlYXRlSHR0cEhhbmRsZXIoSHR0cE1ldGhvZHMuUEFUQ0gpLFxuICBvcHRpb25zOiBjcmVhdGVIdHRwSGFuZGxlcihIdHRwTWV0aG9kcy5PUFRJT05TKVxufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZlcnNpb24ubWpzXG52YXIgdmVyc2lvbkluZm8gPSBPYmplY3QuZnJlZXplKHtcbiAgbWFqb3I6IDE2LFxuICBtaW5vcjogOCxcbiAgcGF0Y2g6IDEsXG4gIHByZVJlbGVhc2VUYWc6IG51bGxcbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9kZXZBc3NlcnQubWpzXG5mdW5jdGlvbiBkZXZBc3NlcnQoY29uZGl0aW9uLCBtZXNzYWdlMykge1xuICBjb25zdCBib29sZWFuQ29uZGl0aW9uID0gQm9vbGVhbihjb25kaXRpb24pO1xuICBpZiAoIWJvb2xlYW5Db25kaXRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZTMpO1xuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL2lzT2JqZWN0TGlrZS5tanNcbmZ1bmN0aW9uIGlzT2JqZWN0TGlrZSh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGw7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL2ludmFyaWFudC5tanNcbmZ1bmN0aW9uIGludmFyaWFudDIoY29uZGl0aW9uLCBtZXNzYWdlMykge1xuICBjb25zdCBib29sZWFuQ29uZGl0aW9uID0gQm9vbGVhbihjb25kaXRpb24pO1xuICBpZiAoIWJvb2xlYW5Db25kaXRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBtZXNzYWdlMyAhPSBudWxsID8gbWVzc2FnZTMgOiBcIlVuZXhwZWN0ZWQgaW52YXJpYW50IHRyaWdnZXJlZC5cIlxuICAgICk7XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL2xvY2F0aW9uLm1qc1xudmFyIExpbmVSZWdFeHAgPSAvXFxyXFxufFtcXG5cXHJdL2c7XG5mdW5jdGlvbiBnZXRMb2NhdGlvbihzb3VyY2UsIHBvc2l0aW9uKSB7XG4gIGxldCBsYXN0TGluZVN0YXJ0ID0gMDtcbiAgbGV0IGxpbmUgPSAxO1xuICBmb3IgKGNvbnN0IG1hdGNoMiBvZiBzb3VyY2UuYm9keS5tYXRjaEFsbChMaW5lUmVnRXhwKSkge1xuICAgIHR5cGVvZiBtYXRjaDIuaW5kZXggPT09IFwibnVtYmVyXCIgfHwgaW52YXJpYW50MihmYWxzZSk7XG4gICAgaWYgKG1hdGNoMi5pbmRleCA+PSBwb3NpdGlvbikge1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGxhc3RMaW5lU3RhcnQgPSBtYXRjaDIuaW5kZXggKyBtYXRjaDJbMF0ubGVuZ3RoO1xuICAgIGxpbmUgKz0gMTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGxpbmUsXG4gICAgY29sdW1uOiBwb3NpdGlvbiArIDEgLSBsYXN0TGluZVN0YXJ0XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9wcmludExvY2F0aW9uLm1qc1xuZnVuY3Rpb24gcHJpbnRMb2NhdGlvbihsb2NhdGlvbjIpIHtcbiAgcmV0dXJuIHByaW50U291cmNlTG9jYXRpb24oXG4gICAgbG9jYXRpb24yLnNvdXJjZSxcbiAgICBnZXRMb2NhdGlvbihsb2NhdGlvbjIuc291cmNlLCBsb2NhdGlvbjIuc3RhcnQpXG4gICk7XG59XG5mdW5jdGlvbiBwcmludFNvdXJjZUxvY2F0aW9uKHNvdXJjZSwgc291cmNlTG9jYXRpb24pIHtcbiAgY29uc3QgZmlyc3RMaW5lQ29sdW1uT2Zmc2V0ID0gc291cmNlLmxvY2F0aW9uT2Zmc2V0LmNvbHVtbiAtIDE7XG4gIGNvbnN0IGJvZHkgPSBcIlwiLnBhZFN0YXJ0KGZpcnN0TGluZUNvbHVtbk9mZnNldCkgKyBzb3VyY2UuYm9keTtcbiAgY29uc3QgbGluZUluZGV4ID0gc291cmNlTG9jYXRpb24ubGluZSAtIDE7XG4gIGNvbnN0IGxpbmVPZmZzZXQgPSBzb3VyY2UubG9jYXRpb25PZmZzZXQubGluZSAtIDE7XG4gIGNvbnN0IGxpbmVOdW0gPSBzb3VyY2VMb2NhdGlvbi5saW5lICsgbGluZU9mZnNldDtcbiAgY29uc3QgY29sdW1uT2Zmc2V0ID0gc291cmNlTG9jYXRpb24ubGluZSA9PT0gMSA/IGZpcnN0TGluZUNvbHVtbk9mZnNldCA6IDA7XG4gIGNvbnN0IGNvbHVtbk51bSA9IHNvdXJjZUxvY2F0aW9uLmNvbHVtbiArIGNvbHVtbk9mZnNldDtcbiAgY29uc3QgbG9jYXRpb25TdHIgPSBgJHtzb3VyY2UubmFtZX06JHtsaW5lTnVtfToke2NvbHVtbk51bX1cbmA7XG4gIGNvbnN0IGxpbmVzID0gYm9keS5zcGxpdCgvXFxyXFxufFtcXG5cXHJdL2cpO1xuICBjb25zdCBsb2NhdGlvbkxpbmUgPSBsaW5lc1tsaW5lSW5kZXhdO1xuICBpZiAobG9jYXRpb25MaW5lLmxlbmd0aCA+IDEyMCkge1xuICAgIGNvbnN0IHN1YkxpbmVJbmRleCA9IE1hdGguZmxvb3IoY29sdW1uTnVtIC8gODApO1xuICAgIGNvbnN0IHN1YkxpbmVDb2x1bW5OdW0gPSBjb2x1bW5OdW0gJSA4MDtcbiAgICBjb25zdCBzdWJMaW5lcyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbG9jYXRpb25MaW5lLmxlbmd0aDsgaSArPSA4MCkge1xuICAgICAgc3ViTGluZXMucHVzaChsb2NhdGlvbkxpbmUuc2xpY2UoaSwgaSArIDgwKSk7XG4gICAgfVxuICAgIHJldHVybiBsb2NhdGlvblN0ciArIHByaW50UHJlZml4ZWRMaW5lcyhbXG4gICAgICBbYCR7bGluZU51bX0gfGAsIHN1YkxpbmVzWzBdXSxcbiAgICAgIC4uLnN1YkxpbmVzLnNsaWNlKDEsIHN1YkxpbmVJbmRleCArIDEpLm1hcCgoc3ViTGluZSkgPT4gW1wifFwiLCBzdWJMaW5lXSksXG4gICAgICBbXCJ8XCIsIFwiXlwiLnBhZFN0YXJ0KHN1YkxpbmVDb2x1bW5OdW0pXSxcbiAgICAgIFtcInxcIiwgc3ViTGluZXNbc3ViTGluZUluZGV4ICsgMV1dXG4gICAgXSk7XG4gIH1cbiAgcmV0dXJuIGxvY2F0aW9uU3RyICsgcHJpbnRQcmVmaXhlZExpbmVzKFtcbiAgICAvLyBMaW5lcyBzcGVjaWZpZWQgbGlrZSB0aGlzOiBbXCJwcmVmaXhcIiwgXCJzdHJpbmdcIl0sXG4gICAgW2Ake2xpbmVOdW0gLSAxfSB8YCwgbGluZXNbbGluZUluZGV4IC0gMV1dLFxuICAgIFtgJHtsaW5lTnVtfSB8YCwgbG9jYXRpb25MaW5lXSxcbiAgICBbXCJ8XCIsIFwiXlwiLnBhZFN0YXJ0KGNvbHVtbk51bSldLFxuICAgIFtgJHtsaW5lTnVtICsgMX0gfGAsIGxpbmVzW2xpbmVJbmRleCArIDFdXVxuICBdKTtcbn1cbmZ1bmN0aW9uIHByaW50UHJlZml4ZWRMaW5lcyhsaW5lcykge1xuICBjb25zdCBleGlzdGluZ0xpbmVzID0gbGluZXMuZmlsdGVyKChbXywgbGluZV0pID0+IGxpbmUgIT09IHZvaWQgMCk7XG4gIGNvbnN0IHBhZExlbiA9IE1hdGgubWF4KC4uLmV4aXN0aW5nTGluZXMubWFwKChbcHJlZml4XSkgPT4gcHJlZml4Lmxlbmd0aCkpO1xuICByZXR1cm4gZXhpc3RpbmdMaW5lcy5tYXAoKFtwcmVmaXgsIGxpbmVdKSA9PiBwcmVmaXgucGFkU3RhcnQocGFkTGVuKSArIChsaW5lID8gXCIgXCIgKyBsaW5lIDogXCJcIikpLmpvaW4oXCJcXG5cIik7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9lcnJvci9HcmFwaFFMRXJyb3IubWpzXG5mdW5jdGlvbiB0b05vcm1hbGl6ZWRPcHRpb25zKGFyZ3MpIHtcbiAgY29uc3QgZmlyc3RBcmcgPSBhcmdzWzBdO1xuICBpZiAoZmlyc3RBcmcgPT0gbnVsbCB8fCBcImtpbmRcIiBpbiBmaXJzdEFyZyB8fCBcImxlbmd0aFwiIGluIGZpcnN0QXJnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5vZGVzOiBmaXJzdEFyZyxcbiAgICAgIHNvdXJjZTogYXJnc1sxXSxcbiAgICAgIHBvc2l0aW9uczogYXJnc1syXSxcbiAgICAgIHBhdGg6IGFyZ3NbM10sXG4gICAgICBvcmlnaW5hbEVycm9yOiBhcmdzWzRdLFxuICAgICAgZXh0ZW5zaW9uczogYXJnc1s1XVxuICAgIH07XG4gIH1cbiAgcmV0dXJuIGZpcnN0QXJnO1xufVxudmFyIEdyYXBoUUxFcnJvciA9IGNsYXNzIF9HcmFwaFFMRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIC8qKlxuICAgKiBBbiBhcnJheSBvZiBgeyBsaW5lLCBjb2x1bW4gfWAgbG9jYXRpb25zIHdpdGhpbiB0aGUgc291cmNlIEdyYXBoUUwgZG9jdW1lbnRcbiAgICogd2hpY2ggY29ycmVzcG9uZCB0byB0aGlzIGVycm9yLlxuICAgKlxuICAgKiBFcnJvcnMgZHVyaW5nIHZhbGlkYXRpb24gb2Z0ZW4gY29udGFpbiBtdWx0aXBsZSBsb2NhdGlvbnMsIGZvciBleGFtcGxlIHRvXG4gICAqIHBvaW50IG91dCB0d28gdGhpbmdzIHdpdGggdGhlIHNhbWUgbmFtZS4gRXJyb3JzIGR1cmluZyBleGVjdXRpb24gaW5jbHVkZSBhXG4gICAqIHNpbmdsZSBsb2NhdGlvbiwgdGhlIGZpZWxkIHdoaWNoIHByb2R1Y2VkIHRoZSBlcnJvci5cbiAgICpcbiAgICogRW51bWVyYWJsZSwgYW5kIGFwcGVhcnMgaW4gdGhlIHJlc3VsdCBvZiBKU09OLnN0cmluZ2lmeSgpLlxuICAgKi9cbiAgLyoqXG4gICAqIEFuIGFycmF5IGRlc2NyaWJpbmcgdGhlIEpTT04tcGF0aCBpbnRvIHRoZSBleGVjdXRpb24gcmVzcG9uc2Ugd2hpY2hcbiAgICogY29ycmVzcG9uZHMgdG8gdGhpcyBlcnJvci4gT25seSBpbmNsdWRlZCBmb3IgZXJyb3JzIGR1cmluZyBleGVjdXRpb24uXG4gICAqXG4gICAqIEVudW1lcmFibGUsIGFuZCBhcHBlYXJzIGluIHRoZSByZXN1bHQgb2YgSlNPTi5zdHJpbmdpZnkoKS5cbiAgICovXG4gIC8qKlxuICAgKiBBbiBhcnJheSBvZiBHcmFwaFFMIEFTVCBOb2RlcyBjb3JyZXNwb25kaW5nIHRvIHRoaXMgZXJyb3IuXG4gICAqL1xuICAvKipcbiAgICogVGhlIHNvdXJjZSBHcmFwaFFMIGRvY3VtZW50IGZvciB0aGUgZmlyc3QgbG9jYXRpb24gb2YgdGhpcyBlcnJvci5cbiAgICpcbiAgICogTm90ZSB0aGF0IGlmIHRoaXMgRXJyb3IgcmVwcmVzZW50cyBtb3JlIHRoYW4gb25lIG5vZGUsIHRoZSBzb3VyY2UgbWF5IG5vdFxuICAgKiByZXByZXNlbnQgbm9kZXMgYWZ0ZXIgdGhlIGZpcnN0IG5vZGUuXG4gICAqL1xuICAvKipcbiAgICogQW4gYXJyYXkgb2YgY2hhcmFjdGVyIG9mZnNldHMgd2l0aGluIHRoZSBzb3VyY2UgR3JhcGhRTCBkb2N1bWVudFxuICAgKiB3aGljaCBjb3JyZXNwb25kIHRvIHRoaXMgZXJyb3IuXG4gICAqL1xuICAvKipcbiAgICogVGhlIG9yaWdpbmFsIGVycm9yIHRocm93biBmcm9tIGEgZmllbGQgcmVzb2x2ZXIgZHVyaW5nIGV4ZWN1dGlvbi5cbiAgICovXG4gIC8qKlxuICAgKiBFeHRlbnNpb24gZmllbGRzIHRvIGFkZCB0byB0aGUgZm9ybWF0dGVkIGVycm9yLlxuICAgKi9cbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIFBsZWFzZSB1c2UgdGhlIGBHcmFwaFFMRXJyb3JPcHRpb25zYCBjb25zdHJ1Y3RvciBvdmVybG9hZCBpbnN0ZWFkLlxuICAgKi9cbiAgY29uc3RydWN0b3IobWVzc2FnZTMsIC4uLnJhd0FyZ3MpIHtcbiAgICB2YXIgX3RoaXMkbm9kZXMsIF9ub2RlTG9jYXRpb25zJCwgX3JlZjtcbiAgICBjb25zdCB7IG5vZGVzLCBzb3VyY2UsIHBvc2l0aW9ucywgcGF0aCwgb3JpZ2luYWxFcnJvciwgZXh0ZW5zaW9ucyB9ID0gdG9Ob3JtYWxpemVkT3B0aW9ucyhyYXdBcmdzKTtcbiAgICBzdXBlcihtZXNzYWdlMyk7XG4gICAgdGhpcy5uYW1lID0gXCJHcmFwaFFMRXJyb3JcIjtcbiAgICB0aGlzLnBhdGggPSBwYXRoICE9PSBudWxsICYmIHBhdGggIT09IHZvaWQgMCA/IHBhdGggOiB2b2lkIDA7XG4gICAgdGhpcy5vcmlnaW5hbEVycm9yID0gb3JpZ2luYWxFcnJvciAhPT0gbnVsbCAmJiBvcmlnaW5hbEVycm9yICE9PSB2b2lkIDAgPyBvcmlnaW5hbEVycm9yIDogdm9pZCAwO1xuICAgIHRoaXMubm9kZXMgPSB1bmRlZmluZWRJZkVtcHR5KFxuICAgICAgQXJyYXkuaXNBcnJheShub2RlcykgPyBub2RlcyA6IG5vZGVzID8gW25vZGVzXSA6IHZvaWQgMFxuICAgICk7XG4gICAgY29uc3Qgbm9kZUxvY2F0aW9ucyA9IHVuZGVmaW5lZElmRW1wdHkoXG4gICAgICAoX3RoaXMkbm9kZXMgPSB0aGlzLm5vZGVzKSA9PT0gbnVsbCB8fCBfdGhpcyRub2RlcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkbm9kZXMubWFwKChub2RlKSA9PiBub2RlLmxvYykuZmlsdGVyKChsb2MpID0+IGxvYyAhPSBudWxsKVxuICAgICk7XG4gICAgdGhpcy5zb3VyY2UgPSBzb3VyY2UgIT09IG51bGwgJiYgc291cmNlICE9PSB2b2lkIDAgPyBzb3VyY2UgOiBub2RlTG9jYXRpb25zID09PSBudWxsIHx8IG5vZGVMb2NhdGlvbnMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IChfbm9kZUxvY2F0aW9ucyQgPSBub2RlTG9jYXRpb25zWzBdKSA9PT0gbnVsbCB8fCBfbm9kZUxvY2F0aW9ucyQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9ub2RlTG9jYXRpb25zJC5zb3VyY2U7XG4gICAgdGhpcy5wb3NpdGlvbnMgPSBwb3NpdGlvbnMgIT09IG51bGwgJiYgcG9zaXRpb25zICE9PSB2b2lkIDAgPyBwb3NpdGlvbnMgOiBub2RlTG9jYXRpb25zID09PSBudWxsIHx8IG5vZGVMb2NhdGlvbnMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG5vZGVMb2NhdGlvbnMubWFwKChsb2MpID0+IGxvYy5zdGFydCk7XG4gICAgdGhpcy5sb2NhdGlvbnMgPSBwb3NpdGlvbnMgJiYgc291cmNlID8gcG9zaXRpb25zLm1hcCgocG9zKSA9PiBnZXRMb2NhdGlvbihzb3VyY2UsIHBvcykpIDogbm9kZUxvY2F0aW9ucyA9PT0gbnVsbCB8fCBub2RlTG9jYXRpb25zID09PSB2b2lkIDAgPyB2b2lkIDAgOiBub2RlTG9jYXRpb25zLm1hcCgobG9jKSA9PiBnZXRMb2NhdGlvbihsb2Muc291cmNlLCBsb2Muc3RhcnQpKTtcbiAgICBjb25zdCBvcmlnaW5hbEV4dGVuc2lvbnMgPSBpc09iamVjdExpa2UoXG4gICAgICBvcmlnaW5hbEVycm9yID09PSBudWxsIHx8IG9yaWdpbmFsRXJyb3IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9yaWdpbmFsRXJyb3IuZXh0ZW5zaW9uc1xuICAgICkgPyBvcmlnaW5hbEVycm9yID09PSBudWxsIHx8IG9yaWdpbmFsRXJyb3IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9yaWdpbmFsRXJyb3IuZXh0ZW5zaW9ucyA6IHZvaWQgMDtcbiAgICB0aGlzLmV4dGVuc2lvbnMgPSAoX3JlZiA9IGV4dGVuc2lvbnMgIT09IG51bGwgJiYgZXh0ZW5zaW9ucyAhPT0gdm9pZCAwID8gZXh0ZW5zaW9ucyA6IG9yaWdpbmFsRXh0ZW5zaW9ucykgIT09IG51bGwgJiYgX3JlZiAhPT0gdm9pZCAwID8gX3JlZiA6IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHRoaXMsIHtcbiAgICAgIG1lc3NhZ2U6IHtcbiAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgIGVudW1lcmFibGU6IHRydWVcbiAgICAgIH0sXG4gICAgICBuYW1lOiB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlXG4gICAgICB9LFxuICAgICAgbm9kZXM6IHtcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2VcbiAgICAgIH0sXG4gICAgICBzb3VyY2U6IHtcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2VcbiAgICAgIH0sXG4gICAgICBwb3NpdGlvbnM6IHtcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2VcbiAgICAgIH0sXG4gICAgICBvcmlnaW5hbEVycm9yOiB7XG4gICAgICAgIGVudW1lcmFibGU6IGZhbHNlXG4gICAgICB9XG4gICAgfSk7XG4gICAgaWYgKG9yaWdpbmFsRXJyb3IgIT09IG51bGwgJiYgb3JpZ2luYWxFcnJvciAhPT0gdm9pZCAwICYmIG9yaWdpbmFsRXJyb3Iuc3RhY2spIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInN0YWNrXCIsIHtcbiAgICAgICAgdmFsdWU6IG9yaWdpbmFsRXJyb3Iuc3RhY2ssXG4gICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UpIHtcbiAgICAgIEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKHRoaXMsIF9HcmFwaFFMRXJyb3IpO1xuICAgIH0gZWxzZSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgXCJzdGFja1wiLCB7XG4gICAgICAgIHZhbHVlOiBFcnJvcigpLnN0YWNrLFxuICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIkdyYXBoUUxFcnJvclwiO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIGxldCBvdXRwdXQgPSB0aGlzLm1lc3NhZ2U7XG4gICAgaWYgKHRoaXMubm9kZXMpIHtcbiAgICAgIGZvciAoY29uc3Qgbm9kZSBvZiB0aGlzLm5vZGVzKSB7XG4gICAgICAgIGlmIChub2RlLmxvYykge1xuICAgICAgICAgIG91dHB1dCArPSBcIlxcblxcblwiICsgcHJpbnRMb2NhdGlvbihub2RlLmxvYyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHRoaXMuc291cmNlICYmIHRoaXMubG9jYXRpb25zKSB7XG4gICAgICBmb3IgKGNvbnN0IGxvY2F0aW9uMiBvZiB0aGlzLmxvY2F0aW9ucykge1xuICAgICAgICBvdXRwdXQgKz0gXCJcXG5cXG5cIiArIHByaW50U291cmNlTG9jYXRpb24odGhpcy5zb3VyY2UsIGxvY2F0aW9uMik7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBvdXRwdXQ7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIGNvbnN0IGZvcm1hdHRlZEVycm9yID0ge1xuICAgICAgbWVzc2FnZTogdGhpcy5tZXNzYWdlXG4gICAgfTtcbiAgICBpZiAodGhpcy5sb2NhdGlvbnMgIT0gbnVsbCkge1xuICAgICAgZm9ybWF0dGVkRXJyb3IubG9jYXRpb25zID0gdGhpcy5sb2NhdGlvbnM7XG4gICAgfVxuICAgIGlmICh0aGlzLnBhdGggIT0gbnVsbCkge1xuICAgICAgZm9ybWF0dGVkRXJyb3IucGF0aCA9IHRoaXMucGF0aDtcbiAgICB9XG4gICAgaWYgKHRoaXMuZXh0ZW5zaW9ucyAhPSBudWxsICYmIE9iamVjdC5rZXlzKHRoaXMuZXh0ZW5zaW9ucykubGVuZ3RoID4gMCkge1xuICAgICAgZm9ybWF0dGVkRXJyb3IuZXh0ZW5zaW9ucyA9IHRoaXMuZXh0ZW5zaW9ucztcbiAgICB9XG4gICAgcmV0dXJuIGZvcm1hdHRlZEVycm9yO1xuICB9XG59O1xuZnVuY3Rpb24gdW5kZWZpbmVkSWZFbXB0eShhcnJheSkge1xuICByZXR1cm4gYXJyYXkgPT09IHZvaWQgMCB8fCBhcnJheS5sZW5ndGggPT09IDAgPyB2b2lkIDAgOiBhcnJheTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2Vycm9yL3N5bnRheEVycm9yLm1qc1xuZnVuY3Rpb24gc3ludGF4RXJyb3Ioc291cmNlLCBwb3NpdGlvbiwgZGVzY3JpcHRpb24pIHtcbiAgcmV0dXJuIG5ldyBHcmFwaFFMRXJyb3IoYFN5bnRheCBFcnJvcjogJHtkZXNjcmlwdGlvbn1gLCB7XG4gICAgc291cmNlLFxuICAgIHBvc2l0aW9uczogW3Bvc2l0aW9uXVxuICB9KTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL2FzdC5tanNcbnZhciBMb2NhdGlvbiA9IGNsYXNzIHtcbiAgLyoqXG4gICAqIFRoZSBjaGFyYWN0ZXIgb2Zmc2V0IGF0IHdoaWNoIHRoaXMgTm9kZSBiZWdpbnMuXG4gICAqL1xuICAvKipcbiAgICogVGhlIGNoYXJhY3RlciBvZmZzZXQgYXQgd2hpY2ggdGhpcyBOb2RlIGVuZHMuXG4gICAqL1xuICAvKipcbiAgICogVGhlIFRva2VuIGF0IHdoaWNoIHRoaXMgTm9kZSBiZWdpbnMuXG4gICAqL1xuICAvKipcbiAgICogVGhlIFRva2VuIGF0IHdoaWNoIHRoaXMgTm9kZSBlbmRzLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBTb3VyY2UgZG9jdW1lbnQgdGhlIEFTVCByZXByZXNlbnRzLlxuICAgKi9cbiAgY29uc3RydWN0b3Ioc3RhcnRUb2tlbiwgZW5kVG9rZW4sIHNvdXJjZSkge1xuICAgIHRoaXMuc3RhcnQgPSBzdGFydFRva2VuLnN0YXJ0O1xuICAgIHRoaXMuZW5kID0gZW5kVG9rZW4uZW5kO1xuICAgIHRoaXMuc3RhcnRUb2tlbiA9IHN0YXJ0VG9rZW47XG4gICAgdGhpcy5lbmRUb2tlbiA9IGVuZFRva2VuO1xuICAgIHRoaXMuc291cmNlID0gc291cmNlO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJMb2NhdGlvblwiO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4ge1xuICAgICAgc3RhcnQ6IHRoaXMuc3RhcnQsXG4gICAgICBlbmQ6IHRoaXMuZW5kXG4gICAgfTtcbiAgfVxufTtcbnZhciBUb2tlbiA9IGNsYXNzIHtcbiAgLyoqXG4gICAqIFRoZSBraW5kIG9mIFRva2VuLlxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBjaGFyYWN0ZXIgb2Zmc2V0IGF0IHdoaWNoIHRoaXMgTm9kZSBiZWdpbnMuXG4gICAqL1xuICAvKipcbiAgICogVGhlIGNoYXJhY3RlciBvZmZzZXQgYXQgd2hpY2ggdGhpcyBOb2RlIGVuZHMuXG4gICAqL1xuICAvKipcbiAgICogVGhlIDEtaW5kZXhlZCBsaW5lIG51bWJlciBvbiB3aGljaCB0aGlzIFRva2VuIGFwcGVhcnMuXG4gICAqL1xuICAvKipcbiAgICogVGhlIDEtaW5kZXhlZCBjb2x1bW4gbnVtYmVyIGF0IHdoaWNoIHRoaXMgVG9rZW4gYmVnaW5zLlxuICAgKi9cbiAgLyoqXG4gICAqIEZvciBub24tcHVuY3R1YXRpb24gdG9rZW5zLCByZXByZXNlbnRzIHRoZSBpbnRlcnByZXRlZCB2YWx1ZSBvZiB0aGUgdG9rZW4uXG4gICAqXG4gICAqIE5vdGU6IGlzIHVuZGVmaW5lZCBmb3IgcHVuY3R1YXRpb24gdG9rZW5zLCBidXQgdHlwZWQgYXMgc3RyaW5nIGZvclxuICAgKiBjb252ZW5pZW5jZSBpbiB0aGUgcGFyc2VyLlxuICAgKi9cbiAgLyoqXG4gICAqIFRva2VucyBleGlzdCBhcyBub2RlcyBpbiBhIGRvdWJsZS1saW5rZWQtbGlzdCBhbW9uZ3N0IGFsbCB0b2tlbnNcbiAgICogaW5jbHVkaW5nIGlnbm9yZWQgdG9rZW5zLiA8U09GPiBpcyBhbHdheXMgdGhlIGZpcnN0IG5vZGUgYW5kIDxFT0Y+XG4gICAqIHRoZSBsYXN0LlxuICAgKi9cbiAgY29uc3RydWN0b3Ioa2luZCwgc3RhcnQsIGVuZCwgbGluZSwgY29sdW1uLCB2YWx1ZSkge1xuICAgIHRoaXMua2luZCA9IGtpbmQ7XG4gICAgdGhpcy5zdGFydCA9IHN0YXJ0O1xuICAgIHRoaXMuZW5kID0gZW5kO1xuICAgIHRoaXMubGluZSA9IGxpbmU7XG4gICAgdGhpcy5jb2x1bW4gPSBjb2x1bW47XG4gICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICAgIHRoaXMucHJldiA9IG51bGw7XG4gICAgdGhpcy5uZXh0ID0gbnVsbDtcbiAgfVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuIFwiVG9rZW5cIjtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGtpbmQ6IHRoaXMua2luZCxcbiAgICAgIHZhbHVlOiB0aGlzLnZhbHVlLFxuICAgICAgbGluZTogdGhpcy5saW5lLFxuICAgICAgY29sdW1uOiB0aGlzLmNvbHVtblxuICAgIH07XG4gIH1cbn07XG52YXIgUXVlcnlEb2N1bWVudEtleXMgPSB7XG4gIE5hbWU6IFtdLFxuICBEb2N1bWVudDogW1wiZGVmaW5pdGlvbnNcIl0sXG4gIE9wZXJhdGlvbkRlZmluaXRpb246IFtcbiAgICBcIm5hbWVcIixcbiAgICBcInZhcmlhYmxlRGVmaW5pdGlvbnNcIixcbiAgICBcImRpcmVjdGl2ZXNcIixcbiAgICBcInNlbGVjdGlvblNldFwiXG4gIF0sXG4gIFZhcmlhYmxlRGVmaW5pdGlvbjogW1widmFyaWFibGVcIiwgXCJ0eXBlXCIsIFwiZGVmYXVsdFZhbHVlXCIsIFwiZGlyZWN0aXZlc1wiXSxcbiAgVmFyaWFibGU6IFtcIm5hbWVcIl0sXG4gIFNlbGVjdGlvblNldDogW1wic2VsZWN0aW9uc1wiXSxcbiAgRmllbGQ6IFtcImFsaWFzXCIsIFwibmFtZVwiLCBcImFyZ3VtZW50c1wiLCBcImRpcmVjdGl2ZXNcIiwgXCJzZWxlY3Rpb25TZXRcIl0sXG4gIEFyZ3VtZW50OiBbXCJuYW1lXCIsIFwidmFsdWVcIl0sXG4gIEZyYWdtZW50U3ByZWFkOiBbXCJuYW1lXCIsIFwiZGlyZWN0aXZlc1wiXSxcbiAgSW5saW5lRnJhZ21lbnQ6IFtcInR5cGVDb25kaXRpb25cIiwgXCJkaXJlY3RpdmVzXCIsIFwic2VsZWN0aW9uU2V0XCJdLFxuICBGcmFnbWVudERlZmluaXRpb246IFtcbiAgICBcIm5hbWVcIixcbiAgICAvLyBOb3RlOiBmcmFnbWVudCB2YXJpYWJsZSBkZWZpbml0aW9ucyBhcmUgZGVwcmVjYXRlZCBhbmQgd2lsbCByZW1vdmVkIGluIHYxNy4wLjBcbiAgICBcInZhcmlhYmxlRGVmaW5pdGlvbnNcIixcbiAgICBcInR5cGVDb25kaXRpb25cIixcbiAgICBcImRpcmVjdGl2ZXNcIixcbiAgICBcInNlbGVjdGlvblNldFwiXG4gIF0sXG4gIEludFZhbHVlOiBbXSxcbiAgRmxvYXRWYWx1ZTogW10sXG4gIFN0cmluZ1ZhbHVlOiBbXSxcbiAgQm9vbGVhblZhbHVlOiBbXSxcbiAgTnVsbFZhbHVlOiBbXSxcbiAgRW51bVZhbHVlOiBbXSxcbiAgTGlzdFZhbHVlOiBbXCJ2YWx1ZXNcIl0sXG4gIE9iamVjdFZhbHVlOiBbXCJmaWVsZHNcIl0sXG4gIE9iamVjdEZpZWxkOiBbXCJuYW1lXCIsIFwidmFsdWVcIl0sXG4gIERpcmVjdGl2ZTogW1wibmFtZVwiLCBcImFyZ3VtZW50c1wiXSxcbiAgTmFtZWRUeXBlOiBbXCJuYW1lXCJdLFxuICBMaXN0VHlwZTogW1widHlwZVwiXSxcbiAgTm9uTnVsbFR5cGU6IFtcInR5cGVcIl0sXG4gIFNjaGVtYURlZmluaXRpb246IFtcImRlc2NyaXB0aW9uXCIsIFwiZGlyZWN0aXZlc1wiLCBcIm9wZXJhdGlvblR5cGVzXCJdLFxuICBPcGVyYXRpb25UeXBlRGVmaW5pdGlvbjogW1widHlwZVwiXSxcbiAgU2NhbGFyVHlwZURlZmluaXRpb246IFtcImRlc2NyaXB0aW9uXCIsIFwibmFtZVwiLCBcImRpcmVjdGl2ZXNcIl0sXG4gIE9iamVjdFR5cGVEZWZpbml0aW9uOiBbXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwibmFtZVwiLFxuICAgIFwiaW50ZXJmYWNlc1wiLFxuICAgIFwiZGlyZWN0aXZlc1wiLFxuICAgIFwiZmllbGRzXCJcbiAgXSxcbiAgRmllbGREZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcIm5hbWVcIiwgXCJhcmd1bWVudHNcIiwgXCJ0eXBlXCIsIFwiZGlyZWN0aXZlc1wiXSxcbiAgSW5wdXRWYWx1ZURlZmluaXRpb246IFtcbiAgICBcImRlc2NyaXB0aW9uXCIsXG4gICAgXCJuYW1lXCIsXG4gICAgXCJ0eXBlXCIsXG4gICAgXCJkZWZhdWx0VmFsdWVcIixcbiAgICBcImRpcmVjdGl2ZXNcIlxuICBdLFxuICBJbnRlcmZhY2VUeXBlRGVmaW5pdGlvbjogW1xuICAgIFwiZGVzY3JpcHRpb25cIixcbiAgICBcIm5hbWVcIixcbiAgICBcImludGVyZmFjZXNcIixcbiAgICBcImRpcmVjdGl2ZXNcIixcbiAgICBcImZpZWxkc1wiXG4gIF0sXG4gIFVuaW9uVHlwZURlZmluaXRpb246IFtcImRlc2NyaXB0aW9uXCIsIFwibmFtZVwiLCBcImRpcmVjdGl2ZXNcIiwgXCJ0eXBlc1wiXSxcbiAgRW51bVR5cGVEZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCIsIFwidmFsdWVzXCJdLFxuICBFbnVtVmFsdWVEZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCJdLFxuICBJbnB1dE9iamVjdFR5cGVEZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCIsIFwiZmllbGRzXCJdLFxuICBEaXJlY3RpdmVEZWZpbml0aW9uOiBbXCJkZXNjcmlwdGlvblwiLCBcIm5hbWVcIiwgXCJhcmd1bWVudHNcIiwgXCJsb2NhdGlvbnNcIl0sXG4gIFNjaGVtYUV4dGVuc2lvbjogW1wiZGlyZWN0aXZlc1wiLCBcIm9wZXJhdGlvblR5cGVzXCJdLFxuICBTY2FsYXJUeXBlRXh0ZW5zaW9uOiBbXCJuYW1lXCIsIFwiZGlyZWN0aXZlc1wiXSxcbiAgT2JqZWN0VHlwZUV4dGVuc2lvbjogW1wibmFtZVwiLCBcImludGVyZmFjZXNcIiwgXCJkaXJlY3RpdmVzXCIsIFwiZmllbGRzXCJdLFxuICBJbnRlcmZhY2VUeXBlRXh0ZW5zaW9uOiBbXCJuYW1lXCIsIFwiaW50ZXJmYWNlc1wiLCBcImRpcmVjdGl2ZXNcIiwgXCJmaWVsZHNcIl0sXG4gIFVuaW9uVHlwZUV4dGVuc2lvbjogW1wibmFtZVwiLCBcImRpcmVjdGl2ZXNcIiwgXCJ0eXBlc1wiXSxcbiAgRW51bVR5cGVFeHRlbnNpb246IFtcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCIsIFwidmFsdWVzXCJdLFxuICBJbnB1dE9iamVjdFR5cGVFeHRlbnNpb246IFtcIm5hbWVcIiwgXCJkaXJlY3RpdmVzXCIsIFwiZmllbGRzXCJdXG59O1xudmFyIGtpbmRWYWx1ZXMgPSBuZXcgU2V0KE9iamVjdC5rZXlzKFF1ZXJ5RG9jdW1lbnRLZXlzKSk7XG5mdW5jdGlvbiBpc05vZGUobWF5YmVOb2RlKSB7XG4gIGNvbnN0IG1heWJlS2luZCA9IG1heWJlTm9kZSA9PT0gbnVsbCB8fCBtYXliZU5vZGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG1heWJlTm9kZS5raW5kO1xuICByZXR1cm4gdHlwZW9mIG1heWJlS2luZCA9PT0gXCJzdHJpbmdcIiAmJiBraW5kVmFsdWVzLmhhcyhtYXliZUtpbmQpO1xufVxudmFyIE9wZXJhdGlvblR5cGVOb2RlO1xuKGZ1bmN0aW9uKE9wZXJhdGlvblR5cGVOb2RlMikge1xuICBPcGVyYXRpb25UeXBlTm9kZTJbXCJRVUVSWVwiXSA9IFwicXVlcnlcIjtcbiAgT3BlcmF0aW9uVHlwZU5vZGUyW1wiTVVUQVRJT05cIl0gPSBcIm11dGF0aW9uXCI7XG4gIE9wZXJhdGlvblR5cGVOb2RlMltcIlNVQlNDUklQVElPTlwiXSA9IFwic3Vic2NyaXB0aW9uXCI7XG59KShPcGVyYXRpb25UeXBlTm9kZSB8fCAoT3BlcmF0aW9uVHlwZU5vZGUgPSB7fSkpO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2UvZGlyZWN0aXZlTG9jYXRpb24ubWpzXG52YXIgRGlyZWN0aXZlTG9jYXRpb247XG4oZnVuY3Rpb24oRGlyZWN0aXZlTG9jYXRpb24yKSB7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIlFVRVJZXCJdID0gXCJRVUVSWVwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJNVVRBVElPTlwiXSA9IFwiTVVUQVRJT05cIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiU1VCU0NSSVBUSU9OXCJdID0gXCJTVUJTQ1JJUFRJT05cIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiRklFTERcIl0gPSBcIkZJRUxEXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIkZSQUdNRU5UX0RFRklOSVRJT05cIl0gPSBcIkZSQUdNRU5UX0RFRklOSVRJT05cIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiRlJBR01FTlRfU1BSRUFEXCJdID0gXCJGUkFHTUVOVF9TUFJFQURcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiSU5MSU5FX0ZSQUdNRU5UXCJdID0gXCJJTkxJTkVfRlJBR01FTlRcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiVkFSSUFCTEVfREVGSU5JVElPTlwiXSA9IFwiVkFSSUFCTEVfREVGSU5JVElPTlwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJTQ0hFTUFcIl0gPSBcIlNDSEVNQVwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJTQ0FMQVJcIl0gPSBcIlNDQUxBUlwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJPQkpFQ1RcIl0gPSBcIk9CSkVDVFwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJGSUVMRF9ERUZJTklUSU9OXCJdID0gXCJGSUVMRF9ERUZJTklUSU9OXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIkFSR1VNRU5UX0RFRklOSVRJT05cIl0gPSBcIkFSR1VNRU5UX0RFRklOSVRJT05cIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiSU5URVJGQUNFXCJdID0gXCJJTlRFUkZBQ0VcIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiVU5JT05cIl0gPSBcIlVOSU9OXCI7XG4gIERpcmVjdGl2ZUxvY2F0aW9uMltcIkVOVU1cIl0gPSBcIkVOVU1cIjtcbiAgRGlyZWN0aXZlTG9jYXRpb24yW1wiRU5VTV9WQUxVRVwiXSA9IFwiRU5VTV9WQUxVRVwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJJTlBVVF9PQkpFQ1RcIl0gPSBcIklOUFVUX09CSkVDVFwiO1xuICBEaXJlY3RpdmVMb2NhdGlvbjJbXCJJTlBVVF9GSUVMRF9ERUZJTklUSU9OXCJdID0gXCJJTlBVVF9GSUVMRF9ERUZJTklUSU9OXCI7XG59KShEaXJlY3RpdmVMb2NhdGlvbiB8fCAoRGlyZWN0aXZlTG9jYXRpb24gPSB7fSkpO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2Uva2luZHMubWpzXG52YXIgS2luZDtcbihmdW5jdGlvbihLaW5kMikge1xuICBLaW5kMltcIk5BTUVcIl0gPSBcIk5hbWVcIjtcbiAgS2luZDJbXCJET0NVTUVOVFwiXSA9IFwiRG9jdW1lbnRcIjtcbiAgS2luZDJbXCJPUEVSQVRJT05fREVGSU5JVElPTlwiXSA9IFwiT3BlcmF0aW9uRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIlZBUklBQkxFX0RFRklOSVRJT05cIl0gPSBcIlZhcmlhYmxlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIlNFTEVDVElPTl9TRVRcIl0gPSBcIlNlbGVjdGlvblNldFwiO1xuICBLaW5kMltcIkZJRUxEXCJdID0gXCJGaWVsZFwiO1xuICBLaW5kMltcIkFSR1VNRU5UXCJdID0gXCJBcmd1bWVudFwiO1xuICBLaW5kMltcIkZSQUdNRU5UX1NQUkVBRFwiXSA9IFwiRnJhZ21lbnRTcHJlYWRcIjtcbiAgS2luZDJbXCJJTkxJTkVfRlJBR01FTlRcIl0gPSBcIklubGluZUZyYWdtZW50XCI7XG4gIEtpbmQyW1wiRlJBR01FTlRfREVGSU5JVElPTlwiXSA9IFwiRnJhZ21lbnREZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiVkFSSUFCTEVcIl0gPSBcIlZhcmlhYmxlXCI7XG4gIEtpbmQyW1wiSU5UXCJdID0gXCJJbnRWYWx1ZVwiO1xuICBLaW5kMltcIkZMT0FUXCJdID0gXCJGbG9hdFZhbHVlXCI7XG4gIEtpbmQyW1wiU1RSSU5HXCJdID0gXCJTdHJpbmdWYWx1ZVwiO1xuICBLaW5kMltcIkJPT0xFQU5cIl0gPSBcIkJvb2xlYW5WYWx1ZVwiO1xuICBLaW5kMltcIk5VTExcIl0gPSBcIk51bGxWYWx1ZVwiO1xuICBLaW5kMltcIkVOVU1cIl0gPSBcIkVudW1WYWx1ZVwiO1xuICBLaW5kMltcIkxJU1RcIl0gPSBcIkxpc3RWYWx1ZVwiO1xuICBLaW5kMltcIk9CSkVDVFwiXSA9IFwiT2JqZWN0VmFsdWVcIjtcbiAgS2luZDJbXCJPQkpFQ1RfRklFTERcIl0gPSBcIk9iamVjdEZpZWxkXCI7XG4gIEtpbmQyW1wiRElSRUNUSVZFXCJdID0gXCJEaXJlY3RpdmVcIjtcbiAgS2luZDJbXCJOQU1FRF9UWVBFXCJdID0gXCJOYW1lZFR5cGVcIjtcbiAgS2luZDJbXCJMSVNUX1RZUEVcIl0gPSBcIkxpc3RUeXBlXCI7XG4gIEtpbmQyW1wiTk9OX05VTExfVFlQRVwiXSA9IFwiTm9uTnVsbFR5cGVcIjtcbiAgS2luZDJbXCJTQ0hFTUFfREVGSU5JVElPTlwiXSA9IFwiU2NoZW1hRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIk9QRVJBVElPTl9UWVBFX0RFRklOSVRJT05cIl0gPSBcIk9wZXJhdGlvblR5cGVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiU0NBTEFSX1RZUEVfREVGSU5JVElPTlwiXSA9IFwiU2NhbGFyVHlwZURlZmluaXRpb25cIjtcbiAgS2luZDJbXCJPQkpFQ1RfVFlQRV9ERUZJTklUSU9OXCJdID0gXCJPYmplY3RUeXBlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIkZJRUxEX0RFRklOSVRJT05cIl0gPSBcIkZpZWxkRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIklOUFVUX1ZBTFVFX0RFRklOSVRJT05cIl0gPSBcIklucHV0VmFsdWVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiSU5URVJGQUNFX1RZUEVfREVGSU5JVElPTlwiXSA9IFwiSW50ZXJmYWNlVHlwZURlZmluaXRpb25cIjtcbiAgS2luZDJbXCJVTklPTl9UWVBFX0RFRklOSVRJT05cIl0gPSBcIlVuaW9uVHlwZURlZmluaXRpb25cIjtcbiAgS2luZDJbXCJFTlVNX1RZUEVfREVGSU5JVElPTlwiXSA9IFwiRW51bVR5cGVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiRU5VTV9WQUxVRV9ERUZJTklUSU9OXCJdID0gXCJFbnVtVmFsdWVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiSU5QVVRfT0JKRUNUX1RZUEVfREVGSU5JVElPTlwiXSA9IFwiSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvblwiO1xuICBLaW5kMltcIkRJUkVDVElWRV9ERUZJTklUSU9OXCJdID0gXCJEaXJlY3RpdmVEZWZpbml0aW9uXCI7XG4gIEtpbmQyW1wiU0NIRU1BX0VYVEVOU0lPTlwiXSA9IFwiU2NoZW1hRXh0ZW5zaW9uXCI7XG4gIEtpbmQyW1wiU0NBTEFSX1RZUEVfRVhURU5TSU9OXCJdID0gXCJTY2FsYXJUeXBlRXh0ZW5zaW9uXCI7XG4gIEtpbmQyW1wiT0JKRUNUX1RZUEVfRVhURU5TSU9OXCJdID0gXCJPYmplY3RUeXBlRXh0ZW5zaW9uXCI7XG4gIEtpbmQyW1wiSU5URVJGQUNFX1RZUEVfRVhURU5TSU9OXCJdID0gXCJJbnRlcmZhY2VUeXBlRXh0ZW5zaW9uXCI7XG4gIEtpbmQyW1wiVU5JT05fVFlQRV9FWFRFTlNJT05cIl0gPSBcIlVuaW9uVHlwZUV4dGVuc2lvblwiO1xuICBLaW5kMltcIkVOVU1fVFlQRV9FWFRFTlNJT05cIl0gPSBcIkVudW1UeXBlRXh0ZW5zaW9uXCI7XG4gIEtpbmQyW1wiSU5QVVRfT0JKRUNUX1RZUEVfRVhURU5TSU9OXCJdID0gXCJJbnB1dE9iamVjdFR5cGVFeHRlbnNpb25cIjtcbn0pKEtpbmQgfHwgKEtpbmQgPSB7fSkpO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2UvY2hhcmFjdGVyQ2xhc3Nlcy5tanNcbmZ1bmN0aW9uIGlzV2hpdGVTcGFjZShjb2RlKSB7XG4gIHJldHVybiBjb2RlID09PSA5IHx8IGNvZGUgPT09IDMyO1xufVxuZnVuY3Rpb24gaXNEaWdpdChjb2RlKSB7XG4gIHJldHVybiBjb2RlID49IDQ4ICYmIGNvZGUgPD0gNTc7XG59XG5mdW5jdGlvbiBpc0xldHRlcihjb2RlKSB7XG4gIHJldHVybiBjb2RlID49IDk3ICYmIGNvZGUgPD0gMTIyIHx8IC8vIEEtWlxuICBjb2RlID49IDY1ICYmIGNvZGUgPD0gOTA7XG59XG5mdW5jdGlvbiBpc05hbWVTdGFydChjb2RlKSB7XG4gIHJldHVybiBpc0xldHRlcihjb2RlKSB8fCBjb2RlID09PSA5NTtcbn1cbmZ1bmN0aW9uIGlzTmFtZUNvbnRpbnVlKGNvZGUpIHtcbiAgcmV0dXJuIGlzTGV0dGVyKGNvZGUpIHx8IGlzRGlnaXQoY29kZSkgfHwgY29kZSA9PT0gOTU7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9ibG9ja1N0cmluZy5tanNcbmZ1bmN0aW9uIGRlZGVudEJsb2NrU3RyaW5nTGluZXMobGluZXMpIHtcbiAgdmFyIF9maXJzdE5vbkVtcHR5TGluZTI7XG4gIGxldCBjb21tb25JbmRlbnQgPSBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUjtcbiAgbGV0IGZpcnN0Tm9uRW1wdHlMaW5lID0gbnVsbDtcbiAgbGV0IGxhc3ROb25FbXB0eUxpbmUgPSAtMTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGg7ICsraSkge1xuICAgIHZhciBfZmlyc3ROb25FbXB0eUxpbmU7XG4gICAgY29uc3QgbGluZSA9IGxpbmVzW2ldO1xuICAgIGNvbnN0IGluZGVudDIgPSBsZWFkaW5nV2hpdGVzcGFjZShsaW5lKTtcbiAgICBpZiAoaW5kZW50MiA9PT0gbGluZS5sZW5ndGgpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBmaXJzdE5vbkVtcHR5TGluZSA9IChfZmlyc3ROb25FbXB0eUxpbmUgPSBmaXJzdE5vbkVtcHR5TGluZSkgIT09IG51bGwgJiYgX2ZpcnN0Tm9uRW1wdHlMaW5lICE9PSB2b2lkIDAgPyBfZmlyc3ROb25FbXB0eUxpbmUgOiBpO1xuICAgIGxhc3ROb25FbXB0eUxpbmUgPSBpO1xuICAgIGlmIChpICE9PSAwICYmIGluZGVudDIgPCBjb21tb25JbmRlbnQpIHtcbiAgICAgIGNvbW1vbkluZGVudCA9IGluZGVudDI7XG4gICAgfVxuICB9XG4gIHJldHVybiBsaW5lcy5tYXAoKGxpbmUsIGkpID0+IGkgPT09IDAgPyBsaW5lIDogbGluZS5zbGljZShjb21tb25JbmRlbnQpKS5zbGljZShcbiAgICAoX2ZpcnN0Tm9uRW1wdHlMaW5lMiA9IGZpcnN0Tm9uRW1wdHlMaW5lKSAhPT0gbnVsbCAmJiBfZmlyc3ROb25FbXB0eUxpbmUyICE9PSB2b2lkIDAgPyBfZmlyc3ROb25FbXB0eUxpbmUyIDogMCxcbiAgICBsYXN0Tm9uRW1wdHlMaW5lICsgMVxuICApO1xufVxuZnVuY3Rpb24gbGVhZGluZ1doaXRlc3BhY2Uoc3RyKSB7XG4gIGxldCBpID0gMDtcbiAgd2hpbGUgKGkgPCBzdHIubGVuZ3RoICYmIGlzV2hpdGVTcGFjZShzdHIuY2hhckNvZGVBdChpKSkpIHtcbiAgICArK2k7XG4gIH1cbiAgcmV0dXJuIGk7XG59XG5mdW5jdGlvbiBwcmludEJsb2NrU3RyaW5nKHZhbHVlLCBvcHRpb25zKSB7XG4gIGNvbnN0IGVzY2FwZWRWYWx1ZSA9IHZhbHVlLnJlcGxhY2UoL1wiXCJcIi9nLCAnXFxcXFwiXCJcIicpO1xuICBjb25zdCBsaW5lcyA9IGVzY2FwZWRWYWx1ZS5zcGxpdCgvXFxyXFxufFtcXG5cXHJdL2cpO1xuICBjb25zdCBpc1NpbmdsZUxpbmUgPSBsaW5lcy5sZW5ndGggPT09IDE7XG4gIGNvbnN0IGZvcmNlTGVhZGluZ05ld0xpbmUgPSBsaW5lcy5sZW5ndGggPiAxICYmIGxpbmVzLnNsaWNlKDEpLmV2ZXJ5KChsaW5lKSA9PiBsaW5lLmxlbmd0aCA9PT0gMCB8fCBpc1doaXRlU3BhY2UobGluZS5jaGFyQ29kZUF0KDApKSk7XG4gIGNvbnN0IGhhc1RyYWlsaW5nVHJpcGxlUXVvdGVzID0gZXNjYXBlZFZhbHVlLmVuZHNXaXRoKCdcXFxcXCJcIlwiJyk7XG4gIGNvbnN0IGhhc1RyYWlsaW5nUXVvdGUgPSB2YWx1ZS5lbmRzV2l0aCgnXCInKSAmJiAhaGFzVHJhaWxpbmdUcmlwbGVRdW90ZXM7XG4gIGNvbnN0IGhhc1RyYWlsaW5nU2xhc2ggPSB2YWx1ZS5lbmRzV2l0aChcIlxcXFxcIik7XG4gIGNvbnN0IGZvcmNlVHJhaWxpbmdOZXdsaW5lID0gaGFzVHJhaWxpbmdRdW90ZSB8fCBoYXNUcmFpbGluZ1NsYXNoO1xuICBjb25zdCBwcmludEFzTXVsdGlwbGVMaW5lcyA9ICEob3B0aW9ucyAhPT0gbnVsbCAmJiBvcHRpb25zICE9PSB2b2lkIDAgJiYgb3B0aW9ucy5taW5pbWl6ZSkgJiYgLy8gYWRkIGxlYWRpbmcgYW5kIHRyYWlsaW5nIG5ldyBsaW5lcyBvbmx5IGlmIGl0IGltcHJvdmVzIHJlYWRhYmlsaXR5XG4gICghaXNTaW5nbGVMaW5lIHx8IHZhbHVlLmxlbmd0aCA+IDcwIHx8IGZvcmNlVHJhaWxpbmdOZXdsaW5lIHx8IGZvcmNlTGVhZGluZ05ld0xpbmUgfHwgaGFzVHJhaWxpbmdUcmlwbGVRdW90ZXMpO1xuICBsZXQgcmVzdWx0ID0gXCJcIjtcbiAgY29uc3Qgc2tpcExlYWRpbmdOZXdMaW5lID0gaXNTaW5nbGVMaW5lICYmIGlzV2hpdGVTcGFjZSh2YWx1ZS5jaGFyQ29kZUF0KDApKTtcbiAgaWYgKHByaW50QXNNdWx0aXBsZUxpbmVzICYmICFza2lwTGVhZGluZ05ld0xpbmUgfHwgZm9yY2VMZWFkaW5nTmV3TGluZSkge1xuICAgIHJlc3VsdCArPSBcIlxcblwiO1xuICB9XG4gIHJlc3VsdCArPSBlc2NhcGVkVmFsdWU7XG4gIGlmIChwcmludEFzTXVsdGlwbGVMaW5lcyB8fCBmb3JjZVRyYWlsaW5nTmV3bGluZSkge1xuICAgIHJlc3VsdCArPSBcIlxcblwiO1xuICB9XG4gIHJldHVybiAnXCJcIlwiJyArIHJlc3VsdCArICdcIlwiXCInO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2UvdG9rZW5LaW5kLm1qc1xudmFyIFRva2VuS2luZDtcbihmdW5jdGlvbihUb2tlbktpbmQyKSB7XG4gIFRva2VuS2luZDJbXCJTT0ZcIl0gPSBcIjxTT0Y+XCI7XG4gIFRva2VuS2luZDJbXCJFT0ZcIl0gPSBcIjxFT0Y+XCI7XG4gIFRva2VuS2luZDJbXCJCQU5HXCJdID0gXCIhXCI7XG4gIFRva2VuS2luZDJbXCJET0xMQVJcIl0gPSBcIiRcIjtcbiAgVG9rZW5LaW5kMltcIkFNUFwiXSA9IFwiJlwiO1xuICBUb2tlbktpbmQyW1wiUEFSRU5fTFwiXSA9IFwiKFwiO1xuICBUb2tlbktpbmQyW1wiUEFSRU5fUlwiXSA9IFwiKVwiO1xuICBUb2tlbktpbmQyW1wiU1BSRUFEXCJdID0gXCIuLi5cIjtcbiAgVG9rZW5LaW5kMltcIkNPTE9OXCJdID0gXCI6XCI7XG4gIFRva2VuS2luZDJbXCJFUVVBTFNcIl0gPSBcIj1cIjtcbiAgVG9rZW5LaW5kMltcIkFUXCJdID0gXCJAXCI7XG4gIFRva2VuS2luZDJbXCJCUkFDS0VUX0xcIl0gPSBcIltcIjtcbiAgVG9rZW5LaW5kMltcIkJSQUNLRVRfUlwiXSA9IFwiXVwiO1xuICBUb2tlbktpbmQyW1wiQlJBQ0VfTFwiXSA9IFwie1wiO1xuICBUb2tlbktpbmQyW1wiUElQRVwiXSA9IFwifFwiO1xuICBUb2tlbktpbmQyW1wiQlJBQ0VfUlwiXSA9IFwifVwiO1xuICBUb2tlbktpbmQyW1wiTkFNRVwiXSA9IFwiTmFtZVwiO1xuICBUb2tlbktpbmQyW1wiSU5UXCJdID0gXCJJbnRcIjtcbiAgVG9rZW5LaW5kMltcIkZMT0FUXCJdID0gXCJGbG9hdFwiO1xuICBUb2tlbktpbmQyW1wiU1RSSU5HXCJdID0gXCJTdHJpbmdcIjtcbiAgVG9rZW5LaW5kMltcIkJMT0NLX1NUUklOR1wiXSA9IFwiQmxvY2tTdHJpbmdcIjtcbiAgVG9rZW5LaW5kMltcIkNPTU1FTlRcIl0gPSBcIkNvbW1lbnRcIjtcbn0pKFRva2VuS2luZCB8fCAoVG9rZW5LaW5kID0ge30pKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL2xleGVyLm1qc1xudmFyIExleGVyID0gY2xhc3Mge1xuICAvKipcbiAgICogVGhlIHByZXZpb3VzbHkgZm9jdXNlZCBub24taWdub3JlZCB0b2tlbi5cbiAgICovXG4gIC8qKlxuICAgKiBUaGUgY3VycmVudGx5IGZvY3VzZWQgbm9uLWlnbm9yZWQgdG9rZW4uXG4gICAqL1xuICAvKipcbiAgICogVGhlICgxLWluZGV4ZWQpIGxpbmUgY29udGFpbmluZyB0aGUgY3VycmVudCB0b2tlbi5cbiAgICovXG4gIC8qKlxuICAgKiBUaGUgY2hhcmFjdGVyIG9mZnNldCBhdCB3aGljaCB0aGUgY3VycmVudCBsaW5lIGJlZ2lucy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHNvdXJjZSkge1xuICAgIGNvbnN0IHN0YXJ0T2ZGaWxlVG9rZW4gPSBuZXcgVG9rZW4oVG9rZW5LaW5kLlNPRiwgMCwgMCwgMCwgMCk7XG4gICAgdGhpcy5zb3VyY2UgPSBzb3VyY2U7XG4gICAgdGhpcy5sYXN0VG9rZW4gPSBzdGFydE9mRmlsZVRva2VuO1xuICAgIHRoaXMudG9rZW4gPSBzdGFydE9mRmlsZVRva2VuO1xuICAgIHRoaXMubGluZSA9IDE7XG4gICAgdGhpcy5saW5lU3RhcnQgPSAwO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJMZXhlclwiO1xuICB9XG4gIC8qKlxuICAgKiBBZHZhbmNlcyB0aGUgdG9rZW4gc3RyZWFtIHRvIHRoZSBuZXh0IG5vbi1pZ25vcmVkIHRva2VuLlxuICAgKi9cbiAgYWR2YW5jZSgpIHtcbiAgICB0aGlzLmxhc3RUb2tlbiA9IHRoaXMudG9rZW47XG4gICAgY29uc3QgdG9rZW4gPSB0aGlzLnRva2VuID0gdGhpcy5sb29rYWhlYWQoKTtcbiAgICByZXR1cm4gdG9rZW47XG4gIH1cbiAgLyoqXG4gICAqIExvb2tzIGFoZWFkIGFuZCByZXR1cm5zIHRoZSBuZXh0IG5vbi1pZ25vcmVkIHRva2VuLCBidXQgZG9lcyBub3QgY2hhbmdlXG4gICAqIHRoZSBzdGF0ZSBvZiBMZXhlci5cbiAgICovXG4gIGxvb2thaGVhZCgpIHtcbiAgICBsZXQgdG9rZW4gPSB0aGlzLnRva2VuO1xuICAgIGlmICh0b2tlbi5raW5kICE9PSBUb2tlbktpbmQuRU9GKSB7XG4gICAgICBkbyB7XG4gICAgICAgIGlmICh0b2tlbi5uZXh0KSB7XG4gICAgICAgICAgdG9rZW4gPSB0b2tlbi5uZXh0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IG5leHRUb2tlbiA9IHJlYWROZXh0VG9rZW4odGhpcywgdG9rZW4uZW5kKTtcbiAgICAgICAgICB0b2tlbi5uZXh0ID0gbmV4dFRva2VuO1xuICAgICAgICAgIG5leHRUb2tlbi5wcmV2ID0gdG9rZW47XG4gICAgICAgICAgdG9rZW4gPSBuZXh0VG9rZW47XG4gICAgICAgIH1cbiAgICAgIH0gd2hpbGUgKHRva2VuLmtpbmQgPT09IFRva2VuS2luZC5DT01NRU5UKTtcbiAgICB9XG4gICAgcmV0dXJuIHRva2VuO1xuICB9XG59O1xuZnVuY3Rpb24gaXNQdW5jdHVhdG9yVG9rZW5LaW5kKGtpbmQpIHtcbiAgcmV0dXJuIGtpbmQgPT09IFRva2VuS2luZC5CQU5HIHx8IGtpbmQgPT09IFRva2VuS2luZC5ET0xMQVIgfHwga2luZCA9PT0gVG9rZW5LaW5kLkFNUCB8fCBraW5kID09PSBUb2tlbktpbmQuUEFSRU5fTCB8fCBraW5kID09PSBUb2tlbktpbmQuUEFSRU5fUiB8fCBraW5kID09PSBUb2tlbktpbmQuU1BSRUFEIHx8IGtpbmQgPT09IFRva2VuS2luZC5DT0xPTiB8fCBraW5kID09PSBUb2tlbktpbmQuRVFVQUxTIHx8IGtpbmQgPT09IFRva2VuS2luZC5BVCB8fCBraW5kID09PSBUb2tlbktpbmQuQlJBQ0tFVF9MIHx8IGtpbmQgPT09IFRva2VuS2luZC5CUkFDS0VUX1IgfHwga2luZCA9PT0gVG9rZW5LaW5kLkJSQUNFX0wgfHwga2luZCA9PT0gVG9rZW5LaW5kLlBJUEUgfHwga2luZCA9PT0gVG9rZW5LaW5kLkJSQUNFX1I7XG59XG5mdW5jdGlvbiBpc1VuaWNvZGVTY2FsYXJWYWx1ZShjb2RlKSB7XG4gIHJldHVybiBjb2RlID49IDAgJiYgY29kZSA8PSA1NTI5NSB8fCBjb2RlID49IDU3MzQ0ICYmIGNvZGUgPD0gMTExNDExMTtcbn1cbmZ1bmN0aW9uIGlzU3VwcGxlbWVudGFyeUNvZGVQb2ludChib2R5LCBsb2NhdGlvbjIpIHtcbiAgcmV0dXJuIGlzTGVhZGluZ1N1cnJvZ2F0ZShib2R5LmNoYXJDb2RlQXQobG9jYXRpb24yKSkgJiYgaXNUcmFpbGluZ1N1cnJvZ2F0ZShib2R5LmNoYXJDb2RlQXQobG9jYXRpb24yICsgMSkpO1xufVxuZnVuY3Rpb24gaXNMZWFkaW5nU3Vycm9nYXRlKGNvZGUpIHtcbiAgcmV0dXJuIGNvZGUgPj0gNTUyOTYgJiYgY29kZSA8PSA1NjMxOTtcbn1cbmZ1bmN0aW9uIGlzVHJhaWxpbmdTdXJyb2dhdGUoY29kZSkge1xuICByZXR1cm4gY29kZSA+PSA1NjMyMCAmJiBjb2RlIDw9IDU3MzQzO1xufVxuZnVuY3Rpb24gcHJpbnRDb2RlUG9pbnRBdChsZXhlcjIsIGxvY2F0aW9uMikge1xuICBjb25zdCBjb2RlID0gbGV4ZXIyLnNvdXJjZS5ib2R5LmNvZGVQb2ludEF0KGxvY2F0aW9uMik7XG4gIGlmIChjb2RlID09PSB2b2lkIDApIHtcbiAgICByZXR1cm4gVG9rZW5LaW5kLkVPRjtcbiAgfSBlbHNlIGlmIChjb2RlID49IDMyICYmIGNvZGUgPD0gMTI2KSB7XG4gICAgY29uc3QgY2hhciA9IFN0cmluZy5mcm9tQ29kZVBvaW50KGNvZGUpO1xuICAgIHJldHVybiBjaGFyID09PSAnXCInID8gYCdcIidgIDogYFwiJHtjaGFyfVwiYDtcbiAgfVxuICByZXR1cm4gXCJVK1wiICsgY29kZS50b1N0cmluZygxNikudG9VcHBlckNhc2UoKS5wYWRTdGFydCg0LCBcIjBcIik7XG59XG5mdW5jdGlvbiBjcmVhdGVUb2tlbihsZXhlcjIsIGtpbmQsIHN0YXJ0LCBlbmQsIHZhbHVlKSB7XG4gIGNvbnN0IGxpbmUgPSBsZXhlcjIubGluZTtcbiAgY29uc3QgY29sID0gMSArIHN0YXJ0IC0gbGV4ZXIyLmxpbmVTdGFydDtcbiAgcmV0dXJuIG5ldyBUb2tlbihraW5kLCBzdGFydCwgZW5kLCBsaW5lLCBjb2wsIHZhbHVlKTtcbn1cbmZ1bmN0aW9uIHJlYWROZXh0VG9rZW4obGV4ZXIyLCBzdGFydCkge1xuICBjb25zdCBib2R5ID0gbGV4ZXIyLnNvdXJjZS5ib2R5O1xuICBjb25zdCBib2R5TGVuZ3RoID0gYm9keS5sZW5ndGg7XG4gIGxldCBwb3NpdGlvbiA9IHN0YXJ0O1xuICB3aGlsZSAocG9zaXRpb24gPCBib2R5TGVuZ3RoKSB7XG4gICAgY29uc3QgY29kZSA9IGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbik7XG4gICAgc3dpdGNoIChjb2RlKSB7XG4gICAgICBjYXNlIDY1Mjc5OlxuICAgICAgY2FzZSA5OlxuICAgICAgY2FzZSAzMjpcbiAgICAgIGNhc2UgNDQ6XG4gICAgICAgICsrcG9zaXRpb247XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgY2FzZSAxMDpcbiAgICAgICAgKytwb3NpdGlvbjtcbiAgICAgICAgKytsZXhlcjIubGluZTtcbiAgICAgICAgbGV4ZXIyLmxpbmVTdGFydCA9IHBvc2l0aW9uO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNhc2UgMTM6XG4gICAgICAgIGlmIChib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAxKSA9PT0gMTApIHtcbiAgICAgICAgICBwb3NpdGlvbiArPSAyO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICsrcG9zaXRpb247XG4gICAgICAgIH1cbiAgICAgICAgKytsZXhlcjIubGluZTtcbiAgICAgICAgbGV4ZXIyLmxpbmVTdGFydCA9IHBvc2l0aW9uO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNhc2UgMzU6XG4gICAgICAgIHJldHVybiByZWFkQ29tbWVudChsZXhlcjIsIHBvc2l0aW9uKTtcbiAgICAgIGNhc2UgMzM6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5CQU5HLCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgMzY6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5ET0xMQVIsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSAzODpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLkFNUCwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDQwOlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuUEFSRU5fTCwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDQxOlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuUEFSRU5fUiwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDQ2OlxuICAgICAgICBpZiAoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkgPT09IDQ2ICYmIGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDIpID09PSA0Nikge1xuICAgICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5TUFJFQUQsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDMpO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSA1ODpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLkNPTE9OLCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgNjE6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5FUVVBTFMsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSA2NDpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLkFULCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgOTE6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5CUkFDS0VUX0wsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSA5MzpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLkJSQUNLRVRfUiwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDEyMzpcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLkJSQUNFX0wsIHBvc2l0aW9uLCBwb3NpdGlvbiArIDEpO1xuICAgICAgY2FzZSAxMjQ6XG4gICAgICAgIHJldHVybiBjcmVhdGVUb2tlbihsZXhlcjIsIFRva2VuS2luZC5QSVBFLCBwb3NpdGlvbiwgcG9zaXRpb24gKyAxKTtcbiAgICAgIGNhc2UgMTI1OlxuICAgICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuQlJBQ0VfUiwgcG9zaXRpb24sIHBvc2l0aW9uICsgMSk7XG4gICAgICBjYXNlIDM0OlxuICAgICAgICBpZiAoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkgPT09IDM0ICYmIGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDIpID09PSAzNCkge1xuICAgICAgICAgIHJldHVybiByZWFkQmxvY2tTdHJpbmcobGV4ZXIyLCBwb3NpdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlYWRTdHJpbmcobGV4ZXIyLCBwb3NpdGlvbik7XG4gICAgfVxuICAgIGlmIChpc0RpZ2l0KGNvZGUpIHx8IGNvZGUgPT09IDQ1KSB7XG4gICAgICByZXR1cm4gcmVhZE51bWJlcihsZXhlcjIsIHBvc2l0aW9uLCBjb2RlKTtcbiAgICB9XG4gICAgaWYgKGlzTmFtZVN0YXJ0KGNvZGUpKSB7XG4gICAgICByZXR1cm4gcmVhZE5hbWUobGV4ZXIyLCBwb3NpdGlvbik7XG4gICAgfVxuICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgbGV4ZXIyLnNvdXJjZSxcbiAgICAgIHBvc2l0aW9uLFxuICAgICAgY29kZSA9PT0gMzkgPyBgVW5leHBlY3RlZCBzaW5nbGUgcXVvdGUgY2hhcmFjdGVyICgnKSwgZGlkIHlvdSBtZWFuIHRvIHVzZSBhIGRvdWJsZSBxdW90ZSAoXCIpP2AgOiBpc1VuaWNvZGVTY2FsYXJWYWx1ZShjb2RlKSB8fCBpc1N1cHBsZW1lbnRhcnlDb2RlUG9pbnQoYm9keSwgcG9zaXRpb24pID8gYFVuZXhwZWN0ZWQgY2hhcmFjdGVyOiAke3ByaW50Q29kZVBvaW50QXQobGV4ZXIyLCBwb3NpdGlvbil9LmAgOiBgSW52YWxpZCBjaGFyYWN0ZXI6ICR7cHJpbnRDb2RlUG9pbnRBdChsZXhlcjIsIHBvc2l0aW9uKX0uYFxuICAgICk7XG4gIH1cbiAgcmV0dXJuIGNyZWF0ZVRva2VuKGxleGVyMiwgVG9rZW5LaW5kLkVPRiwgYm9keUxlbmd0aCwgYm9keUxlbmd0aCk7XG59XG5mdW5jdGlvbiByZWFkQ29tbWVudChsZXhlcjIsIHN0YXJ0KSB7XG4gIGNvbnN0IGJvZHkgPSBsZXhlcjIuc291cmNlLmJvZHk7XG4gIGNvbnN0IGJvZHlMZW5ndGggPSBib2R5Lmxlbmd0aDtcbiAgbGV0IHBvc2l0aW9uID0gc3RhcnQgKyAxO1xuICB3aGlsZSAocG9zaXRpb24gPCBib2R5TGVuZ3RoKSB7XG4gICAgY29uc3QgY29kZSA9IGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbik7XG4gICAgaWYgKGNvZGUgPT09IDEwIHx8IGNvZGUgPT09IDEzKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgaWYgKGlzVW5pY29kZVNjYWxhclZhbHVlKGNvZGUpKSB7XG4gICAgICArK3Bvc2l0aW9uO1xuICAgIH0gZWxzZSBpZiAoaXNTdXBwbGVtZW50YXJ5Q29kZVBvaW50KGJvZHksIHBvc2l0aW9uKSkge1xuICAgICAgcG9zaXRpb24gKz0gMjtcbiAgICB9IGVsc2Uge1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIHJldHVybiBjcmVhdGVUb2tlbihcbiAgICBsZXhlcjIsXG4gICAgVG9rZW5LaW5kLkNPTU1FTlQsXG4gICAgc3RhcnQsXG4gICAgcG9zaXRpb24sXG4gICAgYm9keS5zbGljZShzdGFydCArIDEsIHBvc2l0aW9uKVxuICApO1xufVxuZnVuY3Rpb24gcmVhZE51bWJlcihsZXhlcjIsIHN0YXJ0LCBmaXJzdENvZGUpIHtcbiAgY29uc3QgYm9keSA9IGxleGVyMi5zb3VyY2UuYm9keTtcbiAgbGV0IHBvc2l0aW9uID0gc3RhcnQ7XG4gIGxldCBjb2RlID0gZmlyc3RDb2RlO1xuICBsZXQgaXNGbG9hdCA9IGZhbHNlO1xuICBpZiAoY29kZSA9PT0gNDUpIHtcbiAgICBjb2RlID0gYm9keS5jaGFyQ29kZUF0KCsrcG9zaXRpb24pO1xuICB9XG4gIGlmIChjb2RlID09PSA0OCkge1xuICAgIGNvZGUgPSBib2R5LmNoYXJDb2RlQXQoKytwb3NpdGlvbik7XG4gICAgaWYgKGlzRGlnaXQoY29kZSkpIHtcbiAgICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgICBsZXhlcjIuc291cmNlLFxuICAgICAgICBwb3NpdGlvbixcbiAgICAgICAgYEludmFsaWQgbnVtYmVyLCB1bmV4cGVjdGVkIGRpZ2l0IGFmdGVyIDA6ICR7cHJpbnRDb2RlUG9pbnRBdChcbiAgICAgICAgICBsZXhlcjIsXG4gICAgICAgICAgcG9zaXRpb25cbiAgICAgICAgKX0uYFxuICAgICAgKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcG9zaXRpb24gPSByZWFkRGlnaXRzKGxleGVyMiwgcG9zaXRpb24sIGNvZGUpO1xuICAgIGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICB9XG4gIGlmIChjb2RlID09PSA0Nikge1xuICAgIGlzRmxvYXQgPSB0cnVlO1xuICAgIGNvZGUgPSBib2R5LmNoYXJDb2RlQXQoKytwb3NpdGlvbik7XG4gICAgcG9zaXRpb24gPSByZWFkRGlnaXRzKGxleGVyMiwgcG9zaXRpb24sIGNvZGUpO1xuICAgIGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICB9XG4gIGlmIChjb2RlID09PSA2OSB8fCBjb2RlID09PSAxMDEpIHtcbiAgICBpc0Zsb2F0ID0gdHJ1ZTtcbiAgICBjb2RlID0gYm9keS5jaGFyQ29kZUF0KCsrcG9zaXRpb24pO1xuICAgIGlmIChjb2RlID09PSA0MyB8fCBjb2RlID09PSA0NSkge1xuICAgICAgY29kZSA9IGJvZHkuY2hhckNvZGVBdCgrK3Bvc2l0aW9uKTtcbiAgICB9XG4gICAgcG9zaXRpb24gPSByZWFkRGlnaXRzKGxleGVyMiwgcG9zaXRpb24sIGNvZGUpO1xuICAgIGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICB9XG4gIGlmIChjb2RlID09PSA0NiB8fCBpc05hbWVTdGFydChjb2RlKSkge1xuICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgbGV4ZXIyLnNvdXJjZSxcbiAgICAgIHBvc2l0aW9uLFxuICAgICAgYEludmFsaWQgbnVtYmVyLCBleHBlY3RlZCBkaWdpdCBidXQgZ290OiAke3ByaW50Q29kZVBvaW50QXQoXG4gICAgICAgIGxleGVyMixcbiAgICAgICAgcG9zaXRpb25cbiAgICAgICl9LmBcbiAgICApO1xuICB9XG4gIHJldHVybiBjcmVhdGVUb2tlbihcbiAgICBsZXhlcjIsXG4gICAgaXNGbG9hdCA/IFRva2VuS2luZC5GTE9BVCA6IFRva2VuS2luZC5JTlQsXG4gICAgc3RhcnQsXG4gICAgcG9zaXRpb24sXG4gICAgYm9keS5zbGljZShzdGFydCwgcG9zaXRpb24pXG4gICk7XG59XG5mdW5jdGlvbiByZWFkRGlnaXRzKGxleGVyMiwgc3RhcnQsIGZpcnN0Q29kZSkge1xuICBpZiAoIWlzRGlnaXQoZmlyc3RDb2RlKSkge1xuICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgbGV4ZXIyLnNvdXJjZSxcbiAgICAgIHN0YXJ0LFxuICAgICAgYEludmFsaWQgbnVtYmVyLCBleHBlY3RlZCBkaWdpdCBidXQgZ290OiAke3ByaW50Q29kZVBvaW50QXQoXG4gICAgICAgIGxleGVyMixcbiAgICAgICAgc3RhcnRcbiAgICAgICl9LmBcbiAgICApO1xuICB9XG4gIGNvbnN0IGJvZHkgPSBsZXhlcjIuc291cmNlLmJvZHk7XG4gIGxldCBwb3NpdGlvbiA9IHN0YXJ0ICsgMTtcbiAgd2hpbGUgKGlzRGlnaXQoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKSkpIHtcbiAgICArK3Bvc2l0aW9uO1xuICB9XG4gIHJldHVybiBwb3NpdGlvbjtcbn1cbmZ1bmN0aW9uIHJlYWRTdHJpbmcobGV4ZXIyLCBzdGFydCkge1xuICBjb25zdCBib2R5ID0gbGV4ZXIyLnNvdXJjZS5ib2R5O1xuICBjb25zdCBib2R5TGVuZ3RoID0gYm9keS5sZW5ndGg7XG4gIGxldCBwb3NpdGlvbiA9IHN0YXJ0ICsgMTtcbiAgbGV0IGNodW5rU3RhcnQgPSBwb3NpdGlvbjtcbiAgbGV0IHZhbHVlID0gXCJcIjtcbiAgd2hpbGUgKHBvc2l0aW9uIDwgYm9keUxlbmd0aCkge1xuICAgIGNvbnN0IGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICAgIGlmIChjb2RlID09PSAzNCkge1xuICAgICAgdmFsdWUgKz0gYm9keS5zbGljZShjaHVua1N0YXJ0LCBwb3NpdGlvbik7XG4gICAgICByZXR1cm4gY3JlYXRlVG9rZW4obGV4ZXIyLCBUb2tlbktpbmQuU1RSSU5HLCBzdGFydCwgcG9zaXRpb24gKyAxLCB2YWx1ZSk7XG4gICAgfVxuICAgIGlmIChjb2RlID09PSA5Mikge1xuICAgICAgdmFsdWUgKz0gYm9keS5zbGljZShjaHVua1N0YXJ0LCBwb3NpdGlvbik7XG4gICAgICBjb25zdCBlc2NhcGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAxKSA9PT0gMTE3ID8gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMikgPT09IDEyMyA/IHJlYWRFc2NhcGVkVW5pY29kZVZhcmlhYmxlV2lkdGgobGV4ZXIyLCBwb3NpdGlvbikgOiByZWFkRXNjYXBlZFVuaWNvZGVGaXhlZFdpZHRoKGxleGVyMiwgcG9zaXRpb24pIDogcmVhZEVzY2FwZWRDaGFyYWN0ZXIobGV4ZXIyLCBwb3NpdGlvbik7XG4gICAgICB2YWx1ZSArPSBlc2NhcGUudmFsdWU7XG4gICAgICBwb3NpdGlvbiArPSBlc2NhcGUuc2l6ZTtcbiAgICAgIGNodW5rU3RhcnQgPSBwb3NpdGlvbjtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY29kZSA9PT0gMTAgfHwgY29kZSA9PT0gMTMpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBpZiAoaXNVbmljb2RlU2NhbGFyVmFsdWUoY29kZSkpIHtcbiAgICAgICsrcG9zaXRpb247XG4gICAgfSBlbHNlIGlmIChpc1N1cHBsZW1lbnRhcnlDb2RlUG9pbnQoYm9keSwgcG9zaXRpb24pKSB7XG4gICAgICBwb3NpdGlvbiArPSAyO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgICAgbGV4ZXIyLnNvdXJjZSxcbiAgICAgICAgcG9zaXRpb24sXG4gICAgICAgIGBJbnZhbGlkIGNoYXJhY3RlciB3aXRoaW4gU3RyaW5nOiAke3ByaW50Q29kZVBvaW50QXQoXG4gICAgICAgICAgbGV4ZXIyLFxuICAgICAgICAgIHBvc2l0aW9uXG4gICAgICAgICl9LmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIHRocm93IHN5bnRheEVycm9yKGxleGVyMi5zb3VyY2UsIHBvc2l0aW9uLCBcIlVudGVybWluYXRlZCBzdHJpbmcuXCIpO1xufVxuZnVuY3Rpb24gcmVhZEVzY2FwZWRVbmljb2RlVmFyaWFibGVXaWR0aChsZXhlcjIsIHBvc2l0aW9uKSB7XG4gIGNvbnN0IGJvZHkgPSBsZXhlcjIuc291cmNlLmJvZHk7XG4gIGxldCBwb2ludCA9IDA7XG4gIGxldCBzaXplID0gMztcbiAgd2hpbGUgKHNpemUgPCAxMikge1xuICAgIGNvbnN0IGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyBzaXplKyspO1xuICAgIGlmIChjb2RlID09PSAxMjUpIHtcbiAgICAgIGlmIChzaXplIDwgNSB8fCAhaXNVbmljb2RlU2NhbGFyVmFsdWUocG9pbnQpKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6IFN0cmluZy5mcm9tQ29kZVBvaW50KHBvaW50KSxcbiAgICAgICAgc2l6ZVxuICAgICAgfTtcbiAgICB9XG4gICAgcG9pbnQgPSBwb2ludCA8PCA0IHwgcmVhZEhleERpZ2l0KGNvZGUpO1xuICAgIGlmIChwb2ludCA8IDApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICBsZXhlcjIuc291cmNlLFxuICAgIHBvc2l0aW9uLFxuICAgIGBJbnZhbGlkIFVuaWNvZGUgZXNjYXBlIHNlcXVlbmNlOiBcIiR7Ym9keS5zbGljZShcbiAgICAgIHBvc2l0aW9uLFxuICAgICAgcG9zaXRpb24gKyBzaXplXG4gICAgKX1cIi5gXG4gICk7XG59XG5mdW5jdGlvbiByZWFkRXNjYXBlZFVuaWNvZGVGaXhlZFdpZHRoKGxleGVyMiwgcG9zaXRpb24pIHtcbiAgY29uc3QgYm9keSA9IGxleGVyMi5zb3VyY2UuYm9keTtcbiAgY29uc3QgY29kZSA9IHJlYWQxNkJpdEhleENvZGUoYm9keSwgcG9zaXRpb24gKyAyKTtcbiAgaWYgKGlzVW5pY29kZVNjYWxhclZhbHVlKGNvZGUpKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHZhbHVlOiBTdHJpbmcuZnJvbUNvZGVQb2ludChjb2RlKSxcbiAgICAgIHNpemU6IDZcbiAgICB9O1xuICB9XG4gIGlmIChpc0xlYWRpbmdTdXJyb2dhdGUoY29kZSkpIHtcbiAgICBpZiAoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgNikgPT09IDkyICYmIGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDcpID09PSAxMTcpIHtcbiAgICAgIGNvbnN0IHRyYWlsaW5nQ29kZSA9IHJlYWQxNkJpdEhleENvZGUoYm9keSwgcG9zaXRpb24gKyA4KTtcbiAgICAgIGlmIChpc1RyYWlsaW5nU3Vycm9nYXRlKHRyYWlsaW5nQ29kZSkpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB2YWx1ZTogU3RyaW5nLmZyb21Db2RlUG9pbnQoY29kZSwgdHJhaWxpbmdDb2RlKSxcbiAgICAgICAgICBzaXplOiAxMlxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICBsZXhlcjIuc291cmNlLFxuICAgIHBvc2l0aW9uLFxuICAgIGBJbnZhbGlkIFVuaWNvZGUgZXNjYXBlIHNlcXVlbmNlOiBcIiR7Ym9keS5zbGljZShwb3NpdGlvbiwgcG9zaXRpb24gKyA2KX1cIi5gXG4gICk7XG59XG5mdW5jdGlvbiByZWFkMTZCaXRIZXhDb2RlKGJvZHksIHBvc2l0aW9uKSB7XG4gIHJldHVybiByZWFkSGV4RGlnaXQoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKSkgPDwgMTIgfCByZWFkSGV4RGlnaXQoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkpIDw8IDggfCByZWFkSGV4RGlnaXQoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMikpIDw8IDQgfCByZWFkSGV4RGlnaXQoYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMykpO1xufVxuZnVuY3Rpb24gcmVhZEhleERpZ2l0KGNvZGUpIHtcbiAgcmV0dXJuIGNvZGUgPj0gNDggJiYgY29kZSA8PSA1NyA/IGNvZGUgLSA0OCA6IGNvZGUgPj0gNjUgJiYgY29kZSA8PSA3MCA/IGNvZGUgLSA1NSA6IGNvZGUgPj0gOTcgJiYgY29kZSA8PSAxMDIgPyBjb2RlIC0gODcgOiAtMTtcbn1cbmZ1bmN0aW9uIHJlYWRFc2NhcGVkQ2hhcmFjdGVyKGxleGVyMiwgcG9zaXRpb24pIHtcbiAgY29uc3QgYm9keSA9IGxleGVyMi5zb3VyY2UuYm9keTtcbiAgY29uc3QgY29kZSA9IGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDEpO1xuICBzd2l0Y2ggKGNvZGUpIHtcbiAgICBjYXNlIDM0OlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6ICdcIicsXG4gICAgICAgIHNpemU6IDJcbiAgICAgIH07XG4gICAgY2FzZSA5MjpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiBcIlxcXFxcIixcbiAgICAgICAgc2l6ZTogMlxuICAgICAgfTtcbiAgICBjYXNlIDQ3OlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6IFwiL1wiLFxuICAgICAgICBzaXplOiAyXG4gICAgICB9O1xuICAgIGNhc2UgOTg6XG4gICAgICByZXR1cm4ge1xuICAgICAgICB2YWx1ZTogXCJcXGJcIixcbiAgICAgICAgc2l6ZTogMlxuICAgICAgfTtcbiAgICBjYXNlIDEwMjpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiBcIlxcZlwiLFxuICAgICAgICBzaXplOiAyXG4gICAgICB9O1xuICAgIGNhc2UgMTEwOlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdmFsdWU6IFwiXFxuXCIsXG4gICAgICAgIHNpemU6IDJcbiAgICAgIH07XG4gICAgY2FzZSAxMTQ6XG4gICAgICByZXR1cm4ge1xuICAgICAgICB2YWx1ZTogXCJcXHJcIixcbiAgICAgICAgc2l6ZTogMlxuICAgICAgfTtcbiAgICBjYXNlIDExNjpcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiBcIlx0XCIsXG4gICAgICAgIHNpemU6IDJcbiAgICAgIH07XG4gIH1cbiAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgbGV4ZXIyLnNvdXJjZSxcbiAgICBwb3NpdGlvbixcbiAgICBgSW52YWxpZCBjaGFyYWN0ZXIgZXNjYXBlIHNlcXVlbmNlOiBcIiR7Ym9keS5zbGljZShcbiAgICAgIHBvc2l0aW9uLFxuICAgICAgcG9zaXRpb24gKyAyXG4gICAgKX1cIi5gXG4gICk7XG59XG5mdW5jdGlvbiByZWFkQmxvY2tTdHJpbmcobGV4ZXIyLCBzdGFydCkge1xuICBjb25zdCBib2R5ID0gbGV4ZXIyLnNvdXJjZS5ib2R5O1xuICBjb25zdCBib2R5TGVuZ3RoID0gYm9keS5sZW5ndGg7XG4gIGxldCBsaW5lU3RhcnQgPSBsZXhlcjIubGluZVN0YXJ0O1xuICBsZXQgcG9zaXRpb24gPSBzdGFydCArIDM7XG4gIGxldCBjaHVua1N0YXJ0ID0gcG9zaXRpb247XG4gIGxldCBjdXJyZW50TGluZSA9IFwiXCI7XG4gIGNvbnN0IGJsb2NrTGluZXMgPSBbXTtcbiAgd2hpbGUgKHBvc2l0aW9uIDwgYm9keUxlbmd0aCkge1xuICAgIGNvbnN0IGNvZGUgPSBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICAgIGlmIChjb2RlID09PSAzNCAmJiBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAxKSA9PT0gMzQgJiYgYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMikgPT09IDM0KSB7XG4gICAgICBjdXJyZW50TGluZSArPSBib2R5LnNsaWNlKGNodW5rU3RhcnQsIHBvc2l0aW9uKTtcbiAgICAgIGJsb2NrTGluZXMucHVzaChjdXJyZW50TGluZSk7XG4gICAgICBjb25zdCB0b2tlbiA9IGNyZWF0ZVRva2VuKFxuICAgICAgICBsZXhlcjIsXG4gICAgICAgIFRva2VuS2luZC5CTE9DS19TVFJJTkcsXG4gICAgICAgIHN0YXJ0LFxuICAgICAgICBwb3NpdGlvbiArIDMsXG4gICAgICAgIC8vIFJldHVybiBhIHN0cmluZyBvZiB0aGUgbGluZXMgam9pbmVkIHdpdGggVSswMDBBLlxuICAgICAgICBkZWRlbnRCbG9ja1N0cmluZ0xpbmVzKGJsb2NrTGluZXMpLmpvaW4oXCJcXG5cIilcbiAgICAgICk7XG4gICAgICBsZXhlcjIubGluZSArPSBibG9ja0xpbmVzLmxlbmd0aCAtIDE7XG4gICAgICBsZXhlcjIubGluZVN0YXJ0ID0gbGluZVN0YXJ0O1xuICAgICAgcmV0dXJuIHRva2VuO1xuICAgIH1cbiAgICBpZiAoY29kZSA9PT0gOTIgJiYgYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkgPT09IDM0ICYmIGJvZHkuY2hhckNvZGVBdChwb3NpdGlvbiArIDIpID09PSAzNCAmJiBib2R5LmNoYXJDb2RlQXQocG9zaXRpb24gKyAzKSA9PT0gMzQpIHtcbiAgICAgIGN1cnJlbnRMaW5lICs9IGJvZHkuc2xpY2UoY2h1bmtTdGFydCwgcG9zaXRpb24pO1xuICAgICAgY2h1bmtTdGFydCA9IHBvc2l0aW9uICsgMTtcbiAgICAgIHBvc2l0aW9uICs9IDQ7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGNvZGUgPT09IDEwIHx8IGNvZGUgPT09IDEzKSB7XG4gICAgICBjdXJyZW50TGluZSArPSBib2R5LnNsaWNlKGNodW5rU3RhcnQsIHBvc2l0aW9uKTtcbiAgICAgIGJsb2NrTGluZXMucHVzaChjdXJyZW50TGluZSk7XG4gICAgICBpZiAoY29kZSA9PT0gMTMgJiYgYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSkgPT09IDEwKSB7XG4gICAgICAgIHBvc2l0aW9uICs9IDI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICArK3Bvc2l0aW9uO1xuICAgICAgfVxuICAgICAgY3VycmVudExpbmUgPSBcIlwiO1xuICAgICAgY2h1bmtTdGFydCA9IHBvc2l0aW9uO1xuICAgICAgbGluZVN0YXJ0ID0gcG9zaXRpb247XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGlzVW5pY29kZVNjYWxhclZhbHVlKGNvZGUpKSB7XG4gICAgICArK3Bvc2l0aW9uO1xuICAgIH0gZWxzZSBpZiAoaXNTdXBwbGVtZW50YXJ5Q29kZVBvaW50KGJvZHksIHBvc2l0aW9uKSkge1xuICAgICAgcG9zaXRpb24gKz0gMjtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgICAgIGxleGVyMi5zb3VyY2UsXG4gICAgICAgIHBvc2l0aW9uLFxuICAgICAgICBgSW52YWxpZCBjaGFyYWN0ZXIgd2l0aGluIFN0cmluZzogJHtwcmludENvZGVQb2ludEF0KFxuICAgICAgICAgIGxleGVyMixcbiAgICAgICAgICBwb3NpdGlvblxuICAgICAgICApfS5gXG4gICAgICApO1xuICAgIH1cbiAgfVxuICB0aHJvdyBzeW50YXhFcnJvcihsZXhlcjIuc291cmNlLCBwb3NpdGlvbiwgXCJVbnRlcm1pbmF0ZWQgc3RyaW5nLlwiKTtcbn1cbmZ1bmN0aW9uIHJlYWROYW1lKGxleGVyMiwgc3RhcnQpIHtcbiAgY29uc3QgYm9keSA9IGxleGVyMi5zb3VyY2UuYm9keTtcbiAgY29uc3QgYm9keUxlbmd0aCA9IGJvZHkubGVuZ3RoO1xuICBsZXQgcG9zaXRpb24gPSBzdGFydCArIDE7XG4gIHdoaWxlIChwb3NpdGlvbiA8IGJvZHlMZW5ndGgpIHtcbiAgICBjb25zdCBjb2RlID0gYm9keS5jaGFyQ29kZUF0KHBvc2l0aW9uKTtcbiAgICBpZiAoaXNOYW1lQ29udGludWUoY29kZSkpIHtcbiAgICAgICsrcG9zaXRpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICByZXR1cm4gY3JlYXRlVG9rZW4oXG4gICAgbGV4ZXIyLFxuICAgIFRva2VuS2luZC5OQU1FLFxuICAgIHN0YXJ0LFxuICAgIHBvc2l0aW9uLFxuICAgIGJvZHkuc2xpY2Uoc3RhcnQsIHBvc2l0aW9uKVxuICApO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9pbnNwZWN0Lm1qc1xudmFyIE1BWF9BUlJBWV9MRU5HVEggPSAxMDtcbnZhciBNQVhfUkVDVVJTSVZFX0RFUFRIID0gMjtcbmZ1bmN0aW9uIGluc3BlY3QodmFsdWUpIHtcbiAgcmV0dXJuIGZvcm1hdFZhbHVlKHZhbHVlLCBbXSk7XG59XG5mdW5jdGlvbiBmb3JtYXRWYWx1ZSh2YWx1ZSwgc2VlblZhbHVlcykge1xuICBzd2l0Y2ggKHR5cGVvZiB2YWx1ZSkge1xuICAgIGNhc2UgXCJzdHJpbmdcIjpcbiAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgY2FzZSBcImZ1bmN0aW9uXCI6XG4gICAgICByZXR1cm4gdmFsdWUubmFtZSA/IGBbZnVuY3Rpb24gJHt2YWx1ZS5uYW1lfV1gIDogXCJbZnVuY3Rpb25dXCI7XG4gICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgcmV0dXJuIGZvcm1hdE9iamVjdFZhbHVlKHZhbHVlLCBzZWVuVmFsdWVzKTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIFN0cmluZyh2YWx1ZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGZvcm1hdE9iamVjdFZhbHVlKHZhbHVlLCBwcmV2aW91c2x5U2VlblZhbHVlcykge1xuICBpZiAodmFsdWUgPT09IG51bGwpIHtcbiAgICByZXR1cm4gXCJudWxsXCI7XG4gIH1cbiAgaWYgKHByZXZpb3VzbHlTZWVuVmFsdWVzLmluY2x1ZGVzKHZhbHVlKSkge1xuICAgIHJldHVybiBcIltDaXJjdWxhcl1cIjtcbiAgfVxuICBjb25zdCBzZWVuVmFsdWVzID0gWy4uLnByZXZpb3VzbHlTZWVuVmFsdWVzLCB2YWx1ZV07XG4gIGlmIChpc0pTT05hYmxlKHZhbHVlKSkge1xuICAgIGNvbnN0IGpzb25WYWx1ZSA9IHZhbHVlLnRvSlNPTigpO1xuICAgIGlmIChqc29uVmFsdWUgIT09IHZhbHVlKSB7XG4gICAgICByZXR1cm4gdHlwZW9mIGpzb25WYWx1ZSA9PT0gXCJzdHJpbmdcIiA/IGpzb25WYWx1ZSA6IGZvcm1hdFZhbHVlKGpzb25WYWx1ZSwgc2VlblZhbHVlcyk7XG4gICAgfVxuICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgcmV0dXJuIGZvcm1hdEFycmF5KHZhbHVlLCBzZWVuVmFsdWVzKTtcbiAgfVxuICByZXR1cm4gZm9ybWF0T2JqZWN0KHZhbHVlLCBzZWVuVmFsdWVzKTtcbn1cbmZ1bmN0aW9uIGlzSlNPTmFibGUodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZS50b0pTT04gPT09IFwiZnVuY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGZvcm1hdE9iamVjdChvYmplY3QsIHNlZW5WYWx1ZXMpIHtcbiAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKG9iamVjdCk7XG4gIGlmIChlbnRyaWVzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBcInt9XCI7XG4gIH1cbiAgaWYgKHNlZW5WYWx1ZXMubGVuZ3RoID4gTUFYX1JFQ1VSU0lWRV9ERVBUSCkge1xuICAgIHJldHVybiBcIltcIiArIGdldE9iamVjdFRhZyhvYmplY3QpICsgXCJdXCI7XG4gIH1cbiAgY29uc3QgcHJvcGVydGllcyA9IGVudHJpZXMubWFwKFxuICAgIChba2V5LCB2YWx1ZV0pID0+IGtleSArIFwiOiBcIiArIGZvcm1hdFZhbHVlKHZhbHVlLCBzZWVuVmFsdWVzKVxuICApO1xuICByZXR1cm4gXCJ7IFwiICsgcHJvcGVydGllcy5qb2luKFwiLCBcIikgKyBcIiB9XCI7XG59XG5mdW5jdGlvbiBmb3JtYXRBcnJheShhcnJheSwgc2VlblZhbHVlcykge1xuICBpZiAoYXJyYXkubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIFwiW11cIjtcbiAgfVxuICBpZiAoc2VlblZhbHVlcy5sZW5ndGggPiBNQVhfUkVDVVJTSVZFX0RFUFRIKSB7XG4gICAgcmV0dXJuIFwiW0FycmF5XVwiO1xuICB9XG4gIGNvbnN0IGxlbiA9IE1hdGgubWluKE1BWF9BUlJBWV9MRU5HVEgsIGFycmF5Lmxlbmd0aCk7XG4gIGNvbnN0IHJlbWFpbmluZyA9IGFycmF5Lmxlbmd0aCAtIGxlbjtcbiAgY29uc3QgaXRlbXMgPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47ICsraSkge1xuICAgIGl0ZW1zLnB1c2goZm9ybWF0VmFsdWUoYXJyYXlbaV0sIHNlZW5WYWx1ZXMpKTtcbiAgfVxuICBpZiAocmVtYWluaW5nID09PSAxKSB7XG4gICAgaXRlbXMucHVzaChcIi4uLiAxIG1vcmUgaXRlbVwiKTtcbiAgfSBlbHNlIGlmIChyZW1haW5pbmcgPiAxKSB7XG4gICAgaXRlbXMucHVzaChgLi4uICR7cmVtYWluaW5nfSBtb3JlIGl0ZW1zYCk7XG4gIH1cbiAgcmV0dXJuIFwiW1wiICsgaXRlbXMuam9pbihcIiwgXCIpICsgXCJdXCI7XG59XG5mdW5jdGlvbiBnZXRPYmplY3RUYWcob2JqZWN0KSB7XG4gIGNvbnN0IHRhZyA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmplY3QpLnJlcGxhY2UoL15cXFtvYmplY3QgLywgXCJcIikucmVwbGFjZSgvXSQvLCBcIlwiKTtcbiAgaWYgKHRhZyA9PT0gXCJPYmplY3RcIiAmJiB0eXBlb2Ygb2JqZWN0LmNvbnN0cnVjdG9yID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICBjb25zdCBuYW1lID0gb2JqZWN0LmNvbnN0cnVjdG9yLm5hbWU7XG4gICAgaWYgKHR5cGVvZiBuYW1lID09PSBcInN0cmluZ1wiICYmIG5hbWUgIT09IFwiXCIpIHtcbiAgICAgIHJldHVybiBuYW1lO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdGFnO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9pbnN0YW5jZU9mLm1qc1xudmFyIGluc3RhbmNlT2YgPSAoXG4gIC8qIGM4IGlnbm9yZSBuZXh0IDYgKi9cbiAgLy8gRklYTUU6IGh0dHBzOi8vZ2l0aHViLmNvbS9ncmFwaHFsL2dyYXBocWwtanMvaXNzdWVzLzIzMTdcbiAgZ2xvYmFsVGhpcy5wcm9jZXNzICYmIGdsb2JhbFRoaXMucHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZnVuY3Rpb24gaW5zdGFuY2VPZjIodmFsdWUsIGNvbnN0cnVjdG9yKSB7XG4gICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgY29uc3RydWN0b3I7XG4gIH0gOiBmdW5jdGlvbiBpbnN0YW5jZU9mMyh2YWx1ZSwgY29uc3RydWN0b3IpIHtcbiAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBjb25zdHJ1Y3Rvcikge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGwpIHtcbiAgICAgIHZhciBfdmFsdWUkY29uc3RydWN0b3I7XG4gICAgICBjb25zdCBjbGFzc05hbWUgPSBjb25zdHJ1Y3Rvci5wcm90b3R5cGVbU3ltYm9sLnRvU3RyaW5nVGFnXTtcbiAgICAgIGNvbnN0IHZhbHVlQ2xhc3NOYW1lID0gKFxuICAgICAgICAvLyBXZSBzdGlsbCBuZWVkIHRvIHN1cHBvcnQgY29uc3RydWN0b3IncyBuYW1lIHRvIGRldGVjdCBjb25mbGljdHMgd2l0aCBvbGRlciB2ZXJzaW9ucyBvZiB0aGlzIGxpYnJhcnkuXG4gICAgICAgIFN5bWJvbC50b1N0cmluZ1RhZyBpbiB2YWx1ZSA/IHZhbHVlW1N5bWJvbC50b1N0cmluZ1RhZ10gOiAoX3ZhbHVlJGNvbnN0cnVjdG9yID0gdmFsdWUuY29uc3RydWN0b3IpID09PSBudWxsIHx8IF92YWx1ZSRjb25zdHJ1Y3RvciA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3ZhbHVlJGNvbnN0cnVjdG9yLm5hbWVcbiAgICAgICk7XG4gICAgICBpZiAoY2xhc3NOYW1lID09PSB2YWx1ZUNsYXNzTmFtZSkge1xuICAgICAgICBjb25zdCBzdHJpbmdpZmllZFZhbHVlID0gaW5zcGVjdCh2YWx1ZSk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2Fubm90IHVzZSAke2NsYXNzTmFtZX0gXCIke3N0cmluZ2lmaWVkVmFsdWV9XCIgZnJvbSBhbm90aGVyIG1vZHVsZSBvciByZWFsbS5cblxuRW5zdXJlIHRoYXQgdGhlcmUgaXMgb25seSBvbmUgaW5zdGFuY2Ugb2YgXCJncmFwaHFsXCIgaW4gdGhlIG5vZGVfbW9kdWxlc1xuZGlyZWN0b3J5LiBJZiBkaWZmZXJlbnQgdmVyc2lvbnMgb2YgXCJncmFwaHFsXCIgYXJlIHRoZSBkZXBlbmRlbmNpZXMgb2Ygb3RoZXJcbnJlbGllZCBvbiBtb2R1bGVzLCB1c2UgXCJyZXNvbHV0aW9uc1wiIHRvIGVuc3VyZSBvbmx5IG9uZSB2ZXJzaW9uIGlzIGluc3RhbGxlZC5cblxuaHR0cHM6Ly95YXJucGtnLmNvbS9lbi9kb2NzL3NlbGVjdGl2ZS12ZXJzaW9uLXJlc29sdXRpb25zXG5cbkR1cGxpY2F0ZSBcImdyYXBocWxcIiBtb2R1bGVzIGNhbm5vdCBiZSB1c2VkIGF0IHRoZSBzYW1lIHRpbWUgc2luY2UgZGlmZmVyZW50XG52ZXJzaW9ucyBtYXkgaGF2ZSBkaWZmZXJlbnQgY2FwYWJpbGl0aWVzIGFuZCBiZWhhdmlvci4gVGhlIGRhdGEgZnJvbSBvbmVcbnZlcnNpb24gdXNlZCBpbiB0aGUgZnVuY3Rpb24gZnJvbSBhbm90aGVyIGNvdWxkIHByb2R1Y2UgY29uZnVzaW5nIGFuZFxuc3B1cmlvdXMgcmVzdWx0cy5gKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4pO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2Uvc291cmNlLm1qc1xudmFyIFNvdXJjZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoYm9keSwgbmFtZSA9IFwiR3JhcGhRTCByZXF1ZXN0XCIsIGxvY2F0aW9uT2Zmc2V0ID0ge1xuICAgIGxpbmU6IDEsXG4gICAgY29sdW1uOiAxXG4gIH0pIHtcbiAgICB0eXBlb2YgYm9keSA9PT0gXCJzdHJpbmdcIiB8fCBkZXZBc3NlcnQoZmFsc2UsIGBCb2R5IG11c3QgYmUgYSBzdHJpbmcuIFJlY2VpdmVkOiAke2luc3BlY3QoYm9keSl9LmApO1xuICAgIHRoaXMuYm9keSA9IGJvZHk7XG4gICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgICB0aGlzLmxvY2F0aW9uT2Zmc2V0ID0gbG9jYXRpb25PZmZzZXQ7XG4gICAgdGhpcy5sb2NhdGlvbk9mZnNldC5saW5lID4gMCB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIFwibGluZSBpbiBsb2NhdGlvbk9mZnNldCBpcyAxLWluZGV4ZWQgYW5kIG11c3QgYmUgcG9zaXRpdmUuXCJcbiAgICApO1xuICAgIHRoaXMubG9jYXRpb25PZmZzZXQuY29sdW1uID4gMCB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIFwiY29sdW1uIGluIGxvY2F0aW9uT2Zmc2V0IGlzIDEtaW5kZXhlZCBhbmQgbXVzdCBiZSBwb3NpdGl2ZS5cIlxuICAgICk7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIlNvdXJjZVwiO1xuICB9XG59O1xuZnVuY3Rpb24gaXNTb3VyY2Uoc291cmNlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHNvdXJjZSwgU291cmNlKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL3BhcnNlci5tanNcbmZ1bmN0aW9uIHBhcnNlMihzb3VyY2UsIG9wdGlvbnMpIHtcbiAgY29uc3QgcGFyc2VyID0gbmV3IFBhcnNlcihzb3VyY2UsIG9wdGlvbnMpO1xuICByZXR1cm4gcGFyc2VyLnBhcnNlRG9jdW1lbnQoKTtcbn1cbnZhciBQYXJzZXIgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3Qgc291cmNlT2JqID0gaXNTb3VyY2Uoc291cmNlKSA/IHNvdXJjZSA6IG5ldyBTb3VyY2Uoc291cmNlKTtcbiAgICB0aGlzLl9sZXhlciA9IG5ldyBMZXhlcihzb3VyY2VPYmopO1xuICAgIHRoaXMuX29wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuX3Rva2VuQ291bnRlciA9IDA7XG4gIH1cbiAgLyoqXG4gICAqIENvbnZlcnRzIGEgbmFtZSBsZXggdG9rZW4gaW50byBhIG5hbWUgcGFyc2Ugbm9kZS5cbiAgICovXG4gIHBhcnNlTmFtZSgpIHtcbiAgICBjb25zdCB0b2tlbiA9IHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLk5BTUUpO1xuICAgIHJldHVybiB0aGlzLm5vZGUodG9rZW4sIHtcbiAgICAgIGtpbmQ6IEtpbmQuTkFNRSxcbiAgICAgIHZhbHVlOiB0b2tlbi52YWx1ZVxuICAgIH0pO1xuICB9XG4gIC8vIEltcGxlbWVudHMgdGhlIHBhcnNpbmcgcnVsZXMgaW4gdGhlIERvY3VtZW50IHNlY3Rpb24uXG4gIC8qKlxuICAgKiBEb2N1bWVudCA6IERlZmluaXRpb24rXG4gICAqL1xuICBwYXJzZURvY3VtZW50KCkge1xuICAgIHJldHVybiB0aGlzLm5vZGUodGhpcy5fbGV4ZXIudG9rZW4sIHtcbiAgICAgIGtpbmQ6IEtpbmQuRE9DVU1FTlQsXG4gICAgICBkZWZpbml0aW9uczogdGhpcy5tYW55KFxuICAgICAgICBUb2tlbktpbmQuU09GLFxuICAgICAgICB0aGlzLnBhcnNlRGVmaW5pdGlvbixcbiAgICAgICAgVG9rZW5LaW5kLkVPRlxuICAgICAgKVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBEZWZpbml0aW9uIDpcbiAgICogICAtIEV4ZWN1dGFibGVEZWZpbml0aW9uXG4gICAqICAgLSBUeXBlU3lzdGVtRGVmaW5pdGlvblxuICAgKiAgIC0gVHlwZVN5c3RlbUV4dGVuc2lvblxuICAgKlxuICAgKiBFeGVjdXRhYmxlRGVmaW5pdGlvbiA6XG4gICAqICAgLSBPcGVyYXRpb25EZWZpbml0aW9uXG4gICAqICAgLSBGcmFnbWVudERlZmluaXRpb25cbiAgICpcbiAgICogVHlwZVN5c3RlbURlZmluaXRpb24gOlxuICAgKiAgIC0gU2NoZW1hRGVmaW5pdGlvblxuICAgKiAgIC0gVHlwZURlZmluaXRpb25cbiAgICogICAtIERpcmVjdGl2ZURlZmluaXRpb25cbiAgICpcbiAgICogVHlwZURlZmluaXRpb24gOlxuICAgKiAgIC0gU2NhbGFyVHlwZURlZmluaXRpb25cbiAgICogICAtIE9iamVjdFR5cGVEZWZpbml0aW9uXG4gICAqICAgLSBJbnRlcmZhY2VUeXBlRGVmaW5pdGlvblxuICAgKiAgIC0gVW5pb25UeXBlRGVmaW5pdGlvblxuICAgKiAgIC0gRW51bVR5cGVEZWZpbml0aW9uXG4gICAqICAgLSBJbnB1dE9iamVjdFR5cGVEZWZpbml0aW9uXG4gICAqL1xuICBwYXJzZURlZmluaXRpb24oKSB7XG4gICAgaWYgKHRoaXMucGVlayhUb2tlbktpbmQuQlJBQ0VfTCkpIHtcbiAgICAgIHJldHVybiB0aGlzLnBhcnNlT3BlcmF0aW9uRGVmaW5pdGlvbigpO1xuICAgIH1cbiAgICBjb25zdCBoYXNEZXNjcmlwdGlvbiA9IHRoaXMucGVla0Rlc2NyaXB0aW9uKCk7XG4gICAgY29uc3Qga2V5d29yZFRva2VuID0gaGFzRGVzY3JpcHRpb24gPyB0aGlzLl9sZXhlci5sb29rYWhlYWQoKSA6IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGlmIChrZXl3b3JkVG9rZW4ua2luZCA9PT0gVG9rZW5LaW5kLk5BTUUpIHtcbiAgICAgIHN3aXRjaCAoa2V5d29yZFRva2VuLnZhbHVlKSB7XG4gICAgICAgIGNhc2UgXCJzY2hlbWFcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVNjaGVtYURlZmluaXRpb24oKTtcbiAgICAgICAgY2FzZSBcInNjYWxhclwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlU2NhbGFyVHlwZURlZmluaXRpb24oKTtcbiAgICAgICAgY2FzZSBcInR5cGVcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZU9iamVjdFR5cGVEZWZpbml0aW9uKCk7XG4gICAgICAgIGNhc2UgXCJpbnRlcmZhY2VcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZUludGVyZmFjZVR5cGVEZWZpbml0aW9uKCk7XG4gICAgICAgIGNhc2UgXCJ1bmlvblwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlVW5pb25UeXBlRGVmaW5pdGlvbigpO1xuICAgICAgICBjYXNlIFwiZW51bVwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlRW51bVR5cGVEZWZpbml0aW9uKCk7XG4gICAgICAgIGNhc2UgXCJpbnB1dFwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvbigpO1xuICAgICAgICBjYXNlIFwiZGlyZWN0aXZlXCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VEaXJlY3RpdmVEZWZpbml0aW9uKCk7XG4gICAgICB9XG4gICAgICBpZiAoaGFzRGVzY3JpcHRpb24pIHtcbiAgICAgICAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgICAgICAgdGhpcy5fbGV4ZXIuc291cmNlLFxuICAgICAgICAgIHRoaXMuX2xleGVyLnRva2VuLnN0YXJ0LFxuICAgICAgICAgIFwiVW5leHBlY3RlZCBkZXNjcmlwdGlvbiwgZGVzY3JpcHRpb25zIGFyZSBzdXBwb3J0ZWQgb25seSBvbiB0eXBlIGRlZmluaXRpb25zLlwiXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBzd2l0Y2ggKGtleXdvcmRUb2tlbi52YWx1ZSkge1xuICAgICAgICBjYXNlIFwicXVlcnlcIjpcbiAgICAgICAgY2FzZSBcIm11dGF0aW9uXCI6XG4gICAgICAgIGNhc2UgXCJzdWJzY3JpcHRpb25cIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZU9wZXJhdGlvbkRlZmluaXRpb24oKTtcbiAgICAgICAgY2FzZSBcImZyYWdtZW50XCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VGcmFnbWVudERlZmluaXRpb24oKTtcbiAgICAgICAgY2FzZSBcImV4dGVuZFwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlVHlwZVN5c3RlbUV4dGVuc2lvbigpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyB0aGlzLnVuZXhwZWN0ZWQoa2V5d29yZFRva2VuKTtcbiAgfVxuICAvLyBJbXBsZW1lbnRzIHRoZSBwYXJzaW5nIHJ1bGVzIGluIHRoZSBPcGVyYXRpb25zIHNlY3Rpb24uXG4gIC8qKlxuICAgKiBPcGVyYXRpb25EZWZpbml0aW9uIDpcbiAgICogIC0gU2VsZWN0aW9uU2V0XG4gICAqICAtIE9wZXJhdGlvblR5cGUgTmFtZT8gVmFyaWFibGVEZWZpbml0aW9ucz8gRGlyZWN0aXZlcz8gU2VsZWN0aW9uU2V0XG4gICAqL1xuICBwYXJzZU9wZXJhdGlvbkRlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBpZiAodGhpcy5wZWVrKFRva2VuS2luZC5CUkFDRV9MKSkge1xuICAgICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAgICBraW5kOiBLaW5kLk9QRVJBVElPTl9ERUZJTklUSU9OLFxuICAgICAgICBvcGVyYXRpb246IE9wZXJhdGlvblR5cGVOb2RlLlFVRVJZLFxuICAgICAgICBuYW1lOiB2b2lkIDAsXG4gICAgICAgIHZhcmlhYmxlRGVmaW5pdGlvbnM6IFtdLFxuICAgICAgICBkaXJlY3RpdmVzOiBbXSxcbiAgICAgICAgc2VsZWN0aW9uU2V0OiB0aGlzLnBhcnNlU2VsZWN0aW9uU2V0KClcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlT3BlcmF0aW9uVHlwZSgpO1xuICAgIGxldCBuYW1lO1xuICAgIGlmICh0aGlzLnBlZWsoVG9rZW5LaW5kLk5BTUUpKSB7XG4gICAgICBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5PUEVSQVRJT05fREVGSU5JVElPTixcbiAgICAgIG9wZXJhdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICB2YXJpYWJsZURlZmluaXRpb25zOiB0aGlzLnBhcnNlVmFyaWFibGVEZWZpbml0aW9ucygpLFxuICAgICAgZGlyZWN0aXZlczogdGhpcy5wYXJzZURpcmVjdGl2ZXMoZmFsc2UpLFxuICAgICAgc2VsZWN0aW9uU2V0OiB0aGlzLnBhcnNlU2VsZWN0aW9uU2V0KClcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogT3BlcmF0aW9uVHlwZSA6IG9uZSBvZiBxdWVyeSBtdXRhdGlvbiBzdWJzY3JpcHRpb25cbiAgICovXG4gIHBhcnNlT3BlcmF0aW9uVHlwZSgpIHtcbiAgICBjb25zdCBvcGVyYXRpb25Ub2tlbiA9IHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLk5BTUUpO1xuICAgIHN3aXRjaCAob3BlcmF0aW9uVG9rZW4udmFsdWUpIHtcbiAgICAgIGNhc2UgXCJxdWVyeVwiOlxuICAgICAgICByZXR1cm4gT3BlcmF0aW9uVHlwZU5vZGUuUVVFUlk7XG4gICAgICBjYXNlIFwibXV0YXRpb25cIjpcbiAgICAgICAgcmV0dXJuIE9wZXJhdGlvblR5cGVOb2RlLk1VVEFUSU9OO1xuICAgICAgY2FzZSBcInN1YnNjcmlwdGlvblwiOlxuICAgICAgICByZXR1cm4gT3BlcmF0aW9uVHlwZU5vZGUuU1VCU0NSSVBUSU9OO1xuICAgIH1cbiAgICB0aHJvdyB0aGlzLnVuZXhwZWN0ZWQob3BlcmF0aW9uVG9rZW4pO1xuICB9XG4gIC8qKlxuICAgKiBWYXJpYWJsZURlZmluaXRpb25zIDogKCBWYXJpYWJsZURlZmluaXRpb24rIClcbiAgICovXG4gIHBhcnNlVmFyaWFibGVEZWZpbml0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbE1hbnkoXG4gICAgICBUb2tlbktpbmQuUEFSRU5fTCxcbiAgICAgIHRoaXMucGFyc2VWYXJpYWJsZURlZmluaXRpb24sXG4gICAgICBUb2tlbktpbmQuUEFSRU5fUlxuICAgICk7XG4gIH1cbiAgLyoqXG4gICAqIFZhcmlhYmxlRGVmaW5pdGlvbiA6IFZhcmlhYmxlIDogVHlwZSBEZWZhdWx0VmFsdWU/IERpcmVjdGl2ZXNbQ29uc3RdP1xuICAgKi9cbiAgcGFyc2VWYXJpYWJsZURlZmluaXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMubm9kZSh0aGlzLl9sZXhlci50b2tlbiwge1xuICAgICAga2luZDogS2luZC5WQVJJQUJMRV9ERUZJTklUSU9OLFxuICAgICAgdmFyaWFibGU6IHRoaXMucGFyc2VWYXJpYWJsZSgpLFxuICAgICAgdHlwZTogKHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkNPTE9OKSwgdGhpcy5wYXJzZVR5cGVSZWZlcmVuY2UoKSksXG4gICAgICBkZWZhdWx0VmFsdWU6IHRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihUb2tlbktpbmQuRVFVQUxTKSA/IHRoaXMucGFyc2VDb25zdFZhbHVlTGl0ZXJhbCgpIDogdm9pZCAwLFxuICAgICAgZGlyZWN0aXZlczogdGhpcy5wYXJzZUNvbnN0RGlyZWN0aXZlcygpXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFZhcmlhYmxlIDogJCBOYW1lXG4gICAqL1xuICBwYXJzZVZhcmlhYmxlKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RUb2tlbihUb2tlbktpbmQuRE9MTEFSKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLlZBUklBQkxFLFxuICAgICAgbmFtZTogdGhpcy5wYXJzZU5hbWUoKVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBgYGBcbiAgICogU2VsZWN0aW9uU2V0IDogeyBTZWxlY3Rpb24rIH1cbiAgICogYGBgXG4gICAqL1xuICBwYXJzZVNlbGVjdGlvblNldCgpIHtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHRoaXMuX2xleGVyLnRva2VuLCB7XG4gICAgICBraW5kOiBLaW5kLlNFTEVDVElPTl9TRVQsXG4gICAgICBzZWxlY3Rpb25zOiB0aGlzLm1hbnkoXG4gICAgICAgIFRva2VuS2luZC5CUkFDRV9MLFxuICAgICAgICB0aGlzLnBhcnNlU2VsZWN0aW9uLFxuICAgICAgICBUb2tlbktpbmQuQlJBQ0VfUlxuICAgICAgKVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBTZWxlY3Rpb24gOlxuICAgKiAgIC0gRmllbGRcbiAgICogICAtIEZyYWdtZW50U3ByZWFkXG4gICAqICAgLSBJbmxpbmVGcmFnbWVudFxuICAgKi9cbiAgcGFyc2VTZWxlY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMucGVlayhUb2tlbktpbmQuU1BSRUFEKSA/IHRoaXMucGFyc2VGcmFnbWVudCgpIDogdGhpcy5wYXJzZUZpZWxkKCk7XG4gIH1cbiAgLyoqXG4gICAqIEZpZWxkIDogQWxpYXM/IE5hbWUgQXJndW1lbnRzPyBEaXJlY3RpdmVzPyBTZWxlY3Rpb25TZXQ/XG4gICAqXG4gICAqIEFsaWFzIDogTmFtZSA6XG4gICAqL1xuICBwYXJzZUZpZWxkKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgbmFtZU9yQWxpYXMgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGxldCBhbGlhcztcbiAgICBsZXQgbmFtZTtcbiAgICBpZiAodGhpcy5leHBlY3RPcHRpb25hbFRva2VuKFRva2VuS2luZC5DT0xPTikpIHtcbiAgICAgIGFsaWFzID0gbmFtZU9yQWxpYXM7XG4gICAgICBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbmFtZSA9IG5hbWVPckFsaWFzO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLkZJRUxELFxuICAgICAgYWxpYXMsXG4gICAgICBuYW1lLFxuICAgICAgYXJndW1lbnRzOiB0aGlzLnBhcnNlQXJndW1lbnRzKGZhbHNlKSxcbiAgICAgIGRpcmVjdGl2ZXM6IHRoaXMucGFyc2VEaXJlY3RpdmVzKGZhbHNlKSxcbiAgICAgIHNlbGVjdGlvblNldDogdGhpcy5wZWVrKFRva2VuS2luZC5CUkFDRV9MKSA/IHRoaXMucGFyc2VTZWxlY3Rpb25TZXQoKSA6IHZvaWQgMFxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBBcmd1bWVudHNbQ29uc3RdIDogKCBBcmd1bWVudFs/Q29uc3RdKyApXG4gICAqL1xuICBwYXJzZUFyZ3VtZW50cyhpc0NvbnN0KSB7XG4gICAgY29uc3QgaXRlbSA9IGlzQ29uc3QgPyB0aGlzLnBhcnNlQ29uc3RBcmd1bWVudCA6IHRoaXMucGFyc2VBcmd1bWVudDtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbE1hbnkoVG9rZW5LaW5kLlBBUkVOX0wsIGl0ZW0sIFRva2VuS2luZC5QQVJFTl9SKTtcbiAgfVxuICAvKipcbiAgICogQXJndW1lbnRbQ29uc3RdIDogTmFtZSA6IFZhbHVlWz9Db25zdF1cbiAgICovXG4gIHBhcnNlQXJndW1lbnQoaXNDb25zdCA9IGZhbHNlKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5DT0xPTik7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5BUkdVTUVOVCxcbiAgICAgIG5hbWUsXG4gICAgICB2YWx1ZTogdGhpcy5wYXJzZVZhbHVlTGl0ZXJhbChpc0NvbnN0KVxuICAgIH0pO1xuICB9XG4gIHBhcnNlQ29uc3RBcmd1bWVudCgpIHtcbiAgICByZXR1cm4gdGhpcy5wYXJzZUFyZ3VtZW50KHRydWUpO1xuICB9XG4gIC8vIEltcGxlbWVudHMgdGhlIHBhcnNpbmcgcnVsZXMgaW4gdGhlIEZyYWdtZW50cyBzZWN0aW9uLlxuICAvKipcbiAgICogQ29ycmVzcG9uZHMgdG8gYm90aCBGcmFnbWVudFNwcmVhZCBhbmQgSW5saW5lRnJhZ21lbnQgaW4gdGhlIHNwZWMuXG4gICAqXG4gICAqIEZyYWdtZW50U3ByZWFkIDogLi4uIEZyYWdtZW50TmFtZSBEaXJlY3RpdmVzP1xuICAgKlxuICAgKiBJbmxpbmVGcmFnbWVudCA6IC4uLiBUeXBlQ29uZGl0aW9uPyBEaXJlY3RpdmVzPyBTZWxlY3Rpb25TZXRcbiAgICovXG4gIHBhcnNlRnJhZ21lbnQoKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5TUFJFQUQpO1xuICAgIGNvbnN0IGhhc1R5cGVDb25kaXRpb24gPSB0aGlzLmV4cGVjdE9wdGlvbmFsS2V5d29yZChcIm9uXCIpO1xuICAgIGlmICghaGFzVHlwZUNvbmRpdGlvbiAmJiB0aGlzLnBlZWsoVG9rZW5LaW5kLk5BTUUpKSB7XG4gICAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICAgIGtpbmQ6IEtpbmQuRlJBR01FTlRfU1BSRUFELFxuICAgICAgICBuYW1lOiB0aGlzLnBhcnNlRnJhZ21lbnROYW1lKCksXG4gICAgICAgIGRpcmVjdGl2ZXM6IHRoaXMucGFyc2VEaXJlY3RpdmVzKGZhbHNlKVxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuSU5MSU5FX0ZSQUdNRU5ULFxuICAgICAgdHlwZUNvbmRpdGlvbjogaGFzVHlwZUNvbmRpdGlvbiA/IHRoaXMucGFyc2VOYW1lZFR5cGUoKSA6IHZvaWQgMCxcbiAgICAgIGRpcmVjdGl2ZXM6IHRoaXMucGFyc2VEaXJlY3RpdmVzKGZhbHNlKSxcbiAgICAgIHNlbGVjdGlvblNldDogdGhpcy5wYXJzZVNlbGVjdGlvblNldCgpXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIEZyYWdtZW50RGVmaW5pdGlvbiA6XG4gICAqICAgLSBmcmFnbWVudCBGcmFnbWVudE5hbWUgb24gVHlwZUNvbmRpdGlvbiBEaXJlY3RpdmVzPyBTZWxlY3Rpb25TZXRcbiAgICpcbiAgICogVHlwZUNvbmRpdGlvbiA6IE5hbWVkVHlwZVxuICAgKi9cbiAgcGFyc2VGcmFnbWVudERlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJmcmFnbWVudFwiKTtcbiAgICBpZiAodGhpcy5fb3B0aW9ucy5hbGxvd0xlZ2FjeUZyYWdtZW50VmFyaWFibGVzID09PSB0cnVlKSB7XG4gICAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICAgIGtpbmQ6IEtpbmQuRlJBR01FTlRfREVGSU5JVElPTixcbiAgICAgICAgbmFtZTogdGhpcy5wYXJzZUZyYWdtZW50TmFtZSgpLFxuICAgICAgICB2YXJpYWJsZURlZmluaXRpb25zOiB0aGlzLnBhcnNlVmFyaWFibGVEZWZpbml0aW9ucygpLFxuICAgICAgICB0eXBlQ29uZGl0aW9uOiAodGhpcy5leHBlY3RLZXl3b3JkKFwib25cIiksIHRoaXMucGFyc2VOYW1lZFR5cGUoKSksXG4gICAgICAgIGRpcmVjdGl2ZXM6IHRoaXMucGFyc2VEaXJlY3RpdmVzKGZhbHNlKSxcbiAgICAgICAgc2VsZWN0aW9uU2V0OiB0aGlzLnBhcnNlU2VsZWN0aW9uU2V0KClcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLkZSQUdNRU5UX0RFRklOSVRJT04sXG4gICAgICBuYW1lOiB0aGlzLnBhcnNlRnJhZ21lbnROYW1lKCksXG4gICAgICB0eXBlQ29uZGl0aW9uOiAodGhpcy5leHBlY3RLZXl3b3JkKFwib25cIiksIHRoaXMucGFyc2VOYW1lZFR5cGUoKSksXG4gICAgICBkaXJlY3RpdmVzOiB0aGlzLnBhcnNlRGlyZWN0aXZlcyhmYWxzZSksXG4gICAgICBzZWxlY3Rpb25TZXQ6IHRoaXMucGFyc2VTZWxlY3Rpb25TZXQoKVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBGcmFnbWVudE5hbWUgOiBOYW1lIGJ1dCBub3QgYG9uYFxuICAgKi9cbiAgcGFyc2VGcmFnbWVudE5hbWUoKSB7XG4gICAgaWYgKHRoaXMuX2xleGVyLnRva2VuLnZhbHVlID09PSBcIm9uXCIpIHtcbiAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5wYXJzZU5hbWUoKTtcbiAgfVxuICAvLyBJbXBsZW1lbnRzIHRoZSBwYXJzaW5nIHJ1bGVzIGluIHRoZSBWYWx1ZXMgc2VjdGlvbi5cbiAgLyoqXG4gICAqIFZhbHVlW0NvbnN0XSA6XG4gICAqICAgLSBbfkNvbnN0XSBWYXJpYWJsZVxuICAgKiAgIC0gSW50VmFsdWVcbiAgICogICAtIEZsb2F0VmFsdWVcbiAgICogICAtIFN0cmluZ1ZhbHVlXG4gICAqICAgLSBCb29sZWFuVmFsdWVcbiAgICogICAtIE51bGxWYWx1ZVxuICAgKiAgIC0gRW51bVZhbHVlXG4gICAqICAgLSBMaXN0VmFsdWVbP0NvbnN0XVxuICAgKiAgIC0gT2JqZWN0VmFsdWVbP0NvbnN0XVxuICAgKlxuICAgKiBCb29sZWFuVmFsdWUgOiBvbmUgb2YgYHRydWVgIGBmYWxzZWBcbiAgICpcbiAgICogTnVsbFZhbHVlIDogYG51bGxgXG4gICAqXG4gICAqIEVudW1WYWx1ZSA6IE5hbWUgYnV0IG5vdCBgdHJ1ZWAsIGBmYWxzZWAgb3IgYG51bGxgXG4gICAqL1xuICBwYXJzZVZhbHVlTGl0ZXJhbChpc0NvbnN0KSB7XG4gICAgY29uc3QgdG9rZW4gPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBzd2l0Y2ggKHRva2VuLmtpbmQpIHtcbiAgICAgIGNhc2UgVG9rZW5LaW5kLkJSQUNLRVRfTDpcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VMaXN0KGlzQ29uc3QpO1xuICAgICAgY2FzZSBUb2tlbktpbmQuQlJBQ0VfTDpcbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VPYmplY3QoaXNDb25zdCk7XG4gICAgICBjYXNlIFRva2VuS2luZC5JTlQ6XG4gICAgICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgICAgIHJldHVybiB0aGlzLm5vZGUodG9rZW4sIHtcbiAgICAgICAgICBraW5kOiBLaW5kLklOVCxcbiAgICAgICAgICB2YWx1ZTogdG9rZW4udmFsdWVcbiAgICAgICAgfSk7XG4gICAgICBjYXNlIFRva2VuS2luZC5GTE9BVDpcbiAgICAgICAgdGhpcy5hZHZhbmNlTGV4ZXIoKTtcbiAgICAgICAgcmV0dXJuIHRoaXMubm9kZSh0b2tlbiwge1xuICAgICAgICAgIGtpbmQ6IEtpbmQuRkxPQVQsXG4gICAgICAgICAgdmFsdWU6IHRva2VuLnZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgY2FzZSBUb2tlbktpbmQuU1RSSU5HOlxuICAgICAgY2FzZSBUb2tlbktpbmQuQkxPQ0tfU1RSSU5HOlxuICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVN0cmluZ0xpdGVyYWwoKTtcbiAgICAgIGNhc2UgVG9rZW5LaW5kLk5BTUU6XG4gICAgICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgICAgIHN3aXRjaCAodG9rZW4udmFsdWUpIHtcbiAgICAgICAgICBjYXNlIFwidHJ1ZVwiOlxuICAgICAgICAgICAgcmV0dXJuIHRoaXMubm9kZSh0b2tlbiwge1xuICAgICAgICAgICAgICBraW5kOiBLaW5kLkJPT0xFQU4sXG4gICAgICAgICAgICAgIHZhbHVlOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICBjYXNlIFwiZmFsc2VcIjpcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm5vZGUodG9rZW4sIHtcbiAgICAgICAgICAgICAga2luZDogS2luZC5CT09MRUFOLFxuICAgICAgICAgICAgICB2YWx1ZTogZmFsc2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIGNhc2UgXCJudWxsXCI6XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5ub2RlKHRva2VuLCB7XG4gICAgICAgICAgICAgIGtpbmQ6IEtpbmQuTlVMTFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm5vZGUodG9rZW4sIHtcbiAgICAgICAgICAgICAga2luZDogS2luZC5FTlVNLFxuICAgICAgICAgICAgICB2YWx1ZTogdG9rZW4udmFsdWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICBjYXNlIFRva2VuS2luZC5ET0xMQVI6XG4gICAgICAgIGlmIChpc0NvbnN0KSB7XG4gICAgICAgICAgdGhpcy5leHBlY3RUb2tlbihUb2tlbktpbmQuRE9MTEFSKTtcbiAgICAgICAgICBpZiAodGhpcy5fbGV4ZXIudG9rZW4ua2luZCA9PT0gVG9rZW5LaW5kLk5BTUUpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhck5hbWUgPSB0aGlzLl9sZXhlci50b2tlbi52YWx1ZTtcbiAgICAgICAgICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgICAgICAgICB0aGlzLl9sZXhlci5zb3VyY2UsXG4gICAgICAgICAgICAgIHRva2VuLnN0YXJ0LFxuICAgICAgICAgICAgICBgVW5leHBlY3RlZCB2YXJpYWJsZSBcIiQke3Zhck5hbWV9XCIgaW4gY29uc3RhbnQgdmFsdWUuYFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKHRva2VuKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VWYXJpYWJsZSgpO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKCk7XG4gICAgfVxuICB9XG4gIHBhcnNlQ29uc3RWYWx1ZUxpdGVyYWwoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFyc2VWYWx1ZUxpdGVyYWwodHJ1ZSk7XG4gIH1cbiAgcGFyc2VTdHJpbmdMaXRlcmFsKCkge1xuICAgIGNvbnN0IHRva2VuID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5hZHZhbmNlTGV4ZXIoKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHRva2VuLCB7XG4gICAgICBraW5kOiBLaW5kLlNUUklORyxcbiAgICAgIHZhbHVlOiB0b2tlbi52YWx1ZSxcbiAgICAgIGJsb2NrOiB0b2tlbi5raW5kID09PSBUb2tlbktpbmQuQkxPQ0tfU1RSSU5HXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIExpc3RWYWx1ZVtDb25zdF0gOlxuICAgKiAgIC0gWyBdXG4gICAqICAgLSBbIFZhbHVlWz9Db25zdF0rIF1cbiAgICovXG4gIHBhcnNlTGlzdChpc0NvbnN0KSB7XG4gICAgY29uc3QgaXRlbSA9ICgpID0+IHRoaXMucGFyc2VWYWx1ZUxpdGVyYWwoaXNDb25zdCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZSh0aGlzLl9sZXhlci50b2tlbiwge1xuICAgICAga2luZDogS2luZC5MSVNULFxuICAgICAgdmFsdWVzOiB0aGlzLmFueShUb2tlbktpbmQuQlJBQ0tFVF9MLCBpdGVtLCBUb2tlbktpbmQuQlJBQ0tFVF9SKVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBgYGBcbiAgICogT2JqZWN0VmFsdWVbQ29uc3RdIDpcbiAgICogICAtIHsgfVxuICAgKiAgIC0geyBPYmplY3RGaWVsZFs/Q29uc3RdKyB9XG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2VPYmplY3QoaXNDb25zdCkge1xuICAgIGNvbnN0IGl0ZW0gPSAoKSA9PiB0aGlzLnBhcnNlT2JqZWN0RmllbGQoaXNDb25zdCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZSh0aGlzLl9sZXhlci50b2tlbiwge1xuICAgICAga2luZDogS2luZC5PQkpFQ1QsXG4gICAgICBmaWVsZHM6IHRoaXMuYW55KFRva2VuS2luZC5CUkFDRV9MLCBpdGVtLCBUb2tlbktpbmQuQlJBQ0VfUilcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogT2JqZWN0RmllbGRbQ29uc3RdIDogTmFtZSA6IFZhbHVlWz9Db25zdF1cbiAgICovXG4gIHBhcnNlT2JqZWN0RmllbGQoaXNDb25zdCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgdGhpcy5leHBlY3RUb2tlbihUb2tlbktpbmQuQ09MT04pO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuT0JKRUNUX0ZJRUxELFxuICAgICAgbmFtZSxcbiAgICAgIHZhbHVlOiB0aGlzLnBhcnNlVmFsdWVMaXRlcmFsKGlzQ29uc3QpXG4gICAgfSk7XG4gIH1cbiAgLy8gSW1wbGVtZW50cyB0aGUgcGFyc2luZyBydWxlcyBpbiB0aGUgRGlyZWN0aXZlcyBzZWN0aW9uLlxuICAvKipcbiAgICogRGlyZWN0aXZlc1tDb25zdF0gOiBEaXJlY3RpdmVbP0NvbnN0XStcbiAgICovXG4gIHBhcnNlRGlyZWN0aXZlcyhpc0NvbnN0KSB7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IFtdO1xuICAgIHdoaWxlICh0aGlzLnBlZWsoVG9rZW5LaW5kLkFUKSkge1xuICAgICAgZGlyZWN0aXZlcy5wdXNoKHRoaXMucGFyc2VEaXJlY3RpdmUoaXNDb25zdCkpO1xuICAgIH1cbiAgICByZXR1cm4gZGlyZWN0aXZlcztcbiAgfVxuICBwYXJzZUNvbnN0RGlyZWN0aXZlcygpIHtcbiAgICByZXR1cm4gdGhpcy5wYXJzZURpcmVjdGl2ZXModHJ1ZSk7XG4gIH1cbiAgLyoqXG4gICAqIGBgYFxuICAgKiBEaXJlY3RpdmVbQ29uc3RdIDogQCBOYW1lIEFyZ3VtZW50c1s/Q29uc3RdP1xuICAgKiBgYGBcbiAgICovXG4gIHBhcnNlRGlyZWN0aXZlKGlzQ29uc3QpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkFUKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLkRJUkVDVElWRSxcbiAgICAgIG5hbWU6IHRoaXMucGFyc2VOYW1lKCksXG4gICAgICBhcmd1bWVudHM6IHRoaXMucGFyc2VBcmd1bWVudHMoaXNDb25zdClcbiAgICB9KTtcbiAgfVxuICAvLyBJbXBsZW1lbnRzIHRoZSBwYXJzaW5nIHJ1bGVzIGluIHRoZSBUeXBlcyBzZWN0aW9uLlxuICAvKipcbiAgICogVHlwZSA6XG4gICAqICAgLSBOYW1lZFR5cGVcbiAgICogICAtIExpc3RUeXBlXG4gICAqICAgLSBOb25OdWxsVHlwZVxuICAgKi9cbiAgcGFyc2VUeXBlUmVmZXJlbmNlKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgbGV0IHR5cGU7XG4gICAgaWYgKHRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihUb2tlbktpbmQuQlJBQ0tFVF9MKSkge1xuICAgICAgY29uc3QgaW5uZXJUeXBlID0gdGhpcy5wYXJzZVR5cGVSZWZlcmVuY2UoKTtcbiAgICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkJSQUNLRVRfUik7XG4gICAgICB0eXBlID0gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICAgIGtpbmQ6IEtpbmQuTElTVF9UWVBFLFxuICAgICAgICB0eXBlOiBpbm5lclR5cGVcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0eXBlID0gdGhpcy5wYXJzZU5hbWVkVHlwZSgpO1xuICAgIH1cbiAgICBpZiAodGhpcy5leHBlY3RPcHRpb25hbFRva2VuKFRva2VuS2luZC5CQU5HKSkge1xuICAgICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAgICBraW5kOiBLaW5kLk5PTl9OVUxMX1RZUEUsXG4gICAgICAgIHR5cGVcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gdHlwZTtcbiAgfVxuICAvKipcbiAgICogTmFtZWRUeXBlIDogTmFtZVxuICAgKi9cbiAgcGFyc2VOYW1lZFR5cGUoKSB7XG4gICAgcmV0dXJuIHRoaXMubm9kZSh0aGlzLl9sZXhlci50b2tlbiwge1xuICAgICAga2luZDogS2luZC5OQU1FRF9UWVBFLFxuICAgICAgbmFtZTogdGhpcy5wYXJzZU5hbWUoKVxuICAgIH0pO1xuICB9XG4gIC8vIEltcGxlbWVudHMgdGhlIHBhcnNpbmcgcnVsZXMgaW4gdGhlIFR5cGUgRGVmaW5pdGlvbiBzZWN0aW9uLlxuICBwZWVrRGVzY3JpcHRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMucGVlayhUb2tlbktpbmQuU1RSSU5HKSB8fCB0aGlzLnBlZWsoVG9rZW5LaW5kLkJMT0NLX1NUUklORyk7XG4gIH1cbiAgLyoqXG4gICAqIERlc2NyaXB0aW9uIDogU3RyaW5nVmFsdWVcbiAgICovXG4gIHBhcnNlRGVzY3JpcHRpb24oKSB7XG4gICAgaWYgKHRoaXMucGVla0Rlc2NyaXB0aW9uKCkpIHtcbiAgICAgIHJldHVybiB0aGlzLnBhcnNlU3RyaW5nTGl0ZXJhbCgpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogYGBgXG4gICAqIFNjaGVtYURlZmluaXRpb24gOiBEZXNjcmlwdGlvbj8gc2NoZW1hIERpcmVjdGl2ZXNbQ29uc3RdPyB7IE9wZXJhdGlvblR5cGVEZWZpbml0aW9uKyB9XG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2VTY2hlbWFEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJzY2hlbWFcIik7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBvcGVyYXRpb25UeXBlcyA9IHRoaXMubWFueShcbiAgICAgIFRva2VuS2luZC5CUkFDRV9MLFxuICAgICAgdGhpcy5wYXJzZU9wZXJhdGlvblR5cGVEZWZpbml0aW9uLFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX1JcbiAgICApO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuU0NIRU1BX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIGRpcmVjdGl2ZXMsXG4gICAgICBvcGVyYXRpb25UeXBlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBPcGVyYXRpb25UeXBlRGVmaW5pdGlvbiA6IE9wZXJhdGlvblR5cGUgOiBOYW1lZFR5cGVcbiAgICovXG4gIHBhcnNlT3BlcmF0aW9uVHlwZURlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBvcGVyYXRpb24gPSB0aGlzLnBhcnNlT3BlcmF0aW9uVHlwZSgpO1xuICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkNPTE9OKTtcbiAgICBjb25zdCB0eXBlID0gdGhpcy5wYXJzZU5hbWVkVHlwZSgpO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuT1BFUkFUSU9OX1RZUEVfREVGSU5JVElPTixcbiAgICAgIG9wZXJhdGlvbixcbiAgICAgIHR5cGVcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogU2NhbGFyVHlwZURlZmluaXRpb24gOiBEZXNjcmlwdGlvbj8gc2NhbGFyIE5hbWUgRGlyZWN0aXZlc1tDb25zdF0/XG4gICAqL1xuICBwYXJzZVNjYWxhclR5cGVEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJzY2FsYXJcIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLlNDQUxBUl9UWVBFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBkaXJlY3RpdmVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIE9iamVjdFR5cGVEZWZpbml0aW9uIDpcbiAgICogICBEZXNjcmlwdGlvbj9cbiAgICogICB0eXBlIE5hbWUgSW1wbGVtZW50c0ludGVyZmFjZXM/IERpcmVjdGl2ZXNbQ29uc3RdPyBGaWVsZHNEZWZpbml0aW9uP1xuICAgKi9cbiAgcGFyc2VPYmplY3RUeXBlRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwidHlwZVwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBpbnRlcmZhY2VzID0gdGhpcy5wYXJzZUltcGxlbWVudHNJbnRlcmZhY2VzKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBmaWVsZHMgPSB0aGlzLnBhcnNlRmllbGRzRGVmaW5pdGlvbigpO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuT0JKRUNUX1RZUEVfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgbmFtZSxcbiAgICAgIGludGVyZmFjZXMsXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgZmllbGRzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIEltcGxlbWVudHNJbnRlcmZhY2VzIDpcbiAgICogICAtIGltcGxlbWVudHMgYCZgPyBOYW1lZFR5cGVcbiAgICogICAtIEltcGxlbWVudHNJbnRlcmZhY2VzICYgTmFtZWRUeXBlXG4gICAqL1xuICBwYXJzZUltcGxlbWVudHNJbnRlcmZhY2VzKCkge1xuICAgIHJldHVybiB0aGlzLmV4cGVjdE9wdGlvbmFsS2V5d29yZChcImltcGxlbWVudHNcIikgPyB0aGlzLmRlbGltaXRlZE1hbnkoVG9rZW5LaW5kLkFNUCwgdGhpcy5wYXJzZU5hbWVkVHlwZSkgOiBbXTtcbiAgfVxuICAvKipcbiAgICogYGBgXG4gICAqIEZpZWxkc0RlZmluaXRpb24gOiB7IEZpZWxkRGVmaW5pdGlvbisgfVxuICAgKiBgYGBcbiAgICovXG4gIHBhcnNlRmllbGRzRGVmaW5pdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbE1hbnkoXG4gICAgICBUb2tlbktpbmQuQlJBQ0VfTCxcbiAgICAgIHRoaXMucGFyc2VGaWVsZERlZmluaXRpb24sXG4gICAgICBUb2tlbktpbmQuQlJBQ0VfUlxuICAgICk7XG4gIH1cbiAgLyoqXG4gICAqIEZpZWxkRGVmaW5pdGlvbiA6XG4gICAqICAgLSBEZXNjcmlwdGlvbj8gTmFtZSBBcmd1bWVudHNEZWZpbml0aW9uPyA6IFR5cGUgRGlyZWN0aXZlc1tDb25zdF0/XG4gICAqL1xuICBwYXJzZUZpZWxkRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgYXJncyA9IHRoaXMucGFyc2VBcmd1bWVudERlZnMoKTtcbiAgICB0aGlzLmV4cGVjdFRva2VuKFRva2VuS2luZC5DT0xPTik7XG4gICAgY29uc3QgdHlwZSA9IHRoaXMucGFyc2VUeXBlUmVmZXJlbmNlKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLkZJRUxEX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBhcmd1bWVudHM6IGFyZ3MsXG4gICAgICB0eXBlLFxuICAgICAgZGlyZWN0aXZlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBBcmd1bWVudHNEZWZpbml0aW9uIDogKCBJbnB1dFZhbHVlRGVmaW5pdGlvbisgKVxuICAgKi9cbiAgcGFyc2VBcmd1bWVudERlZnMoKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWxNYW55KFxuICAgICAgVG9rZW5LaW5kLlBBUkVOX0wsXG4gICAgICB0aGlzLnBhcnNlSW5wdXRWYWx1ZURlZixcbiAgICAgIFRva2VuS2luZC5QQVJFTl9SXG4gICAgKTtcbiAgfVxuICAvKipcbiAgICogSW5wdXRWYWx1ZURlZmluaXRpb24gOlxuICAgKiAgIC0gRGVzY3JpcHRpb24/IE5hbWUgOiBUeXBlIERlZmF1bHRWYWx1ZT8gRGlyZWN0aXZlc1tDb25zdF0/XG4gICAqL1xuICBwYXJzZUlucHV0VmFsdWVEZWYoKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHRoaXMucGFyc2VEZXNjcmlwdGlvbigpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIHRoaXMuZXhwZWN0VG9rZW4oVG9rZW5LaW5kLkNPTE9OKTtcbiAgICBjb25zdCB0eXBlID0gdGhpcy5wYXJzZVR5cGVSZWZlcmVuY2UoKTtcbiAgICBsZXQgZGVmYXVsdFZhbHVlO1xuICAgIGlmICh0aGlzLmV4cGVjdE9wdGlvbmFsVG9rZW4oVG9rZW5LaW5kLkVRVUFMUykpIHtcbiAgICAgIGRlZmF1bHRWYWx1ZSA9IHRoaXMucGFyc2VDb25zdFZhbHVlTGl0ZXJhbCgpO1xuICAgIH1cbiAgICBjb25zdCBkaXJlY3RpdmVzID0gdGhpcy5wYXJzZUNvbnN0RGlyZWN0aXZlcygpO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuSU5QVVRfVkFMVUVfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgbmFtZSxcbiAgICAgIHR5cGUsXG4gICAgICBkZWZhdWx0VmFsdWUsXG4gICAgICBkaXJlY3RpdmVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIEludGVyZmFjZVR5cGVEZWZpbml0aW9uIDpcbiAgICogICAtIERlc2NyaXB0aW9uPyBpbnRlcmZhY2UgTmFtZSBEaXJlY3RpdmVzW0NvbnN0XT8gRmllbGRzRGVmaW5pdGlvbj9cbiAgICovXG4gIHBhcnNlSW50ZXJmYWNlVHlwZURlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHRoaXMucGFyc2VEZXNjcmlwdGlvbigpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImludGVyZmFjZVwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBpbnRlcmZhY2VzID0gdGhpcy5wYXJzZUltcGxlbWVudHNJbnRlcmZhY2VzKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBmaWVsZHMgPSB0aGlzLnBhcnNlRmllbGRzRGVmaW5pdGlvbigpO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuSU5URVJGQUNFX1RZUEVfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgbmFtZSxcbiAgICAgIGludGVyZmFjZXMsXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgZmllbGRzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFVuaW9uVHlwZURlZmluaXRpb24gOlxuICAgKiAgIC0gRGVzY3JpcHRpb24/IHVuaW9uIE5hbWUgRGlyZWN0aXZlc1tDb25zdF0/IFVuaW9uTWVtYmVyVHlwZXM/XG4gICAqL1xuICBwYXJzZVVuaW9uVHlwZURlZmluaXRpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHRoaXMucGFyc2VEZXNjcmlwdGlvbigpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcInVuaW9uXCIpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgdHlwZXMgPSB0aGlzLnBhcnNlVW5pb25NZW1iZXJUeXBlcygpO1xuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuVU5JT05fVFlQRV9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgICBuYW1lLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIHR5cGVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFVuaW9uTWVtYmVyVHlwZXMgOlxuICAgKiAgIC0gPSBgfGA/IE5hbWVkVHlwZVxuICAgKiAgIC0gVW5pb25NZW1iZXJUeXBlcyB8IE5hbWVkVHlwZVxuICAgKi9cbiAgcGFyc2VVbmlvbk1lbWJlclR5cGVzKCkge1xuICAgIHJldHVybiB0aGlzLmV4cGVjdE9wdGlvbmFsVG9rZW4oVG9rZW5LaW5kLkVRVUFMUykgPyB0aGlzLmRlbGltaXRlZE1hbnkoVG9rZW5LaW5kLlBJUEUsIHRoaXMucGFyc2VOYW1lZFR5cGUpIDogW107XG4gIH1cbiAgLyoqXG4gICAqIEVudW1UeXBlRGVmaW5pdGlvbiA6XG4gICAqICAgLSBEZXNjcmlwdGlvbj8gZW51bSBOYW1lIERpcmVjdGl2ZXNbQ29uc3RdPyBFbnVtVmFsdWVzRGVmaW5pdGlvbj9cbiAgICovXG4gIHBhcnNlRW51bVR5cGVEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJlbnVtXCIpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGRpcmVjdGl2ZXMgPSB0aGlzLnBhcnNlQ29uc3REaXJlY3RpdmVzKCk7XG4gICAgY29uc3QgdmFsdWVzID0gdGhpcy5wYXJzZUVudW1WYWx1ZXNEZWZpbml0aW9uKCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5FTlVNX1RZUEVfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgbmFtZSxcbiAgICAgIGRpcmVjdGl2ZXMsXG4gICAgICB2YWx1ZXNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogYGBgXG4gICAqIEVudW1WYWx1ZXNEZWZpbml0aW9uIDogeyBFbnVtVmFsdWVEZWZpbml0aW9uKyB9XG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2VFbnVtVmFsdWVzRGVmaW5pdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25hbE1hbnkoXG4gICAgICBUb2tlbktpbmQuQlJBQ0VfTCxcbiAgICAgIHRoaXMucGFyc2VFbnVtVmFsdWVEZWZpbml0aW9uLFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX1JcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBFbnVtVmFsdWVEZWZpbml0aW9uIDogRGVzY3JpcHRpb24/IEVudW1WYWx1ZSBEaXJlY3RpdmVzW0NvbnN0XT9cbiAgICovXG4gIHBhcnNlRW51bVZhbHVlRGVmaW5pdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gdGhpcy5wYXJzZURlc2NyaXB0aW9uKCk7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VFbnVtVmFsdWVOYW1lKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLkVOVU1fVkFMVUVfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgbmFtZSxcbiAgICAgIGRpcmVjdGl2ZXNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogRW51bVZhbHVlIDogTmFtZSBidXQgbm90IGB0cnVlYCwgYGZhbHNlYCBvciBgbnVsbGBcbiAgICovXG4gIHBhcnNlRW51bVZhbHVlTmFtZSgpIHtcbiAgICBpZiAodGhpcy5fbGV4ZXIudG9rZW4udmFsdWUgPT09IFwidHJ1ZVwiIHx8IHRoaXMuX2xleGVyLnRva2VuLnZhbHVlID09PSBcImZhbHNlXCIgfHwgdGhpcy5fbGV4ZXIudG9rZW4udmFsdWUgPT09IFwibnVsbFwiKSB7XG4gICAgICB0aHJvdyBzeW50YXhFcnJvcihcbiAgICAgICAgdGhpcy5fbGV4ZXIuc291cmNlLFxuICAgICAgICB0aGlzLl9sZXhlci50b2tlbi5zdGFydCxcbiAgICAgICAgYCR7Z2V0VG9rZW5EZXNjKFxuICAgICAgICAgIHRoaXMuX2xleGVyLnRva2VuXG4gICAgICAgICl9IGlzIHJlc2VydmVkIGFuZCBjYW5ub3QgYmUgdXNlZCBmb3IgYW4gZW51bSB2YWx1ZS5gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5wYXJzZU5hbWUoKTtcbiAgfVxuICAvKipcbiAgICogSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvbiA6XG4gICAqICAgLSBEZXNjcmlwdGlvbj8gaW5wdXQgTmFtZSBEaXJlY3RpdmVzW0NvbnN0XT8gSW5wdXRGaWVsZHNEZWZpbml0aW9uP1xuICAgKi9cbiAgcGFyc2VJbnB1dE9iamVjdFR5cGVEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJpbnB1dFwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBkaXJlY3RpdmVzID0gdGhpcy5wYXJzZUNvbnN0RGlyZWN0aXZlcygpO1xuICAgIGNvbnN0IGZpZWxkcyA9IHRoaXMucGFyc2VJbnB1dEZpZWxkc0RlZmluaXRpb24oKTtcbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLklOUFVUX09CSkVDVF9UWVBFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbixcbiAgICAgIG5hbWUsXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgZmllbGRzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIGBgYFxuICAgKiBJbnB1dEZpZWxkc0RlZmluaXRpb24gOiB7IElucHV0VmFsdWVEZWZpbml0aW9uKyB9XG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2VJbnB1dEZpZWxkc0RlZmluaXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMub3B0aW9uYWxNYW55KFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX0wsXG4gICAgICB0aGlzLnBhcnNlSW5wdXRWYWx1ZURlZixcbiAgICAgIFRva2VuS2luZC5CUkFDRV9SXG4gICAgKTtcbiAgfVxuICAvKipcbiAgICogVHlwZVN5c3RlbUV4dGVuc2lvbiA6XG4gICAqICAgLSBTY2hlbWFFeHRlbnNpb25cbiAgICogICAtIFR5cGVFeHRlbnNpb25cbiAgICpcbiAgICogVHlwZUV4dGVuc2lvbiA6XG4gICAqICAgLSBTY2FsYXJUeXBlRXh0ZW5zaW9uXG4gICAqICAgLSBPYmplY3RUeXBlRXh0ZW5zaW9uXG4gICAqICAgLSBJbnRlcmZhY2VUeXBlRXh0ZW5zaW9uXG4gICAqICAgLSBVbmlvblR5cGVFeHRlbnNpb25cbiAgICogICAtIEVudW1UeXBlRXh0ZW5zaW9uXG4gICAqICAgLSBJbnB1dE9iamVjdFR5cGVEZWZpbml0aW9uXG4gICAqL1xuICBwYXJzZVR5cGVTeXN0ZW1FeHRlbnNpb24oKSB7XG4gICAgY29uc3Qga2V5d29yZFRva2VuID0gdGhpcy5fbGV4ZXIubG9va2FoZWFkKCk7XG4gICAgaWYgKGtleXdvcmRUb2tlbi5raW5kID09PSBUb2tlbktpbmQuTkFNRSkge1xuICAgICAgc3dpdGNoIChrZXl3b3JkVG9rZW4udmFsdWUpIHtcbiAgICAgICAgY2FzZSBcInNjaGVtYVwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlU2NoZW1hRXh0ZW5zaW9uKCk7XG4gICAgICAgIGNhc2UgXCJzY2FsYXJcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVNjYWxhclR5cGVFeHRlbnNpb24oKTtcbiAgICAgICAgY2FzZSBcInR5cGVcIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZU9iamVjdFR5cGVFeHRlbnNpb24oKTtcbiAgICAgICAgY2FzZSBcImludGVyZmFjZVwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlSW50ZXJmYWNlVHlwZUV4dGVuc2lvbigpO1xuICAgICAgICBjYXNlIFwidW5pb25cIjpcbiAgICAgICAgICByZXR1cm4gdGhpcy5wYXJzZVVuaW9uVHlwZUV4dGVuc2lvbigpO1xuICAgICAgICBjYXNlIFwiZW51bVwiOlxuICAgICAgICAgIHJldHVybiB0aGlzLnBhcnNlRW51bVR5cGVFeHRlbnNpb24oKTtcbiAgICAgICAgY2FzZSBcImlucHV0XCI6XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyc2VJbnB1dE9iamVjdFR5cGVFeHRlbnNpb24oKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKGtleXdvcmRUb2tlbik7XG4gIH1cbiAgLyoqXG4gICAqIGBgYFxuICAgKiBTY2hlbWFFeHRlbnNpb24gOlxuICAgKiAgLSBleHRlbmQgc2NoZW1hIERpcmVjdGl2ZXNbQ29uc3RdPyB7IE9wZXJhdGlvblR5cGVEZWZpbml0aW9uKyB9XG4gICAqICAtIGV4dGVuZCBzY2hlbWEgRGlyZWN0aXZlc1tDb25zdF1cbiAgICogYGBgXG4gICAqL1xuICBwYXJzZVNjaGVtYUV4dGVuc2lvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImV4dGVuZFwiKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJzY2hlbWFcIik7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBvcGVyYXRpb25UeXBlcyA9IHRoaXMub3B0aW9uYWxNYW55KFxuICAgICAgVG9rZW5LaW5kLkJSQUNFX0wsXG4gICAgICB0aGlzLnBhcnNlT3BlcmF0aW9uVHlwZURlZmluaXRpb24sXG4gICAgICBUb2tlbktpbmQuQlJBQ0VfUlxuICAgICk7XG4gICAgaWYgKGRpcmVjdGl2ZXMubGVuZ3RoID09PSAwICYmIG9wZXJhdGlvblR5cGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuU0NIRU1BX0VYVEVOU0lPTixcbiAgICAgIGRpcmVjdGl2ZXMsXG4gICAgICBvcGVyYXRpb25UeXBlc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBTY2FsYXJUeXBlRXh0ZW5zaW9uIDpcbiAgICogICAtIGV4dGVuZCBzY2FsYXIgTmFtZSBEaXJlY3RpdmVzW0NvbnN0XVxuICAgKi9cbiAgcGFyc2VTY2FsYXJUeXBlRXh0ZW5zaW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZXh0ZW5kXCIpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcInNjYWxhclwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBkaXJlY3RpdmVzID0gdGhpcy5wYXJzZUNvbnN0RGlyZWN0aXZlcygpO1xuICAgIGlmIChkaXJlY3RpdmVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuU0NBTEFSX1RZUEVfRVhURU5TSU9OLFxuICAgICAgbmFtZSxcbiAgICAgIGRpcmVjdGl2ZXNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogT2JqZWN0VHlwZUV4dGVuc2lvbiA6XG4gICAqICAtIGV4dGVuZCB0eXBlIE5hbWUgSW1wbGVtZW50c0ludGVyZmFjZXM/IERpcmVjdGl2ZXNbQ29uc3RdPyBGaWVsZHNEZWZpbml0aW9uXG4gICAqICAtIGV4dGVuZCB0eXBlIE5hbWUgSW1wbGVtZW50c0ludGVyZmFjZXM/IERpcmVjdGl2ZXNbQ29uc3RdXG4gICAqICAtIGV4dGVuZCB0eXBlIE5hbWUgSW1wbGVtZW50c0ludGVyZmFjZXNcbiAgICovXG4gIHBhcnNlT2JqZWN0VHlwZUV4dGVuc2lvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImV4dGVuZFwiKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJ0eXBlXCIpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGludGVyZmFjZXMgPSB0aGlzLnBhcnNlSW1wbGVtZW50c0ludGVyZmFjZXMoKTtcbiAgICBjb25zdCBkaXJlY3RpdmVzID0gdGhpcy5wYXJzZUNvbnN0RGlyZWN0aXZlcygpO1xuICAgIGNvbnN0IGZpZWxkcyA9IHRoaXMucGFyc2VGaWVsZHNEZWZpbml0aW9uKCk7XG4gICAgaWYgKGludGVyZmFjZXMubGVuZ3RoID09PSAwICYmIGRpcmVjdGl2ZXMubGVuZ3RoID09PSAwICYmIGZpZWxkcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLk9CSkVDVF9UWVBFX0VYVEVOU0lPTixcbiAgICAgIG5hbWUsXG4gICAgICBpbnRlcmZhY2VzLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIGZpZWxkc1xuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBJbnRlcmZhY2VUeXBlRXh0ZW5zaW9uIDpcbiAgICogIC0gZXh0ZW5kIGludGVyZmFjZSBOYW1lIEltcGxlbWVudHNJbnRlcmZhY2VzPyBEaXJlY3RpdmVzW0NvbnN0XT8gRmllbGRzRGVmaW5pdGlvblxuICAgKiAgLSBleHRlbmQgaW50ZXJmYWNlIE5hbWUgSW1wbGVtZW50c0ludGVyZmFjZXM/IERpcmVjdGl2ZXNbQ29uc3RdXG4gICAqICAtIGV4dGVuZCBpbnRlcmZhY2UgTmFtZSBJbXBsZW1lbnRzSW50ZXJmYWNlc1xuICAgKi9cbiAgcGFyc2VJbnRlcmZhY2VUeXBlRXh0ZW5zaW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZXh0ZW5kXCIpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImludGVyZmFjZVwiKTtcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wYXJzZU5hbWUoKTtcbiAgICBjb25zdCBpbnRlcmZhY2VzID0gdGhpcy5wYXJzZUltcGxlbWVudHNJbnRlcmZhY2VzKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBmaWVsZHMgPSB0aGlzLnBhcnNlRmllbGRzRGVmaW5pdGlvbigpO1xuICAgIGlmIChpbnRlcmZhY2VzLmxlbmd0aCA9PT0gMCAmJiBkaXJlY3RpdmVzLmxlbmd0aCA9PT0gMCAmJiBmaWVsZHMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyB0aGlzLnVuZXhwZWN0ZWQoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5JTlRFUkZBQ0VfVFlQRV9FWFRFTlNJT04sXG4gICAgICBuYW1lLFxuICAgICAgaW50ZXJmYWNlcyxcbiAgICAgIGRpcmVjdGl2ZXMsXG4gICAgICBmaWVsZHNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogVW5pb25UeXBlRXh0ZW5zaW9uIDpcbiAgICogICAtIGV4dGVuZCB1bmlvbiBOYW1lIERpcmVjdGl2ZXNbQ29uc3RdPyBVbmlvbk1lbWJlclR5cGVzXG4gICAqICAgLSBleHRlbmQgdW5pb24gTmFtZSBEaXJlY3RpdmVzW0NvbnN0XVxuICAgKi9cbiAgcGFyc2VVbmlvblR5cGVFeHRlbnNpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJleHRlbmRcIik7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwidW5pb25cIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCB0eXBlcyA9IHRoaXMucGFyc2VVbmlvbk1lbWJlclR5cGVzKCk7XG4gICAgaWYgKGRpcmVjdGl2ZXMubGVuZ3RoID09PSAwICYmIHR5cGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuVU5JT05fVFlQRV9FWFRFTlNJT04sXG4gICAgICBuYW1lLFxuICAgICAgZGlyZWN0aXZlcyxcbiAgICAgIHR5cGVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIEVudW1UeXBlRXh0ZW5zaW9uIDpcbiAgICogICAtIGV4dGVuZCBlbnVtIE5hbWUgRGlyZWN0aXZlc1tDb25zdF0/IEVudW1WYWx1ZXNEZWZpbml0aW9uXG4gICAqICAgLSBleHRlbmQgZW51bSBOYW1lIERpcmVjdGl2ZXNbQ29uc3RdXG4gICAqL1xuICBwYXJzZUVudW1UeXBlRXh0ZW5zaW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiZXh0ZW5kXCIpO1xuICAgIHRoaXMuZXhwZWN0S2V5d29yZChcImVudW1cIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLnBhcnNlRW51bVZhbHVlc0RlZmluaXRpb24oKTtcbiAgICBpZiAoZGlyZWN0aXZlcy5sZW5ndGggPT09IDAgJiYgdmFsdWVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vZGUoc3RhcnQsIHtcbiAgICAgIGtpbmQ6IEtpbmQuRU5VTV9UWVBFX0VYVEVOU0lPTixcbiAgICAgIG5hbWUsXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgdmFsdWVzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIElucHV0T2JqZWN0VHlwZUV4dGVuc2lvbiA6XG4gICAqICAgLSBleHRlbmQgaW5wdXQgTmFtZSBEaXJlY3RpdmVzW0NvbnN0XT8gSW5wdXRGaWVsZHNEZWZpbml0aW9uXG4gICAqICAgLSBleHRlbmQgaW5wdXQgTmFtZSBEaXJlY3RpdmVzW0NvbnN0XVxuICAgKi9cbiAgcGFyc2VJbnB1dE9iamVjdFR5cGVFeHRlbnNpb24oKSB7XG4gICAgY29uc3Qgc3RhcnQgPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJleHRlbmRcIik7XG4gICAgdGhpcy5leHBlY3RLZXl3b3JkKFwiaW5wdXRcIik7XG4gICAgY29uc3QgbmFtZSA9IHRoaXMucGFyc2VOYW1lKCk7XG4gICAgY29uc3QgZGlyZWN0aXZlcyA9IHRoaXMucGFyc2VDb25zdERpcmVjdGl2ZXMoKTtcbiAgICBjb25zdCBmaWVsZHMgPSB0aGlzLnBhcnNlSW5wdXRGaWVsZHNEZWZpbml0aW9uKCk7XG4gICAgaWYgKGRpcmVjdGl2ZXMubGVuZ3RoID09PSAwICYmIGZpZWxkcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IHRoaXMudW5leHBlY3RlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5ub2RlKHN0YXJ0LCB7XG4gICAgICBraW5kOiBLaW5kLklOUFVUX09CSkVDVF9UWVBFX0VYVEVOU0lPTixcbiAgICAgIG5hbWUsXG4gICAgICBkaXJlY3RpdmVzLFxuICAgICAgZmllbGRzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIGBgYFxuICAgKiBEaXJlY3RpdmVEZWZpbml0aW9uIDpcbiAgICogICAtIERlc2NyaXB0aW9uPyBkaXJlY3RpdmUgQCBOYW1lIEFyZ3VtZW50c0RlZmluaXRpb24/IGByZXBlYXRhYmxlYD8gb24gRGlyZWN0aXZlTG9jYXRpb25zXG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2VEaXJlY3RpdmVEZWZpbml0aW9uKCkge1xuICAgIGNvbnN0IHN0YXJ0ID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSB0aGlzLnBhcnNlRGVzY3JpcHRpb24oKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJkaXJlY3RpdmVcIik7XG4gICAgdGhpcy5leHBlY3RUb2tlbihUb2tlbktpbmQuQVQpO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGNvbnN0IGFyZ3MgPSB0aGlzLnBhcnNlQXJndW1lbnREZWZzKCk7XG4gICAgY29uc3QgcmVwZWF0YWJsZSA9IHRoaXMuZXhwZWN0T3B0aW9uYWxLZXl3b3JkKFwicmVwZWF0YWJsZVwiKTtcbiAgICB0aGlzLmV4cGVjdEtleXdvcmQoXCJvblwiKTtcbiAgICBjb25zdCBsb2NhdGlvbnMgPSB0aGlzLnBhcnNlRGlyZWN0aXZlTG9jYXRpb25zKCk7XG4gICAgcmV0dXJuIHRoaXMubm9kZShzdGFydCwge1xuICAgICAga2luZDogS2luZC5ESVJFQ1RJVkVfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uLFxuICAgICAgbmFtZSxcbiAgICAgIGFyZ3VtZW50czogYXJncyxcbiAgICAgIHJlcGVhdGFibGUsXG4gICAgICBsb2NhdGlvbnNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogRGlyZWN0aXZlTG9jYXRpb25zIDpcbiAgICogICAtIGB8YD8gRGlyZWN0aXZlTG9jYXRpb25cbiAgICogICAtIERpcmVjdGl2ZUxvY2F0aW9ucyB8IERpcmVjdGl2ZUxvY2F0aW9uXG4gICAqL1xuICBwYXJzZURpcmVjdGl2ZUxvY2F0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5kZWxpbWl0ZWRNYW55KFRva2VuS2luZC5QSVBFLCB0aGlzLnBhcnNlRGlyZWN0aXZlTG9jYXRpb24pO1xuICB9XG4gIC8qXG4gICAqIERpcmVjdGl2ZUxvY2F0aW9uIDpcbiAgICogICAtIEV4ZWN1dGFibGVEaXJlY3RpdmVMb2NhdGlvblxuICAgKiAgIC0gVHlwZVN5c3RlbURpcmVjdGl2ZUxvY2F0aW9uXG4gICAqXG4gICAqIEV4ZWN1dGFibGVEaXJlY3RpdmVMb2NhdGlvbiA6IG9uZSBvZlxuICAgKiAgIGBRVUVSWWBcbiAgICogICBgTVVUQVRJT05gXG4gICAqICAgYFNVQlNDUklQVElPTmBcbiAgICogICBgRklFTERgXG4gICAqICAgYEZSQUdNRU5UX0RFRklOSVRJT05gXG4gICAqICAgYEZSQUdNRU5UX1NQUkVBRGBcbiAgICogICBgSU5MSU5FX0ZSQUdNRU5UYFxuICAgKlxuICAgKiBUeXBlU3lzdGVtRGlyZWN0aXZlTG9jYXRpb24gOiBvbmUgb2ZcbiAgICogICBgU0NIRU1BYFxuICAgKiAgIGBTQ0FMQVJgXG4gICAqICAgYE9CSkVDVGBcbiAgICogICBgRklFTERfREVGSU5JVElPTmBcbiAgICogICBgQVJHVU1FTlRfREVGSU5JVElPTmBcbiAgICogICBgSU5URVJGQUNFYFxuICAgKiAgIGBVTklPTmBcbiAgICogICBgRU5VTWBcbiAgICogICBgRU5VTV9WQUxVRWBcbiAgICogICBgSU5QVVRfT0JKRUNUYFxuICAgKiAgIGBJTlBVVF9GSUVMRF9ERUZJTklUSU9OYFxuICAgKi9cbiAgcGFyc2VEaXJlY3RpdmVMb2NhdGlvbigpIHtcbiAgICBjb25zdCBzdGFydCA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGNvbnN0IG5hbWUgPSB0aGlzLnBhcnNlTmFtZSgpO1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoRGlyZWN0aXZlTG9jYXRpb24sIG5hbWUudmFsdWUpKSB7XG4gICAgICByZXR1cm4gbmFtZTtcbiAgICB9XG4gICAgdGhyb3cgdGhpcy51bmV4cGVjdGVkKHN0YXJ0KTtcbiAgfVxuICAvLyBDb3JlIHBhcnNpbmcgdXRpbGl0eSBmdW5jdGlvbnNcbiAgLyoqXG4gICAqIFJldHVybnMgYSBub2RlIHRoYXQsIGlmIGNvbmZpZ3VyZWQgdG8gZG8gc28sIHNldHMgYSBcImxvY1wiIGZpZWxkIGFzIGFcbiAgICogbG9jYXRpb24gb2JqZWN0LCB1c2VkIHRvIGlkZW50aWZ5IHRoZSBwbGFjZSBpbiB0aGUgc291cmNlIHRoYXQgY3JlYXRlZCBhXG4gICAqIGdpdmVuIHBhcnNlZCBvYmplY3QuXG4gICAqL1xuICBub2RlKHN0YXJ0VG9rZW4sIG5vZGUpIHtcbiAgICBpZiAodGhpcy5fb3B0aW9ucy5ub0xvY2F0aW9uICE9PSB0cnVlKSB7XG4gICAgICBub2RlLmxvYyA9IG5ldyBMb2NhdGlvbihcbiAgICAgICAgc3RhcnRUb2tlbixcbiAgICAgICAgdGhpcy5fbGV4ZXIubGFzdFRva2VuLFxuICAgICAgICB0aGlzLl9sZXhlci5zb3VyY2VcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9XG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIGlmIHRoZSBuZXh0IHRva2VuIGlzIG9mIGEgZ2l2ZW4ga2luZFxuICAgKi9cbiAgcGVlayhraW5kKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xleGVyLnRva2VuLmtpbmQgPT09IGtpbmQ7XG4gIH1cbiAgLyoqXG4gICAqIElmIHRoZSBuZXh0IHRva2VuIGlzIG9mIHRoZSBnaXZlbiBraW5kLCByZXR1cm4gdGhhdCB0b2tlbiBhZnRlciBhZHZhbmNpbmcgdGhlIGxleGVyLlxuICAgKiBPdGhlcndpc2UsIGRvIG5vdCBjaGFuZ2UgdGhlIHBhcnNlciBzdGF0ZSBhbmQgdGhyb3cgYW4gZXJyb3IuXG4gICAqL1xuICBleHBlY3RUb2tlbihraW5kKSB7XG4gICAgY29uc3QgdG9rZW4gPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBpZiAodG9rZW4ua2luZCA9PT0ga2luZCkge1xuICAgICAgdGhpcy5hZHZhbmNlTGV4ZXIoKTtcbiAgICAgIHJldHVybiB0b2tlbjtcbiAgICB9XG4gICAgdGhyb3cgc3ludGF4RXJyb3IoXG4gICAgICB0aGlzLl9sZXhlci5zb3VyY2UsXG4gICAgICB0b2tlbi5zdGFydCxcbiAgICAgIGBFeHBlY3RlZCAke2dldFRva2VuS2luZERlc2Moa2luZCl9LCBmb3VuZCAke2dldFRva2VuRGVzYyh0b2tlbil9LmBcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBJZiB0aGUgbmV4dCB0b2tlbiBpcyBvZiB0aGUgZ2l2ZW4ga2luZCwgcmV0dXJuIFwidHJ1ZVwiIGFmdGVyIGFkdmFuY2luZyB0aGUgbGV4ZXIuXG4gICAqIE90aGVyd2lzZSwgZG8gbm90IGNoYW5nZSB0aGUgcGFyc2VyIHN0YXRlIGFuZCByZXR1cm4gXCJmYWxzZVwiLlxuICAgKi9cbiAgZXhwZWN0T3B0aW9uYWxUb2tlbihraW5kKSB7XG4gICAgY29uc3QgdG9rZW4gPSB0aGlzLl9sZXhlci50b2tlbjtcbiAgICBpZiAodG9rZW4ua2luZCA9PT0ga2luZCkge1xuICAgICAgdGhpcy5hZHZhbmNlTGV4ZXIoKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIElmIHRoZSBuZXh0IHRva2VuIGlzIGEgZ2l2ZW4ga2V5d29yZCwgYWR2YW5jZSB0aGUgbGV4ZXIuXG4gICAqIE90aGVyd2lzZSwgZG8gbm90IGNoYW5nZSB0aGUgcGFyc2VyIHN0YXRlIGFuZCB0aHJvdyBhbiBlcnJvci5cbiAgICovXG4gIGV4cGVjdEtleXdvcmQodmFsdWUpIHtcbiAgICBjb25zdCB0b2tlbiA9IHRoaXMuX2xleGVyLnRva2VuO1xuICAgIGlmICh0b2tlbi5raW5kID09PSBUb2tlbktpbmQuTkFNRSAmJiB0b2tlbi52YWx1ZSA9PT0gdmFsdWUpIHtcbiAgICAgIHRoaXMuYWR2YW5jZUxleGVyKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgICB0aGlzLl9sZXhlci5zb3VyY2UsXG4gICAgICAgIHRva2VuLnN0YXJ0LFxuICAgICAgICBgRXhwZWN0ZWQgXCIke3ZhbHVlfVwiLCBmb3VuZCAke2dldFRva2VuRGVzYyh0b2tlbil9LmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBJZiB0aGUgbmV4dCB0b2tlbiBpcyBhIGdpdmVuIGtleXdvcmQsIHJldHVybiBcInRydWVcIiBhZnRlciBhZHZhbmNpbmcgdGhlIGxleGVyLlxuICAgKiBPdGhlcndpc2UsIGRvIG5vdCBjaGFuZ2UgdGhlIHBhcnNlciBzdGF0ZSBhbmQgcmV0dXJuIFwiZmFsc2VcIi5cbiAgICovXG4gIGV4cGVjdE9wdGlvbmFsS2V5d29yZCh2YWx1ZSkge1xuICAgIGNvbnN0IHRva2VuID0gdGhpcy5fbGV4ZXIudG9rZW47XG4gICAgaWYgKHRva2VuLmtpbmQgPT09IFRva2VuS2luZC5OQU1FICYmIHRva2VuLnZhbHVlID09PSB2YWx1ZSkge1xuICAgICAgdGhpcy5hZHZhbmNlTGV4ZXIoKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIEhlbHBlciBmdW5jdGlvbiBmb3IgY3JlYXRpbmcgYW4gZXJyb3Igd2hlbiBhbiB1bmV4cGVjdGVkIGxleGVkIHRva2VuIGlzIGVuY291bnRlcmVkLlxuICAgKi9cbiAgdW5leHBlY3RlZChhdFRva2VuKSB7XG4gICAgY29uc3QgdG9rZW4gPSBhdFRva2VuICE9PSBudWxsICYmIGF0VG9rZW4gIT09IHZvaWQgMCA/IGF0VG9rZW4gOiB0aGlzLl9sZXhlci50b2tlbjtcbiAgICByZXR1cm4gc3ludGF4RXJyb3IoXG4gICAgICB0aGlzLl9sZXhlci5zb3VyY2UsXG4gICAgICB0b2tlbi5zdGFydCxcbiAgICAgIGBVbmV4cGVjdGVkICR7Z2V0VG9rZW5EZXNjKHRva2VuKX0uYFxuICAgICk7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYSBwb3NzaWJseSBlbXB0eSBsaXN0IG9mIHBhcnNlIG5vZGVzLCBkZXRlcm1pbmVkIGJ5IHRoZSBwYXJzZUZuLlxuICAgKiBUaGlzIGxpc3QgYmVnaW5zIHdpdGggYSBsZXggdG9rZW4gb2Ygb3BlbktpbmQgYW5kIGVuZHMgd2l0aCBhIGxleCB0b2tlbiBvZiBjbG9zZUtpbmQuXG4gICAqIEFkdmFuY2VzIHRoZSBwYXJzZXIgdG8gdGhlIG5leHQgbGV4IHRva2VuIGFmdGVyIHRoZSBjbG9zaW5nIHRva2VuLlxuICAgKi9cbiAgYW55KG9wZW5LaW5kLCBwYXJzZUZuLCBjbG9zZUtpbmQpIHtcbiAgICB0aGlzLmV4cGVjdFRva2VuKG9wZW5LaW5kKTtcbiAgICBjb25zdCBub2RlcyA9IFtdO1xuICAgIHdoaWxlICghdGhpcy5leHBlY3RPcHRpb25hbFRva2VuKGNsb3NlS2luZCkpIHtcbiAgICAgIG5vZGVzLnB1c2gocGFyc2VGbi5jYWxsKHRoaXMpKTtcbiAgICB9XG4gICAgcmV0dXJuIG5vZGVzO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbGlzdCBvZiBwYXJzZSBub2RlcywgZGV0ZXJtaW5lZCBieSB0aGUgcGFyc2VGbi5cbiAgICogSXQgY2FuIGJlIGVtcHR5IG9ubHkgaWYgb3BlbiB0b2tlbiBpcyBtaXNzaW5nIG90aGVyd2lzZSBpdCB3aWxsIGFsd2F5cyByZXR1cm4gbm9uLWVtcHR5IGxpc3RcbiAgICogdGhhdCBiZWdpbnMgd2l0aCBhIGxleCB0b2tlbiBvZiBvcGVuS2luZCBhbmQgZW5kcyB3aXRoIGEgbGV4IHRva2VuIG9mIGNsb3NlS2luZC5cbiAgICogQWR2YW5jZXMgdGhlIHBhcnNlciB0byB0aGUgbmV4dCBsZXggdG9rZW4gYWZ0ZXIgdGhlIGNsb3NpbmcgdG9rZW4uXG4gICAqL1xuICBvcHRpb25hbE1hbnkob3BlbktpbmQsIHBhcnNlRm4sIGNsb3NlS2luZCkge1xuICAgIGlmICh0aGlzLmV4cGVjdE9wdGlvbmFsVG9rZW4ob3BlbktpbmQpKSB7XG4gICAgICBjb25zdCBub2RlcyA9IFtdO1xuICAgICAgZG8ge1xuICAgICAgICBub2Rlcy5wdXNoKHBhcnNlRm4uY2FsbCh0aGlzKSk7XG4gICAgICB9IHdoaWxlICghdGhpcy5leHBlY3RPcHRpb25hbFRva2VuKGNsb3NlS2luZCkpO1xuICAgICAgcmV0dXJuIG5vZGVzO1xuICAgIH1cbiAgICByZXR1cm4gW107XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYSBub24tZW1wdHkgbGlzdCBvZiBwYXJzZSBub2RlcywgZGV0ZXJtaW5lZCBieSB0aGUgcGFyc2VGbi5cbiAgICogVGhpcyBsaXN0IGJlZ2lucyB3aXRoIGEgbGV4IHRva2VuIG9mIG9wZW5LaW5kIGFuZCBlbmRzIHdpdGggYSBsZXggdG9rZW4gb2YgY2xvc2VLaW5kLlxuICAgKiBBZHZhbmNlcyB0aGUgcGFyc2VyIHRvIHRoZSBuZXh0IGxleCB0b2tlbiBhZnRlciB0aGUgY2xvc2luZyB0b2tlbi5cbiAgICovXG4gIG1hbnkob3BlbktpbmQsIHBhcnNlRm4sIGNsb3NlS2luZCkge1xuICAgIHRoaXMuZXhwZWN0VG9rZW4ob3BlbktpbmQpO1xuICAgIGNvbnN0IG5vZGVzID0gW107XG4gICAgZG8ge1xuICAgICAgbm9kZXMucHVzaChwYXJzZUZuLmNhbGwodGhpcykpO1xuICAgIH0gd2hpbGUgKCF0aGlzLmV4cGVjdE9wdGlvbmFsVG9rZW4oY2xvc2VLaW5kKSk7XG4gICAgcmV0dXJuIG5vZGVzO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbm9uLWVtcHR5IGxpc3Qgb2YgcGFyc2Ugbm9kZXMsIGRldGVybWluZWQgYnkgdGhlIHBhcnNlRm4uXG4gICAqIFRoaXMgbGlzdCBtYXkgYmVnaW4gd2l0aCBhIGxleCB0b2tlbiBvZiBkZWxpbWl0ZXJLaW5kIGZvbGxvd2VkIGJ5IGl0ZW1zIHNlcGFyYXRlZCBieSBsZXggdG9rZW5zIG9mIHRva2VuS2luZC5cbiAgICogQWR2YW5jZXMgdGhlIHBhcnNlciB0byB0aGUgbmV4dCBsZXggdG9rZW4gYWZ0ZXIgbGFzdCBpdGVtIGluIHRoZSBsaXN0LlxuICAgKi9cbiAgZGVsaW1pdGVkTWFueShkZWxpbWl0ZXJLaW5kLCBwYXJzZUZuKSB7XG4gICAgdGhpcy5leHBlY3RPcHRpb25hbFRva2VuKGRlbGltaXRlcktpbmQpO1xuICAgIGNvbnN0IG5vZGVzID0gW107XG4gICAgZG8ge1xuICAgICAgbm9kZXMucHVzaChwYXJzZUZuLmNhbGwodGhpcykpO1xuICAgIH0gd2hpbGUgKHRoaXMuZXhwZWN0T3B0aW9uYWxUb2tlbihkZWxpbWl0ZXJLaW5kKSk7XG4gICAgcmV0dXJuIG5vZGVzO1xuICB9XG4gIGFkdmFuY2VMZXhlcigpIHtcbiAgICBjb25zdCB7IG1heFRva2VucyB9ID0gdGhpcy5fb3B0aW9ucztcbiAgICBjb25zdCB0b2tlbiA9IHRoaXMuX2xleGVyLmFkdmFuY2UoKTtcbiAgICBpZiAobWF4VG9rZW5zICE9PSB2b2lkIDAgJiYgdG9rZW4ua2luZCAhPT0gVG9rZW5LaW5kLkVPRikge1xuICAgICAgKyt0aGlzLl90b2tlbkNvdW50ZXI7XG4gICAgICBpZiAodGhpcy5fdG9rZW5Db3VudGVyID4gbWF4VG9rZW5zKSB7XG4gICAgICAgIHRocm93IHN5bnRheEVycm9yKFxuICAgICAgICAgIHRoaXMuX2xleGVyLnNvdXJjZSxcbiAgICAgICAgICB0b2tlbi5zdGFydCxcbiAgICAgICAgICBgRG9jdW1lbnQgY29udGFpbnMgbW9yZSB0aGF0ICR7bWF4VG9rZW5zfSB0b2tlbnMuIFBhcnNpbmcgYWJvcnRlZC5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG59O1xuZnVuY3Rpb24gZ2V0VG9rZW5EZXNjKHRva2VuKSB7XG4gIGNvbnN0IHZhbHVlID0gdG9rZW4udmFsdWU7XG4gIHJldHVybiBnZXRUb2tlbktpbmREZXNjKHRva2VuLmtpbmQpICsgKHZhbHVlICE9IG51bGwgPyBgIFwiJHt2YWx1ZX1cImAgOiBcIlwiKTtcbn1cbmZ1bmN0aW9uIGdldFRva2VuS2luZERlc2Moa2luZCkge1xuICByZXR1cm4gaXNQdW5jdHVhdG9yVG9rZW5LaW5kKGtpbmQpID8gYFwiJHtraW5kfVwiYCA6IGtpbmQ7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL2RpZFlvdU1lYW4ubWpzXG52YXIgTUFYX1NVR0dFU1RJT05TID0gNTtcbmZ1bmN0aW9uIGRpZFlvdU1lYW4oZmlyc3RBcmcsIHNlY29uZEFyZykge1xuICBjb25zdCBbc3ViTWVzc2FnZSwgc3VnZ2VzdGlvbnNBcmddID0gc2Vjb25kQXJnID8gW2ZpcnN0QXJnLCBzZWNvbmRBcmddIDogW3ZvaWQgMCwgZmlyc3RBcmddO1xuICBsZXQgbWVzc2FnZTMgPSBcIiBEaWQgeW91IG1lYW4gXCI7XG4gIGlmIChzdWJNZXNzYWdlKSB7XG4gICAgbWVzc2FnZTMgKz0gc3ViTWVzc2FnZSArIFwiIFwiO1xuICB9XG4gIGNvbnN0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbnNBcmcubWFwKCh4KSA9PiBgXCIke3h9XCJgKTtcbiAgc3dpdGNoIChzdWdnZXN0aW9ucy5sZW5ndGgpIHtcbiAgICBjYXNlIDA6XG4gICAgICByZXR1cm4gXCJcIjtcbiAgICBjYXNlIDE6XG4gICAgICByZXR1cm4gbWVzc2FnZTMgKyBzdWdnZXN0aW9uc1swXSArIFwiP1wiO1xuICAgIGNhc2UgMjpcbiAgICAgIHJldHVybiBtZXNzYWdlMyArIHN1Z2dlc3Rpb25zWzBdICsgXCIgb3IgXCIgKyBzdWdnZXN0aW9uc1sxXSArIFwiP1wiO1xuICB9XG4gIGNvbnN0IHNlbGVjdGVkID0gc3VnZ2VzdGlvbnMuc2xpY2UoMCwgTUFYX1NVR0dFU1RJT05TKTtcbiAgY29uc3QgbGFzdEl0ZW0gPSBzZWxlY3RlZC5wb3AoKTtcbiAgcmV0dXJuIG1lc3NhZ2UzICsgc2VsZWN0ZWQuam9pbihcIiwgXCIpICsgXCIsIG9yIFwiICsgbGFzdEl0ZW0gKyBcIj9cIjtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvaWRlbnRpdHlGdW5jLm1qc1xuZnVuY3Rpb24gaWRlbnRpdHlGdW5jKHgpIHtcbiAgcmV0dXJuIHg7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL2tleU1hcC5tanNcbmZ1bmN0aW9uIGtleU1hcChsaXN0LCBrZXlGbikge1xuICBjb25zdCByZXN1bHQgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgZm9yIChjb25zdCBpdGVtIG9mIGxpc3QpIHtcbiAgICByZXN1bHRba2V5Rm4oaXRlbSldID0gaXRlbTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9rZXlWYWxNYXAubWpzXG5mdW5jdGlvbiBrZXlWYWxNYXAobGlzdCwga2V5Rm4sIHZhbEZuKSB7XG4gIGNvbnN0IHJlc3VsdCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBmb3IgKGNvbnN0IGl0ZW0gb2YgbGlzdCkge1xuICAgIHJlc3VsdFtrZXlGbihpdGVtKV0gPSB2YWxGbihpdGVtKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9tYXBWYWx1ZS5tanNcbmZ1bmN0aW9uIG1hcFZhbHVlKG1hcCwgZm4pIHtcbiAgY29uc3QgcmVzdWx0ID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKG1hcCkpIHtcbiAgICByZXN1bHRba2V5XSA9IGZuKG1hcFtrZXldLCBrZXkpO1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL25hdHVyYWxDb21wYXJlLm1qc1xuZnVuY3Rpb24gbmF0dXJhbENvbXBhcmUoYVN0ciwgYlN0cikge1xuICBsZXQgYUluZGV4ID0gMDtcbiAgbGV0IGJJbmRleCA9IDA7XG4gIHdoaWxlIChhSW5kZXggPCBhU3RyLmxlbmd0aCAmJiBiSW5kZXggPCBiU3RyLmxlbmd0aCkge1xuICAgIGxldCBhQ2hhciA9IGFTdHIuY2hhckNvZGVBdChhSW5kZXgpO1xuICAgIGxldCBiQ2hhciA9IGJTdHIuY2hhckNvZGVBdChiSW5kZXgpO1xuICAgIGlmIChpc0RpZ2l0MihhQ2hhcikgJiYgaXNEaWdpdDIoYkNoYXIpKSB7XG4gICAgICBsZXQgYU51bSA9IDA7XG4gICAgICBkbyB7XG4gICAgICAgICsrYUluZGV4O1xuICAgICAgICBhTnVtID0gYU51bSAqIDEwICsgYUNoYXIgLSBESUdJVF8wO1xuICAgICAgICBhQ2hhciA9IGFTdHIuY2hhckNvZGVBdChhSW5kZXgpO1xuICAgICAgfSB3aGlsZSAoaXNEaWdpdDIoYUNoYXIpICYmIGFOdW0gPiAwKTtcbiAgICAgIGxldCBiTnVtID0gMDtcbiAgICAgIGRvIHtcbiAgICAgICAgKytiSW5kZXg7XG4gICAgICAgIGJOdW0gPSBiTnVtICogMTAgKyBiQ2hhciAtIERJR0lUXzA7XG4gICAgICAgIGJDaGFyID0gYlN0ci5jaGFyQ29kZUF0KGJJbmRleCk7XG4gICAgICB9IHdoaWxlIChpc0RpZ2l0MihiQ2hhcikgJiYgYk51bSA+IDApO1xuICAgICAgaWYgKGFOdW0gPCBiTnVtKSB7XG4gICAgICAgIHJldHVybiAtMTtcbiAgICAgIH1cbiAgICAgIGlmIChhTnVtID4gYk51bSkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGFDaGFyIDwgYkNoYXIpIHtcbiAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgfVxuICAgICAgaWYgKGFDaGFyID4gYkNoYXIpIHtcbiAgICAgICAgcmV0dXJuIDE7XG4gICAgICB9XG4gICAgICArK2FJbmRleDtcbiAgICAgICsrYkluZGV4O1xuICAgIH1cbiAgfVxuICByZXR1cm4gYVN0ci5sZW5ndGggLSBiU3RyLmxlbmd0aDtcbn1cbnZhciBESUdJVF8wID0gNDg7XG52YXIgRElHSVRfOSA9IDU3O1xuZnVuY3Rpb24gaXNEaWdpdDIoY29kZSkge1xuICByZXR1cm4gIWlzTmFOKGNvZGUpICYmIERJR0lUXzAgPD0gY29kZSAmJiBjb2RlIDw9IERJR0lUXzk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9qc3V0aWxzL3N1Z2dlc3Rpb25MaXN0Lm1qc1xuZnVuY3Rpb24gc3VnZ2VzdGlvbkxpc3QoaW5wdXQsIG9wdGlvbnMpIHtcbiAgY29uc3Qgb3B0aW9uc0J5RGlzdGFuY2UgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgbGV4aWNhbERpc3RhbmNlID0gbmV3IExleGljYWxEaXN0YW5jZShpbnB1dCk7XG4gIGNvbnN0IHRocmVzaG9sZCA9IE1hdGguZmxvb3IoaW5wdXQubGVuZ3RoICogMC40KSArIDE7XG4gIGZvciAoY29uc3Qgb3B0aW9uIG9mIG9wdGlvbnMpIHtcbiAgICBjb25zdCBkaXN0YW5jZSA9IGxleGljYWxEaXN0YW5jZS5tZWFzdXJlKG9wdGlvbiwgdGhyZXNob2xkKTtcbiAgICBpZiAoZGlzdGFuY2UgIT09IHZvaWQgMCkge1xuICAgICAgb3B0aW9uc0J5RGlzdGFuY2Vbb3B0aW9uXSA9IGRpc3RhbmNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gT2JqZWN0LmtleXMob3B0aW9uc0J5RGlzdGFuY2UpLnNvcnQoKGEsIGIpID0+IHtcbiAgICBjb25zdCBkaXN0YW5jZURpZmYgPSBvcHRpb25zQnlEaXN0YW5jZVthXSAtIG9wdGlvbnNCeURpc3RhbmNlW2JdO1xuICAgIHJldHVybiBkaXN0YW5jZURpZmYgIT09IDAgPyBkaXN0YW5jZURpZmYgOiBuYXR1cmFsQ29tcGFyZShhLCBiKTtcbiAgfSk7XG59XG52YXIgTGV4aWNhbERpc3RhbmNlID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihpbnB1dCkge1xuICAgIHRoaXMuX2lucHV0ID0gaW5wdXQ7XG4gICAgdGhpcy5faW5wdXRMb3dlckNhc2UgPSBpbnB1dC50b0xvd2VyQ2FzZSgpO1xuICAgIHRoaXMuX2lucHV0QXJyYXkgPSBzdHJpbmdUb0FycmF5KHRoaXMuX2lucHV0TG93ZXJDYXNlKTtcbiAgICB0aGlzLl9yb3dzID0gW1xuICAgICAgbmV3IEFycmF5KGlucHV0Lmxlbmd0aCArIDEpLmZpbGwoMCksXG4gICAgICBuZXcgQXJyYXkoaW5wdXQubGVuZ3RoICsgMSkuZmlsbCgwKSxcbiAgICAgIG5ldyBBcnJheShpbnB1dC5sZW5ndGggKyAxKS5maWxsKDApXG4gICAgXTtcbiAgfVxuICBtZWFzdXJlKG9wdGlvbiwgdGhyZXNob2xkKSB7XG4gICAgaWYgKHRoaXMuX2lucHV0ID09PSBvcHRpb24pIHtcbiAgICAgIHJldHVybiAwO1xuICAgIH1cbiAgICBjb25zdCBvcHRpb25Mb3dlckNhc2UgPSBvcHRpb24udG9Mb3dlckNhc2UoKTtcbiAgICBpZiAodGhpcy5faW5wdXRMb3dlckNhc2UgPT09IG9wdGlvbkxvd2VyQ2FzZSkge1xuICAgICAgcmV0dXJuIDE7XG4gICAgfVxuICAgIGxldCBhID0gc3RyaW5nVG9BcnJheShvcHRpb25Mb3dlckNhc2UpO1xuICAgIGxldCBiID0gdGhpcy5faW5wdXRBcnJheTtcbiAgICBpZiAoYS5sZW5ndGggPCBiLmxlbmd0aCkge1xuICAgICAgY29uc3QgdG1wID0gYTtcbiAgICAgIGEgPSBiO1xuICAgICAgYiA9IHRtcDtcbiAgICB9XG4gICAgY29uc3QgYUxlbmd0aCA9IGEubGVuZ3RoO1xuICAgIGNvbnN0IGJMZW5ndGggPSBiLmxlbmd0aDtcbiAgICBpZiAoYUxlbmd0aCAtIGJMZW5ndGggPiB0aHJlc2hvbGQpIHtcbiAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgfVxuICAgIGNvbnN0IHJvd3MgPSB0aGlzLl9yb3dzO1xuICAgIGZvciAobGV0IGogPSAwOyBqIDw9IGJMZW5ndGg7IGorKykge1xuICAgICAgcm93c1swXVtqXSA9IGo7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAxOyBpIDw9IGFMZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgdXBSb3cgPSByb3dzWyhpIC0gMSkgJSAzXTtcbiAgICAgIGNvbnN0IGN1cnJlbnRSb3cgPSByb3dzW2kgJSAzXTtcbiAgICAgIGxldCBzbWFsbGVzdENlbGwgPSBjdXJyZW50Um93WzBdID0gaTtcbiAgICAgIGZvciAobGV0IGogPSAxOyBqIDw9IGJMZW5ndGg7IGorKykge1xuICAgICAgICBjb25zdCBjb3N0ID0gYVtpIC0gMV0gPT09IGJbaiAtIDFdID8gMCA6IDE7XG4gICAgICAgIGxldCBjdXJyZW50Q2VsbCA9IE1hdGgubWluKFxuICAgICAgICAgIHVwUm93W2pdICsgMSxcbiAgICAgICAgICAvLyBkZWxldGVcbiAgICAgICAgICBjdXJyZW50Um93W2ogLSAxXSArIDEsXG4gICAgICAgICAgLy8gaW5zZXJ0XG4gICAgICAgICAgdXBSb3dbaiAtIDFdICsgY29zdFxuICAgICAgICAgIC8vIHN1YnN0aXR1dGVcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKGkgPiAxICYmIGogPiAxICYmIGFbaSAtIDFdID09PSBiW2ogLSAyXSAmJiBhW2kgLSAyXSA9PT0gYltqIC0gMV0pIHtcbiAgICAgICAgICBjb25zdCBkb3VibGVEaWFnb25hbENlbGwgPSByb3dzWyhpIC0gMikgJSAzXVtqIC0gMl07XG4gICAgICAgICAgY3VycmVudENlbGwgPSBNYXRoLm1pbihjdXJyZW50Q2VsbCwgZG91YmxlRGlhZ29uYWxDZWxsICsgMSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGN1cnJlbnRDZWxsIDwgc21hbGxlc3RDZWxsKSB7XG4gICAgICAgICAgc21hbGxlc3RDZWxsID0gY3VycmVudENlbGw7XG4gICAgICAgIH1cbiAgICAgICAgY3VycmVudFJvd1tqXSA9IGN1cnJlbnRDZWxsO1xuICAgICAgfVxuICAgICAgaWYgKHNtYWxsZXN0Q2VsbCA+IHRocmVzaG9sZCkge1xuICAgICAgICByZXR1cm4gdm9pZCAwO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBkaXN0YW5jZSA9IHJvd3NbYUxlbmd0aCAlIDNdW2JMZW5ndGhdO1xuICAgIHJldHVybiBkaXN0YW5jZSA8PSB0aHJlc2hvbGQgPyBkaXN0YW5jZSA6IHZvaWQgMDtcbiAgfVxufTtcbmZ1bmN0aW9uIHN0cmluZ1RvQXJyYXkoc3RyKSB7XG4gIGNvbnN0IHN0ckxlbmd0aCA9IHN0ci5sZW5ndGg7XG4gIGNvbnN0IGFycmF5ID0gbmV3IEFycmF5KHN0ckxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyTGVuZ3RoOyArK2kpIHtcbiAgICBhcnJheVtpXSA9IHN0ci5jaGFyQ29kZUF0KGkpO1xuICB9XG4gIHJldHVybiBhcnJheTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvdG9PYmpNYXAubWpzXG5mdW5jdGlvbiB0b09iak1hcChvYmopIHtcbiAgaWYgKG9iaiA9PSBudWxsKSB7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB9XG4gIGlmIChPYmplY3QuZ2V0UHJvdG90eXBlT2Yob2JqKSA9PT0gbnVsbCkge1xuICAgIHJldHVybiBvYmo7XG4gIH1cbiAgY29uc3QgbWFwID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKG9iaikpIHtcbiAgICBtYXBba2V5XSA9IHZhbHVlO1xuICB9XG4gIHJldHVybiBtYXA7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC9sYW5ndWFnZS9wcmludFN0cmluZy5tanNcbmZ1bmN0aW9uIHByaW50U3RyaW5nKHN0cikge1xuICByZXR1cm4gYFwiJHtzdHIucmVwbGFjZShlc2NhcGVkUmVnRXhwLCBlc2NhcGVkUmVwbGFjZXIpfVwiYDtcbn1cbnZhciBlc2NhcGVkUmVnRXhwID0gL1tcXHgwMC1cXHgxZlxceDIyXFx4NWNcXHg3Zi1cXHg5Zl0vZztcbmZ1bmN0aW9uIGVzY2FwZWRSZXBsYWNlcihzdHIpIHtcbiAgcmV0dXJuIGVzY2FwZVNlcXVlbmNlc1tzdHIuY2hhckNvZGVBdCgwKV07XG59XG52YXIgZXNjYXBlU2VxdWVuY2VzID0gW1xuICBcIlxcXFx1MDAwMFwiLFxuICBcIlxcXFx1MDAwMVwiLFxuICBcIlxcXFx1MDAwMlwiLFxuICBcIlxcXFx1MDAwM1wiLFxuICBcIlxcXFx1MDAwNFwiLFxuICBcIlxcXFx1MDAwNVwiLFxuICBcIlxcXFx1MDAwNlwiLFxuICBcIlxcXFx1MDAwN1wiLFxuICBcIlxcXFxiXCIsXG4gIFwiXFxcXHRcIixcbiAgXCJcXFxcblwiLFxuICBcIlxcXFx1MDAwQlwiLFxuICBcIlxcXFxmXCIsXG4gIFwiXFxcXHJcIixcbiAgXCJcXFxcdTAwMEVcIixcbiAgXCJcXFxcdTAwMEZcIixcbiAgXCJcXFxcdTAwMTBcIixcbiAgXCJcXFxcdTAwMTFcIixcbiAgXCJcXFxcdTAwMTJcIixcbiAgXCJcXFxcdTAwMTNcIixcbiAgXCJcXFxcdTAwMTRcIixcbiAgXCJcXFxcdTAwMTVcIixcbiAgXCJcXFxcdTAwMTZcIixcbiAgXCJcXFxcdTAwMTdcIixcbiAgXCJcXFxcdTAwMThcIixcbiAgXCJcXFxcdTAwMTlcIixcbiAgXCJcXFxcdTAwMUFcIixcbiAgXCJcXFxcdTAwMUJcIixcbiAgXCJcXFxcdTAwMUNcIixcbiAgXCJcXFxcdTAwMURcIixcbiAgXCJcXFxcdTAwMUVcIixcbiAgXCJcXFxcdTAwMUZcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgJ1xcXFxcIicsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIC8vIDJGXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIC8vIDNGXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIC8vIDRGXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXCIsXG4gIFwiXFxcXFxcXFxcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgLy8gNUZcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgLy8gNkZcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcIixcbiAgXCJcXFxcdTAwN0ZcIixcbiAgXCJcXFxcdTAwODBcIixcbiAgXCJcXFxcdTAwODFcIixcbiAgXCJcXFxcdTAwODJcIixcbiAgXCJcXFxcdTAwODNcIixcbiAgXCJcXFxcdTAwODRcIixcbiAgXCJcXFxcdTAwODVcIixcbiAgXCJcXFxcdTAwODZcIixcbiAgXCJcXFxcdTAwODdcIixcbiAgXCJcXFxcdTAwODhcIixcbiAgXCJcXFxcdTAwODlcIixcbiAgXCJcXFxcdTAwOEFcIixcbiAgXCJcXFxcdTAwOEJcIixcbiAgXCJcXFxcdTAwOENcIixcbiAgXCJcXFxcdTAwOERcIixcbiAgXCJcXFxcdTAwOEVcIixcbiAgXCJcXFxcdTAwOEZcIixcbiAgXCJcXFxcdTAwOTBcIixcbiAgXCJcXFxcdTAwOTFcIixcbiAgXCJcXFxcdTAwOTJcIixcbiAgXCJcXFxcdTAwOTNcIixcbiAgXCJcXFxcdTAwOTRcIixcbiAgXCJcXFxcdTAwOTVcIixcbiAgXCJcXFxcdTAwOTZcIixcbiAgXCJcXFxcdTAwOTdcIixcbiAgXCJcXFxcdTAwOThcIixcbiAgXCJcXFxcdTAwOTlcIixcbiAgXCJcXFxcdTAwOUFcIixcbiAgXCJcXFxcdTAwOUJcIixcbiAgXCJcXFxcdTAwOUNcIixcbiAgXCJcXFxcdTAwOURcIixcbiAgXCJcXFxcdTAwOUVcIixcbiAgXCJcXFxcdTAwOUZcIlxuXTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL3Zpc2l0b3IubWpzXG52YXIgQlJFQUsgPSBPYmplY3QuZnJlZXplKHt9KTtcbmZ1bmN0aW9uIHZpc2l0KHJvb3QsIHZpc2l0b3IsIHZpc2l0b3JLZXlzID0gUXVlcnlEb2N1bWVudEtleXMpIHtcbiAgY29uc3QgZW50ZXJMZWF2ZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIGZvciAoY29uc3Qga2luZCBvZiBPYmplY3QudmFsdWVzKEtpbmQpKSB7XG4gICAgZW50ZXJMZWF2ZU1hcC5zZXQoa2luZCwgZ2V0RW50ZXJMZWF2ZUZvcktpbmQodmlzaXRvciwga2luZCkpO1xuICB9XG4gIGxldCBzdGFjayA9IHZvaWQgMDtcbiAgbGV0IGluQXJyYXkgPSBBcnJheS5pc0FycmF5KHJvb3QpO1xuICBsZXQga2V5cyA9IFtyb290XTtcbiAgbGV0IGluZGV4ID0gLTE7XG4gIGxldCBlZGl0cyA9IFtdO1xuICBsZXQgbm9kZSA9IHJvb3Q7XG4gIGxldCBrZXkgPSB2b2lkIDA7XG4gIGxldCBwYXJlbnQgPSB2b2lkIDA7XG4gIGNvbnN0IHBhdGggPSBbXTtcbiAgY29uc3QgYW5jZXN0b3JzID0gW107XG4gIGRvIHtcbiAgICBpbmRleCsrO1xuICAgIGNvbnN0IGlzTGVhdmluZyA9IGluZGV4ID09PSBrZXlzLmxlbmd0aDtcbiAgICBjb25zdCBpc0VkaXRlZCA9IGlzTGVhdmluZyAmJiBlZGl0cy5sZW5ndGggIT09IDA7XG4gICAgaWYgKGlzTGVhdmluZykge1xuICAgICAga2V5ID0gYW5jZXN0b3JzLmxlbmd0aCA9PT0gMCA/IHZvaWQgMCA6IHBhdGhbcGF0aC5sZW5ndGggLSAxXTtcbiAgICAgIG5vZGUgPSBwYXJlbnQ7XG4gICAgICBwYXJlbnQgPSBhbmNlc3RvcnMucG9wKCk7XG4gICAgICBpZiAoaXNFZGl0ZWQpIHtcbiAgICAgICAgaWYgKGluQXJyYXkpIHtcbiAgICAgICAgICBub2RlID0gbm9kZS5zbGljZSgpO1xuICAgICAgICAgIGxldCBlZGl0T2Zmc2V0ID0gMDtcbiAgICAgICAgICBmb3IgKGNvbnN0IFtlZGl0S2V5LCBlZGl0VmFsdWVdIG9mIGVkaXRzKSB7XG4gICAgICAgICAgICBjb25zdCBhcnJheUtleSA9IGVkaXRLZXkgLSBlZGl0T2Zmc2V0O1xuICAgICAgICAgICAgaWYgKGVkaXRWYWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICBub2RlLnNwbGljZShhcnJheUtleSwgMSk7XG4gICAgICAgICAgICAgIGVkaXRPZmZzZXQrKztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIG5vZGVbYXJyYXlLZXldID0gZWRpdFZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBub2RlID0gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoXG4gICAgICAgICAgICB7fSxcbiAgICAgICAgICAgIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKG5vZGUpXG4gICAgICAgICAgKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IFtlZGl0S2V5LCBlZGl0VmFsdWVdIG9mIGVkaXRzKSB7XG4gICAgICAgICAgICBub2RlW2VkaXRLZXldID0gZWRpdFZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaW5kZXggPSBzdGFjay5pbmRleDtcbiAgICAgIGtleXMgPSBzdGFjay5rZXlzO1xuICAgICAgZWRpdHMgPSBzdGFjay5lZGl0cztcbiAgICAgIGluQXJyYXkgPSBzdGFjay5pbkFycmF5O1xuICAgICAgc3RhY2sgPSBzdGFjay5wcmV2O1xuICAgIH0gZWxzZSBpZiAocGFyZW50KSB7XG4gICAgICBrZXkgPSBpbkFycmF5ID8gaW5kZXggOiBrZXlzW2luZGV4XTtcbiAgICAgIG5vZGUgPSBwYXJlbnRba2V5XTtcbiAgICAgIGlmIChub2RlID09PSBudWxsIHx8IG5vZGUgPT09IHZvaWQgMCkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIHBhdGgucHVzaChrZXkpO1xuICAgIH1cbiAgICBsZXQgcmVzdWx0O1xuICAgIGlmICghQXJyYXkuaXNBcnJheShub2RlKSkge1xuICAgICAgdmFyIF9lbnRlckxlYXZlTWFwJGdldCwgX2VudGVyTGVhdmVNYXAkZ2V0MjtcbiAgICAgIGlzTm9kZShub2RlKSB8fCBkZXZBc3NlcnQoZmFsc2UsIGBJbnZhbGlkIEFTVCBOb2RlOiAke2luc3BlY3Qobm9kZSl9LmApO1xuICAgICAgY29uc3QgdmlzaXRGbiA9IGlzTGVhdmluZyA/IChfZW50ZXJMZWF2ZU1hcCRnZXQgPSBlbnRlckxlYXZlTWFwLmdldChub2RlLmtpbmQpKSA9PT0gbnVsbCB8fCBfZW50ZXJMZWF2ZU1hcCRnZXQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9lbnRlckxlYXZlTWFwJGdldC5sZWF2ZSA6IChfZW50ZXJMZWF2ZU1hcCRnZXQyID0gZW50ZXJMZWF2ZU1hcC5nZXQobm9kZS5raW5kKSkgPT09IG51bGwgfHwgX2VudGVyTGVhdmVNYXAkZ2V0MiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2VudGVyTGVhdmVNYXAkZ2V0Mi5lbnRlcjtcbiAgICAgIHJlc3VsdCA9IHZpc2l0Rm4gPT09IG51bGwgfHwgdmlzaXRGbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogdmlzaXRGbi5jYWxsKHZpc2l0b3IsIG5vZGUsIGtleSwgcGFyZW50LCBwYXRoLCBhbmNlc3RvcnMpO1xuICAgICAgaWYgKHJlc3VsdCA9PT0gQlJFQUspIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBpZiAocmVzdWx0ID09PSBmYWxzZSkge1xuICAgICAgICBpZiAoIWlzTGVhdmluZykge1xuICAgICAgICAgIHBhdGgucG9wKCk7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAocmVzdWx0ICE9PSB2b2lkIDApIHtcbiAgICAgICAgZWRpdHMucHVzaChba2V5LCByZXN1bHRdKTtcbiAgICAgICAgaWYgKCFpc0xlYXZpbmcpIHtcbiAgICAgICAgICBpZiAoaXNOb2RlKHJlc3VsdCkpIHtcbiAgICAgICAgICAgIG5vZGUgPSByZXN1bHQ7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHBhdGgucG9wKCk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHJlc3VsdCA9PT0gdm9pZCAwICYmIGlzRWRpdGVkKSB7XG4gICAgICBlZGl0cy5wdXNoKFtrZXksIG5vZGVdKTtcbiAgICB9XG4gICAgaWYgKGlzTGVhdmluZykge1xuICAgICAgcGF0aC5wb3AoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIF9ub2RlJGtpbmQ7XG4gICAgICBzdGFjayA9IHtcbiAgICAgICAgaW5BcnJheSxcbiAgICAgICAgaW5kZXgsXG4gICAgICAgIGtleXMsXG4gICAgICAgIGVkaXRzLFxuICAgICAgICBwcmV2OiBzdGFja1xuICAgICAgfTtcbiAgICAgIGluQXJyYXkgPSBBcnJheS5pc0FycmF5KG5vZGUpO1xuICAgICAga2V5cyA9IGluQXJyYXkgPyBub2RlIDogKF9ub2RlJGtpbmQgPSB2aXNpdG9yS2V5c1tub2RlLmtpbmRdKSAhPT0gbnVsbCAmJiBfbm9kZSRraW5kICE9PSB2b2lkIDAgPyBfbm9kZSRraW5kIDogW107XG4gICAgICBpbmRleCA9IC0xO1xuICAgICAgZWRpdHMgPSBbXTtcbiAgICAgIGlmIChwYXJlbnQpIHtcbiAgICAgICAgYW5jZXN0b3JzLnB1c2gocGFyZW50KTtcbiAgICAgIH1cbiAgICAgIHBhcmVudCA9IG5vZGU7XG4gICAgfVxuICB9IHdoaWxlIChzdGFjayAhPT0gdm9pZCAwKTtcbiAgaWYgKGVkaXRzLmxlbmd0aCAhPT0gMCkge1xuICAgIHJldHVybiBlZGl0c1tlZGl0cy5sZW5ndGggLSAxXVsxXTtcbiAgfVxuICByZXR1cm4gcm9vdDtcbn1cbmZ1bmN0aW9uIGdldEVudGVyTGVhdmVGb3JLaW5kKHZpc2l0b3IsIGtpbmQpIHtcbiAgY29uc3Qga2luZFZpc2l0b3IgPSB2aXNpdG9yW2tpbmRdO1xuICBpZiAodHlwZW9mIGtpbmRWaXNpdG9yID09PSBcIm9iamVjdFwiKSB7XG4gICAgcmV0dXJuIGtpbmRWaXNpdG9yO1xuICB9IGVsc2UgaWYgKHR5cGVvZiBraW5kVmlzaXRvciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGVudGVyOiBraW5kVmlzaXRvcixcbiAgICAgIGxlYXZlOiB2b2lkIDBcbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgZW50ZXI6IHZpc2l0b3IuZW50ZXIsXG4gICAgbGVhdmU6IHZpc2l0b3IubGVhdmVcbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2xhbmd1YWdlL3ByaW50ZXIubWpzXG5mdW5jdGlvbiBwcmludChhc3QpIHtcbiAgcmV0dXJuIHZpc2l0KGFzdCwgcHJpbnREb2NBU1RSZWR1Y2VyKTtcbn1cbnZhciBNQVhfTElORV9MRU5HVEggPSA4MDtcbnZhciBwcmludERvY0FTVFJlZHVjZXIgPSB7XG4gIE5hbWU6IHtcbiAgICBsZWF2ZTogKG5vZGUpID0+IG5vZGUudmFsdWVcbiAgfSxcbiAgVmFyaWFibGU6IHtcbiAgICBsZWF2ZTogKG5vZGUpID0+IFwiJFwiICsgbm9kZS5uYW1lXG4gIH0sXG4gIC8vIERvY3VtZW50XG4gIERvY3VtZW50OiB7XG4gICAgbGVhdmU6IChub2RlKSA9PiBqb2luKG5vZGUuZGVmaW5pdGlvbnMsIFwiXFxuXFxuXCIpXG4gIH0sXG4gIE9wZXJhdGlvbkRlZmluaXRpb246IHtcbiAgICBsZWF2ZShub2RlKSB7XG4gICAgICBjb25zdCB2YXJEZWZzID0gd3JhcChcIihcIiwgam9pbihub2RlLnZhcmlhYmxlRGVmaW5pdGlvbnMsIFwiLCBcIiksIFwiKVwiKTtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGpvaW4oXG4gICAgICAgIFtcbiAgICAgICAgICBub2RlLm9wZXJhdGlvbixcbiAgICAgICAgICBqb2luKFtub2RlLm5hbWUsIHZhckRlZnNdKSxcbiAgICAgICAgICBqb2luKG5vZGUuZGlyZWN0aXZlcywgXCIgXCIpXG4gICAgICAgIF0sXG4gICAgICAgIFwiIFwiXG4gICAgICApO1xuICAgICAgcmV0dXJuIChwcmVmaXggPT09IFwicXVlcnlcIiA/IFwiXCIgOiBwcmVmaXggKyBcIiBcIikgKyBub2RlLnNlbGVjdGlvblNldDtcbiAgICB9XG4gIH0sXG4gIFZhcmlhYmxlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyB2YXJpYWJsZSwgdHlwZSwgZGVmYXVsdFZhbHVlLCBkaXJlY3RpdmVzIH0pID0+IHZhcmlhYmxlICsgXCI6IFwiICsgdHlwZSArIHdyYXAoXCIgPSBcIiwgZGVmYXVsdFZhbHVlKSArIHdyYXAoXCIgXCIsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpKVxuICB9LFxuICBTZWxlY3Rpb25TZXQ6IHtcbiAgICBsZWF2ZTogKHsgc2VsZWN0aW9ucyB9KSA9PiBibG9jayhzZWxlY3Rpb25zKVxuICB9LFxuICBGaWVsZDoge1xuICAgIGxlYXZlKHsgYWxpYXMsIG5hbWUsIGFyZ3VtZW50czogYXJncywgZGlyZWN0aXZlcywgc2VsZWN0aW9uU2V0IH0pIHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IHdyYXAoXCJcIiwgYWxpYXMsIFwiOiBcIikgKyBuYW1lO1xuICAgICAgbGV0IGFyZ3NMaW5lID0gcHJlZml4ICsgd3JhcChcIihcIiwgam9pbihhcmdzLCBcIiwgXCIpLCBcIilcIik7XG4gICAgICBpZiAoYXJnc0xpbmUubGVuZ3RoID4gTUFYX0xJTkVfTEVOR1RIKSB7XG4gICAgICAgIGFyZ3NMaW5lID0gcHJlZml4ICsgd3JhcChcIihcXG5cIiwgaW5kZW50KGpvaW4oYXJncywgXCJcXG5cIikpLCBcIlxcbilcIik7XG4gICAgICB9XG4gICAgICByZXR1cm4gam9pbihbYXJnc0xpbmUsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLCBzZWxlY3Rpb25TZXRdLCBcIiBcIik7XG4gICAgfVxuICB9LFxuICBBcmd1bWVudDoge1xuICAgIGxlYXZlOiAoeyBuYW1lLCB2YWx1ZSB9KSA9PiBuYW1lICsgXCI6IFwiICsgdmFsdWVcbiAgfSxcbiAgLy8gRnJhZ21lbnRzXG4gIEZyYWdtZW50U3ByZWFkOiB7XG4gICAgbGVhdmU6ICh7IG5hbWUsIGRpcmVjdGl2ZXMgfSkgPT4gXCIuLi5cIiArIG5hbWUgKyB3cmFwKFwiIFwiLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSlcbiAgfSxcbiAgSW5saW5lRnJhZ21lbnQ6IHtcbiAgICBsZWF2ZTogKHsgdHlwZUNvbmRpdGlvbiwgZGlyZWN0aXZlcywgc2VsZWN0aW9uU2V0IH0pID0+IGpvaW4oXG4gICAgICBbXG4gICAgICAgIFwiLi4uXCIsXG4gICAgICAgIHdyYXAoXCJvbiBcIiwgdHlwZUNvbmRpdGlvbiksXG4gICAgICAgIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLFxuICAgICAgICBzZWxlY3Rpb25TZXRcbiAgICAgIF0sXG4gICAgICBcIiBcIlxuICAgIClcbiAgfSxcbiAgRnJhZ21lbnREZWZpbml0aW9uOiB7XG4gICAgbGVhdmU6ICh7IG5hbWUsIHR5cGVDb25kaXRpb24sIHZhcmlhYmxlRGVmaW5pdGlvbnMsIGRpcmVjdGl2ZXMsIHNlbGVjdGlvblNldCB9KSA9PiAoXG4gICAgICAvLyBvciByZW1vdmVkIGluIHRoZSBmdXR1cmUuXG4gICAgICBgZnJhZ21lbnQgJHtuYW1lfSR7d3JhcChcIihcIiwgam9pbih2YXJpYWJsZURlZmluaXRpb25zLCBcIiwgXCIpLCBcIilcIil9IG9uICR7dHlwZUNvbmRpdGlvbn0gJHt3cmFwKFwiXCIsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLCBcIiBcIil9YCArIHNlbGVjdGlvblNldFxuICAgIClcbiAgfSxcbiAgLy8gVmFsdWVcbiAgSW50VmFsdWU6IHtcbiAgICBsZWF2ZTogKHsgdmFsdWUgfSkgPT4gdmFsdWVcbiAgfSxcbiAgRmxvYXRWYWx1ZToge1xuICAgIGxlYXZlOiAoeyB2YWx1ZSB9KSA9PiB2YWx1ZVxuICB9LFxuICBTdHJpbmdWYWx1ZToge1xuICAgIGxlYXZlOiAoeyB2YWx1ZSwgYmxvY2s6IGlzQmxvY2tTdHJpbmcgfSkgPT4gaXNCbG9ja1N0cmluZyA/IHByaW50QmxvY2tTdHJpbmcodmFsdWUpIDogcHJpbnRTdHJpbmcodmFsdWUpXG4gIH0sXG4gIEJvb2xlYW5WYWx1ZToge1xuICAgIGxlYXZlOiAoeyB2YWx1ZSB9KSA9PiB2YWx1ZSA/IFwidHJ1ZVwiIDogXCJmYWxzZVwiXG4gIH0sXG4gIE51bGxWYWx1ZToge1xuICAgIGxlYXZlOiAoKSA9PiBcIm51bGxcIlxuICB9LFxuICBFbnVtVmFsdWU6IHtcbiAgICBsZWF2ZTogKHsgdmFsdWUgfSkgPT4gdmFsdWVcbiAgfSxcbiAgTGlzdFZhbHVlOiB7XG4gICAgbGVhdmU6ICh7IHZhbHVlcyB9KSA9PiBcIltcIiArIGpvaW4odmFsdWVzLCBcIiwgXCIpICsgXCJdXCJcbiAgfSxcbiAgT2JqZWN0VmFsdWU6IHtcbiAgICBsZWF2ZTogKHsgZmllbGRzIH0pID0+IFwie1wiICsgam9pbihmaWVsZHMsIFwiLCBcIikgKyBcIn1cIlxuICB9LFxuICBPYmplY3RGaWVsZDoge1xuICAgIGxlYXZlOiAoeyBuYW1lLCB2YWx1ZSB9KSA9PiBuYW1lICsgXCI6IFwiICsgdmFsdWVcbiAgfSxcbiAgLy8gRGlyZWN0aXZlXG4gIERpcmVjdGl2ZToge1xuICAgIGxlYXZlOiAoeyBuYW1lLCBhcmd1bWVudHM6IGFyZ3MgfSkgPT4gXCJAXCIgKyBuYW1lICsgd3JhcChcIihcIiwgam9pbihhcmdzLCBcIiwgXCIpLCBcIilcIilcbiAgfSxcbiAgLy8gVHlwZVxuICBOYW1lZFR5cGU6IHtcbiAgICBsZWF2ZTogKHsgbmFtZSB9KSA9PiBuYW1lXG4gIH0sXG4gIExpc3RUeXBlOiB7XG4gICAgbGVhdmU6ICh7IHR5cGUgfSkgPT4gXCJbXCIgKyB0eXBlICsgXCJdXCJcbiAgfSxcbiAgTm9uTnVsbFR5cGU6IHtcbiAgICBsZWF2ZTogKHsgdHlwZSB9KSA9PiB0eXBlICsgXCIhXCJcbiAgfSxcbiAgLy8gVHlwZSBTeXN0ZW0gRGVmaW5pdGlvbnNcbiAgU2NoZW1hRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgZGlyZWN0aXZlcywgb3BlcmF0aW9uVHlwZXMgfSkgPT4gd3JhcChcIlwiLCBkZXNjcmlwdGlvbiwgXCJcXG5cIikgKyBqb2luKFtcInNjaGVtYVwiLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSwgYmxvY2sob3BlcmF0aW9uVHlwZXMpXSwgXCIgXCIpXG4gIH0sXG4gIE9wZXJhdGlvblR5cGVEZWZpbml0aW9uOiB7XG4gICAgbGVhdmU6ICh7IG9wZXJhdGlvbiwgdHlwZSB9KSA9PiBvcGVyYXRpb24gKyBcIjogXCIgKyB0eXBlXG4gIH0sXG4gIFNjYWxhclR5cGVEZWZpbml0aW9uOiB7XG4gICAgbGVhdmU6ICh7IGRlc2NyaXB0aW9uLCBuYW1lLCBkaXJlY3RpdmVzIH0pID0+IHdyYXAoXCJcIiwgZGVzY3JpcHRpb24sIFwiXFxuXCIpICsgam9pbihbXCJzY2FsYXJcIiwgbmFtZSwgam9pbihkaXJlY3RpdmVzLCBcIiBcIildLCBcIiBcIilcbiAgfSxcbiAgT2JqZWN0VHlwZURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIG5hbWUsIGludGVyZmFjZXMsIGRpcmVjdGl2ZXMsIGZpZWxkcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIGpvaW4oXG4gICAgICBbXG4gICAgICAgIFwidHlwZVwiLFxuICAgICAgICBuYW1lLFxuICAgICAgICB3cmFwKFwiaW1wbGVtZW50cyBcIiwgam9pbihpbnRlcmZhY2VzLCBcIiAmIFwiKSksXG4gICAgICAgIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLFxuICAgICAgICBibG9jayhmaWVsZHMpXG4gICAgICBdLFxuICAgICAgXCIgXCJcbiAgICApXG4gIH0sXG4gIEZpZWxkRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgYXJndW1lbnRzOiBhcmdzLCB0eXBlLCBkaXJlY3RpdmVzIH0pID0+IHdyYXAoXCJcIiwgZGVzY3JpcHRpb24sIFwiXFxuXCIpICsgbmFtZSArIChoYXNNdWx0aWxpbmVJdGVtcyhhcmdzKSA/IHdyYXAoXCIoXFxuXCIsIGluZGVudChqb2luKGFyZ3MsIFwiXFxuXCIpKSwgXCJcXG4pXCIpIDogd3JhcChcIihcIiwgam9pbihhcmdzLCBcIiwgXCIpLCBcIilcIikpICsgXCI6IFwiICsgdHlwZSArIHdyYXAoXCIgXCIsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpKVxuICB9LFxuICBJbnB1dFZhbHVlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgdHlwZSwgZGVmYXVsdFZhbHVlLCBkaXJlY3RpdmVzIH0pID0+IHdyYXAoXCJcIiwgZGVzY3JpcHRpb24sIFwiXFxuXCIpICsgam9pbihcbiAgICAgIFtuYW1lICsgXCI6IFwiICsgdHlwZSwgd3JhcChcIj0gXCIsIGRlZmF1bHRWYWx1ZSksIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpXSxcbiAgICAgIFwiIFwiXG4gICAgKVxuICB9LFxuICBJbnRlcmZhY2VUeXBlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgaW50ZXJmYWNlcywgZGlyZWN0aXZlcywgZmllbGRzIH0pID0+IHdyYXAoXCJcIiwgZGVzY3JpcHRpb24sIFwiXFxuXCIpICsgam9pbihcbiAgICAgIFtcbiAgICAgICAgXCJpbnRlcmZhY2VcIixcbiAgICAgICAgbmFtZSxcbiAgICAgICAgd3JhcChcImltcGxlbWVudHMgXCIsIGpvaW4oaW50ZXJmYWNlcywgXCIgJiBcIikpLFxuICAgICAgICBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSxcbiAgICAgICAgYmxvY2soZmllbGRzKVxuICAgICAgXSxcbiAgICAgIFwiIFwiXG4gICAgKVxuICB9LFxuICBVbmlvblR5cGVEZWZpbml0aW9uOiB7XG4gICAgbGVhdmU6ICh7IGRlc2NyaXB0aW9uLCBuYW1lLCBkaXJlY3RpdmVzLCB0eXBlcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIGpvaW4oXG4gICAgICBbXCJ1bmlvblwiLCBuYW1lLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSwgd3JhcChcIj0gXCIsIGpvaW4odHlwZXMsIFwiIHwgXCIpKV0sXG4gICAgICBcIiBcIlxuICAgIClcbiAgfSxcbiAgRW51bVR5cGVEZWZpbml0aW9uOiB7XG4gICAgbGVhdmU6ICh7IGRlc2NyaXB0aW9uLCBuYW1lLCBkaXJlY3RpdmVzLCB2YWx1ZXMgfSkgPT4gd3JhcChcIlwiLCBkZXNjcmlwdGlvbiwgXCJcXG5cIikgKyBqb2luKFtcImVudW1cIiwgbmFtZSwgam9pbihkaXJlY3RpdmVzLCBcIiBcIiksIGJsb2NrKHZhbHVlcyldLCBcIiBcIilcbiAgfSxcbiAgRW51bVZhbHVlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgZGlyZWN0aXZlcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIGpvaW4oW25hbWUsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpXSwgXCIgXCIpXG4gIH0sXG4gIElucHV0T2JqZWN0VHlwZURlZmluaXRpb246IHtcbiAgICBsZWF2ZTogKHsgZGVzY3JpcHRpb24sIG5hbWUsIGRpcmVjdGl2ZXMsIGZpZWxkcyB9KSA9PiB3cmFwKFwiXCIsIGRlc2NyaXB0aW9uLCBcIlxcblwiKSArIGpvaW4oW1wiaW5wdXRcIiwgbmFtZSwgam9pbihkaXJlY3RpdmVzLCBcIiBcIiksIGJsb2NrKGZpZWxkcyldLCBcIiBcIilcbiAgfSxcbiAgRGlyZWN0aXZlRGVmaW5pdGlvbjoge1xuICAgIGxlYXZlOiAoeyBkZXNjcmlwdGlvbiwgbmFtZSwgYXJndW1lbnRzOiBhcmdzLCByZXBlYXRhYmxlLCBsb2NhdGlvbnMgfSkgPT4gd3JhcChcIlwiLCBkZXNjcmlwdGlvbiwgXCJcXG5cIikgKyBcImRpcmVjdGl2ZSBAXCIgKyBuYW1lICsgKGhhc011bHRpbGluZUl0ZW1zKGFyZ3MpID8gd3JhcChcIihcXG5cIiwgaW5kZW50KGpvaW4oYXJncywgXCJcXG5cIikpLCBcIlxcbilcIikgOiB3cmFwKFwiKFwiLCBqb2luKGFyZ3MsIFwiLCBcIiksIFwiKVwiKSkgKyAocmVwZWF0YWJsZSA/IFwiIHJlcGVhdGFibGVcIiA6IFwiXCIpICsgXCIgb24gXCIgKyBqb2luKGxvY2F0aW9ucywgXCIgfCBcIilcbiAgfSxcbiAgU2NoZW1hRXh0ZW5zaW9uOiB7XG4gICAgbGVhdmU6ICh7IGRpcmVjdGl2ZXMsIG9wZXJhdGlvblR5cGVzIH0pID0+IGpvaW4oXG4gICAgICBbXCJleHRlbmQgc2NoZW1hXCIsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLCBibG9jayhvcGVyYXRpb25UeXBlcyldLFxuICAgICAgXCIgXCJcbiAgICApXG4gIH0sXG4gIFNjYWxhclR5cGVFeHRlbnNpb246IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgZGlyZWN0aXZlcyB9KSA9PiBqb2luKFtcImV4dGVuZCBzY2FsYXJcIiwgbmFtZSwgam9pbihkaXJlY3RpdmVzLCBcIiBcIildLCBcIiBcIilcbiAgfSxcbiAgT2JqZWN0VHlwZUV4dGVuc2lvbjoge1xuICAgIGxlYXZlOiAoeyBuYW1lLCBpbnRlcmZhY2VzLCBkaXJlY3RpdmVzLCBmaWVsZHMgfSkgPT4gam9pbihcbiAgICAgIFtcbiAgICAgICAgXCJleHRlbmQgdHlwZVwiLFxuICAgICAgICBuYW1lLFxuICAgICAgICB3cmFwKFwiaW1wbGVtZW50cyBcIiwgam9pbihpbnRlcmZhY2VzLCBcIiAmIFwiKSksXG4gICAgICAgIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLFxuICAgICAgICBibG9jayhmaWVsZHMpXG4gICAgICBdLFxuICAgICAgXCIgXCJcbiAgICApXG4gIH0sXG4gIEludGVyZmFjZVR5cGVFeHRlbnNpb246IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgaW50ZXJmYWNlcywgZGlyZWN0aXZlcywgZmllbGRzIH0pID0+IGpvaW4oXG4gICAgICBbXG4gICAgICAgIFwiZXh0ZW5kIGludGVyZmFjZVwiLFxuICAgICAgICBuYW1lLFxuICAgICAgICB3cmFwKFwiaW1wbGVtZW50cyBcIiwgam9pbihpbnRlcmZhY2VzLCBcIiAmIFwiKSksXG4gICAgICAgIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLFxuICAgICAgICBibG9jayhmaWVsZHMpXG4gICAgICBdLFxuICAgICAgXCIgXCJcbiAgICApXG4gIH0sXG4gIFVuaW9uVHlwZUV4dGVuc2lvbjoge1xuICAgIGxlYXZlOiAoeyBuYW1lLCBkaXJlY3RpdmVzLCB0eXBlcyB9KSA9PiBqb2luKFxuICAgICAgW1xuICAgICAgICBcImV4dGVuZCB1bmlvblwiLFxuICAgICAgICBuYW1lLFxuICAgICAgICBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSxcbiAgICAgICAgd3JhcChcIj0gXCIsIGpvaW4odHlwZXMsIFwiIHwgXCIpKVxuICAgICAgXSxcbiAgICAgIFwiIFwiXG4gICAgKVxuICB9LFxuICBFbnVtVHlwZUV4dGVuc2lvbjoge1xuICAgIGxlYXZlOiAoeyBuYW1lLCBkaXJlY3RpdmVzLCB2YWx1ZXMgfSkgPT4gam9pbihbXCJleHRlbmQgZW51bVwiLCBuYW1lLCBqb2luKGRpcmVjdGl2ZXMsIFwiIFwiKSwgYmxvY2sodmFsdWVzKV0sIFwiIFwiKVxuICB9LFxuICBJbnB1dE9iamVjdFR5cGVFeHRlbnNpb246IHtcbiAgICBsZWF2ZTogKHsgbmFtZSwgZGlyZWN0aXZlcywgZmllbGRzIH0pID0+IGpvaW4oW1wiZXh0ZW5kIGlucHV0XCIsIG5hbWUsIGpvaW4oZGlyZWN0aXZlcywgXCIgXCIpLCBibG9jayhmaWVsZHMpXSwgXCIgXCIpXG4gIH1cbn07XG5mdW5jdGlvbiBqb2luKG1heWJlQXJyYXksIHNlcGFyYXRvciA9IFwiXCIpIHtcbiAgdmFyIF9tYXliZUFycmF5JGZpbHRlciRqbztcbiAgcmV0dXJuIChfbWF5YmVBcnJheSRmaWx0ZXIkam8gPSBtYXliZUFycmF5ID09PSBudWxsIHx8IG1heWJlQXJyYXkgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG1heWJlQXJyYXkuZmlsdGVyKCh4KSA9PiB4KS5qb2luKHNlcGFyYXRvcikpICE9PSBudWxsICYmIF9tYXliZUFycmF5JGZpbHRlciRqbyAhPT0gdm9pZCAwID8gX21heWJlQXJyYXkkZmlsdGVyJGpvIDogXCJcIjtcbn1cbmZ1bmN0aW9uIGJsb2NrKGFycmF5KSB7XG4gIHJldHVybiB3cmFwKFwie1xcblwiLCBpbmRlbnQoam9pbihhcnJheSwgXCJcXG5cIikpLCBcIlxcbn1cIik7XG59XG5mdW5jdGlvbiB3cmFwKHN0YXJ0LCBtYXliZVN0cmluZywgZW5kID0gXCJcIikge1xuICByZXR1cm4gbWF5YmVTdHJpbmcgIT0gbnVsbCAmJiBtYXliZVN0cmluZyAhPT0gXCJcIiA/IHN0YXJ0ICsgbWF5YmVTdHJpbmcgKyBlbmQgOiBcIlwiO1xufVxuZnVuY3Rpb24gaW5kZW50KHN0cikge1xuICByZXR1cm4gd3JhcChcIiAgXCIsIHN0ci5yZXBsYWNlKC9cXG4vZywgXCJcXG4gIFwiKSk7XG59XG5mdW5jdGlvbiBoYXNNdWx0aWxpbmVJdGVtcyhtYXliZUFycmF5KSB7XG4gIHZhciBfbWF5YmVBcnJheSRzb21lO1xuICByZXR1cm4gKF9tYXliZUFycmF5JHNvbWUgPSBtYXliZUFycmF5ID09PSBudWxsIHx8IG1heWJlQXJyYXkgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG1heWJlQXJyYXkuc29tZSgoc3RyKSA9PiBzdHIuaW5jbHVkZXMoXCJcXG5cIikpKSAhPT0gbnVsbCAmJiBfbWF5YmVBcnJheSRzb21lICE9PSB2b2lkIDAgPyBfbWF5YmVBcnJheSRzb21lIDogZmFsc2U7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC91dGlsaXRpZXMvdmFsdWVGcm9tQVNUVW50eXBlZC5tanNcbmZ1bmN0aW9uIHZhbHVlRnJvbUFTVFVudHlwZWQodmFsdWVOb2RlLCB2YXJpYWJsZXMpIHtcbiAgc3dpdGNoICh2YWx1ZU5vZGUua2luZCkge1xuICAgIGNhc2UgS2luZC5OVUxMOlxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgY2FzZSBLaW5kLklOVDpcbiAgICAgIHJldHVybiBwYXJzZUludCh2YWx1ZU5vZGUudmFsdWUsIDEwKTtcbiAgICBjYXNlIEtpbmQuRkxPQVQ6XG4gICAgICByZXR1cm4gcGFyc2VGbG9hdCh2YWx1ZU5vZGUudmFsdWUpO1xuICAgIGNhc2UgS2luZC5TVFJJTkc6XG4gICAgY2FzZSBLaW5kLkVOVU06XG4gICAgY2FzZSBLaW5kLkJPT0xFQU46XG4gICAgICByZXR1cm4gdmFsdWVOb2RlLnZhbHVlO1xuICAgIGNhc2UgS2luZC5MSVNUOlxuICAgICAgcmV0dXJuIHZhbHVlTm9kZS52YWx1ZXMubWFwKFxuICAgICAgICAobm9kZSkgPT4gdmFsdWVGcm9tQVNUVW50eXBlZChub2RlLCB2YXJpYWJsZXMpXG4gICAgICApO1xuICAgIGNhc2UgS2luZC5PQkpFQ1Q6XG4gICAgICByZXR1cm4ga2V5VmFsTWFwKFxuICAgICAgICB2YWx1ZU5vZGUuZmllbGRzLFxuICAgICAgICAoZmllbGQpID0+IGZpZWxkLm5hbWUudmFsdWUsXG4gICAgICAgIChmaWVsZCkgPT4gdmFsdWVGcm9tQVNUVW50eXBlZChmaWVsZC52YWx1ZSwgdmFyaWFibGVzKVxuICAgICAgKTtcbiAgICBjYXNlIEtpbmQuVkFSSUFCTEU6XG4gICAgICByZXR1cm4gdmFyaWFibGVzID09PSBudWxsIHx8IHZhcmlhYmxlcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogdmFyaWFibGVzW3ZhbHVlTm9kZS5uYW1lLnZhbHVlXTtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdHlwZS9hc3NlcnROYW1lLm1qc1xuZnVuY3Rpb24gYXNzZXJ0TmFtZShuYW1lKSB7XG4gIG5hbWUgIT0gbnVsbCB8fCBkZXZBc3NlcnQoZmFsc2UsIFwiTXVzdCBwcm92aWRlIG5hbWUuXCIpO1xuICB0eXBlb2YgbmFtZSA9PT0gXCJzdHJpbmdcIiB8fCBkZXZBc3NlcnQoZmFsc2UsIFwiRXhwZWN0ZWQgbmFtZSB0byBiZSBhIHN0cmluZy5cIik7XG4gIGlmIChuYW1lLmxlbmd0aCA9PT0gMCkge1xuICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXCJFeHBlY3RlZCBuYW1lIHRvIGJlIGEgbm9uLWVtcHR5IHN0cmluZy5cIik7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDE7IGkgPCBuYW1lLmxlbmd0aDsgKytpKSB7XG4gICAgaWYgKCFpc05hbWVDb250aW51ZShuYW1lLmNoYXJDb2RlQXQoaSkpKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgTmFtZXMgbXVzdCBvbmx5IGNvbnRhaW4gW19hLXpBLVowLTldIGJ1dCBcIiR7bmFtZX1cIiBkb2VzIG5vdC5gXG4gICAgICApO1xuICAgIH1cbiAgfVxuICBpZiAoIWlzTmFtZVN0YXJ0KG5hbWUuY2hhckNvZGVBdCgwKSkpIHtcbiAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgYE5hbWVzIG11c3Qgc3RhcnQgd2l0aCBbX2EtekEtWl0gYnV0IFwiJHtuYW1lfVwiIGRvZXMgbm90LmBcbiAgICApO1xuICB9XG4gIHJldHVybiBuYW1lO1xufVxuZnVuY3Rpb24gYXNzZXJ0RW51bVZhbHVlTmFtZShuYW1lKSB7XG4gIGlmIChuYW1lID09PSBcInRydWVcIiB8fCBuYW1lID09PSBcImZhbHNlXCIgfHwgbmFtZSA9PT0gXCJudWxsXCIpIHtcbiAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKGBFbnVtIHZhbHVlcyBjYW5ub3QgYmUgbmFtZWQ6ICR7bmFtZX1gKTtcbiAgfVxuICByZXR1cm4gYXNzZXJ0TmFtZShuYW1lKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3R5cGUvZGVmaW5pdGlvbi5tanNcbmZ1bmN0aW9uIGlzVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpc1NjYWxhclR5cGUodHlwZSkgfHwgaXNPYmplY3RUeXBlKHR5cGUpIHx8IGlzSW50ZXJmYWNlVHlwZSh0eXBlKSB8fCBpc1VuaW9uVHlwZSh0eXBlKSB8fCBpc0VudW1UeXBlKHR5cGUpIHx8IGlzSW5wdXRPYmplY3RUeXBlKHR5cGUpIHx8IGlzTGlzdFR5cGUodHlwZSkgfHwgaXNOb25OdWxsVHlwZSh0eXBlKTtcbn1cbmZ1bmN0aW9uIGlzU2NhbGFyVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxTY2FsYXJUeXBlKTtcbn1cbmZ1bmN0aW9uIGlzT2JqZWN0VHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxPYmplY3RUeXBlKTtcbn1cbmZ1bmN0aW9uIGlzSW50ZXJmYWNlVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxJbnRlcmZhY2VUeXBlKTtcbn1cbmZ1bmN0aW9uIGlzVW5pb25UeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGluc3RhbmNlT2YodHlwZSwgR3JhcGhRTFVuaW9uVHlwZSk7XG59XG5mdW5jdGlvbiBpc0VudW1UeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGluc3RhbmNlT2YodHlwZSwgR3JhcGhRTEVudW1UeXBlKTtcbn1cbmZ1bmN0aW9uIGlzSW5wdXRPYmplY3RUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGluc3RhbmNlT2YodHlwZSwgR3JhcGhRTElucHV0T2JqZWN0VHlwZSk7XG59XG5mdW5jdGlvbiBpc0xpc3RUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGluc3RhbmNlT2YodHlwZSwgR3JhcGhRTExpc3QpO1xufVxuZnVuY3Rpb24gaXNOb25OdWxsVHlwZSh0eXBlKSB7XG4gIHJldHVybiBpbnN0YW5jZU9mKHR5cGUsIEdyYXBoUUxOb25OdWxsKTtcbn1cbmZ1bmN0aW9uIGlzSW5wdXRUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGlzU2NhbGFyVHlwZSh0eXBlKSB8fCBpc0VudW1UeXBlKHR5cGUpIHx8IGlzSW5wdXRPYmplY3RUeXBlKHR5cGUpIHx8IGlzV3JhcHBpbmdUeXBlKHR5cGUpICYmIGlzSW5wdXRUeXBlKHR5cGUub2ZUeXBlKTtcbn1cbmZ1bmN0aW9uIGlzTGVhZlR5cGUodHlwZSkge1xuICByZXR1cm4gaXNTY2FsYXJUeXBlKHR5cGUpIHx8IGlzRW51bVR5cGUodHlwZSk7XG59XG5mdW5jdGlvbiBpc0NvbXBvc2l0ZVR5cGUodHlwZSkge1xuICByZXR1cm4gaXNPYmplY3RUeXBlKHR5cGUpIHx8IGlzSW50ZXJmYWNlVHlwZSh0eXBlKSB8fCBpc1VuaW9uVHlwZSh0eXBlKTtcbn1cbmZ1bmN0aW9uIGlzQWJzdHJhY3RUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGlzSW50ZXJmYWNlVHlwZSh0eXBlKSB8fCBpc1VuaW9uVHlwZSh0eXBlKTtcbn1cbnZhciBHcmFwaFFMTGlzdCA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3Iob2ZUeXBlKSB7XG4gICAgaXNUeXBlKG9mVHlwZSkgfHwgZGV2QXNzZXJ0KGZhbHNlLCBgRXhwZWN0ZWQgJHtpbnNwZWN0KG9mVHlwZSl9IHRvIGJlIGEgR3JhcGhRTCB0eXBlLmApO1xuICAgIHRoaXMub2ZUeXBlID0gb2ZUeXBlO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMTGlzdFwiO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBcIltcIiArIFN0cmluZyh0aGlzLm9mVHlwZSkgKyBcIl1cIjtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMudG9TdHJpbmcoKTtcbiAgfVxufTtcbnZhciBHcmFwaFFMTm9uTnVsbCA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3Iob2ZUeXBlKSB7XG4gICAgaXNOdWxsYWJsZVR5cGUob2ZUeXBlKSB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGBFeHBlY3RlZCAke2luc3BlY3Qob2ZUeXBlKX0gdG8gYmUgYSBHcmFwaFFMIG51bGxhYmxlIHR5cGUuYFxuICAgICk7XG4gICAgdGhpcy5vZlR5cGUgPSBvZlR5cGU7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIkdyYXBoUUxOb25OdWxsXCI7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIFN0cmluZyh0aGlzLm9mVHlwZSkgKyBcIiFcIjtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMudG9TdHJpbmcoKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGlzV3JhcHBpbmdUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGlzTGlzdFR5cGUodHlwZSkgfHwgaXNOb25OdWxsVHlwZSh0eXBlKTtcbn1cbmZ1bmN0aW9uIGlzTnVsbGFibGVUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIGlzVHlwZSh0eXBlKSAmJiAhaXNOb25OdWxsVHlwZSh0eXBlKTtcbn1cbmZ1bmN0aW9uIGdldE51bGxhYmxlVHlwZSh0eXBlKSB7XG4gIGlmICh0eXBlKSB7XG4gICAgcmV0dXJuIGlzTm9uTnVsbFR5cGUodHlwZSkgPyB0eXBlLm9mVHlwZSA6IHR5cGU7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldE5hbWVkVHlwZSh0eXBlKSB7XG4gIGlmICh0eXBlKSB7XG4gICAgbGV0IHVud3JhcHBlZFR5cGUgPSB0eXBlO1xuICAgIHdoaWxlIChpc1dyYXBwaW5nVHlwZSh1bndyYXBwZWRUeXBlKSkge1xuICAgICAgdW53cmFwcGVkVHlwZSA9IHVud3JhcHBlZFR5cGUub2ZUeXBlO1xuICAgIH1cbiAgICByZXR1cm4gdW53cmFwcGVkVHlwZTtcbiAgfVxufVxuZnVuY3Rpb24gcmVzb2x2ZVJlYWRvbmx5QXJyYXlUaHVuayh0aHVuaykge1xuICByZXR1cm4gdHlwZW9mIHRodW5rID09PSBcImZ1bmN0aW9uXCIgPyB0aHVuaygpIDogdGh1bms7XG59XG5mdW5jdGlvbiByZXNvbHZlT2JqTWFwVGh1bmsodGh1bmspIHtcbiAgcmV0dXJuIHR5cGVvZiB0aHVuayA9PT0gXCJmdW5jdGlvblwiID8gdGh1bmsoKSA6IHRodW5rO1xufVxudmFyIEdyYXBoUUxTY2FsYXJUeXBlID0gY2xhc3Mge1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICB2YXIgX2NvbmZpZyRwYXJzZVZhbHVlLCBfY29uZmlnJHNlcmlhbGl6ZSwgX2NvbmZpZyRwYXJzZUxpdGVyYWwsIF9jb25maWckZXh0ZW5zaW9uQVNUTjtcbiAgICBjb25zdCBwYXJzZVZhbHVlMiA9IChfY29uZmlnJHBhcnNlVmFsdWUgPSBjb25maWcucGFyc2VWYWx1ZSkgIT09IG51bGwgJiYgX2NvbmZpZyRwYXJzZVZhbHVlICE9PSB2b2lkIDAgPyBfY29uZmlnJHBhcnNlVmFsdWUgOiBpZGVudGl0eUZ1bmM7XG4gICAgdGhpcy5uYW1lID0gYXNzZXJ0TmFtZShjb25maWcubmFtZSk7XG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IGNvbmZpZy5kZXNjcmlwdGlvbjtcbiAgICB0aGlzLnNwZWNpZmllZEJ5VVJMID0gY29uZmlnLnNwZWNpZmllZEJ5VVJMO1xuICAgIHRoaXMuc2VyaWFsaXplID0gKF9jb25maWckc2VyaWFsaXplID0gY29uZmlnLnNlcmlhbGl6ZSkgIT09IG51bGwgJiYgX2NvbmZpZyRzZXJpYWxpemUgIT09IHZvaWQgMCA/IF9jb25maWckc2VyaWFsaXplIDogaWRlbnRpdHlGdW5jO1xuICAgIHRoaXMucGFyc2VWYWx1ZSA9IHBhcnNlVmFsdWUyO1xuICAgIHRoaXMucGFyc2VMaXRlcmFsID0gKF9jb25maWckcGFyc2VMaXRlcmFsID0gY29uZmlnLnBhcnNlTGl0ZXJhbCkgIT09IG51bGwgJiYgX2NvbmZpZyRwYXJzZUxpdGVyYWwgIT09IHZvaWQgMCA/IF9jb25maWckcGFyc2VMaXRlcmFsIDogKG5vZGUsIHZhcmlhYmxlcykgPT4gcGFyc2VWYWx1ZTIodmFsdWVGcm9tQVNUVW50eXBlZChub2RlLCB2YXJpYWJsZXMpKTtcbiAgICB0aGlzLmV4dGVuc2lvbnMgPSB0b09iak1hcChjb25maWcuZXh0ZW5zaW9ucyk7XG4gICAgdGhpcy5hc3ROb2RlID0gY29uZmlnLmFzdE5vZGU7XG4gICAgdGhpcy5leHRlbnNpb25BU1ROb2RlcyA9IChfY29uZmlnJGV4dGVuc2lvbkFTVE4gPSBjb25maWcuZXh0ZW5zaW9uQVNUTm9kZXMpICE9PSBudWxsICYmIF9jb25maWckZXh0ZW5zaW9uQVNUTiAhPT0gdm9pZCAwID8gX2NvbmZpZyRleHRlbnNpb25BU1ROIDogW107XG4gICAgY29uZmlnLnNwZWNpZmllZEJ5VVJMID09IG51bGwgfHwgdHlwZW9mIGNvbmZpZy5zcGVjaWZpZWRCeVVSTCA9PT0gXCJzdHJpbmdcIiB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke3RoaXMubmFtZX0gbXVzdCBwcm92aWRlIFwic3BlY2lmaWVkQnlVUkxcIiBhcyBhIHN0cmluZywgYnV0IGdvdDogJHtpbnNwZWN0KGNvbmZpZy5zcGVjaWZpZWRCeVVSTCl9LmBcbiAgICApO1xuICAgIGNvbmZpZy5zZXJpYWxpemUgPT0gbnVsbCB8fCB0eXBlb2YgY29uZmlnLnNlcmlhbGl6ZSA9PT0gXCJmdW5jdGlvblwiIHx8IGRldkFzc2VydChcbiAgICAgIGZhbHNlLFxuICAgICAgYCR7dGhpcy5uYW1lfSBtdXN0IHByb3ZpZGUgXCJzZXJpYWxpemVcIiBmdW5jdGlvbi4gSWYgdGhpcyBjdXN0b20gU2NhbGFyIGlzIGFsc28gdXNlZCBhcyBhbiBpbnB1dCB0eXBlLCBlbnN1cmUgXCJwYXJzZVZhbHVlXCIgYW5kIFwicGFyc2VMaXRlcmFsXCIgZnVuY3Rpb25zIGFyZSBhbHNvIHByb3ZpZGVkLmBcbiAgICApO1xuICAgIGlmIChjb25maWcucGFyc2VMaXRlcmFsKSB7XG4gICAgICB0eXBlb2YgY29uZmlnLnBhcnNlVmFsdWUgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgY29uZmlnLnBhcnNlTGl0ZXJhbCA9PT0gXCJmdW5jdGlvblwiIHx8IGRldkFzc2VydChcbiAgICAgICAgZmFsc2UsXG4gICAgICAgIGAke3RoaXMubmFtZX0gbXVzdCBwcm92aWRlIGJvdGggXCJwYXJzZVZhbHVlXCIgYW5kIFwicGFyc2VMaXRlcmFsXCIgZnVuY3Rpb25zLmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMU2NhbGFyVHlwZVwiO1xuICB9XG4gIHRvQ29uZmlnKCkge1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIHNwZWNpZmllZEJ5VVJMOiB0aGlzLnNwZWNpZmllZEJ5VVJMLFxuICAgICAgc2VyaWFsaXplOiB0aGlzLnNlcmlhbGl6ZSxcbiAgICAgIHBhcnNlVmFsdWU6IHRoaXMucGFyc2VWYWx1ZSxcbiAgICAgIHBhcnNlTGl0ZXJhbDogdGhpcy5wYXJzZUxpdGVyYWwsXG4gICAgICBleHRlbnNpb25zOiB0aGlzLmV4dGVuc2lvbnMsXG4gICAgICBhc3ROb2RlOiB0aGlzLmFzdE5vZGUsXG4gICAgICBleHRlbnNpb25BU1ROb2RlczogdGhpcy5leHRlbnNpb25BU1ROb2Rlc1xuICAgIH07XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMubmFtZTtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMudG9TdHJpbmcoKTtcbiAgfVxufTtcbnZhciBHcmFwaFFMT2JqZWN0VHlwZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgdmFyIF9jb25maWckZXh0ZW5zaW9uQVNUTjI7XG4gICAgdGhpcy5uYW1lID0gYXNzZXJ0TmFtZShjb25maWcubmFtZSk7XG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IGNvbmZpZy5kZXNjcmlwdGlvbjtcbiAgICB0aGlzLmlzVHlwZU9mID0gY29uZmlnLmlzVHlwZU9mO1xuICAgIHRoaXMuZXh0ZW5zaW9ucyA9IHRvT2JqTWFwKGNvbmZpZy5leHRlbnNpb25zKTtcbiAgICB0aGlzLmFzdE5vZGUgPSBjb25maWcuYXN0Tm9kZTtcbiAgICB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzID0gKF9jb25maWckZXh0ZW5zaW9uQVNUTjIgPSBjb25maWcuZXh0ZW5zaW9uQVNUTm9kZXMpICE9PSBudWxsICYmIF9jb25maWckZXh0ZW5zaW9uQVNUTjIgIT09IHZvaWQgMCA/IF9jb25maWckZXh0ZW5zaW9uQVNUTjIgOiBbXTtcbiAgICB0aGlzLl9maWVsZHMgPSAoKSA9PiBkZWZpbmVGaWVsZE1hcChjb25maWcpO1xuICAgIHRoaXMuX2ludGVyZmFjZXMgPSAoKSA9PiBkZWZpbmVJbnRlcmZhY2VzKGNvbmZpZyk7XG4gICAgY29uZmlnLmlzVHlwZU9mID09IG51bGwgfHwgdHlwZW9mIGNvbmZpZy5pc1R5cGVPZiA9PT0gXCJmdW5jdGlvblwiIHx8IGRldkFzc2VydChcbiAgICAgIGZhbHNlLFxuICAgICAgYCR7dGhpcy5uYW1lfSBtdXN0IHByb3ZpZGUgXCJpc1R5cGVPZlwiIGFzIGEgZnVuY3Rpb24sIGJ1dCBnb3Q6ICR7aW5zcGVjdChjb25maWcuaXNUeXBlT2YpfS5gXG4gICAgKTtcbiAgfVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuIFwiR3JhcGhRTE9iamVjdFR5cGVcIjtcbiAgfVxuICBnZXRGaWVsZHMoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLl9maWVsZHMgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhpcy5fZmllbGRzID0gdGhpcy5fZmllbGRzKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9maWVsZHM7XG4gIH1cbiAgZ2V0SW50ZXJmYWNlcygpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMuX2ludGVyZmFjZXMgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhpcy5faW50ZXJmYWNlcyA9IHRoaXMuX2ludGVyZmFjZXMoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2ludGVyZmFjZXM7XG4gIH1cbiAgdG9Db25maWcoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgIGRlc2NyaXB0aW9uOiB0aGlzLmRlc2NyaXB0aW9uLFxuICAgICAgaW50ZXJmYWNlczogdGhpcy5nZXRJbnRlcmZhY2VzKCksXG4gICAgICBmaWVsZHM6IGZpZWxkc1RvRmllbGRzQ29uZmlnKHRoaXMuZ2V0RmllbGRzKCkpLFxuICAgICAgaXNUeXBlT2Y6IHRoaXMuaXNUeXBlT2YsXG4gICAgICBleHRlbnNpb25zOiB0aGlzLmV4dGVuc2lvbnMsXG4gICAgICBhc3ROb2RlOiB0aGlzLmFzdE5vZGUsXG4gICAgICBleHRlbnNpb25BU1ROb2RlczogdGhpcy5leHRlbnNpb25BU1ROb2Rlc1xuICAgIH07XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMubmFtZTtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMudG9TdHJpbmcoKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGRlZmluZUludGVyZmFjZXMoY29uZmlnKSB7XG4gIHZhciBfY29uZmlnJGludGVyZmFjZXM7XG4gIGNvbnN0IGludGVyZmFjZXMgPSByZXNvbHZlUmVhZG9ubHlBcnJheVRodW5rKFxuICAgIChfY29uZmlnJGludGVyZmFjZXMgPSBjb25maWcuaW50ZXJmYWNlcykgIT09IG51bGwgJiYgX2NvbmZpZyRpbnRlcmZhY2VzICE9PSB2b2lkIDAgPyBfY29uZmlnJGludGVyZmFjZXMgOiBbXVxuICApO1xuICBBcnJheS5pc0FycmF5KGludGVyZmFjZXMpIHx8IGRldkFzc2VydChcbiAgICBmYWxzZSxcbiAgICBgJHtjb25maWcubmFtZX0gaW50ZXJmYWNlcyBtdXN0IGJlIGFuIEFycmF5IG9yIGEgZnVuY3Rpb24gd2hpY2ggcmV0dXJucyBhbiBBcnJheS5gXG4gICk7XG4gIHJldHVybiBpbnRlcmZhY2VzO1xufVxuZnVuY3Rpb24gZGVmaW5lRmllbGRNYXAoY29uZmlnKSB7XG4gIGNvbnN0IGZpZWxkTWFwID0gcmVzb2x2ZU9iak1hcFRodW5rKGNvbmZpZy5maWVsZHMpO1xuICBpc1BsYWluT2JqKGZpZWxkTWFwKSB8fCBkZXZBc3NlcnQoXG4gICAgZmFsc2UsXG4gICAgYCR7Y29uZmlnLm5hbWV9IGZpZWxkcyBtdXN0IGJlIGFuIG9iamVjdCB3aXRoIGZpZWxkIG5hbWVzIGFzIGtleXMgb3IgYSBmdW5jdGlvbiB3aGljaCByZXR1cm5zIHN1Y2ggYW4gb2JqZWN0LmBcbiAgKTtcbiAgcmV0dXJuIG1hcFZhbHVlKGZpZWxkTWFwLCAoZmllbGRDb25maWcsIGZpZWxkTmFtZSkgPT4ge1xuICAgIHZhciBfZmllbGRDb25maWckYXJncztcbiAgICBpc1BsYWluT2JqKGZpZWxkQ29uZmlnKSB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke2NvbmZpZy5uYW1lfS4ke2ZpZWxkTmFtZX0gZmllbGQgY29uZmlnIG11c3QgYmUgYW4gb2JqZWN0LmBcbiAgICApO1xuICAgIGZpZWxkQ29uZmlnLnJlc29sdmUgPT0gbnVsbCB8fCB0eXBlb2YgZmllbGRDb25maWcucmVzb2x2ZSA9PT0gXCJmdW5jdGlvblwiIHx8IGRldkFzc2VydChcbiAgICAgIGZhbHNlLFxuICAgICAgYCR7Y29uZmlnLm5hbWV9LiR7ZmllbGROYW1lfSBmaWVsZCByZXNvbHZlciBtdXN0IGJlIGEgZnVuY3Rpb24gaWYgcHJvdmlkZWQsIGJ1dCBnb3Q6ICR7aW5zcGVjdChmaWVsZENvbmZpZy5yZXNvbHZlKX0uYFxuICAgICk7XG4gICAgY29uc3QgYXJnc0NvbmZpZyA9IChfZmllbGRDb25maWckYXJncyA9IGZpZWxkQ29uZmlnLmFyZ3MpICE9PSBudWxsICYmIF9maWVsZENvbmZpZyRhcmdzICE9PSB2b2lkIDAgPyBfZmllbGRDb25maWckYXJncyA6IHt9O1xuICAgIGlzUGxhaW5PYmooYXJnc0NvbmZpZykgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgJHtjb25maWcubmFtZX0uJHtmaWVsZE5hbWV9IGFyZ3MgbXVzdCBiZSBhbiBvYmplY3Qgd2l0aCBhcmd1bWVudCBuYW1lcyBhcyBrZXlzLmBcbiAgICApO1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiBhc3NlcnROYW1lKGZpZWxkTmFtZSksXG4gICAgICBkZXNjcmlwdGlvbjogZmllbGRDb25maWcuZGVzY3JpcHRpb24sXG4gICAgICB0eXBlOiBmaWVsZENvbmZpZy50eXBlLFxuICAgICAgYXJnczogZGVmaW5lQXJndW1lbnRzKGFyZ3NDb25maWcpLFxuICAgICAgcmVzb2x2ZTogZmllbGRDb25maWcucmVzb2x2ZSxcbiAgICAgIHN1YnNjcmliZTogZmllbGRDb25maWcuc3Vic2NyaWJlLFxuICAgICAgZGVwcmVjYXRpb25SZWFzb246IGZpZWxkQ29uZmlnLmRlcHJlY2F0aW9uUmVhc29uLFxuICAgICAgZXh0ZW5zaW9uczogdG9PYmpNYXAoZmllbGRDb25maWcuZXh0ZW5zaW9ucyksXG4gICAgICBhc3ROb2RlOiBmaWVsZENvbmZpZy5hc3ROb2RlXG4gICAgfTtcbiAgfSk7XG59XG5mdW5jdGlvbiBkZWZpbmVBcmd1bWVudHMoY29uZmlnKSB7XG4gIHJldHVybiBPYmplY3QuZW50cmllcyhjb25maWcpLm1hcCgoW2FyZ05hbWUsIGFyZ0NvbmZpZ10pID0+ICh7XG4gICAgbmFtZTogYXNzZXJ0TmFtZShhcmdOYW1lKSxcbiAgICBkZXNjcmlwdGlvbjogYXJnQ29uZmlnLmRlc2NyaXB0aW9uLFxuICAgIHR5cGU6IGFyZ0NvbmZpZy50eXBlLFxuICAgIGRlZmF1bHRWYWx1ZTogYXJnQ29uZmlnLmRlZmF1bHRWYWx1ZSxcbiAgICBkZXByZWNhdGlvblJlYXNvbjogYXJnQ29uZmlnLmRlcHJlY2F0aW9uUmVhc29uLFxuICAgIGV4dGVuc2lvbnM6IHRvT2JqTWFwKGFyZ0NvbmZpZy5leHRlbnNpb25zKSxcbiAgICBhc3ROb2RlOiBhcmdDb25maWcuYXN0Tm9kZVxuICB9KSk7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqKG9iaikge1xuICByZXR1cm4gaXNPYmplY3RMaWtlKG9iaikgJiYgIUFycmF5LmlzQXJyYXkob2JqKTtcbn1cbmZ1bmN0aW9uIGZpZWxkc1RvRmllbGRzQ29uZmlnKGZpZWxkcykge1xuICByZXR1cm4gbWFwVmFsdWUoZmllbGRzLCAoZmllbGQpID0+ICh7XG4gICAgZGVzY3JpcHRpb246IGZpZWxkLmRlc2NyaXB0aW9uLFxuICAgIHR5cGU6IGZpZWxkLnR5cGUsXG4gICAgYXJnczogYXJnc1RvQXJnc0NvbmZpZyhmaWVsZC5hcmdzKSxcbiAgICByZXNvbHZlOiBmaWVsZC5yZXNvbHZlLFxuICAgIHN1YnNjcmliZTogZmllbGQuc3Vic2NyaWJlLFxuICAgIGRlcHJlY2F0aW9uUmVhc29uOiBmaWVsZC5kZXByZWNhdGlvblJlYXNvbixcbiAgICBleHRlbnNpb25zOiBmaWVsZC5leHRlbnNpb25zLFxuICAgIGFzdE5vZGU6IGZpZWxkLmFzdE5vZGVcbiAgfSkpO1xufVxuZnVuY3Rpb24gYXJnc1RvQXJnc0NvbmZpZyhhcmdzKSB7XG4gIHJldHVybiBrZXlWYWxNYXAoXG4gICAgYXJncyxcbiAgICAoYXJnKSA9PiBhcmcubmFtZSxcbiAgICAoYXJnKSA9PiAoe1xuICAgICAgZGVzY3JpcHRpb246IGFyZy5kZXNjcmlwdGlvbixcbiAgICAgIHR5cGU6IGFyZy50eXBlLFxuICAgICAgZGVmYXVsdFZhbHVlOiBhcmcuZGVmYXVsdFZhbHVlLFxuICAgICAgZGVwcmVjYXRpb25SZWFzb246IGFyZy5kZXByZWNhdGlvblJlYXNvbixcbiAgICAgIGV4dGVuc2lvbnM6IGFyZy5leHRlbnNpb25zLFxuICAgICAgYXN0Tm9kZTogYXJnLmFzdE5vZGVcbiAgICB9KVxuICApO1xufVxuZnVuY3Rpb24gaXNSZXF1aXJlZEFyZ3VtZW50KGFyZykge1xuICByZXR1cm4gaXNOb25OdWxsVHlwZShhcmcudHlwZSkgJiYgYXJnLmRlZmF1bHRWYWx1ZSA9PT0gdm9pZCAwO1xufVxudmFyIEdyYXBoUUxJbnRlcmZhY2VUeXBlID0gY2xhc3Mge1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICB2YXIgX2NvbmZpZyRleHRlbnNpb25BU1ROMztcbiAgICB0aGlzLm5hbWUgPSBhc3NlcnROYW1lKGNvbmZpZy5uYW1lKTtcbiAgICB0aGlzLmRlc2NyaXB0aW9uID0gY29uZmlnLmRlc2NyaXB0aW9uO1xuICAgIHRoaXMucmVzb2x2ZVR5cGUgPSBjb25maWcucmVzb2x2ZVR5cGU7XG4gICAgdGhpcy5leHRlbnNpb25zID0gdG9PYmpNYXAoY29uZmlnLmV4dGVuc2lvbnMpO1xuICAgIHRoaXMuYXN0Tm9kZSA9IGNvbmZpZy5hc3ROb2RlO1xuICAgIHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXMgPSAoX2NvbmZpZyRleHRlbnNpb25BU1ROMyA9IGNvbmZpZy5leHRlbnNpb25BU1ROb2RlcykgIT09IG51bGwgJiYgX2NvbmZpZyRleHRlbnNpb25BU1ROMyAhPT0gdm9pZCAwID8gX2NvbmZpZyRleHRlbnNpb25BU1ROMyA6IFtdO1xuICAgIHRoaXMuX2ZpZWxkcyA9IGRlZmluZUZpZWxkTWFwLmJpbmQodm9pZCAwLCBjb25maWcpO1xuICAgIHRoaXMuX2ludGVyZmFjZXMgPSBkZWZpbmVJbnRlcmZhY2VzLmJpbmQodm9pZCAwLCBjb25maWcpO1xuICAgIGNvbmZpZy5yZXNvbHZlVHlwZSA9PSBudWxsIHx8IHR5cGVvZiBjb25maWcucmVzb2x2ZVR5cGUgPT09IFwiZnVuY3Rpb25cIiB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke3RoaXMubmFtZX0gbXVzdCBwcm92aWRlIFwicmVzb2x2ZVR5cGVcIiBhcyBhIGZ1bmN0aW9uLCBidXQgZ290OiAke2luc3BlY3QoY29uZmlnLnJlc29sdmVUeXBlKX0uYFxuICAgICk7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIkdyYXBoUUxJbnRlcmZhY2VUeXBlXCI7XG4gIH1cbiAgZ2V0RmllbGRzKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy5fZmllbGRzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRoaXMuX2ZpZWxkcyA9IHRoaXMuX2ZpZWxkcygpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fZmllbGRzO1xuICB9XG4gIGdldEludGVyZmFjZXMoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLl9pbnRlcmZhY2VzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRoaXMuX2ludGVyZmFjZXMgPSB0aGlzLl9pbnRlcmZhY2VzKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9pbnRlcmZhY2VzO1xuICB9XG4gIHRvQ29uZmlnKCkge1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIGludGVyZmFjZXM6IHRoaXMuZ2V0SW50ZXJmYWNlcygpLFxuICAgICAgZmllbGRzOiBmaWVsZHNUb0ZpZWxkc0NvbmZpZyh0aGlzLmdldEZpZWxkcygpKSxcbiAgICAgIHJlc29sdmVUeXBlOiB0aGlzLnJlc29sdmVUeXBlLFxuICAgICAgZXh0ZW5zaW9uczogdGhpcy5leHRlbnNpb25zLFxuICAgICAgYXN0Tm9kZTogdGhpcy5hc3ROb2RlLFxuICAgICAgZXh0ZW5zaW9uQVNUTm9kZXM6IHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXNcbiAgICB9O1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLm5hbWU7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIHJldHVybiB0aGlzLnRvU3RyaW5nKCk7XG4gIH1cbn07XG52YXIgR3JhcGhRTFVuaW9uVHlwZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgdmFyIF9jb25maWckZXh0ZW5zaW9uQVNUTjQ7XG4gICAgdGhpcy5uYW1lID0gYXNzZXJ0TmFtZShjb25maWcubmFtZSk7XG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IGNvbmZpZy5kZXNjcmlwdGlvbjtcbiAgICB0aGlzLnJlc29sdmVUeXBlID0gY29uZmlnLnJlc29sdmVUeXBlO1xuICAgIHRoaXMuZXh0ZW5zaW9ucyA9IHRvT2JqTWFwKGNvbmZpZy5leHRlbnNpb25zKTtcbiAgICB0aGlzLmFzdE5vZGUgPSBjb25maWcuYXN0Tm9kZTtcbiAgICB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzID0gKF9jb25maWckZXh0ZW5zaW9uQVNUTjQgPSBjb25maWcuZXh0ZW5zaW9uQVNUTm9kZXMpICE9PSBudWxsICYmIF9jb25maWckZXh0ZW5zaW9uQVNUTjQgIT09IHZvaWQgMCA/IF9jb25maWckZXh0ZW5zaW9uQVNUTjQgOiBbXTtcbiAgICB0aGlzLl90eXBlcyA9IGRlZmluZVR5cGVzLmJpbmQodm9pZCAwLCBjb25maWcpO1xuICAgIGNvbmZpZy5yZXNvbHZlVHlwZSA9PSBudWxsIHx8IHR5cGVvZiBjb25maWcucmVzb2x2ZVR5cGUgPT09IFwiZnVuY3Rpb25cIiB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke3RoaXMubmFtZX0gbXVzdCBwcm92aWRlIFwicmVzb2x2ZVR5cGVcIiBhcyBhIGZ1bmN0aW9uLCBidXQgZ290OiAke2luc3BlY3QoY29uZmlnLnJlc29sdmVUeXBlKX0uYFxuICAgICk7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIkdyYXBoUUxVbmlvblR5cGVcIjtcbiAgfVxuICBnZXRUeXBlcygpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMuX3R5cGVzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRoaXMuX3R5cGVzID0gdGhpcy5fdHlwZXMoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3R5cGVzO1xuICB9XG4gIHRvQ29uZmlnKCkge1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIHR5cGVzOiB0aGlzLmdldFR5cGVzKCksXG4gICAgICByZXNvbHZlVHlwZTogdGhpcy5yZXNvbHZlVHlwZSxcbiAgICAgIGV4dGVuc2lvbnM6IHRoaXMuZXh0ZW5zaW9ucyxcbiAgICAgIGFzdE5vZGU6IHRoaXMuYXN0Tm9kZSxcbiAgICAgIGV4dGVuc2lvbkFTVE5vZGVzOiB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzXG4gICAgfTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gdGhpcy5uYW1lO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4gdGhpcy50b1N0cmluZygpO1xuICB9XG59O1xuZnVuY3Rpb24gZGVmaW5lVHlwZXMoY29uZmlnKSB7XG4gIGNvbnN0IHR5cGVzID0gcmVzb2x2ZVJlYWRvbmx5QXJyYXlUaHVuayhjb25maWcudHlwZXMpO1xuICBBcnJheS5pc0FycmF5KHR5cGVzKSB8fCBkZXZBc3NlcnQoXG4gICAgZmFsc2UsXG4gICAgYE11c3QgcHJvdmlkZSBBcnJheSBvZiB0eXBlcyBvciBhIGZ1bmN0aW9uIHdoaWNoIHJldHVybnMgc3VjaCBhbiBhcnJheSBmb3IgVW5pb24gJHtjb25maWcubmFtZX0uYFxuICApO1xuICByZXR1cm4gdHlwZXM7XG59XG52YXIgR3JhcGhRTEVudW1UeXBlID0gY2xhc3Mge1xuICAvKiA8VD4gKi9cbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgdmFyIF9jb25maWckZXh0ZW5zaW9uQVNUTjU7XG4gICAgdGhpcy5uYW1lID0gYXNzZXJ0TmFtZShjb25maWcubmFtZSk7XG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IGNvbmZpZy5kZXNjcmlwdGlvbjtcbiAgICB0aGlzLmV4dGVuc2lvbnMgPSB0b09iak1hcChjb25maWcuZXh0ZW5zaW9ucyk7XG4gICAgdGhpcy5hc3ROb2RlID0gY29uZmlnLmFzdE5vZGU7XG4gICAgdGhpcy5leHRlbnNpb25BU1ROb2RlcyA9IChfY29uZmlnJGV4dGVuc2lvbkFTVE41ID0gY29uZmlnLmV4dGVuc2lvbkFTVE5vZGVzKSAhPT0gbnVsbCAmJiBfY29uZmlnJGV4dGVuc2lvbkFTVE41ICE9PSB2b2lkIDAgPyBfY29uZmlnJGV4dGVuc2lvbkFTVE41IDogW107XG4gICAgdGhpcy5fdmFsdWVzID0gZGVmaW5lRW51bVZhbHVlcyh0aGlzLm5hbWUsIGNvbmZpZy52YWx1ZXMpO1xuICAgIHRoaXMuX3ZhbHVlTG9va3VwID0gbmV3IE1hcChcbiAgICAgIHRoaXMuX3ZhbHVlcy5tYXAoKGVudW1WYWx1ZSkgPT4gW2VudW1WYWx1ZS52YWx1ZSwgZW51bVZhbHVlXSlcbiAgICApO1xuICAgIHRoaXMuX25hbWVMb29rdXAgPSBrZXlNYXAodGhpcy5fdmFsdWVzLCAodmFsdWUpID0+IHZhbHVlLm5hbWUpO1xuICB9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpIHtcbiAgICByZXR1cm4gXCJHcmFwaFFMRW51bVR5cGVcIjtcbiAgfVxuICBnZXRWYWx1ZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3ZhbHVlcztcbiAgfVxuICBnZXRWYWx1ZShuYW1lKSB7XG4gICAgcmV0dXJuIHRoaXMuX25hbWVMb29rdXBbbmFtZV07XG4gIH1cbiAgc2VyaWFsaXplKG91dHB1dFZhbHVlKSB7XG4gICAgY29uc3QgZW51bVZhbHVlID0gdGhpcy5fdmFsdWVMb29rdXAuZ2V0KG91dHB1dFZhbHVlKTtcbiAgICBpZiAoZW51bVZhbHVlID09PSB2b2lkIDApIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBFbnVtIFwiJHt0aGlzLm5hbWV9XCIgY2Fubm90IHJlcHJlc2VudCB2YWx1ZTogJHtpbnNwZWN0KG91dHB1dFZhbHVlKX1gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gZW51bVZhbHVlLm5hbWU7XG4gIH1cbiAgcGFyc2VWYWx1ZShpbnB1dFZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiBpbnB1dFZhbHVlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCB2YWx1ZVN0ciA9IGluc3BlY3QoaW5wdXRWYWx1ZSk7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgRW51bSBcIiR7dGhpcy5uYW1lfVwiIGNhbm5vdCByZXByZXNlbnQgbm9uLXN0cmluZyB2YWx1ZTogJHt2YWx1ZVN0cn0uYCArIGRpZFlvdU1lYW5FbnVtVmFsdWUodGhpcywgdmFsdWVTdHIpXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBlbnVtVmFsdWUgPSB0aGlzLmdldFZhbHVlKGlucHV0VmFsdWUpO1xuICAgIGlmIChlbnVtVmFsdWUgPT0gbnVsbCkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYFZhbHVlIFwiJHtpbnB1dFZhbHVlfVwiIGRvZXMgbm90IGV4aXN0IGluIFwiJHt0aGlzLm5hbWV9XCIgZW51bS5gICsgZGlkWW91TWVhbkVudW1WYWx1ZSh0aGlzLCBpbnB1dFZhbHVlKVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIGVudW1WYWx1ZS52YWx1ZTtcbiAgfVxuICBwYXJzZUxpdGVyYWwodmFsdWVOb2RlLCBfdmFyaWFibGVzKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLkVOVU0pIHtcbiAgICAgIGNvbnN0IHZhbHVlU3RyID0gcHJpbnQodmFsdWVOb2RlKTtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBFbnVtIFwiJHt0aGlzLm5hbWV9XCIgY2Fubm90IHJlcHJlc2VudCBub24tZW51bSB2YWx1ZTogJHt2YWx1ZVN0cn0uYCArIGRpZFlvdU1lYW5FbnVtVmFsdWUodGhpcywgdmFsdWVTdHIpLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBlbnVtVmFsdWUgPSB0aGlzLmdldFZhbHVlKHZhbHVlTm9kZS52YWx1ZSk7XG4gICAgaWYgKGVudW1WYWx1ZSA9PSBudWxsKSB7XG4gICAgICBjb25zdCB2YWx1ZVN0ciA9IHByaW50KHZhbHVlTm9kZSk7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgVmFsdWUgXCIke3ZhbHVlU3RyfVwiIGRvZXMgbm90IGV4aXN0IGluIFwiJHt0aGlzLm5hbWV9XCIgZW51bS5gICsgZGlkWW91TWVhbkVudW1WYWx1ZSh0aGlzLCB2YWx1ZVN0ciksXG4gICAgICAgIHtcbiAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBlbnVtVmFsdWUudmFsdWU7XG4gIH1cbiAgdG9Db25maWcoKSB7XG4gICAgY29uc3QgdmFsdWVzID0ga2V5VmFsTWFwKFxuICAgICAgdGhpcy5nZXRWYWx1ZXMoKSxcbiAgICAgICh2YWx1ZSkgPT4gdmFsdWUubmFtZSxcbiAgICAgICh2YWx1ZSkgPT4gKHtcbiAgICAgICAgZGVzY3JpcHRpb246IHZhbHVlLmRlc2NyaXB0aW9uLFxuICAgICAgICB2YWx1ZTogdmFsdWUudmFsdWUsXG4gICAgICAgIGRlcHJlY2F0aW9uUmVhc29uOiB2YWx1ZS5kZXByZWNhdGlvblJlYXNvbixcbiAgICAgICAgZXh0ZW5zaW9uczogdmFsdWUuZXh0ZW5zaW9ucyxcbiAgICAgICAgYXN0Tm9kZTogdmFsdWUuYXN0Tm9kZVxuICAgICAgfSlcbiAgICApO1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIHZhbHVlcyxcbiAgICAgIGV4dGVuc2lvbnM6IHRoaXMuZXh0ZW5zaW9ucyxcbiAgICAgIGFzdE5vZGU6IHRoaXMuYXN0Tm9kZSxcbiAgICAgIGV4dGVuc2lvbkFTVE5vZGVzOiB0aGlzLmV4dGVuc2lvbkFTVE5vZGVzXG4gICAgfTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gdGhpcy5uYW1lO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4gdGhpcy50b1N0cmluZygpO1xuICB9XG59O1xuZnVuY3Rpb24gZGlkWW91TWVhbkVudW1WYWx1ZShlbnVtVHlwZSwgdW5rbm93blZhbHVlU3RyKSB7XG4gIGNvbnN0IGFsbE5hbWVzID0gZW51bVR5cGUuZ2V0VmFsdWVzKCkubWFwKCh2YWx1ZSkgPT4gdmFsdWUubmFtZSk7XG4gIGNvbnN0IHN1Z2dlc3RlZFZhbHVlcyA9IHN1Z2dlc3Rpb25MaXN0KHVua25vd25WYWx1ZVN0ciwgYWxsTmFtZXMpO1xuICByZXR1cm4gZGlkWW91TWVhbihcInRoZSBlbnVtIHZhbHVlXCIsIHN1Z2dlc3RlZFZhbHVlcyk7XG59XG5mdW5jdGlvbiBkZWZpbmVFbnVtVmFsdWVzKHR5cGVOYW1lLCB2YWx1ZU1hcCkge1xuICBpc1BsYWluT2JqKHZhbHVlTWFwKSB8fCBkZXZBc3NlcnQoXG4gICAgZmFsc2UsXG4gICAgYCR7dHlwZU5hbWV9IHZhbHVlcyBtdXN0IGJlIGFuIG9iamVjdCB3aXRoIHZhbHVlIG5hbWVzIGFzIGtleXMuYFxuICApO1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXModmFsdWVNYXApLm1hcCgoW3ZhbHVlTmFtZSwgdmFsdWVDb25maWddKSA9PiB7XG4gICAgaXNQbGFpbk9iaih2YWx1ZUNvbmZpZykgfHwgZGV2QXNzZXJ0KFxuICAgICAgZmFsc2UsXG4gICAgICBgJHt0eXBlTmFtZX0uJHt2YWx1ZU5hbWV9IG11c3QgcmVmZXIgdG8gYW4gb2JqZWN0IHdpdGggYSBcInZhbHVlXCIga2V5IHJlcHJlc2VudGluZyBhbiBpbnRlcm5hbCB2YWx1ZSBidXQgZ290OiAke2luc3BlY3QodmFsdWVDb25maWcpfS5gXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogYXNzZXJ0RW51bVZhbHVlTmFtZSh2YWx1ZU5hbWUpLFxuICAgICAgZGVzY3JpcHRpb246IHZhbHVlQ29uZmlnLmRlc2NyaXB0aW9uLFxuICAgICAgdmFsdWU6IHZhbHVlQ29uZmlnLnZhbHVlICE9PSB2b2lkIDAgPyB2YWx1ZUNvbmZpZy52YWx1ZSA6IHZhbHVlTmFtZSxcbiAgICAgIGRlcHJlY2F0aW9uUmVhc29uOiB2YWx1ZUNvbmZpZy5kZXByZWNhdGlvblJlYXNvbixcbiAgICAgIGV4dGVuc2lvbnM6IHRvT2JqTWFwKHZhbHVlQ29uZmlnLmV4dGVuc2lvbnMpLFxuICAgICAgYXN0Tm9kZTogdmFsdWVDb25maWcuYXN0Tm9kZVxuICAgIH07XG4gIH0pO1xufVxudmFyIEdyYXBoUUxJbnB1dE9iamVjdFR5cGUgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHZhciBfY29uZmlnJGV4dGVuc2lvbkFTVE42O1xuICAgIHRoaXMubmFtZSA9IGFzc2VydE5hbWUoY29uZmlnLm5hbWUpO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBjb25maWcuZGVzY3JpcHRpb247XG4gICAgdGhpcy5leHRlbnNpb25zID0gdG9PYmpNYXAoY29uZmlnLmV4dGVuc2lvbnMpO1xuICAgIHRoaXMuYXN0Tm9kZSA9IGNvbmZpZy5hc3ROb2RlO1xuICAgIHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXMgPSAoX2NvbmZpZyRleHRlbnNpb25BU1RONiA9IGNvbmZpZy5leHRlbnNpb25BU1ROb2RlcykgIT09IG51bGwgJiYgX2NvbmZpZyRleHRlbnNpb25BU1RONiAhPT0gdm9pZCAwID8gX2NvbmZpZyRleHRlbnNpb25BU1RONiA6IFtdO1xuICAgIHRoaXMuX2ZpZWxkcyA9IGRlZmluZUlucHV0RmllbGRNYXAuYmluZCh2b2lkIDAsIGNvbmZpZyk7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIkdyYXBoUUxJbnB1dE9iamVjdFR5cGVcIjtcbiAgfVxuICBnZXRGaWVsZHMoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLl9maWVsZHMgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhpcy5fZmllbGRzID0gdGhpcy5fZmllbGRzKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9maWVsZHM7XG4gIH1cbiAgdG9Db25maWcoKSB7XG4gICAgY29uc3QgZmllbGRzID0gbWFwVmFsdWUodGhpcy5nZXRGaWVsZHMoKSwgKGZpZWxkKSA9PiAoe1xuICAgICAgZGVzY3JpcHRpb246IGZpZWxkLmRlc2NyaXB0aW9uLFxuICAgICAgdHlwZTogZmllbGQudHlwZSxcbiAgICAgIGRlZmF1bHRWYWx1ZTogZmllbGQuZGVmYXVsdFZhbHVlLFxuICAgICAgZGVwcmVjYXRpb25SZWFzb246IGZpZWxkLmRlcHJlY2F0aW9uUmVhc29uLFxuICAgICAgZXh0ZW5zaW9uczogZmllbGQuZXh0ZW5zaW9ucyxcbiAgICAgIGFzdE5vZGU6IGZpZWxkLmFzdE5vZGVcbiAgICB9KSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgIGRlc2NyaXB0aW9uOiB0aGlzLmRlc2NyaXB0aW9uLFxuICAgICAgZmllbGRzLFxuICAgICAgZXh0ZW5zaW9uczogdGhpcy5leHRlbnNpb25zLFxuICAgICAgYXN0Tm9kZTogdGhpcy5hc3ROb2RlLFxuICAgICAgZXh0ZW5zaW9uQVNUTm9kZXM6IHRoaXMuZXh0ZW5zaW9uQVNUTm9kZXNcbiAgICB9O1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLm5hbWU7XG4gIH1cbiAgdG9KU09OKCkge1xuICAgIHJldHVybiB0aGlzLnRvU3RyaW5nKCk7XG4gIH1cbn07XG5mdW5jdGlvbiBkZWZpbmVJbnB1dEZpZWxkTWFwKGNvbmZpZykge1xuICBjb25zdCBmaWVsZE1hcCA9IHJlc29sdmVPYmpNYXBUaHVuayhjb25maWcuZmllbGRzKTtcbiAgaXNQbGFpbk9iaihmaWVsZE1hcCkgfHwgZGV2QXNzZXJ0KFxuICAgIGZhbHNlLFxuICAgIGAke2NvbmZpZy5uYW1lfSBmaWVsZHMgbXVzdCBiZSBhbiBvYmplY3Qgd2l0aCBmaWVsZCBuYW1lcyBhcyBrZXlzIG9yIGEgZnVuY3Rpb24gd2hpY2ggcmV0dXJucyBzdWNoIGFuIG9iamVjdC5gXG4gICk7XG4gIHJldHVybiBtYXBWYWx1ZShmaWVsZE1hcCwgKGZpZWxkQ29uZmlnLCBmaWVsZE5hbWUpID0+IHtcbiAgICAhKFwicmVzb2x2ZVwiIGluIGZpZWxkQ29uZmlnKSB8fCBkZXZBc3NlcnQoXG4gICAgICBmYWxzZSxcbiAgICAgIGAke2NvbmZpZy5uYW1lfS4ke2ZpZWxkTmFtZX0gZmllbGQgaGFzIGEgcmVzb2x2ZSBwcm9wZXJ0eSwgYnV0IElucHV0IFR5cGVzIGNhbm5vdCBkZWZpbmUgcmVzb2x2ZXJzLmBcbiAgICApO1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiBhc3NlcnROYW1lKGZpZWxkTmFtZSksXG4gICAgICBkZXNjcmlwdGlvbjogZmllbGRDb25maWcuZGVzY3JpcHRpb24sXG4gICAgICB0eXBlOiBmaWVsZENvbmZpZy50eXBlLFxuICAgICAgZGVmYXVsdFZhbHVlOiBmaWVsZENvbmZpZy5kZWZhdWx0VmFsdWUsXG4gICAgICBkZXByZWNhdGlvblJlYXNvbjogZmllbGRDb25maWcuZGVwcmVjYXRpb25SZWFzb24sXG4gICAgICBleHRlbnNpb25zOiB0b09iak1hcChmaWVsZENvbmZpZy5leHRlbnNpb25zKSxcbiAgICAgIGFzdE5vZGU6IGZpZWxkQ29uZmlnLmFzdE5vZGVcbiAgICB9O1xuICB9KTtcbn1cbmZ1bmN0aW9uIGlzUmVxdWlyZWRJbnB1dEZpZWxkKGZpZWxkKSB7XG4gIHJldHVybiBpc05vbk51bGxUeXBlKGZpZWxkLnR5cGUpICYmIGZpZWxkLmRlZmF1bHRWYWx1ZSA9PT0gdm9pZCAwO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdXRpbGl0aWVzL3R5cGVDb21wYXJhdG9ycy5tanNcbmZ1bmN0aW9uIGlzVHlwZVN1YlR5cGVPZihzY2hlbWEsIG1heWJlU3ViVHlwZSwgc3VwZXJUeXBlKSB7XG4gIGlmIChtYXliZVN1YlR5cGUgPT09IHN1cGVyVHlwZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChpc05vbk51bGxUeXBlKHN1cGVyVHlwZSkpIHtcbiAgICBpZiAoaXNOb25OdWxsVHlwZShtYXliZVN1YlR5cGUpKSB7XG4gICAgICByZXR1cm4gaXNUeXBlU3ViVHlwZU9mKHNjaGVtYSwgbWF5YmVTdWJUeXBlLm9mVHlwZSwgc3VwZXJUeXBlLm9mVHlwZSk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoaXNOb25OdWxsVHlwZShtYXliZVN1YlR5cGUpKSB7XG4gICAgcmV0dXJuIGlzVHlwZVN1YlR5cGVPZihzY2hlbWEsIG1heWJlU3ViVHlwZS5vZlR5cGUsIHN1cGVyVHlwZSk7XG4gIH1cbiAgaWYgKGlzTGlzdFR5cGUoc3VwZXJUeXBlKSkge1xuICAgIGlmIChpc0xpc3RUeXBlKG1heWJlU3ViVHlwZSkpIHtcbiAgICAgIHJldHVybiBpc1R5cGVTdWJUeXBlT2Yoc2NoZW1hLCBtYXliZVN1YlR5cGUub2ZUeXBlLCBzdXBlclR5cGUub2ZUeXBlKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChpc0xpc3RUeXBlKG1heWJlU3ViVHlwZSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIGlzQWJzdHJhY3RUeXBlKHN1cGVyVHlwZSkgJiYgKGlzSW50ZXJmYWNlVHlwZShtYXliZVN1YlR5cGUpIHx8IGlzT2JqZWN0VHlwZShtYXliZVN1YlR5cGUpKSAmJiBzY2hlbWEuaXNTdWJUeXBlKHN1cGVyVHlwZSwgbWF5YmVTdWJUeXBlKTtcbn1cbmZ1bmN0aW9uIGRvVHlwZXNPdmVybGFwKHNjaGVtYSwgdHlwZUEsIHR5cGVCKSB7XG4gIGlmICh0eXBlQSA9PT0gdHlwZUIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAoaXNBYnN0cmFjdFR5cGUodHlwZUEpKSB7XG4gICAgaWYgKGlzQWJzdHJhY3RUeXBlKHR5cGVCKSkge1xuICAgICAgcmV0dXJuIHNjaGVtYS5nZXRQb3NzaWJsZVR5cGVzKHR5cGVBKS5zb21lKCh0eXBlKSA9PiBzY2hlbWEuaXNTdWJUeXBlKHR5cGVCLCB0eXBlKSk7XG4gICAgfVxuICAgIHJldHVybiBzY2hlbWEuaXNTdWJUeXBlKHR5cGVBLCB0eXBlQik7XG4gIH1cbiAgaWYgKGlzQWJzdHJhY3RUeXBlKHR5cGVCKSkge1xuICAgIHJldHVybiBzY2hlbWEuaXNTdWJUeXBlKHR5cGVCLCB0eXBlQSk7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdHlwZS9zY2FsYXJzLm1qc1xudmFyIEdSQVBIUUxfTUFYX0lOVCA9IDIxNDc0ODM2NDc7XG52YXIgR1JBUEhRTF9NSU5fSU5UID0gLTIxNDc0ODM2NDg7XG52YXIgR3JhcGhRTEludCA9IG5ldyBHcmFwaFFMU2NhbGFyVHlwZSh7XG4gIG5hbWU6IFwiSW50XCIsXG4gIGRlc2NyaXB0aW9uOiBcIlRoZSBgSW50YCBzY2FsYXIgdHlwZSByZXByZXNlbnRzIG5vbi1mcmFjdGlvbmFsIHNpZ25lZCB3aG9sZSBudW1lcmljIHZhbHVlcy4gSW50IGNhbiByZXByZXNlbnQgdmFsdWVzIGJldHdlZW4gLSgyXjMxKSBhbmQgMl4zMSAtIDEuXCIsXG4gIHNlcmlhbGl6ZShvdXRwdXRWYWx1ZSkge1xuICAgIGNvbnN0IGNvZXJjZWRWYWx1ZSA9IHNlcmlhbGl6ZU9iamVjdChvdXRwdXRWYWx1ZSk7XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICByZXR1cm4gY29lcmNlZFZhbHVlID8gMSA6IDA7XG4gICAgfVxuICAgIGxldCBudW0gPSBjb2VyY2VkVmFsdWU7XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwic3RyaW5nXCIgJiYgY29lcmNlZFZhbHVlICE9PSBcIlwiKSB7XG4gICAgICBudW0gPSBOdW1iZXIoY29lcmNlZFZhbHVlKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBudW0gIT09IFwibnVtYmVyXCIgfHwgIU51bWJlci5pc0ludGVnZXIobnVtKSkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEludCBjYW5ub3QgcmVwcmVzZW50IG5vbi1pbnRlZ2VyIHZhbHVlOiAke2luc3BlY3QoY29lcmNlZFZhbHVlKX1gXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAobnVtID4gR1JBUEhRTF9NQVhfSU5UIHx8IG51bSA8IEdSQVBIUUxfTUlOX0lOVCkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgXCJJbnQgY2Fubm90IHJlcHJlc2VudCBub24gMzItYml0IHNpZ25lZCBpbnRlZ2VyIHZhbHVlOiBcIiArIGluc3BlY3QoY29lcmNlZFZhbHVlKVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bTtcbiAgfSxcbiAgcGFyc2VWYWx1ZShpbnB1dFZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiBpbnB1dFZhbHVlICE9PSBcIm51bWJlclwiIHx8ICFOdW1iZXIuaXNJbnRlZ2VyKGlucHV0VmFsdWUpKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgSW50IGNhbm5vdCByZXByZXNlbnQgbm9uLWludGVnZXIgdmFsdWU6ICR7aW5zcGVjdChpbnB1dFZhbHVlKX1gXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoaW5wdXRWYWx1ZSA+IEdSQVBIUUxfTUFYX0lOVCB8fCBpbnB1dFZhbHVlIDwgR1JBUEhRTF9NSU5fSU5UKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgSW50IGNhbm5vdCByZXByZXNlbnQgbm9uIDMyLWJpdCBzaWduZWQgaW50ZWdlciB2YWx1ZTogJHtpbnB1dFZhbHVlfWBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBpbnB1dFZhbHVlO1xuICB9LFxuICBwYXJzZUxpdGVyYWwodmFsdWVOb2RlKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLklOVCkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEludCBjYW5ub3QgcmVwcmVzZW50IG5vbi1pbnRlZ2VyIHZhbHVlOiAke3ByaW50KHZhbHVlTm9kZSl9YCxcbiAgICAgICAge1xuICAgICAgICAgIG5vZGVzOiB2YWx1ZU5vZGVcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgbnVtID0gcGFyc2VJbnQodmFsdWVOb2RlLnZhbHVlLCAxMCk7XG4gICAgaWYgKG51bSA+IEdSQVBIUUxfTUFYX0lOVCB8fCBudW0gPCBHUkFQSFFMX01JTl9JTlQpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBJbnQgY2Fubm90IHJlcHJlc2VudCBub24gMzItYml0IHNpZ25lZCBpbnRlZ2VyIHZhbHVlOiAke3ZhbHVlTm9kZS52YWx1ZX1gLFxuICAgICAgICB7XG4gICAgICAgICAgbm9kZXM6IHZhbHVlTm9kZVxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gbnVtO1xuICB9XG59KTtcbnZhciBHcmFwaFFMRmxvYXQgPSBuZXcgR3JhcGhRTFNjYWxhclR5cGUoe1xuICBuYW1lOiBcIkZsb2F0XCIsXG4gIGRlc2NyaXB0aW9uOiBcIlRoZSBgRmxvYXRgIHNjYWxhciB0eXBlIHJlcHJlc2VudHMgc2lnbmVkIGRvdWJsZS1wcmVjaXNpb24gZnJhY3Rpb25hbCB2YWx1ZXMgYXMgc3BlY2lmaWVkIGJ5IFtJRUVFIDc1NF0oaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSUVFRV9mbG9hdGluZ19wb2ludCkuXCIsXG4gIHNlcmlhbGl6ZShvdXRwdXRWYWx1ZSkge1xuICAgIGNvbnN0IGNvZXJjZWRWYWx1ZSA9IHNlcmlhbGl6ZU9iamVjdChvdXRwdXRWYWx1ZSk7XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICByZXR1cm4gY29lcmNlZFZhbHVlID8gMSA6IDA7XG4gICAgfVxuICAgIGxldCBudW0gPSBjb2VyY2VkVmFsdWU7XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwic3RyaW5nXCIgJiYgY29lcmNlZFZhbHVlICE9PSBcIlwiKSB7XG4gICAgICBudW0gPSBOdW1iZXIoY29lcmNlZFZhbHVlKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBudW0gIT09IFwibnVtYmVyXCIgfHwgIU51bWJlci5pc0Zpbml0ZShudW0pKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgRmxvYXQgY2Fubm90IHJlcHJlc2VudCBub24gbnVtZXJpYyB2YWx1ZTogJHtpbnNwZWN0KGNvZXJjZWRWYWx1ZSl9YFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bTtcbiAgfSxcbiAgcGFyc2VWYWx1ZShpbnB1dFZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiBpbnB1dFZhbHVlICE9PSBcIm51bWJlclwiIHx8ICFOdW1iZXIuaXNGaW5pdGUoaW5wdXRWYWx1ZSkpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBGbG9hdCBjYW5ub3QgcmVwcmVzZW50IG5vbiBudW1lcmljIHZhbHVlOiAke2luc3BlY3QoaW5wdXRWYWx1ZSl9YFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIGlucHV0VmFsdWU7XG4gIH0sXG4gIHBhcnNlTGl0ZXJhbCh2YWx1ZU5vZGUpIHtcbiAgICBpZiAodmFsdWVOb2RlLmtpbmQgIT09IEtpbmQuRkxPQVQgJiYgdmFsdWVOb2RlLmtpbmQgIT09IEtpbmQuSU5UKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgRmxvYXQgY2Fubm90IHJlcHJlc2VudCBub24gbnVtZXJpYyB2YWx1ZTogJHtwcmludCh2YWx1ZU5vZGUpfWAsXG4gICAgICAgIHZhbHVlTm9kZVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcnNlRmxvYXQodmFsdWVOb2RlLnZhbHVlKTtcbiAgfVxufSk7XG52YXIgR3JhcGhRTFN0cmluZyA9IG5ldyBHcmFwaFFMU2NhbGFyVHlwZSh7XG4gIG5hbWU6IFwiU3RyaW5nXCIsXG4gIGRlc2NyaXB0aW9uOiBcIlRoZSBgU3RyaW5nYCBzY2FsYXIgdHlwZSByZXByZXNlbnRzIHRleHR1YWwgZGF0YSwgcmVwcmVzZW50ZWQgYXMgVVRGLTggY2hhcmFjdGVyIHNlcXVlbmNlcy4gVGhlIFN0cmluZyB0eXBlIGlzIG1vc3Qgb2Z0ZW4gdXNlZCBieSBHcmFwaFFMIHRvIHJlcHJlc2VudCBmcmVlLWZvcm0gaHVtYW4tcmVhZGFibGUgdGV4dC5cIixcbiAgc2VyaWFsaXplKG91dHB1dFZhbHVlKSB7XG4gICAgY29uc3QgY29lcmNlZFZhbHVlID0gc2VyaWFsaXplT2JqZWN0KG91dHB1dFZhbHVlKTtcbiAgICBpZiAodHlwZW9mIGNvZXJjZWRWYWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBjb2VyY2VkVmFsdWUgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICByZXR1cm4gY29lcmNlZFZhbHVlID8gXCJ0cnVlXCIgOiBcImZhbHNlXCI7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgY29lcmNlZFZhbHVlID09PSBcIm51bWJlclwiICYmIE51bWJlci5pc0Zpbml0ZShjb2VyY2VkVmFsdWUpKSB7XG4gICAgICByZXR1cm4gY29lcmNlZFZhbHVlLnRvU3RyaW5nKCk7XG4gICAgfVxuICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICBgU3RyaW5nIGNhbm5vdCByZXByZXNlbnQgdmFsdWU6ICR7aW5zcGVjdChvdXRwdXRWYWx1ZSl9YFxuICAgICk7XG4gIH0sXG4gIHBhcnNlVmFsdWUoaW5wdXRWYWx1ZSkge1xuICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZSAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYFN0cmluZyBjYW5ub3QgcmVwcmVzZW50IGEgbm9uIHN0cmluZyB2YWx1ZTogJHtpbnNwZWN0KGlucHV0VmFsdWUpfWBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBpbnB1dFZhbHVlO1xuICB9LFxuICBwYXJzZUxpdGVyYWwodmFsdWVOb2RlKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLlNUUklORykge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYFN0cmluZyBjYW5ub3QgcmVwcmVzZW50IGEgbm9uIHN0cmluZyB2YWx1ZTogJHtwcmludCh2YWx1ZU5vZGUpfWAsXG4gICAgICAgIHtcbiAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZU5vZGUudmFsdWU7XG4gIH1cbn0pO1xudmFyIEdyYXBoUUxCb29sZWFuID0gbmV3IEdyYXBoUUxTY2FsYXJUeXBlKHtcbiAgbmFtZTogXCJCb29sZWFuXCIsXG4gIGRlc2NyaXB0aW9uOiBcIlRoZSBgQm9vbGVhbmAgc2NhbGFyIHR5cGUgcmVwcmVzZW50cyBgdHJ1ZWAgb3IgYGZhbHNlYC5cIixcbiAgc2VyaWFsaXplKG91dHB1dFZhbHVlKSB7XG4gICAgY29uc3QgY29lcmNlZFZhbHVlID0gc2VyaWFsaXplT2JqZWN0KG91dHB1dFZhbHVlKTtcbiAgICBpZiAodHlwZW9mIGNvZXJjZWRWYWx1ZSA9PT0gXCJib29sZWFuXCIpIHtcbiAgICAgIHJldHVybiBjb2VyY2VkVmFsdWU7XG4gICAgfVxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoY29lcmNlZFZhbHVlKSkge1xuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZSAhPT0gMDtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgIGBCb29sZWFuIGNhbm5vdCByZXByZXNlbnQgYSBub24gYm9vbGVhbiB2YWx1ZTogJHtpbnNwZWN0KGNvZXJjZWRWYWx1ZSl9YFxuICAgICk7XG4gIH0sXG4gIHBhcnNlVmFsdWUoaW5wdXRWYWx1ZSkge1xuICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZSAhPT0gXCJib29sZWFuXCIpIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBCb29sZWFuIGNhbm5vdCByZXByZXNlbnQgYSBub24gYm9vbGVhbiB2YWx1ZTogJHtpbnNwZWN0KGlucHV0VmFsdWUpfWBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBpbnB1dFZhbHVlO1xuICB9LFxuICBwYXJzZUxpdGVyYWwodmFsdWVOb2RlKSB7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLkJPT0xFQU4pIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBCb29sZWFuIGNhbm5vdCByZXByZXNlbnQgYSBub24gYm9vbGVhbiB2YWx1ZTogJHtwcmludCh2YWx1ZU5vZGUpfWAsXG4gICAgICAgIHtcbiAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZU5vZGUudmFsdWU7XG4gIH1cbn0pO1xudmFyIEdyYXBoUUxJRCA9IG5ldyBHcmFwaFFMU2NhbGFyVHlwZSh7XG4gIG5hbWU6IFwiSURcIixcbiAgZGVzY3JpcHRpb246ICdUaGUgYElEYCBzY2FsYXIgdHlwZSByZXByZXNlbnRzIGEgdW5pcXVlIGlkZW50aWZpZXIsIG9mdGVuIHVzZWQgdG8gcmVmZXRjaCBhbiBvYmplY3Qgb3IgYXMga2V5IGZvciBhIGNhY2hlLiBUaGUgSUQgdHlwZSBhcHBlYXJzIGluIGEgSlNPTiByZXNwb25zZSBhcyBhIFN0cmluZzsgaG93ZXZlciwgaXQgaXMgbm90IGludGVuZGVkIHRvIGJlIGh1bWFuLXJlYWRhYmxlLiBXaGVuIGV4cGVjdGVkIGFzIGFuIGlucHV0IHR5cGUsIGFueSBzdHJpbmcgKHN1Y2ggYXMgYFwiNFwiYCkgb3IgaW50ZWdlciAoc3VjaCBhcyBgNGApIGlucHV0IHZhbHVlIHdpbGwgYmUgYWNjZXB0ZWQgYXMgYW4gSUQuJyxcbiAgc2VyaWFsaXplKG91dHB1dFZhbHVlKSB7XG4gICAgY29uc3QgY29lcmNlZFZhbHVlID0gc2VyaWFsaXplT2JqZWN0KG91dHB1dFZhbHVlKTtcbiAgICBpZiAodHlwZW9mIGNvZXJjZWRWYWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIGNvZXJjZWRWYWx1ZTtcbiAgICB9XG4gICAgaWYgKE51bWJlci5pc0ludGVnZXIoY29lcmNlZFZhbHVlKSkge1xuICAgICAgcmV0dXJuIFN0cmluZyhjb2VyY2VkVmFsdWUpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgYElEIGNhbm5vdCByZXByZXNlbnQgdmFsdWU6ICR7aW5zcGVjdChvdXRwdXRWYWx1ZSl9YFxuICAgICk7XG4gIH0sXG4gIHBhcnNlVmFsdWUoaW5wdXRWYWx1ZSkge1xuICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIGlucHV0VmFsdWU7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZSA9PT0gXCJudW1iZXJcIiAmJiBOdW1iZXIuaXNJbnRlZ2VyKGlucHV0VmFsdWUpKSB7XG4gICAgICByZXR1cm4gaW5wdXRWYWx1ZS50b1N0cmluZygpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKGBJRCBjYW5ub3QgcmVwcmVzZW50IHZhbHVlOiAke2luc3BlY3QoaW5wdXRWYWx1ZSl9YCk7XG4gIH0sXG4gIHBhcnNlTGl0ZXJhbCh2YWx1ZU5vZGUpIHtcbiAgICBpZiAodmFsdWVOb2RlLmtpbmQgIT09IEtpbmQuU1RSSU5HICYmIHZhbHVlTm9kZS5raW5kICE9PSBLaW5kLklOVCkge1xuICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgXCJJRCBjYW5ub3QgcmVwcmVzZW50IGEgbm9uLXN0cmluZyBhbmQgbm9uLWludGVnZXIgdmFsdWU6IFwiICsgcHJpbnQodmFsdWVOb2RlKSxcbiAgICAgICAge1xuICAgICAgICAgIG5vZGVzOiB2YWx1ZU5vZGVcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlTm9kZS52YWx1ZTtcbiAgfVxufSk7XG52YXIgc3BlY2lmaWVkU2NhbGFyVHlwZXMgPSBPYmplY3QuZnJlZXplKFtcbiAgR3JhcGhRTFN0cmluZyxcbiAgR3JhcGhRTEludCxcbiAgR3JhcGhRTEZsb2F0LFxuICBHcmFwaFFMQm9vbGVhbixcbiAgR3JhcGhRTElEXG5dKTtcbmZ1bmN0aW9uIHNlcmlhbGl6ZU9iamVjdChvdXRwdXRWYWx1ZSkge1xuICBpZiAoaXNPYmplY3RMaWtlKG91dHB1dFZhbHVlKSkge1xuICAgIGlmICh0eXBlb2Ygb3V0cHV0VmFsdWUudmFsdWVPZiA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICBjb25zdCB2YWx1ZU9mUmVzdWx0ID0gb3V0cHV0VmFsdWUudmFsdWVPZigpO1xuICAgICAgaWYgKCFpc09iamVjdExpa2UodmFsdWVPZlJlc3VsdCkpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlT2ZSZXN1bHQ7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygb3V0cHV0VmFsdWUudG9KU09OID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHJldHVybiBvdXRwdXRWYWx1ZS50b0pTT04oKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dHB1dFZhbHVlO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdHlwZS9kaXJlY3RpdmVzLm1qc1xudmFyIEdyYXBoUUxEaXJlY3RpdmUgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHZhciBfY29uZmlnJGlzUmVwZWF0YWJsZSwgX2NvbmZpZyRhcmdzO1xuICAgIHRoaXMubmFtZSA9IGFzc2VydE5hbWUoY29uZmlnLm5hbWUpO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBjb25maWcuZGVzY3JpcHRpb247XG4gICAgdGhpcy5sb2NhdGlvbnMgPSBjb25maWcubG9jYXRpb25zO1xuICAgIHRoaXMuaXNSZXBlYXRhYmxlID0gKF9jb25maWckaXNSZXBlYXRhYmxlID0gY29uZmlnLmlzUmVwZWF0YWJsZSkgIT09IG51bGwgJiYgX2NvbmZpZyRpc1JlcGVhdGFibGUgIT09IHZvaWQgMCA/IF9jb25maWckaXNSZXBlYXRhYmxlIDogZmFsc2U7XG4gICAgdGhpcy5leHRlbnNpb25zID0gdG9PYmpNYXAoY29uZmlnLmV4dGVuc2lvbnMpO1xuICAgIHRoaXMuYXN0Tm9kZSA9IGNvbmZpZy5hc3ROb2RlO1xuICAgIEFycmF5LmlzQXJyYXkoY29uZmlnLmxvY2F0aW9ucykgfHwgZGV2QXNzZXJ0KGZhbHNlLCBgQCR7Y29uZmlnLm5hbWV9IGxvY2F0aW9ucyBtdXN0IGJlIGFuIEFycmF5LmApO1xuICAgIGNvbnN0IGFyZ3MgPSAoX2NvbmZpZyRhcmdzID0gY29uZmlnLmFyZ3MpICE9PSBudWxsICYmIF9jb25maWckYXJncyAhPT0gdm9pZCAwID8gX2NvbmZpZyRhcmdzIDoge307XG4gICAgaXNPYmplY3RMaWtlKGFyZ3MpICYmICFBcnJheS5pc0FycmF5KGFyZ3MpIHx8IGRldkFzc2VydChcbiAgICAgIGZhbHNlLFxuICAgICAgYEAke2NvbmZpZy5uYW1lfSBhcmdzIG11c3QgYmUgYW4gb2JqZWN0IHdpdGggYXJndW1lbnQgbmFtZXMgYXMga2V5cy5gXG4gICAgKTtcbiAgICB0aGlzLmFyZ3MgPSBkZWZpbmVBcmd1bWVudHMoYXJncyk7XG4gIH1cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiBcIkdyYXBoUUxEaXJlY3RpdmVcIjtcbiAgfVxuICB0b0NvbmZpZygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICBsb2NhdGlvbnM6IHRoaXMubG9jYXRpb25zLFxuICAgICAgYXJnczogYXJnc1RvQXJnc0NvbmZpZyh0aGlzLmFyZ3MpLFxuICAgICAgaXNSZXBlYXRhYmxlOiB0aGlzLmlzUmVwZWF0YWJsZSxcbiAgICAgIGV4dGVuc2lvbnM6IHRoaXMuZXh0ZW5zaW9ucyxcbiAgICAgIGFzdE5vZGU6IHRoaXMuYXN0Tm9kZVxuICAgIH07XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIFwiQFwiICsgdGhpcy5uYW1lO1xuICB9XG4gIHRvSlNPTigpIHtcbiAgICByZXR1cm4gdGhpcy50b1N0cmluZygpO1xuICB9XG59O1xudmFyIEdyYXBoUUxJbmNsdWRlRGlyZWN0aXZlID0gbmV3IEdyYXBoUUxEaXJlY3RpdmUoe1xuICBuYW1lOiBcImluY2x1ZGVcIixcbiAgZGVzY3JpcHRpb246IFwiRGlyZWN0cyB0aGUgZXhlY3V0b3IgdG8gaW5jbHVkZSB0aGlzIGZpZWxkIG9yIGZyYWdtZW50IG9ubHkgd2hlbiB0aGUgYGlmYCBhcmd1bWVudCBpcyB0cnVlLlwiLFxuICBsb2NhdGlvbnM6IFtcbiAgICBEaXJlY3RpdmVMb2NhdGlvbi5GSUVMRCxcbiAgICBEaXJlY3RpdmVMb2NhdGlvbi5GUkFHTUVOVF9TUFJFQUQsXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uSU5MSU5FX0ZSQUdNRU5UXG4gIF0sXG4gIGFyZ3M6IHtcbiAgICBpZjoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxCb29sZWFuKSxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkluY2x1ZGVkIHdoZW4gdHJ1ZS5cIlxuICAgIH1cbiAgfVxufSk7XG52YXIgR3JhcGhRTFNraXBEaXJlY3RpdmUgPSBuZXcgR3JhcGhRTERpcmVjdGl2ZSh7XG4gIG5hbWU6IFwic2tpcFwiLFxuICBkZXNjcmlwdGlvbjogXCJEaXJlY3RzIHRoZSBleGVjdXRvciB0byBza2lwIHRoaXMgZmllbGQgb3IgZnJhZ21lbnQgd2hlbiB0aGUgYGlmYCBhcmd1bWVudCBpcyB0cnVlLlwiLFxuICBsb2NhdGlvbnM6IFtcbiAgICBEaXJlY3RpdmVMb2NhdGlvbi5GSUVMRCxcbiAgICBEaXJlY3RpdmVMb2NhdGlvbi5GUkFHTUVOVF9TUFJFQUQsXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uSU5MSU5FX0ZSQUdNRU5UXG4gIF0sXG4gIGFyZ3M6IHtcbiAgICBpZjoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxCb29sZWFuKSxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlNraXBwZWQgd2hlbiB0cnVlLlwiXG4gICAgfVxuICB9XG59KTtcbnZhciBERUZBVUxUX0RFUFJFQ0FUSU9OX1JFQVNPTiA9IFwiTm8gbG9uZ2VyIHN1cHBvcnRlZFwiO1xudmFyIEdyYXBoUUxEZXByZWNhdGVkRGlyZWN0aXZlID0gbmV3IEdyYXBoUUxEaXJlY3RpdmUoe1xuICBuYW1lOiBcImRlcHJlY2F0ZWRcIixcbiAgZGVzY3JpcHRpb246IFwiTWFya3MgYW4gZWxlbWVudCBvZiBhIEdyYXBoUUwgc2NoZW1hIGFzIG5vIGxvbmdlciBzdXBwb3J0ZWQuXCIsXG4gIGxvY2F0aW9uczogW1xuICAgIERpcmVjdGl2ZUxvY2F0aW9uLkZJRUxEX0RFRklOSVRJT04sXG4gICAgRGlyZWN0aXZlTG9jYXRpb24uQVJHVU1FTlRfREVGSU5JVElPTixcbiAgICBEaXJlY3RpdmVMb2NhdGlvbi5JTlBVVF9GSUVMRF9ERUZJTklUSU9OLFxuICAgIERpcmVjdGl2ZUxvY2F0aW9uLkVOVU1fVkFMVUVcbiAgXSxcbiAgYXJnczoge1xuICAgIHJlYXNvbjoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkV4cGxhaW5zIHdoeSB0aGlzIGVsZW1lbnQgd2FzIGRlcHJlY2F0ZWQsIHVzdWFsbHkgYWxzbyBpbmNsdWRpbmcgYSBzdWdnZXN0aW9uIGZvciBob3cgdG8gYWNjZXNzIHN1cHBvcnRlZCBzaW1pbGFyIGRhdGEuIEZvcm1hdHRlZCB1c2luZyB0aGUgTWFya2Rvd24gc3ludGF4LCBhcyBzcGVjaWZpZWQgYnkgW0NvbW1vbk1hcmtdKGh0dHBzOi8vY29tbW9ubWFyay5vcmcvKS5cIixcbiAgICAgIGRlZmF1bHRWYWx1ZTogREVGQVVMVF9ERVBSRUNBVElPTl9SRUFTT05cbiAgICB9XG4gIH1cbn0pO1xudmFyIEdyYXBoUUxTcGVjaWZpZWRCeURpcmVjdGl2ZSA9IG5ldyBHcmFwaFFMRGlyZWN0aXZlKHtcbiAgbmFtZTogXCJzcGVjaWZpZWRCeVwiLFxuICBkZXNjcmlwdGlvbjogXCJFeHBvc2VzIGEgVVJMIHRoYXQgc3BlY2lmaWVzIHRoZSBiZWhhdmlvciBvZiB0aGlzIHNjYWxhci5cIixcbiAgbG9jYXRpb25zOiBbRGlyZWN0aXZlTG9jYXRpb24uU0NBTEFSXSxcbiAgYXJnczoge1xuICAgIHVybDoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxTdHJpbmcpLFxuICAgICAgZGVzY3JpcHRpb246IFwiVGhlIFVSTCB0aGF0IHNwZWNpZmllcyB0aGUgYmVoYXZpb3Igb2YgdGhpcyBzY2FsYXIuXCJcbiAgICB9XG4gIH1cbn0pO1xudmFyIHNwZWNpZmllZERpcmVjdGl2ZXMgPSBPYmplY3QuZnJlZXplKFtcbiAgR3JhcGhRTEluY2x1ZGVEaXJlY3RpdmUsXG4gIEdyYXBoUUxTa2lwRGlyZWN0aXZlLFxuICBHcmFwaFFMRGVwcmVjYXRlZERpcmVjdGl2ZSxcbiAgR3JhcGhRTFNwZWNpZmllZEJ5RGlyZWN0aXZlXG5dKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvaXNJdGVyYWJsZU9iamVjdC5tanNcbmZ1bmN0aW9uIGlzSXRlcmFibGVPYmplY3QobWF5YmVJdGVyYWJsZSkge1xuICByZXR1cm4gdHlwZW9mIG1heWJlSXRlcmFibGUgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIChtYXliZUl0ZXJhYmxlID09PSBudWxsIHx8IG1heWJlSXRlcmFibGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG1heWJlSXRlcmFibGVbU3ltYm9sLml0ZXJhdG9yXSkgPT09IFwiZnVuY3Rpb25cIjtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3V0aWxpdGllcy9hc3RGcm9tVmFsdWUubWpzXG5mdW5jdGlvbiBhc3RGcm9tVmFsdWUodmFsdWUsIHR5cGUpIHtcbiAgaWYgKGlzTm9uTnVsbFR5cGUodHlwZSkpIHtcbiAgICBjb25zdCBhc3RWYWx1ZSA9IGFzdEZyb21WYWx1ZSh2YWx1ZSwgdHlwZS5vZlR5cGUpO1xuICAgIGlmICgoYXN0VmFsdWUgPT09IG51bGwgfHwgYXN0VmFsdWUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGFzdFZhbHVlLmtpbmQpID09PSBLaW5kLk5VTEwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gYXN0VmFsdWU7XG4gIH1cbiAgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGtpbmQ6IEtpbmQuTlVMTFxuICAgIH07XG4gIH1cbiAgaWYgKHZhbHVlID09PSB2b2lkIDApIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoaXNMaXN0VHlwZSh0eXBlKSkge1xuICAgIGNvbnN0IGl0ZW1UeXBlID0gdHlwZS5vZlR5cGU7XG4gICAgaWYgKGlzSXRlcmFibGVPYmplY3QodmFsdWUpKSB7XG4gICAgICBjb25zdCB2YWx1ZXNOb2RlcyA9IFtdO1xuICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IGl0ZW1Ob2RlID0gYXN0RnJvbVZhbHVlKGl0ZW0sIGl0ZW1UeXBlKTtcbiAgICAgICAgaWYgKGl0ZW1Ob2RlICE9IG51bGwpIHtcbiAgICAgICAgICB2YWx1ZXNOb2Rlcy5wdXNoKGl0ZW1Ob2RlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAga2luZDogS2luZC5MSVNULFxuICAgICAgICB2YWx1ZXM6IHZhbHVlc05vZGVzXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gYXN0RnJvbVZhbHVlKHZhbHVlLCBpdGVtVHlwZSk7XG4gIH1cbiAgaWYgKGlzSW5wdXRPYmplY3RUeXBlKHR5cGUpKSB7XG4gICAgaWYgKCFpc09iamVjdExpa2UodmFsdWUpKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgZmllbGROb2RlcyA9IFtdO1xuICAgIGZvciAoY29uc3QgZmllbGQgb2YgT2JqZWN0LnZhbHVlcyh0eXBlLmdldEZpZWxkcygpKSkge1xuICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IGFzdEZyb21WYWx1ZSh2YWx1ZVtmaWVsZC5uYW1lXSwgZmllbGQudHlwZSk7XG4gICAgICBpZiAoZmllbGRWYWx1ZSkge1xuICAgICAgICBmaWVsZE5vZGVzLnB1c2goe1xuICAgICAgICAgIGtpbmQ6IEtpbmQuT0JKRUNUX0ZJRUxELFxuICAgICAgICAgIG5hbWU6IHtcbiAgICAgICAgICAgIGtpbmQ6IEtpbmQuTkFNRSxcbiAgICAgICAgICAgIHZhbHVlOiBmaWVsZC5uYW1lXG4gICAgICAgICAgfSxcbiAgICAgICAgICB2YWx1ZTogZmllbGRWYWx1ZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGtpbmQ6IEtpbmQuT0JKRUNULFxuICAgICAgZmllbGRzOiBmaWVsZE5vZGVzXG4gICAgfTtcbiAgfVxuICBpZiAoaXNMZWFmVHlwZSh0eXBlKSkge1xuICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSB0eXBlLnNlcmlhbGl6ZSh2YWx1ZSk7XG4gICAgaWYgKHNlcmlhbGl6ZWQgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygc2VyaWFsaXplZCA9PT0gXCJib29sZWFuXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGtpbmQ6IEtpbmQuQk9PTEVBTixcbiAgICAgICAgdmFsdWU6IHNlcmlhbGl6ZWRcbiAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygc2VyaWFsaXplZCA9PT0gXCJudW1iZXJcIiAmJiBOdW1iZXIuaXNGaW5pdGUoc2VyaWFsaXplZCkpIHtcbiAgICAgIGNvbnN0IHN0cmluZ051bSA9IFN0cmluZyhzZXJpYWxpemVkKTtcbiAgICAgIHJldHVybiBpbnRlZ2VyU3RyaW5nUmVnRXhwLnRlc3Qoc3RyaW5nTnVtKSA/IHtcbiAgICAgICAga2luZDogS2luZC5JTlQsXG4gICAgICAgIHZhbHVlOiBzdHJpbmdOdW1cbiAgICAgIH0gOiB7XG4gICAgICAgIGtpbmQ6IEtpbmQuRkxPQVQsXG4gICAgICAgIHZhbHVlOiBzdHJpbmdOdW1cbiAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygc2VyaWFsaXplZCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgaWYgKGlzRW51bVR5cGUodHlwZSkpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBraW5kOiBLaW5kLkVOVU0sXG4gICAgICAgICAgdmFsdWU6IHNlcmlhbGl6ZWRcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlID09PSBHcmFwaFFMSUQgJiYgaW50ZWdlclN0cmluZ1JlZ0V4cC50ZXN0KHNlcmlhbGl6ZWQpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAga2luZDogS2luZC5JTlQsXG4gICAgICAgICAgdmFsdWU6IHNlcmlhbGl6ZWRcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGtpbmQ6IEtpbmQuU1RSSU5HLFxuICAgICAgICB2YWx1ZTogc2VyaWFsaXplZFxuICAgICAgfTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgQ2Fubm90IGNvbnZlcnQgdmFsdWUgdG8gQVNUOiAke2luc3BlY3Qoc2VyaWFsaXplZCl9LmApO1xuICB9XG4gIGludmFyaWFudDIoZmFsc2UsIFwiVW5leHBlY3RlZCBpbnB1dCB0eXBlOiBcIiArIGluc3BlY3QodHlwZSkpO1xufVxudmFyIGludGVnZXJTdHJpbmdSZWdFeHAgPSAvXi0/KD86MHxbMS05XVswLTldKikkLztcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3R5cGUvaW50cm9zcGVjdGlvbi5tanNcbnZhciBfX1NjaGVtYSA9IG5ldyBHcmFwaFFMT2JqZWN0VHlwZSh7XG4gIG5hbWU6IFwiX19TY2hlbWFcIixcbiAgZGVzY3JpcHRpb246IFwiQSBHcmFwaFFMIFNjaGVtYSBkZWZpbmVzIHRoZSBjYXBhYmlsaXRpZXMgb2YgYSBHcmFwaFFMIHNlcnZlci4gSXQgZXhwb3NlcyBhbGwgYXZhaWxhYmxlIHR5cGVzIGFuZCBkaXJlY3RpdmVzIG9uIHRoZSBzZXJ2ZXIsIGFzIHdlbGwgYXMgdGhlIGVudHJ5IHBvaW50cyBmb3IgcXVlcnksIG11dGF0aW9uLCBhbmQgc3Vic2NyaXB0aW9uIG9wZXJhdGlvbnMuXCIsXG4gIGZpZWxkczogKCkgPT4gKHtcbiAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIHJlc29sdmU6IChzY2hlbWEpID0+IHNjaGVtYS5kZXNjcmlwdGlvblxuICAgIH0sXG4gICAgdHlwZXM6IHtcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkEgbGlzdCBvZiBhbGwgdHlwZXMgc3VwcG9ydGVkIGJ5IHRoaXMgc2VydmVyLlwiLFxuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKG5ldyBHcmFwaFFMTGlzdChuZXcgR3JhcGhRTE5vbk51bGwoX19UeXBlKSkpLFxuICAgICAgcmVzb2x2ZShzY2hlbWEpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC52YWx1ZXMoc2NoZW1hLmdldFR5cGVNYXAoKSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBxdWVyeVR5cGU6IHtcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlRoZSB0eXBlIHRoYXQgcXVlcnkgb3BlcmF0aW9ucyB3aWxsIGJlIHJvb3RlZCBhdC5cIixcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChfX1R5cGUpLFxuICAgICAgcmVzb2x2ZTogKHNjaGVtYSkgPT4gc2NoZW1hLmdldFF1ZXJ5VHlwZSgpXG4gICAgfSxcbiAgICBtdXRhdGlvblR5cGU6IHtcbiAgICAgIGRlc2NyaXB0aW9uOiBcIklmIHRoaXMgc2VydmVyIHN1cHBvcnRzIG11dGF0aW9uLCB0aGUgdHlwZSB0aGF0IG11dGF0aW9uIG9wZXJhdGlvbnMgd2lsbCBiZSByb290ZWQgYXQuXCIsXG4gICAgICB0eXBlOiBfX1R5cGUsXG4gICAgICByZXNvbHZlOiAoc2NoZW1hKSA9PiBzY2hlbWEuZ2V0TXV0YXRpb25UeXBlKClcbiAgICB9LFxuICAgIHN1YnNjcmlwdGlvblR5cGU6IHtcbiAgICAgIGRlc2NyaXB0aW9uOiBcIklmIHRoaXMgc2VydmVyIHN1cHBvcnQgc3Vic2NyaXB0aW9uLCB0aGUgdHlwZSB0aGF0IHN1YnNjcmlwdGlvbiBvcGVyYXRpb25zIHdpbGwgYmUgcm9vdGVkIGF0LlwiLFxuICAgICAgdHlwZTogX19UeXBlLFxuICAgICAgcmVzb2x2ZTogKHNjaGVtYSkgPT4gc2NoZW1hLmdldFN1YnNjcmlwdGlvblR5cGUoKVxuICAgIH0sXG4gICAgZGlyZWN0aXZlczoge1xuICAgICAgZGVzY3JpcHRpb246IFwiQSBsaXN0IG9mIGFsbCBkaXJlY3RpdmVzIHN1cHBvcnRlZCBieSB0aGlzIHNlcnZlci5cIixcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChcbiAgICAgICAgbmV3IEdyYXBoUUxMaXN0KG5ldyBHcmFwaFFMTm9uTnVsbChfX0RpcmVjdGl2ZSkpXG4gICAgICApLFxuICAgICAgcmVzb2x2ZTogKHNjaGVtYSkgPT4gc2NoZW1hLmdldERpcmVjdGl2ZXMoKVxuICAgIH1cbiAgfSlcbn0pO1xudmFyIF9fRGlyZWN0aXZlID0gbmV3IEdyYXBoUUxPYmplY3RUeXBlKHtcbiAgbmFtZTogXCJfX0RpcmVjdGl2ZVwiLFxuICBkZXNjcmlwdGlvbjogXCJBIERpcmVjdGl2ZSBwcm92aWRlcyBhIHdheSB0byBkZXNjcmliZSBhbHRlcm5hdGUgcnVudGltZSBleGVjdXRpb24gYW5kIHR5cGUgdmFsaWRhdGlvbiBiZWhhdmlvciBpbiBhIEdyYXBoUUwgZG9jdW1lbnQuXFxuXFxuSW4gc29tZSBjYXNlcywgeW91IG5lZWQgdG8gcHJvdmlkZSBvcHRpb25zIHRvIGFsdGVyIEdyYXBoUUwncyBleGVjdXRpb24gYmVoYXZpb3IgaW4gd2F5cyBmaWVsZCBhcmd1bWVudHMgd2lsbCBub3Qgc3VmZmljZSwgc3VjaCBhcyBjb25kaXRpb25hbGx5IGluY2x1ZGluZyBvciBza2lwcGluZyBhIGZpZWxkLiBEaXJlY3RpdmVzIHByb3ZpZGUgdGhpcyBieSBkZXNjcmliaW5nIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gdG8gdGhlIGV4ZWN1dG9yLlwiLFxuICBmaWVsZHM6ICgpID0+ICh7XG4gICAgbmFtZToge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxTdHJpbmcpLFxuICAgICAgcmVzb2x2ZTogKGRpcmVjdGl2ZSkgPT4gZGlyZWN0aXZlLm5hbWVcbiAgICB9LFxuICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKGRpcmVjdGl2ZSkgPT4gZGlyZWN0aXZlLmRlc2NyaXB0aW9uXG4gICAgfSxcbiAgICBpc1JlcGVhdGFibGU6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMQm9vbGVhbiksXG4gICAgICByZXNvbHZlOiAoZGlyZWN0aXZlKSA9PiBkaXJlY3RpdmUuaXNSZXBlYXRhYmxlXG4gICAgfSxcbiAgICBsb2NhdGlvbnM6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChcbiAgICAgICAgbmV3IEdyYXBoUUxMaXN0KG5ldyBHcmFwaFFMTm9uTnVsbChfX0RpcmVjdGl2ZUxvY2F0aW9uKSlcbiAgICAgICksXG4gICAgICByZXNvbHZlOiAoZGlyZWN0aXZlKSA9PiBkaXJlY3RpdmUubG9jYXRpb25zXG4gICAgfSxcbiAgICBhcmdzOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoXG4gICAgICAgIG5ldyBHcmFwaFFMTGlzdChuZXcgR3JhcGhRTE5vbk51bGwoX19JbnB1dFZhbHVlKSlcbiAgICAgICksXG4gICAgICBhcmdzOiB7XG4gICAgICAgIGluY2x1ZGVEZXByZWNhdGVkOiB7XG4gICAgICAgICAgdHlwZTogR3JhcGhRTEJvb2xlYW4sXG4gICAgICAgICAgZGVmYXVsdFZhbHVlOiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcmVzb2x2ZShmaWVsZCwgeyBpbmNsdWRlRGVwcmVjYXRlZCB9KSB7XG4gICAgICAgIHJldHVybiBpbmNsdWRlRGVwcmVjYXRlZCA/IGZpZWxkLmFyZ3MgOiBmaWVsZC5hcmdzLmZpbHRlcigoYXJnKSA9PiBhcmcuZGVwcmVjYXRpb25SZWFzb24gPT0gbnVsbCk7XG4gICAgICB9XG4gICAgfVxuICB9KVxufSk7XG52YXIgX19EaXJlY3RpdmVMb2NhdGlvbiA9IG5ldyBHcmFwaFFMRW51bVR5cGUoe1xuICBuYW1lOiBcIl9fRGlyZWN0aXZlTG9jYXRpb25cIixcbiAgZGVzY3JpcHRpb246IFwiQSBEaXJlY3RpdmUgY2FuIGJlIGFkamFjZW50IHRvIG1hbnkgcGFydHMgb2YgdGhlIEdyYXBoUUwgbGFuZ3VhZ2UsIGEgX19EaXJlY3RpdmVMb2NhdGlvbiBkZXNjcmliZXMgb25lIHN1Y2ggcG9zc2libGUgYWRqYWNlbmNpZXMuXCIsXG4gIHZhbHVlczoge1xuICAgIFFVRVJZOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uUVVFUlksXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIHF1ZXJ5IG9wZXJhdGlvbi5cIlxuICAgIH0sXG4gICAgTVVUQVRJT046IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5NVVRBVElPTixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGEgbXV0YXRpb24gb3BlcmF0aW9uLlwiXG4gICAgfSxcbiAgICBTVUJTQ1JJUFRJT046IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5TVUJTQ1JJUFRJT04sXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIHN1YnNjcmlwdGlvbiBvcGVyYXRpb24uXCJcbiAgICB9LFxuICAgIEZJRUxEOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uRklFTEQsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIGZpZWxkLlwiXG4gICAgfSxcbiAgICBGUkFHTUVOVF9ERUZJTklUSU9OOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uRlJBR01FTlRfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGEgZnJhZ21lbnQgZGVmaW5pdGlvbi5cIlxuICAgIH0sXG4gICAgRlJBR01FTlRfU1BSRUFEOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uRlJBR01FTlRfU1BSRUFELFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYSBmcmFnbWVudCBzcHJlYWQuXCJcbiAgICB9LFxuICAgIElOTElORV9GUkFHTUVOVDoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLklOTElORV9GUkFHTUVOVCxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGFuIGlubGluZSBmcmFnbWVudC5cIlxuICAgIH0sXG4gICAgVkFSSUFCTEVfREVGSU5JVElPTjoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLlZBUklBQkxFX0RFRklOSVRJT04sXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhIHZhcmlhYmxlIGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIFNDSEVNQToge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLlNDSEVNQSxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGEgc2NoZW1hIGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIFNDQUxBUjoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLlNDQUxBUixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGEgc2NhbGFyIGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIE9CSkVDVDoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLk9CSkVDVCxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGFuIG9iamVjdCB0eXBlIGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIEZJRUxEX0RFRklOSVRJT046IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5GSUVMRF9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYSBmaWVsZCBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBBUkdVTUVOVF9ERUZJTklUSU9OOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uQVJHVU1FTlRfREVGSU5JVElPTixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGFuIGFyZ3VtZW50IGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIElOVEVSRkFDRToge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLklOVEVSRkFDRSxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGFuIGludGVyZmFjZSBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBVTklPTjoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLlVOSU9OLFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYSB1bmlvbiBkZWZpbml0aW9uLlwiXG4gICAgfSxcbiAgICBFTlVNOiB7XG4gICAgICB2YWx1ZTogRGlyZWN0aXZlTG9jYXRpb24uRU5VTSxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGFuIGVudW0gZGVmaW5pdGlvbi5cIlxuICAgIH0sXG4gICAgRU5VTV9WQUxVRToge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLkVOVU1fVkFMVUUsXG4gICAgICBkZXNjcmlwdGlvbjogXCJMb2NhdGlvbiBhZGphY2VudCB0byBhbiBlbnVtIHZhbHVlIGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIElOUFVUX09CSkVDVDoge1xuICAgICAgdmFsdWU6IERpcmVjdGl2ZUxvY2F0aW9uLklOUFVUX09CSkVDVCxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkxvY2F0aW9uIGFkamFjZW50IHRvIGFuIGlucHV0IG9iamVjdCB0eXBlIGRlZmluaXRpb24uXCJcbiAgICB9LFxuICAgIElOUFVUX0ZJRUxEX0RFRklOSVRJT046IHtcbiAgICAgIHZhbHVlOiBEaXJlY3RpdmVMb2NhdGlvbi5JTlBVVF9GSUVMRF9ERUZJTklUSU9OLFxuICAgICAgZGVzY3JpcHRpb246IFwiTG9jYXRpb24gYWRqYWNlbnQgdG8gYW4gaW5wdXQgb2JqZWN0IGZpZWxkIGRlZmluaXRpb24uXCJcbiAgICB9XG4gIH1cbn0pO1xudmFyIF9fVHlwZSA9IG5ldyBHcmFwaFFMT2JqZWN0VHlwZSh7XG4gIG5hbWU6IFwiX19UeXBlXCIsXG4gIGRlc2NyaXB0aW9uOiBcIlRoZSBmdW5kYW1lbnRhbCB1bml0IG9mIGFueSBHcmFwaFFMIFNjaGVtYSBpcyB0aGUgdHlwZS4gVGhlcmUgYXJlIG1hbnkga2luZHMgb2YgdHlwZXMgaW4gR3JhcGhRTCBhcyByZXByZXNlbnRlZCBieSB0aGUgYF9fVHlwZUtpbmRgIGVudW0uXFxuXFxuRGVwZW5kaW5nIG9uIHRoZSBraW5kIG9mIGEgdHlwZSwgY2VydGFpbiBmaWVsZHMgZGVzY3JpYmUgaW5mb3JtYXRpb24gYWJvdXQgdGhhdCB0eXBlLiBTY2FsYXIgdHlwZXMgcHJvdmlkZSBubyBpbmZvcm1hdGlvbiBiZXlvbmQgYSBuYW1lLCBkZXNjcmlwdGlvbiBhbmQgb3B0aW9uYWwgYHNwZWNpZmllZEJ5VVJMYCwgd2hpbGUgRW51bSB0eXBlcyBwcm92aWRlIHRoZWlyIHZhbHVlcy4gT2JqZWN0IGFuZCBJbnRlcmZhY2UgdHlwZXMgcHJvdmlkZSB0aGUgZmllbGRzIHRoZXkgZGVzY3JpYmUuIEFic3RyYWN0IHR5cGVzLCBVbmlvbiBhbmQgSW50ZXJmYWNlLCBwcm92aWRlIHRoZSBPYmplY3QgdHlwZXMgcG9zc2libGUgYXQgcnVudGltZS4gTGlzdCBhbmQgTm9uTnVsbCB0eXBlcyBjb21wb3NlIG90aGVyIHR5cGVzLlwiLFxuICBmaWVsZHM6ICgpID0+ICh7XG4gICAga2luZDoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKF9fVHlwZUtpbmQpLFxuICAgICAgcmVzb2x2ZSh0eXBlKSB7XG4gICAgICAgIGlmIChpc1NjYWxhclR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuU0NBTEFSO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc09iamVjdFR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuT0JKRUNUO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0ludGVyZmFjZVR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuSU5URVJGQUNFO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc1VuaW9uVHlwZSh0eXBlKSkge1xuICAgICAgICAgIHJldHVybiBUeXBlS2luZC5VTklPTjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNFbnVtVHlwZSh0eXBlKSkge1xuICAgICAgICAgIHJldHVybiBUeXBlS2luZC5FTlVNO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSkge1xuICAgICAgICAgIHJldHVybiBUeXBlS2luZC5JTlBVVF9PQkpFQ1Q7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzTGlzdFR5cGUodHlwZSkpIHtcbiAgICAgICAgICByZXR1cm4gVHlwZUtpbmQuTElTVDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNOb25OdWxsVHlwZSh0eXBlKSkge1xuICAgICAgICAgIHJldHVybiBUeXBlS2luZC5OT05fTlVMTDtcbiAgICAgICAgfVxuICAgICAgICBpbnZhcmlhbnQyKGZhbHNlLCBgVW5leHBlY3RlZCB0eXBlOiBcIiR7aW5zcGVjdCh0eXBlKX1cIi5gKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG5hbWU6IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICByZXNvbHZlOiAodHlwZSkgPT4gXCJuYW1lXCIgaW4gdHlwZSA/IHR5cGUubmFtZSA6IHZvaWQgMFxuICAgIH0sXG4gICAgZGVzY3JpcHRpb246IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICByZXNvbHZlOiAodHlwZSkgPT4gKFxuICAgICAgICAvKiBjOCBpZ25vcmUgbmV4dCAqL1xuICAgICAgICBcImRlc2NyaXB0aW9uXCIgaW4gdHlwZSA/IHR5cGUuZGVzY3JpcHRpb24gOiB2b2lkIDBcbiAgICAgIClcbiAgICB9LFxuICAgIHNwZWNpZmllZEJ5VVJMOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKG9iaikgPT4gXCJzcGVjaWZpZWRCeVVSTFwiIGluIG9iaiA/IG9iai5zcGVjaWZpZWRCeVVSTCA6IHZvaWQgMFxuICAgIH0sXG4gICAgZmllbGRzOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fRmllbGQpKSxcbiAgICAgIGFyZ3M6IHtcbiAgICAgICAgaW5jbHVkZURlcHJlY2F0ZWQ6IHtcbiAgICAgICAgICB0eXBlOiBHcmFwaFFMQm9vbGVhbixcbiAgICAgICAgICBkZWZhdWx0VmFsdWU6IGZhbHNlXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICByZXNvbHZlKHR5cGUsIHsgaW5jbHVkZURlcHJlY2F0ZWQgfSkge1xuICAgICAgICBpZiAoaXNPYmplY3RUeXBlKHR5cGUpIHx8IGlzSW50ZXJmYWNlVHlwZSh0eXBlKSkge1xuICAgICAgICAgIGNvbnN0IGZpZWxkcyA9IE9iamVjdC52YWx1ZXModHlwZS5nZXRGaWVsZHMoKSk7XG4gICAgICAgICAgcmV0dXJuIGluY2x1ZGVEZXByZWNhdGVkID8gZmllbGRzIDogZmllbGRzLmZpbHRlcigoZmllbGQpID0+IGZpZWxkLmRlcHJlY2F0aW9uUmVhc29uID09IG51bGwpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBpbnRlcmZhY2VzOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fVHlwZSkpLFxuICAgICAgcmVzb2x2ZSh0eXBlKSB7XG4gICAgICAgIGlmIChpc09iamVjdFR5cGUodHlwZSkgfHwgaXNJbnRlcmZhY2VUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgcmV0dXJuIHR5cGUuZ2V0SW50ZXJmYWNlcygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBwb3NzaWJsZVR5cGVzOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fVHlwZSkpLFxuICAgICAgcmVzb2x2ZSh0eXBlLCBfYXJncywgX2NvbnRleHQsIHsgc2NoZW1hIH0pIHtcbiAgICAgICAgaWYgKGlzQWJzdHJhY3RUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgcmV0dXJuIHNjaGVtYS5nZXRQb3NzaWJsZVR5cGVzKHR5cGUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBlbnVtVmFsdWVzOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fRW51bVZhbHVlKSksXG4gICAgICBhcmdzOiB7XG4gICAgICAgIGluY2x1ZGVEZXByZWNhdGVkOiB7XG4gICAgICAgICAgdHlwZTogR3JhcGhRTEJvb2xlYW4sXG4gICAgICAgICAgZGVmYXVsdFZhbHVlOiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcmVzb2x2ZSh0eXBlLCB7IGluY2x1ZGVEZXByZWNhdGVkIH0pIHtcbiAgICAgICAgaWYgKGlzRW51bVR5cGUodHlwZSkpIHtcbiAgICAgICAgICBjb25zdCB2YWx1ZXMgPSB0eXBlLmdldFZhbHVlcygpO1xuICAgICAgICAgIHJldHVybiBpbmNsdWRlRGVwcmVjYXRlZCA/IHZhbHVlcyA6IHZhbHVlcy5maWx0ZXIoKGZpZWxkKSA9PiBmaWVsZC5kZXByZWNhdGlvblJlYXNvbiA9PSBudWxsKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgaW5wdXRGaWVsZHM6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTGlzdChuZXcgR3JhcGhRTE5vbk51bGwoX19JbnB1dFZhbHVlKSksXG4gICAgICBhcmdzOiB7XG4gICAgICAgIGluY2x1ZGVEZXByZWNhdGVkOiB7XG4gICAgICAgICAgdHlwZTogR3JhcGhRTEJvb2xlYW4sXG4gICAgICAgICAgZGVmYXVsdFZhbHVlOiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgcmVzb2x2ZSh0eXBlLCB7IGluY2x1ZGVEZXByZWNhdGVkIH0pIHtcbiAgICAgICAgaWYgKGlzSW5wdXRPYmplY3RUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgY29uc3QgdmFsdWVzID0gT2JqZWN0LnZhbHVlcyh0eXBlLmdldEZpZWxkcygpKTtcbiAgICAgICAgICByZXR1cm4gaW5jbHVkZURlcHJlY2F0ZWQgPyB2YWx1ZXMgOiB2YWx1ZXMuZmlsdGVyKChmaWVsZCkgPT4gZmllbGQuZGVwcmVjYXRpb25SZWFzb24gPT0gbnVsbCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIG9mVHlwZToge1xuICAgICAgdHlwZTogX19UeXBlLFxuICAgICAgcmVzb2x2ZTogKHR5cGUpID0+IFwib2ZUeXBlXCIgaW4gdHlwZSA/IHR5cGUub2ZUeXBlIDogdm9pZCAwXG4gICAgfVxuICB9KVxufSk7XG52YXIgX19GaWVsZCA9IG5ldyBHcmFwaFFMT2JqZWN0VHlwZSh7XG4gIG5hbWU6IFwiX19GaWVsZFwiLFxuICBkZXNjcmlwdGlvbjogXCJPYmplY3QgYW5kIEludGVyZmFjZSB0eXBlcyBhcmUgZGVzY3JpYmVkIGJ5IGEgbGlzdCBvZiBGaWVsZHMsIGVhY2ggb2Ygd2hpY2ggaGFzIGEgbmFtZSwgcG90ZW50aWFsbHkgYSBsaXN0IG9mIGFyZ3VtZW50cywgYW5kIGEgcmV0dXJuIHR5cGUuXCIsXG4gIGZpZWxkczogKCkgPT4gKHtcbiAgICBuYW1lOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoR3JhcGhRTFN0cmluZyksXG4gICAgICByZXNvbHZlOiAoZmllbGQpID0+IGZpZWxkLm5hbWVcbiAgICB9LFxuICAgIGRlc2NyaXB0aW9uOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKGZpZWxkKSA9PiBmaWVsZC5kZXNjcmlwdGlvblxuICAgIH0sXG4gICAgYXJnczoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKFxuICAgICAgICBuZXcgR3JhcGhRTExpc3QobmV3IEdyYXBoUUxOb25OdWxsKF9fSW5wdXRWYWx1ZSkpXG4gICAgICApLFxuICAgICAgYXJnczoge1xuICAgICAgICBpbmNsdWRlRGVwcmVjYXRlZDoge1xuICAgICAgICAgIHR5cGU6IEdyYXBoUUxCb29sZWFuLFxuICAgICAgICAgIGRlZmF1bHRWYWx1ZTogZmFsc2VcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHJlc29sdmUoZmllbGQsIHsgaW5jbHVkZURlcHJlY2F0ZWQgfSkge1xuICAgICAgICByZXR1cm4gaW5jbHVkZURlcHJlY2F0ZWQgPyBmaWVsZC5hcmdzIDogZmllbGQuYXJncy5maWx0ZXIoKGFyZykgPT4gYXJnLmRlcHJlY2F0aW9uUmVhc29uID09IG51bGwpO1xuICAgICAgfVxuICAgIH0sXG4gICAgdHlwZToge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKF9fVHlwZSksXG4gICAgICByZXNvbHZlOiAoZmllbGQpID0+IGZpZWxkLnR5cGVcbiAgICB9LFxuICAgIGlzRGVwcmVjYXRlZDoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxCb29sZWFuKSxcbiAgICAgIHJlc29sdmU6IChmaWVsZCkgPT4gZmllbGQuZGVwcmVjYXRpb25SZWFzb24gIT0gbnVsbFxuICAgIH0sXG4gICAgZGVwcmVjYXRpb25SZWFzb246IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICByZXNvbHZlOiAoZmllbGQpID0+IGZpZWxkLmRlcHJlY2F0aW9uUmVhc29uXG4gICAgfVxuICB9KVxufSk7XG52YXIgX19JbnB1dFZhbHVlID0gbmV3IEdyYXBoUUxPYmplY3RUeXBlKHtcbiAgbmFtZTogXCJfX0lucHV0VmFsdWVcIixcbiAgZGVzY3JpcHRpb246IFwiQXJndW1lbnRzIHByb3ZpZGVkIHRvIEZpZWxkcyBvciBEaXJlY3RpdmVzIGFuZCB0aGUgaW5wdXQgZmllbGRzIG9mIGFuIElucHV0T2JqZWN0IGFyZSByZXByZXNlbnRlZCBhcyBJbnB1dCBWYWx1ZXMgd2hpY2ggZGVzY3JpYmUgdGhlaXIgdHlwZSBhbmQgb3B0aW9uYWxseSBhIGRlZmF1bHQgdmFsdWUuXCIsXG4gIGZpZWxkczogKCkgPT4gKHtcbiAgICBuYW1lOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoR3JhcGhRTFN0cmluZyksXG4gICAgICByZXNvbHZlOiAoaW5wdXRWYWx1ZSkgPT4gaW5wdXRWYWx1ZS5uYW1lXG4gICAgfSxcbiAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIHJlc29sdmU6IChpbnB1dFZhbHVlKSA9PiBpbnB1dFZhbHVlLmRlc2NyaXB0aW9uXG4gICAgfSxcbiAgICB0eXBlOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoX19UeXBlKSxcbiAgICAgIHJlc29sdmU6IChpbnB1dFZhbHVlKSA9PiBpbnB1dFZhbHVlLnR5cGVcbiAgICB9LFxuICAgIGRlZmF1bHRWYWx1ZToge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkEgR3JhcGhRTC1mb3JtYXR0ZWQgc3RyaW5nIHJlcHJlc2VudGluZyB0aGUgZGVmYXVsdCB2YWx1ZSBmb3IgdGhpcyBpbnB1dCB2YWx1ZS5cIixcbiAgICAgIHJlc29sdmUoaW5wdXRWYWx1ZSkge1xuICAgICAgICBjb25zdCB7IHR5cGUsIGRlZmF1bHRWYWx1ZSB9ID0gaW5wdXRWYWx1ZTtcbiAgICAgICAgY29uc3QgdmFsdWVBU1QgPSBhc3RGcm9tVmFsdWUoZGVmYXVsdFZhbHVlLCB0eXBlKTtcbiAgICAgICAgcmV0dXJuIHZhbHVlQVNUID8gcHJpbnQodmFsdWVBU1QpIDogbnVsbDtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlzRGVwcmVjYXRlZDoge1xuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxCb29sZWFuKSxcbiAgICAgIHJlc29sdmU6IChmaWVsZCkgPT4gZmllbGQuZGVwcmVjYXRpb25SZWFzb24gIT0gbnVsbFxuICAgIH0sXG4gICAgZGVwcmVjYXRpb25SZWFzb246IHtcbiAgICAgIHR5cGU6IEdyYXBoUUxTdHJpbmcsXG4gICAgICByZXNvbHZlOiAob2JqKSA9PiBvYmouZGVwcmVjYXRpb25SZWFzb25cbiAgICB9XG4gIH0pXG59KTtcbnZhciBfX0VudW1WYWx1ZSA9IG5ldyBHcmFwaFFMT2JqZWN0VHlwZSh7XG4gIG5hbWU6IFwiX19FbnVtVmFsdWVcIixcbiAgZGVzY3JpcHRpb246IFwiT25lIHBvc3NpYmxlIHZhbHVlIGZvciBhIGdpdmVuIEVudW0uIEVudW0gdmFsdWVzIGFyZSB1bmlxdWUgdmFsdWVzLCBub3QgYSBwbGFjZWhvbGRlciBmb3IgYSBzdHJpbmcgb3IgbnVtZXJpYyB2YWx1ZS4gSG93ZXZlciBhbiBFbnVtIHZhbHVlIGlzIHJldHVybmVkIGluIGEgSlNPTiByZXNwb25zZSBhcyBhIHN0cmluZy5cIixcbiAgZmllbGRzOiAoKSA9PiAoe1xuICAgIG5hbWU6IHtcbiAgICAgIHR5cGU6IG5ldyBHcmFwaFFMTm9uTnVsbChHcmFwaFFMU3RyaW5nKSxcbiAgICAgIHJlc29sdmU6IChlbnVtVmFsdWUpID0+IGVudW1WYWx1ZS5uYW1lXG4gICAgfSxcbiAgICBkZXNjcmlwdGlvbjoge1xuICAgICAgdHlwZTogR3JhcGhRTFN0cmluZyxcbiAgICAgIHJlc29sdmU6IChlbnVtVmFsdWUpID0+IGVudW1WYWx1ZS5kZXNjcmlwdGlvblxuICAgIH0sXG4gICAgaXNEZXByZWNhdGVkOiB7XG4gICAgICB0eXBlOiBuZXcgR3JhcGhRTE5vbk51bGwoR3JhcGhRTEJvb2xlYW4pLFxuICAgICAgcmVzb2x2ZTogKGVudW1WYWx1ZSkgPT4gZW51bVZhbHVlLmRlcHJlY2F0aW9uUmVhc29uICE9IG51bGxcbiAgICB9LFxuICAgIGRlcHJlY2F0aW9uUmVhc29uOiB7XG4gICAgICB0eXBlOiBHcmFwaFFMU3RyaW5nLFxuICAgICAgcmVzb2x2ZTogKGVudW1WYWx1ZSkgPT4gZW51bVZhbHVlLmRlcHJlY2F0aW9uUmVhc29uXG4gICAgfVxuICB9KVxufSk7XG52YXIgVHlwZUtpbmQ7XG4oZnVuY3Rpb24oVHlwZUtpbmQyKSB7XG4gIFR5cGVLaW5kMltcIlNDQUxBUlwiXSA9IFwiU0NBTEFSXCI7XG4gIFR5cGVLaW5kMltcIk9CSkVDVFwiXSA9IFwiT0JKRUNUXCI7XG4gIFR5cGVLaW5kMltcIklOVEVSRkFDRVwiXSA9IFwiSU5URVJGQUNFXCI7XG4gIFR5cGVLaW5kMltcIlVOSU9OXCJdID0gXCJVTklPTlwiO1xuICBUeXBlS2luZDJbXCJFTlVNXCJdID0gXCJFTlVNXCI7XG4gIFR5cGVLaW5kMltcIklOUFVUX09CSkVDVFwiXSA9IFwiSU5QVVRfT0JKRUNUXCI7XG4gIFR5cGVLaW5kMltcIkxJU1RcIl0gPSBcIkxJU1RcIjtcbiAgVHlwZUtpbmQyW1wiTk9OX05VTExcIl0gPSBcIk5PTl9OVUxMXCI7XG59KShUeXBlS2luZCB8fCAoVHlwZUtpbmQgPSB7fSkpO1xudmFyIF9fVHlwZUtpbmQgPSBuZXcgR3JhcGhRTEVudW1UeXBlKHtcbiAgbmFtZTogXCJfX1R5cGVLaW5kXCIsXG4gIGRlc2NyaXB0aW9uOiBcIkFuIGVudW0gZGVzY3JpYmluZyB3aGF0IGtpbmQgb2YgdHlwZSBhIGdpdmVuIGBfX1R5cGVgIGlzLlwiLFxuICB2YWx1ZXM6IHtcbiAgICBTQ0FMQVI6IHtcbiAgICAgIHZhbHVlOiBUeXBlS2luZC5TQ0FMQVIsXG4gICAgICBkZXNjcmlwdGlvbjogXCJJbmRpY2F0ZXMgdGhpcyB0eXBlIGlzIGEgc2NhbGFyLlwiXG4gICAgfSxcbiAgICBPQkpFQ1Q6IHtcbiAgICAgIHZhbHVlOiBUeXBlS2luZC5PQkpFQ1QsXG4gICAgICBkZXNjcmlwdGlvbjogXCJJbmRpY2F0ZXMgdGhpcyB0eXBlIGlzIGFuIG9iamVjdC4gYGZpZWxkc2AgYW5kIGBpbnRlcmZhY2VzYCBhcmUgdmFsaWQgZmllbGRzLlwiXG4gICAgfSxcbiAgICBJTlRFUkZBQ0U6IHtcbiAgICAgIHZhbHVlOiBUeXBlS2luZC5JTlRFUkZBQ0UsXG4gICAgICBkZXNjcmlwdGlvbjogXCJJbmRpY2F0ZXMgdGhpcyB0eXBlIGlzIGFuIGludGVyZmFjZS4gYGZpZWxkc2AsIGBpbnRlcmZhY2VzYCwgYW5kIGBwb3NzaWJsZVR5cGVzYCBhcmUgdmFsaWQgZmllbGRzLlwiXG4gICAgfSxcbiAgICBVTklPTjoge1xuICAgICAgdmFsdWU6IFR5cGVLaW5kLlVOSU9OLFxuICAgICAgZGVzY3JpcHRpb246IFwiSW5kaWNhdGVzIHRoaXMgdHlwZSBpcyBhIHVuaW9uLiBgcG9zc2libGVUeXBlc2AgaXMgYSB2YWxpZCBmaWVsZC5cIlxuICAgIH0sXG4gICAgRU5VTToge1xuICAgICAgdmFsdWU6IFR5cGVLaW5kLkVOVU0sXG4gICAgICBkZXNjcmlwdGlvbjogXCJJbmRpY2F0ZXMgdGhpcyB0eXBlIGlzIGFuIGVudW0uIGBlbnVtVmFsdWVzYCBpcyBhIHZhbGlkIGZpZWxkLlwiXG4gICAgfSxcbiAgICBJTlBVVF9PQkpFQ1Q6IHtcbiAgICAgIHZhbHVlOiBUeXBlS2luZC5JTlBVVF9PQkpFQ1QsXG4gICAgICBkZXNjcmlwdGlvbjogXCJJbmRpY2F0ZXMgdGhpcyB0eXBlIGlzIGFuIGlucHV0IG9iamVjdC4gYGlucHV0RmllbGRzYCBpcyBhIHZhbGlkIGZpZWxkLlwiXG4gICAgfSxcbiAgICBMSVNUOiB7XG4gICAgICB2YWx1ZTogVHlwZUtpbmQuTElTVCxcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkluZGljYXRlcyB0aGlzIHR5cGUgaXMgYSBsaXN0LiBgb2ZUeXBlYCBpcyBhIHZhbGlkIGZpZWxkLlwiXG4gICAgfSxcbiAgICBOT05fTlVMTDoge1xuICAgICAgdmFsdWU6IFR5cGVLaW5kLk5PTl9OVUxMLFxuICAgICAgZGVzY3JpcHRpb246IFwiSW5kaWNhdGVzIHRoaXMgdHlwZSBpcyBhIG5vbi1udWxsLiBgb2ZUeXBlYCBpcyBhIHZhbGlkIGZpZWxkLlwiXG4gICAgfVxuICB9XG59KTtcbnZhciBTY2hlbWFNZXRhRmllbGREZWYgPSB7XG4gIG5hbWU6IFwiX19zY2hlbWFcIixcbiAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKF9fU2NoZW1hKSxcbiAgZGVzY3JpcHRpb246IFwiQWNjZXNzIHRoZSBjdXJyZW50IHR5cGUgc2NoZW1hIG9mIHRoaXMgc2VydmVyLlwiLFxuICBhcmdzOiBbXSxcbiAgcmVzb2x2ZTogKF9zb3VyY2UsIF9hcmdzLCBfY29udGV4dCwgeyBzY2hlbWEgfSkgPT4gc2NoZW1hLFxuICBkZXByZWNhdGlvblJlYXNvbjogdm9pZCAwLFxuICBleHRlbnNpb25zOiAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKSxcbiAgYXN0Tm9kZTogdm9pZCAwXG59O1xudmFyIFR5cGVNZXRhRmllbGREZWYgPSB7XG4gIG5hbWU6IFwiX190eXBlXCIsXG4gIHR5cGU6IF9fVHlwZSxcbiAgZGVzY3JpcHRpb246IFwiUmVxdWVzdCB0aGUgdHlwZSBpbmZvcm1hdGlvbiBvZiBhIHNpbmdsZSB0eXBlLlwiLFxuICBhcmdzOiBbXG4gICAge1xuICAgICAgbmFtZTogXCJuYW1lXCIsXG4gICAgICBkZXNjcmlwdGlvbjogdm9pZCAwLFxuICAgICAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxTdHJpbmcpLFxuICAgICAgZGVmYXVsdFZhbHVlOiB2b2lkIDAsXG4gICAgICBkZXByZWNhdGlvblJlYXNvbjogdm9pZCAwLFxuICAgICAgZXh0ZW5zaW9uczogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCksXG4gICAgICBhc3ROb2RlOiB2b2lkIDBcbiAgICB9XG4gIF0sXG4gIHJlc29sdmU6IChfc291cmNlLCB7IG5hbWUgfSwgX2NvbnRleHQsIHsgc2NoZW1hIH0pID0+IHNjaGVtYS5nZXRUeXBlKG5hbWUpLFxuICBkZXByZWNhdGlvblJlYXNvbjogdm9pZCAwLFxuICBleHRlbnNpb25zOiAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKSxcbiAgYXN0Tm9kZTogdm9pZCAwXG59O1xudmFyIFR5cGVOYW1lTWV0YUZpZWxkRGVmID0ge1xuICBuYW1lOiBcIl9fdHlwZW5hbWVcIixcbiAgdHlwZTogbmV3IEdyYXBoUUxOb25OdWxsKEdyYXBoUUxTdHJpbmcpLFxuICBkZXNjcmlwdGlvbjogXCJUaGUgbmFtZSBvZiB0aGUgY3VycmVudCBPYmplY3QgdHlwZSBhdCBydW50aW1lLlwiLFxuICBhcmdzOiBbXSxcbiAgcmVzb2x2ZTogKF9zb3VyY2UsIF9hcmdzLCBfY29udGV4dCwgeyBwYXJlbnRUeXBlIH0pID0+IHBhcmVudFR5cGUubmFtZSxcbiAgZGVwcmVjYXRpb25SZWFzb246IHZvaWQgMCxcbiAgZXh0ZW5zaW9uczogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCksXG4gIGFzdE5vZGU6IHZvaWQgMFxufTtcbnZhciBpbnRyb3NwZWN0aW9uVHlwZXMgPSBPYmplY3QuZnJlZXplKFtcbiAgX19TY2hlbWEsXG4gIF9fRGlyZWN0aXZlLFxuICBfX0RpcmVjdGl2ZUxvY2F0aW9uLFxuICBfX1R5cGUsXG4gIF9fRmllbGQsXG4gIF9fSW5wdXRWYWx1ZSxcbiAgX19FbnVtVmFsdWUsXG4gIF9fVHlwZUtpbmRcbl0pO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdXRpbGl0aWVzL3R5cGVGcm9tQVNULm1qc1xuZnVuY3Rpb24gdHlwZUZyb21BU1Qoc2NoZW1hLCB0eXBlTm9kZSkge1xuICBzd2l0Y2ggKHR5cGVOb2RlLmtpbmQpIHtcbiAgICBjYXNlIEtpbmQuTElTVF9UWVBFOiB7XG4gICAgICBjb25zdCBpbm5lclR5cGUgPSB0eXBlRnJvbUFTVChzY2hlbWEsIHR5cGVOb2RlLnR5cGUpO1xuICAgICAgcmV0dXJuIGlubmVyVHlwZSAmJiBuZXcgR3JhcGhRTExpc3QoaW5uZXJUeXBlKTtcbiAgICB9XG4gICAgY2FzZSBLaW5kLk5PTl9OVUxMX1RZUEU6IHtcbiAgICAgIGNvbnN0IGlubmVyVHlwZSA9IHR5cGVGcm9tQVNUKHNjaGVtYSwgdHlwZU5vZGUudHlwZSk7XG4gICAgICByZXR1cm4gaW5uZXJUeXBlICYmIG5ldyBHcmFwaFFMTm9uTnVsbChpbm5lclR5cGUpO1xuICAgIH1cbiAgICBjYXNlIEtpbmQuTkFNRURfVFlQRTpcbiAgICAgIHJldHVybiBzY2hlbWEuZ2V0VHlwZSh0eXBlTm9kZS5uYW1lLnZhbHVlKTtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvbGFuZ3VhZ2UvcHJlZGljYXRlcy5tanNcbmZ1bmN0aW9uIGlzRXhlY3V0YWJsZURlZmluaXRpb25Ob2RlKG5vZGUpIHtcbiAgcmV0dXJuIG5vZGUua2luZCA9PT0gS2luZC5PUEVSQVRJT05fREVGSU5JVElPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuRlJBR01FTlRfREVGSU5JVElPTjtcbn1cbmZ1bmN0aW9uIGlzVHlwZVN5c3RlbURlZmluaXRpb25Ob2RlKG5vZGUpIHtcbiAgcmV0dXJuIG5vZGUua2luZCA9PT0gS2luZC5TQ0hFTUFfREVGSU5JVElPTiB8fCBpc1R5cGVEZWZpbml0aW9uTm9kZShub2RlKSB8fCBub2RlLmtpbmQgPT09IEtpbmQuRElSRUNUSVZFX0RFRklOSVRJT047XG59XG5mdW5jdGlvbiBpc1R5cGVEZWZpbml0aW9uTm9kZShub2RlKSB7XG4gIHJldHVybiBub2RlLmtpbmQgPT09IEtpbmQuU0NBTEFSX1RZUEVfREVGSU5JVElPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuT0JKRUNUX1RZUEVfREVGSU5JVElPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuSU5URVJGQUNFX1RZUEVfREVGSU5JVElPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuVU5JT05fVFlQRV9ERUZJTklUSU9OIHx8IG5vZGUua2luZCA9PT0gS2luZC5FTlVNX1RZUEVfREVGSU5JVElPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuSU5QVVRfT0JKRUNUX1RZUEVfREVGSU5JVElPTjtcbn1cbmZ1bmN0aW9uIGlzVHlwZVN5c3RlbUV4dGVuc2lvbk5vZGUobm9kZSkge1xuICByZXR1cm4gbm9kZS5raW5kID09PSBLaW5kLlNDSEVNQV9FWFRFTlNJT04gfHwgaXNUeXBlRXh0ZW5zaW9uTm9kZShub2RlKTtcbn1cbmZ1bmN0aW9uIGlzVHlwZUV4dGVuc2lvbk5vZGUobm9kZSkge1xuICByZXR1cm4gbm9kZS5raW5kID09PSBLaW5kLlNDQUxBUl9UWVBFX0VYVEVOU0lPTiB8fCBub2RlLmtpbmQgPT09IEtpbmQuT0JKRUNUX1RZUEVfRVhURU5TSU9OIHx8IG5vZGUua2luZCA9PT0gS2luZC5JTlRFUkZBQ0VfVFlQRV9FWFRFTlNJT04gfHwgbm9kZS5raW5kID09PSBLaW5kLlVOSU9OX1RZUEVfRVhURU5TSU9OIHx8IG5vZGUua2luZCA9PT0gS2luZC5FTlVNX1RZUEVfRVhURU5TSU9OIHx8IG5vZGUua2luZCA9PT0gS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9FWFRFTlNJT047XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL0V4ZWN1dGFibGVEZWZpbml0aW9uc1J1bGUubWpzXG5mdW5jdGlvbiBFeGVjdXRhYmxlRGVmaW5pdGlvbnNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBEb2N1bWVudChub2RlKSB7XG4gICAgICBmb3IgKGNvbnN0IGRlZmluaXRpb24gb2Ygbm9kZS5kZWZpbml0aW9ucykge1xuICAgICAgICBpZiAoIWlzRXhlY3V0YWJsZURlZmluaXRpb25Ob2RlKGRlZmluaXRpb24pKSB7XG4gICAgICAgICAgY29uc3QgZGVmTmFtZSA9IGRlZmluaXRpb24ua2luZCA9PT0gS2luZC5TQ0hFTUFfREVGSU5JVElPTiB8fCBkZWZpbml0aW9uLmtpbmQgPT09IEtpbmQuU0NIRU1BX0VYVEVOU0lPTiA/IFwic2NoZW1hXCIgOiAnXCInICsgZGVmaW5pdGlvbi5uYW1lLnZhbHVlICsgJ1wiJztcbiAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihgVGhlICR7ZGVmTmFtZX0gZGVmaW5pdGlvbiBpcyBub3QgZXhlY3V0YWJsZS5gLCB7XG4gICAgICAgICAgICAgIG5vZGVzOiBkZWZpbml0aW9uXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL0ZpZWxkc09uQ29ycmVjdFR5cGVSdWxlLm1qc1xuZnVuY3Rpb24gRmllbGRzT25Db3JyZWN0VHlwZVJ1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIEZpZWxkKG5vZGUpIHtcbiAgICAgIGNvbnN0IHR5cGUgPSBjb250ZXh0LmdldFBhcmVudFR5cGUoKTtcbiAgICAgIGlmICh0eXBlKSB7XG4gICAgICAgIGNvbnN0IGZpZWxkRGVmID0gY29udGV4dC5nZXRGaWVsZERlZigpO1xuICAgICAgICBpZiAoIWZpZWxkRGVmKSB7XG4gICAgICAgICAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgICAgICAgICBjb25zdCBmaWVsZE5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICAgICAgbGV0IHN1Z2dlc3Rpb24gPSBkaWRZb3VNZWFuKFxuICAgICAgICAgICAgXCJ0byB1c2UgYW4gaW5saW5lIGZyYWdtZW50IG9uXCIsXG4gICAgICAgICAgICBnZXRTdWdnZXN0ZWRUeXBlTmFtZXMoc2NoZW1hLCB0eXBlLCBmaWVsZE5hbWUpXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAoc3VnZ2VzdGlvbiA9PT0gXCJcIikge1xuICAgICAgICAgICAgc3VnZ2VzdGlvbiA9IGRpZFlvdU1lYW4oZ2V0U3VnZ2VzdGVkRmllbGROYW1lcyh0eXBlLCBmaWVsZE5hbWUpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgIGBDYW5ub3QgcXVlcnkgZmllbGQgXCIke2ZpZWxkTmFtZX1cIiBvbiB0eXBlIFwiJHt0eXBlLm5hbWV9XCIuYCArIHN1Z2dlc3Rpb24sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBub2Rlczogbm9kZVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldFN1Z2dlc3RlZFR5cGVOYW1lcyhzY2hlbWEsIHR5cGUsIGZpZWxkTmFtZSkge1xuICBpZiAoIWlzQWJzdHJhY3RUeXBlKHR5cGUpKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGNvbnN0IHN1Z2dlc3RlZFR5cGVzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgY29uc3QgdXNhZ2VDb3VudCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBmb3IgKGNvbnN0IHBvc3NpYmxlVHlwZSBvZiBzY2hlbWEuZ2V0UG9zc2libGVUeXBlcyh0eXBlKSkge1xuICAgIGlmICghcG9zc2libGVUeXBlLmdldEZpZWxkcygpW2ZpZWxkTmFtZV0pIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBzdWdnZXN0ZWRUeXBlcy5hZGQocG9zc2libGVUeXBlKTtcbiAgICB1c2FnZUNvdW50W3Bvc3NpYmxlVHlwZS5uYW1lXSA9IDE7XG4gICAgZm9yIChjb25zdCBwb3NzaWJsZUludGVyZmFjZSBvZiBwb3NzaWJsZVR5cGUuZ2V0SW50ZXJmYWNlcygpKSB7XG4gICAgICB2YXIgX3VzYWdlQ291bnQkcG9zc2libGVJO1xuICAgICAgaWYgKCFwb3NzaWJsZUludGVyZmFjZS5nZXRGaWVsZHMoKVtmaWVsZE5hbWVdKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgc3VnZ2VzdGVkVHlwZXMuYWRkKHBvc3NpYmxlSW50ZXJmYWNlKTtcbiAgICAgIHVzYWdlQ291bnRbcG9zc2libGVJbnRlcmZhY2UubmFtZV0gPSAoKF91c2FnZUNvdW50JHBvc3NpYmxlSSA9IHVzYWdlQ291bnRbcG9zc2libGVJbnRlcmZhY2UubmFtZV0pICE9PSBudWxsICYmIF91c2FnZUNvdW50JHBvc3NpYmxlSSAhPT0gdm9pZCAwID8gX3VzYWdlQ291bnQkcG9zc2libGVJIDogMCkgKyAxO1xuICAgIH1cbiAgfVxuICByZXR1cm4gWy4uLnN1Z2dlc3RlZFR5cGVzXS5zb3J0KCh0eXBlQSwgdHlwZUIpID0+IHtcbiAgICBjb25zdCB1c2FnZUNvdW50RGlmZiA9IHVzYWdlQ291bnRbdHlwZUIubmFtZV0gLSB1c2FnZUNvdW50W3R5cGVBLm5hbWVdO1xuICAgIGlmICh1c2FnZUNvdW50RGlmZiAhPT0gMCkge1xuICAgICAgcmV0dXJuIHVzYWdlQ291bnREaWZmO1xuICAgIH1cbiAgICBpZiAoaXNJbnRlcmZhY2VUeXBlKHR5cGVBKSAmJiBzY2hlbWEuaXNTdWJUeXBlKHR5cGVBLCB0eXBlQikpIHtcbiAgICAgIHJldHVybiAtMTtcbiAgICB9XG4gICAgaWYgKGlzSW50ZXJmYWNlVHlwZSh0eXBlQikgJiYgc2NoZW1hLmlzU3ViVHlwZSh0eXBlQiwgdHlwZUEpKSB7XG4gICAgICByZXR1cm4gMTtcbiAgICB9XG4gICAgcmV0dXJuIG5hdHVyYWxDb21wYXJlKHR5cGVBLm5hbWUsIHR5cGVCLm5hbWUpO1xuICB9KS5tYXAoKHgpID0+IHgubmFtZSk7XG59XG5mdW5jdGlvbiBnZXRTdWdnZXN0ZWRGaWVsZE5hbWVzKHR5cGUsIGZpZWxkTmFtZSkge1xuICBpZiAoaXNPYmplY3RUeXBlKHR5cGUpIHx8IGlzSW50ZXJmYWNlVHlwZSh0eXBlKSkge1xuICAgIGNvbnN0IHBvc3NpYmxlRmllbGROYW1lcyA9IE9iamVjdC5rZXlzKHR5cGUuZ2V0RmllbGRzKCkpO1xuICAgIHJldHVybiBzdWdnZXN0aW9uTGlzdChmaWVsZE5hbWUsIHBvc3NpYmxlRmllbGROYW1lcyk7XG4gIH1cbiAgcmV0dXJuIFtdO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9GcmFnbWVudHNPbkNvbXBvc2l0ZVR5cGVzUnVsZS5tanNcbmZ1bmN0aW9uIEZyYWdtZW50c09uQ29tcG9zaXRlVHlwZXNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBJbmxpbmVGcmFnbWVudChub2RlKSB7XG4gICAgICBjb25zdCB0eXBlQ29uZGl0aW9uID0gbm9kZS50eXBlQ29uZGl0aW9uO1xuICAgICAgaWYgKHR5cGVDb25kaXRpb24pIHtcbiAgICAgICAgY29uc3QgdHlwZSA9IHR5cGVGcm9tQVNUKGNvbnRleHQuZ2V0U2NoZW1hKCksIHR5cGVDb25kaXRpb24pO1xuICAgICAgICBpZiAodHlwZSAmJiAhaXNDb21wb3NpdGVUeXBlKHR5cGUpKSB7XG4gICAgICAgICAgY29uc3QgdHlwZVN0ciA9IHByaW50KHR5cGVDb25kaXRpb24pO1xuICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICBgRnJhZ21lbnQgY2Fubm90IGNvbmRpdGlvbiBvbiBub24gY29tcG9zaXRlIHR5cGUgXCIke3R5cGVTdHJ9XCIuYCxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5vZGVzOiB0eXBlQ29uZGl0aW9uXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBGcmFnbWVudERlZmluaXRpb24obm9kZSkge1xuICAgICAgY29uc3QgdHlwZSA9IHR5cGVGcm9tQVNUKGNvbnRleHQuZ2V0U2NoZW1hKCksIG5vZGUudHlwZUNvbmRpdGlvbik7XG4gICAgICBpZiAodHlwZSAmJiAhaXNDb21wb3NpdGVUeXBlKHR5cGUpKSB7XG4gICAgICAgIGNvbnN0IHR5cGVTdHIgPSBwcmludChub2RlLnR5cGVDb25kaXRpb24pO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRnJhZ21lbnQgXCIke25vZGUubmFtZS52YWx1ZX1cIiBjYW5ub3QgY29uZGl0aW9uIG9uIG5vbiBjb21wb3NpdGUgdHlwZSBcIiR7dHlwZVN0cn1cIi5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2Rlczogbm9kZS50eXBlQ29uZGl0aW9uXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvS25vd25Bcmd1bWVudE5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIEtub3duQXJndW1lbnROYW1lc1J1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuZXctY2FwXG4gICAgLi4uS25vd25Bcmd1bWVudE5hbWVzT25EaXJlY3RpdmVzUnVsZShjb250ZXh0KSxcbiAgICBBcmd1bWVudChhcmdOb2RlKSB7XG4gICAgICBjb25zdCBhcmdEZWYgPSBjb250ZXh0LmdldEFyZ3VtZW50KCk7XG4gICAgICBjb25zdCBmaWVsZERlZiA9IGNvbnRleHQuZ2V0RmllbGREZWYoKTtcbiAgICAgIGNvbnN0IHBhcmVudFR5cGUgPSBjb250ZXh0LmdldFBhcmVudFR5cGUoKTtcbiAgICAgIGlmICghYXJnRGVmICYmIGZpZWxkRGVmICYmIHBhcmVudFR5cGUpIHtcbiAgICAgICAgY29uc3QgYXJnTmFtZSA9IGFyZ05vZGUubmFtZS52YWx1ZTtcbiAgICAgICAgY29uc3Qga25vd25BcmdzTmFtZXMgPSBmaWVsZERlZi5hcmdzLm1hcCgoYXJnKSA9PiBhcmcubmFtZSk7XG4gICAgICAgIGNvbnN0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbkxpc3QoYXJnTmFtZSwga25vd25BcmdzTmFtZXMpO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVW5rbm93biBhcmd1bWVudCBcIiR7YXJnTmFtZX1cIiBvbiBmaWVsZCBcIiR7cGFyZW50VHlwZS5uYW1lfS4ke2ZpZWxkRGVmLm5hbWV9XCIuYCArIGRpZFlvdU1lYW4oc3VnZ2VzdGlvbnMpLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogYXJnTm9kZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBLbm93bkFyZ3VtZW50TmFtZXNPbkRpcmVjdGl2ZXNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3QgZGlyZWN0aXZlQXJncyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBkZWZpbmVkRGlyZWN0aXZlcyA9IHNjaGVtYSA/IHNjaGVtYS5nZXREaXJlY3RpdmVzKCkgOiBzcGVjaWZpZWREaXJlY3RpdmVzO1xuICBmb3IgKGNvbnN0IGRpcmVjdGl2ZSBvZiBkZWZpbmVkRGlyZWN0aXZlcykge1xuICAgIGRpcmVjdGl2ZUFyZ3NbZGlyZWN0aXZlLm5hbWVdID0gZGlyZWN0aXZlLmFyZ3MubWFwKChhcmcpID0+IGFyZy5uYW1lKTtcbiAgfVxuICBjb25zdCBhc3REZWZpbml0aW9ucyA9IGNvbnRleHQuZ2V0RG9jdW1lbnQoKS5kZWZpbml0aW9ucztcbiAgZm9yIChjb25zdCBkZWYgb2YgYXN0RGVmaW5pdGlvbnMpIHtcbiAgICBpZiAoZGVmLmtpbmQgPT09IEtpbmQuRElSRUNUSVZFX0RFRklOSVRJT04pIHtcbiAgICAgIHZhciBfZGVmJGFyZ3VtZW50cztcbiAgICAgIGNvbnN0IGFyZ3NOb2RlcyA9IChfZGVmJGFyZ3VtZW50cyA9IGRlZi5hcmd1bWVudHMpICE9PSBudWxsICYmIF9kZWYkYXJndW1lbnRzICE9PSB2b2lkIDAgPyBfZGVmJGFyZ3VtZW50cyA6IFtdO1xuICAgICAgZGlyZWN0aXZlQXJnc1tkZWYubmFtZS52YWx1ZV0gPSBhcmdzTm9kZXMubWFwKChhcmcpID0+IGFyZy5uYW1lLnZhbHVlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBEaXJlY3RpdmUoZGlyZWN0aXZlTm9kZSkge1xuICAgICAgY29uc3QgZGlyZWN0aXZlTmFtZSA9IGRpcmVjdGl2ZU5vZGUubmFtZS52YWx1ZTtcbiAgICAgIGNvbnN0IGtub3duQXJncyA9IGRpcmVjdGl2ZUFyZ3NbZGlyZWN0aXZlTmFtZV07XG4gICAgICBpZiAoZGlyZWN0aXZlTm9kZS5hcmd1bWVudHMgJiYga25vd25BcmdzKSB7XG4gICAgICAgIGZvciAoY29uc3QgYXJnTm9kZSBvZiBkaXJlY3RpdmVOb2RlLmFyZ3VtZW50cykge1xuICAgICAgICAgIGNvbnN0IGFyZ05hbWUgPSBhcmdOb2RlLm5hbWUudmFsdWU7XG4gICAgICAgICAgaWYgKCFrbm93bkFyZ3MuaW5jbHVkZXMoYXJnTmFtZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHN1Z2dlc3Rpb25zID0gc3VnZ2VzdGlvbkxpc3QoYXJnTmFtZSwga25vd25BcmdzKTtcbiAgICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgICAgYFVua25vd24gYXJndW1lbnQgXCIke2FyZ05hbWV9XCIgb24gZGlyZWN0aXZlIFwiQCR7ZGlyZWN0aXZlTmFtZX1cIi5gICsgZGlkWW91TWVhbihzdWdnZXN0aW9ucyksXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbm9kZXM6IGFyZ05vZGVcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Lbm93bkRpcmVjdGl2ZXNSdWxlLm1qc1xuZnVuY3Rpb24gS25vd25EaXJlY3RpdmVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IGxvY2F0aW9uc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBkZWZpbmVkRGlyZWN0aXZlcyA9IHNjaGVtYSA/IHNjaGVtYS5nZXREaXJlY3RpdmVzKCkgOiBzcGVjaWZpZWREaXJlY3RpdmVzO1xuICBmb3IgKGNvbnN0IGRpcmVjdGl2ZSBvZiBkZWZpbmVkRGlyZWN0aXZlcykge1xuICAgIGxvY2F0aW9uc01hcFtkaXJlY3RpdmUubmFtZV0gPSBkaXJlY3RpdmUubG9jYXRpb25zO1xuICB9XG4gIGNvbnN0IGFzdERlZmluaXRpb25zID0gY29udGV4dC5nZXREb2N1bWVudCgpLmRlZmluaXRpb25zO1xuICBmb3IgKGNvbnN0IGRlZiBvZiBhc3REZWZpbml0aW9ucykge1xuICAgIGlmIChkZWYua2luZCA9PT0gS2luZC5ESVJFQ1RJVkVfREVGSU5JVElPTikge1xuICAgICAgbG9jYXRpb25zTWFwW2RlZi5uYW1lLnZhbHVlXSA9IGRlZi5sb2NhdGlvbnMubWFwKChuYW1lKSA9PiBuYW1lLnZhbHVlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBEaXJlY3RpdmUobm9kZSwgX2tleSwgX3BhcmVudCwgX3BhdGgsIGFuY2VzdG9ycykge1xuICAgICAgY29uc3QgbmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgIGNvbnN0IGxvY2F0aW9ucyA9IGxvY2F0aW9uc01hcFtuYW1lXTtcbiAgICAgIGlmICghbG9jYXRpb25zKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihgVW5rbm93biBkaXJlY3RpdmUgXCJAJHtuYW1lfVwiLmAsIHtcbiAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgY2FuZGlkYXRlTG9jYXRpb24gPSBnZXREaXJlY3RpdmVMb2NhdGlvbkZvckFTVFBhdGgoYW5jZXN0b3JzKTtcbiAgICAgIGlmIChjYW5kaWRhdGVMb2NhdGlvbiAmJiAhbG9jYXRpb25zLmluY2x1ZGVzKGNhbmRpZGF0ZUxvY2F0aW9uKSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRGlyZWN0aXZlIFwiQCR7bmFtZX1cIiBtYXkgbm90IGJlIHVzZWQgb24gJHtjYW5kaWRhdGVMb2NhdGlvbn0uYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0RGlyZWN0aXZlTG9jYXRpb25Gb3JBU1RQYXRoKGFuY2VzdG9ycykge1xuICBjb25zdCBhcHBsaWVkVG8gPSBhbmNlc3RvcnNbYW5jZXN0b3JzLmxlbmd0aCAtIDFdO1xuICBcImtpbmRcIiBpbiBhcHBsaWVkVG8gfHwgaW52YXJpYW50MihmYWxzZSk7XG4gIHN3aXRjaCAoYXBwbGllZFRvLmtpbmQpIHtcbiAgICBjYXNlIEtpbmQuT1BFUkFUSU9OX0RFRklOSVRJT046XG4gICAgICByZXR1cm4gZ2V0RGlyZWN0aXZlTG9jYXRpb25Gb3JPcGVyYXRpb24oYXBwbGllZFRvLm9wZXJhdGlvbik7XG4gICAgY2FzZSBLaW5kLkZJRUxEOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLkZJRUxEO1xuICAgIGNhc2UgS2luZC5GUkFHTUVOVF9TUFJFQUQ6XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uRlJBR01FTlRfU1BSRUFEO1xuICAgIGNhc2UgS2luZC5JTkxJTkVfRlJBR01FTlQ6XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uSU5MSU5FX0ZSQUdNRU5UO1xuICAgIGNhc2UgS2luZC5GUkFHTUVOVF9ERUZJTklUSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLkZSQUdNRU5UX0RFRklOSVRJT047XG4gICAgY2FzZSBLaW5kLlZBUklBQkxFX0RFRklOSVRJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uVkFSSUFCTEVfREVGSU5JVElPTjtcbiAgICBjYXNlIEtpbmQuU0NIRU1BX0RFRklOSVRJT046XG4gICAgY2FzZSBLaW5kLlNDSEVNQV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uU0NIRU1BO1xuICAgIGNhc2UgS2luZC5TQ0FMQVJfVFlQRV9ERUZJTklUSU9OOlxuICAgIGNhc2UgS2luZC5TQ0FMQVJfVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uU0NBTEFSO1xuICAgIGNhc2UgS2luZC5PQkpFQ1RfVFlQRV9ERUZJTklUSU9OOlxuICAgIGNhc2UgS2luZC5PQkpFQ1RfVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uT0JKRUNUO1xuICAgIGNhc2UgS2luZC5GSUVMRF9ERUZJTklUSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLkZJRUxEX0RFRklOSVRJT047XG4gICAgY2FzZSBLaW5kLklOVEVSRkFDRV9UWVBFX0RFRklOSVRJT046XG4gICAgY2FzZSBLaW5kLklOVEVSRkFDRV9UWVBFX0VYVEVOU0lPTjpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5JTlRFUkZBQ0U7XG4gICAgY2FzZSBLaW5kLlVOSU9OX1RZUEVfREVGSU5JVElPTjpcbiAgICBjYXNlIEtpbmQuVU5JT05fVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uVU5JT047XG4gICAgY2FzZSBLaW5kLkVOVU1fVFlQRV9ERUZJTklUSU9OOlxuICAgIGNhc2UgS2luZC5FTlVNX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLkVOVU07XG4gICAgY2FzZSBLaW5kLkVOVU1fVkFMVUVfREVGSU5JVElPTjpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5FTlVNX1ZBTFVFO1xuICAgIGNhc2UgS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9ERUZJTklUSU9OOlxuICAgIGNhc2UgS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gRGlyZWN0aXZlTG9jYXRpb24uSU5QVVRfT0JKRUNUO1xuICAgIGNhc2UgS2luZC5JTlBVVF9WQUxVRV9ERUZJTklUSU9OOiB7XG4gICAgICBjb25zdCBwYXJlbnROb2RlID0gYW5jZXN0b3JzW2FuY2VzdG9ycy5sZW5ndGggLSAzXTtcbiAgICAgIFwia2luZFwiIGluIHBhcmVudE5vZGUgfHwgaW52YXJpYW50MihmYWxzZSk7XG4gICAgICByZXR1cm4gcGFyZW50Tm9kZS5raW5kID09PSBLaW5kLklOUFVUX09CSkVDVF9UWVBFX0RFRklOSVRJT04gPyBEaXJlY3RpdmVMb2NhdGlvbi5JTlBVVF9GSUVMRF9ERUZJTklUSU9OIDogRGlyZWN0aXZlTG9jYXRpb24uQVJHVU1FTlRfREVGSU5JVElPTjtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIGludmFyaWFudDIoZmFsc2UsIFwiVW5leHBlY3RlZCBraW5kOiBcIiArIGluc3BlY3QoYXBwbGllZFRvLmtpbmQpKTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0RGlyZWN0aXZlTG9jYXRpb25Gb3JPcGVyYXRpb24ob3BlcmF0aW9uKSB7XG4gIHN3aXRjaCAob3BlcmF0aW9uKSB7XG4gICAgY2FzZSBPcGVyYXRpb25UeXBlTm9kZS5RVUVSWTpcbiAgICAgIHJldHVybiBEaXJlY3RpdmVMb2NhdGlvbi5RVUVSWTtcbiAgICBjYXNlIE9wZXJhdGlvblR5cGVOb2RlLk1VVEFUSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLk1VVEFUSU9OO1xuICAgIGNhc2UgT3BlcmF0aW9uVHlwZU5vZGUuU1VCU0NSSVBUSU9OOlxuICAgICAgcmV0dXJuIERpcmVjdGl2ZUxvY2F0aW9uLlNVQlNDUklQVElPTjtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Lbm93bkZyYWdtZW50TmFtZXNSdWxlLm1qc1xuZnVuY3Rpb24gS25vd25GcmFnbWVudE5hbWVzUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgRnJhZ21lbnRTcHJlYWQobm9kZSkge1xuICAgICAgY29uc3QgZnJhZ21lbnROYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgY29uc3QgZnJhZ21lbnQgPSBjb250ZXh0LmdldEZyYWdtZW50KGZyYWdtZW50TmFtZSk7XG4gICAgICBpZiAoIWZyYWdtZW50KSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihgVW5rbm93biBmcmFnbWVudCBcIiR7ZnJhZ21lbnROYW1lfVwiLmAsIHtcbiAgICAgICAgICAgIG5vZGVzOiBub2RlLm5hbWVcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvS25vd25UeXBlTmFtZXNSdWxlLm1qc1xuZnVuY3Rpb24gS25vd25UeXBlTmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgY29uc3QgZXhpc3RpbmdUeXBlc01hcCA9IHNjaGVtYSA/IHNjaGVtYS5nZXRUeXBlTWFwKCkgOiAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgZGVmaW5lZFR5cGVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGZvciAoY29uc3QgZGVmIG9mIGNvbnRleHQuZ2V0RG9jdW1lbnQoKS5kZWZpbml0aW9ucykge1xuICAgIGlmIChpc1R5cGVEZWZpbml0aW9uTm9kZShkZWYpKSB7XG4gICAgICBkZWZpbmVkVHlwZXNbZGVmLm5hbWUudmFsdWVdID0gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgY29uc3QgdHlwZU5hbWVzID0gW1xuICAgIC4uLk9iamVjdC5rZXlzKGV4aXN0aW5nVHlwZXNNYXApLFxuICAgIC4uLk9iamVjdC5rZXlzKGRlZmluZWRUeXBlcylcbiAgXTtcbiAgcmV0dXJuIHtcbiAgICBOYW1lZFR5cGUobm9kZSwgXzEsIHBhcmVudCwgXzIsIGFuY2VzdG9ycykge1xuICAgICAgY29uc3QgdHlwZU5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICBpZiAoIWV4aXN0aW5nVHlwZXNNYXBbdHlwZU5hbWVdICYmICFkZWZpbmVkVHlwZXNbdHlwZU5hbWVdKSB7XG4gICAgICAgIHZhciBfYW5jZXN0b3JzJDtcbiAgICAgICAgY29uc3QgZGVmaW5pdGlvbk5vZGUgPSAoX2FuY2VzdG9ycyQgPSBhbmNlc3RvcnNbMl0pICE9PSBudWxsICYmIF9hbmNlc3RvcnMkICE9PSB2b2lkIDAgPyBfYW5jZXN0b3JzJCA6IHBhcmVudDtcbiAgICAgICAgY29uc3QgaXNTREwgPSBkZWZpbml0aW9uTm9kZSAhPSBudWxsICYmIGlzU0RMTm9kZShkZWZpbml0aW9uTm9kZSk7XG4gICAgICAgIGlmIChpc1NETCAmJiBzdGFuZGFyZFR5cGVOYW1lcy5pbmNsdWRlcyh0eXBlTmFtZSkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3VnZ2VzdGVkVHlwZXMgPSBzdWdnZXN0aW9uTGlzdChcbiAgICAgICAgICB0eXBlTmFtZSxcbiAgICAgICAgICBpc1NETCA/IHN0YW5kYXJkVHlwZU5hbWVzLmNvbmNhdCh0eXBlTmFtZXMpIDogdHlwZU5hbWVzXG4gICAgICAgICk7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBVbmtub3duIHR5cGUgXCIke3R5cGVOYW1lfVwiLmAgKyBkaWRZb3VNZWFuKHN1Z2dlc3RlZFR5cGVzKSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxudmFyIHN0YW5kYXJkVHlwZU5hbWVzID0gWy4uLnNwZWNpZmllZFNjYWxhclR5cGVzLCAuLi5pbnRyb3NwZWN0aW9uVHlwZXNdLm1hcChcbiAgKHR5cGUpID0+IHR5cGUubmFtZVxuKTtcbmZ1bmN0aW9uIGlzU0RMTm9kZSh2YWx1ZSkge1xuICByZXR1cm4gXCJraW5kXCIgaW4gdmFsdWUgJiYgKGlzVHlwZVN5c3RlbURlZmluaXRpb25Ob2RlKHZhbHVlKSB8fCBpc1R5cGVTeXN0ZW1FeHRlbnNpb25Ob2RlKHZhbHVlKSk7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL0xvbmVBbm9ueW1vdXNPcGVyYXRpb25SdWxlLm1qc1xuZnVuY3Rpb24gTG9uZUFub255bW91c09wZXJhdGlvblJ1bGUoY29udGV4dCkge1xuICBsZXQgb3BlcmF0aW9uQ291bnQgPSAwO1xuICByZXR1cm4ge1xuICAgIERvY3VtZW50KG5vZGUpIHtcbiAgICAgIG9wZXJhdGlvbkNvdW50ID0gbm9kZS5kZWZpbml0aW9ucy5maWx0ZXIoXG4gICAgICAgIChkZWZpbml0aW9uKSA9PiBkZWZpbml0aW9uLmtpbmQgPT09IEtpbmQuT1BFUkFUSU9OX0RFRklOSVRJT05cbiAgICAgICkubGVuZ3RoO1xuICAgIH0sXG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBpZiAoIW5vZGUubmFtZSAmJiBvcGVyYXRpb25Db3VudCA+IDEpIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgXCJUaGlzIGFub255bW91cyBvcGVyYXRpb24gbXVzdCBiZSB0aGUgb25seSBkZWZpbmVkIG9wZXJhdGlvbi5cIixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Mb25lU2NoZW1hRGVmaW5pdGlvblJ1bGUubWpzXG5mdW5jdGlvbiBMb25lU2NoZW1hRGVmaW5pdGlvblJ1bGUoY29udGV4dCkge1xuICB2YXIgX3JlZiwgX3JlZjIsIF9vbGRTY2hlbWEkYXN0Tm9kZTtcbiAgY29uc3Qgb2xkU2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgY29uc3QgYWxyZWFkeURlZmluZWQgPSAoX3JlZiA9IChfcmVmMiA9IChfb2xkU2NoZW1hJGFzdE5vZGUgPSBvbGRTY2hlbWEgPT09IG51bGwgfHwgb2xkU2NoZW1hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvbGRTY2hlbWEuYXN0Tm9kZSkgIT09IG51bGwgJiYgX29sZFNjaGVtYSRhc3ROb2RlICE9PSB2b2lkIDAgPyBfb2xkU2NoZW1hJGFzdE5vZGUgOiBvbGRTY2hlbWEgPT09IG51bGwgfHwgb2xkU2NoZW1hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvbGRTY2hlbWEuZ2V0UXVlcnlUeXBlKCkpICE9PSBudWxsICYmIF9yZWYyICE9PSB2b2lkIDAgPyBfcmVmMiA6IG9sZFNjaGVtYSA9PT0gbnVsbCB8fCBvbGRTY2hlbWEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9sZFNjaGVtYS5nZXRNdXRhdGlvblR5cGUoKSkgIT09IG51bGwgJiYgX3JlZiAhPT0gdm9pZCAwID8gX3JlZiA6IG9sZFNjaGVtYSA9PT0gbnVsbCB8fCBvbGRTY2hlbWEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9sZFNjaGVtYS5nZXRTdWJzY3JpcHRpb25UeXBlKCk7XG4gIGxldCBzY2hlbWFEZWZpbml0aW9uc0NvdW50ID0gMDtcbiAgcmV0dXJuIHtcbiAgICBTY2hlbWFEZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIGlmIChhbHJlYWR5RGVmaW5lZCkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBcIkNhbm5vdCBkZWZpbmUgYSBuZXcgc2NoZW1hIHdpdGhpbiBhIHNjaGVtYSBleHRlbnNpb24uXCIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBub2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoc2NoZW1hRGVmaW5pdGlvbnNDb3VudCA+IDApIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFwiTXVzdCBwcm92aWRlIG9ubHkgb25lIHNjaGVtYSBkZWZpbml0aW9uLlwiLCB7XG4gICAgICAgICAgICBub2Rlczogbm9kZVxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICArK3NjaGVtYURlZmluaXRpb25zQ291bnQ7XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9Ob0ZyYWdtZW50Q3ljbGVzUnVsZS5tanNcbmZ1bmN0aW9uIE5vRnJhZ21lbnRDeWNsZXNSdWxlKGNvbnRleHQpIHtcbiAgY29uc3QgdmlzaXRlZEZyYWdzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IHNwcmVhZFBhdGggPSBbXTtcbiAgY29uc3Qgc3ByZWFkUGF0aEluZGV4QnlOYW1lID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiB7XG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbjogKCkgPT4gZmFsc2UsXG4gICAgRnJhZ21lbnREZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIGRldGVjdEN5Y2xlUmVjdXJzaXZlKG5vZGUpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfTtcbiAgZnVuY3Rpb24gZGV0ZWN0Q3ljbGVSZWN1cnNpdmUoZnJhZ21lbnQpIHtcbiAgICBpZiAodmlzaXRlZEZyYWdzW2ZyYWdtZW50Lm5hbWUudmFsdWVdKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGZyYWdtZW50TmFtZSA9IGZyYWdtZW50Lm5hbWUudmFsdWU7XG4gICAgdmlzaXRlZEZyYWdzW2ZyYWdtZW50TmFtZV0gPSB0cnVlO1xuICAgIGNvbnN0IHNwcmVhZE5vZGVzID0gY29udGV4dC5nZXRGcmFnbWVudFNwcmVhZHMoZnJhZ21lbnQuc2VsZWN0aW9uU2V0KTtcbiAgICBpZiAoc3ByZWFkTm9kZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNwcmVhZFBhdGhJbmRleEJ5TmFtZVtmcmFnbWVudE5hbWVdID0gc3ByZWFkUGF0aC5sZW5ndGg7XG4gICAgZm9yIChjb25zdCBzcHJlYWROb2RlIG9mIHNwcmVhZE5vZGVzKSB7XG4gICAgICBjb25zdCBzcHJlYWROYW1lID0gc3ByZWFkTm9kZS5uYW1lLnZhbHVlO1xuICAgICAgY29uc3QgY3ljbGVJbmRleCA9IHNwcmVhZFBhdGhJbmRleEJ5TmFtZVtzcHJlYWROYW1lXTtcbiAgICAgIHNwcmVhZFBhdGgucHVzaChzcHJlYWROb2RlKTtcbiAgICAgIGlmIChjeWNsZUluZGV4ID09PSB2b2lkIDApIHtcbiAgICAgICAgY29uc3Qgc3ByZWFkRnJhZ21lbnQgPSBjb250ZXh0LmdldEZyYWdtZW50KHNwcmVhZE5hbWUpO1xuICAgICAgICBpZiAoc3ByZWFkRnJhZ21lbnQpIHtcbiAgICAgICAgICBkZXRlY3RDeWNsZVJlY3Vyc2l2ZShzcHJlYWRGcmFnbWVudCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGN5Y2xlUGF0aCA9IHNwcmVhZFBhdGguc2xpY2UoY3ljbGVJbmRleCk7XG4gICAgICAgIGNvbnN0IHZpYVBhdGggPSBjeWNsZVBhdGguc2xpY2UoMCwgLTEpLm1hcCgocykgPT4gJ1wiJyArIHMubmFtZS52YWx1ZSArICdcIicpLmpvaW4oXCIsIFwiKTtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYENhbm5vdCBzcHJlYWQgZnJhZ21lbnQgXCIke3NwcmVhZE5hbWV9XCIgd2l0aGluIGl0c2VsZmAgKyAodmlhUGF0aCAhPT0gXCJcIiA/IGAgdmlhICR7dmlhUGF0aH0uYCA6IFwiLlwiKSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IGN5Y2xlUGF0aFxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHNwcmVhZFBhdGgucG9wKCk7XG4gICAgfVxuICAgIHNwcmVhZFBhdGhJbmRleEJ5TmFtZVtmcmFnbWVudE5hbWVdID0gdm9pZCAwO1xuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL05vVW5kZWZpbmVkVmFyaWFibGVzUnVsZS5tanNcbmZ1bmN0aW9uIE5vVW5kZWZpbmVkVmFyaWFibGVzUnVsZShjb250ZXh0KSB7XG4gIGxldCB2YXJpYWJsZU5hbWVEZWZpbmVkID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiB7XG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbjoge1xuICAgICAgZW50ZXIoKSB7XG4gICAgICAgIHZhcmlhYmxlTmFtZURlZmluZWQgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgIH0sXG4gICAgICBsZWF2ZShvcGVyYXRpb24pIHtcbiAgICAgICAgY29uc3QgdXNhZ2VzID0gY29udGV4dC5nZXRSZWN1cnNpdmVWYXJpYWJsZVVzYWdlcyhvcGVyYXRpb24pO1xuICAgICAgICBmb3IgKGNvbnN0IHsgbm9kZSB9IG9mIHVzYWdlcykge1xuICAgICAgICAgIGNvbnN0IHZhck5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICAgICAgaWYgKHZhcmlhYmxlTmFtZURlZmluZWRbdmFyTmFtZV0gIT09IHRydWUpIHtcbiAgICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uLm5hbWUgPyBgVmFyaWFibGUgXCIkJHt2YXJOYW1lfVwiIGlzIG5vdCBkZWZpbmVkIGJ5IG9wZXJhdGlvbiBcIiR7b3BlcmF0aW9uLm5hbWUudmFsdWV9XCIuYCA6IGBWYXJpYWJsZSBcIiQke3Zhck5hbWV9XCIgaXMgbm90IGRlZmluZWQuYCxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBub2RlczogW25vZGUsIG9wZXJhdGlvbl1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBWYXJpYWJsZURlZmluaXRpb24obm9kZSkge1xuICAgICAgdmFyaWFibGVOYW1lRGVmaW5lZFtub2RlLnZhcmlhYmxlLm5hbWUudmFsdWVdID0gdHJ1ZTtcbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL05vVW51c2VkRnJhZ21lbnRzUnVsZS5tanNcbmZ1bmN0aW9uIE5vVW51c2VkRnJhZ21lbnRzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IG9wZXJhdGlvbkRlZnMgPSBbXTtcbiAgY29uc3QgZnJhZ21lbnREZWZzID0gW107XG4gIHJldHVybiB7XG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBvcGVyYXRpb25EZWZzLnB1c2gobm9kZSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSxcbiAgICBGcmFnbWVudERlZmluaXRpb24obm9kZSkge1xuICAgICAgZnJhZ21lbnREZWZzLnB1c2gobm9kZSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSxcbiAgICBEb2N1bWVudDoge1xuICAgICAgbGVhdmUoKSB7XG4gICAgICAgIGNvbnN0IGZyYWdtZW50TmFtZVVzZWQgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgZm9yIChjb25zdCBvcGVyYXRpb24gb2Ygb3BlcmF0aW9uRGVmcykge1xuICAgICAgICAgIGZvciAoY29uc3QgZnJhZ21lbnQgb2YgY29udGV4dC5nZXRSZWN1cnNpdmVseVJlZmVyZW5jZWRGcmFnbWVudHMoXG4gICAgICAgICAgICBvcGVyYXRpb25cbiAgICAgICAgICApKSB7XG4gICAgICAgICAgICBmcmFnbWVudE5hbWVVc2VkW2ZyYWdtZW50Lm5hbWUudmFsdWVdID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBmcmFnbWVudERlZiBvZiBmcmFnbWVudERlZnMpIHtcbiAgICAgICAgICBjb25zdCBmcmFnTmFtZSA9IGZyYWdtZW50RGVmLm5hbWUudmFsdWU7XG4gICAgICAgICAgaWYgKGZyYWdtZW50TmFtZVVzZWRbZnJhZ05hbWVdICE9PSB0cnVlKSB7XG4gICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKGBGcmFnbWVudCBcIiR7ZnJhZ05hbWV9XCIgaXMgbmV2ZXIgdXNlZC5gLCB7XG4gICAgICAgICAgICAgICAgbm9kZXM6IGZyYWdtZW50RGVmXG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvTm9VbnVzZWRWYXJpYWJsZXNSdWxlLm1qc1xuZnVuY3Rpb24gTm9VbnVzZWRWYXJpYWJsZXNSdWxlKGNvbnRleHQpIHtcbiAgbGV0IHZhcmlhYmxlRGVmcyA9IFtdO1xuICByZXR1cm4ge1xuICAgIE9wZXJhdGlvbkRlZmluaXRpb246IHtcbiAgICAgIGVudGVyKCkge1xuICAgICAgICB2YXJpYWJsZURlZnMgPSBbXTtcbiAgICAgIH0sXG4gICAgICBsZWF2ZShvcGVyYXRpb24pIHtcbiAgICAgICAgY29uc3QgdmFyaWFibGVOYW1lVXNlZCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICBjb25zdCB1c2FnZXMgPSBjb250ZXh0LmdldFJlY3Vyc2l2ZVZhcmlhYmxlVXNhZ2VzKG9wZXJhdGlvbik7XG4gICAgICAgIGZvciAoY29uc3QgeyBub2RlIH0gb2YgdXNhZ2VzKSB7XG4gICAgICAgICAgdmFyaWFibGVOYW1lVXNlZFtub2RlLm5hbWUudmFsdWVdID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IHZhcmlhYmxlRGVmIG9mIHZhcmlhYmxlRGVmcykge1xuICAgICAgICAgIGNvbnN0IHZhcmlhYmxlTmFtZSA9IHZhcmlhYmxlRGVmLnZhcmlhYmxlLm5hbWUudmFsdWU7XG4gICAgICAgICAgaWYgKHZhcmlhYmxlTmFtZVVzZWRbdmFyaWFibGVOYW1lXSAhPT0gdHJ1ZSkge1xuICAgICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgICBvcGVyYXRpb24ubmFtZSA/IGBWYXJpYWJsZSBcIiQke3ZhcmlhYmxlTmFtZX1cIiBpcyBuZXZlciB1c2VkIGluIG9wZXJhdGlvbiBcIiR7b3BlcmF0aW9uLm5hbWUudmFsdWV9XCIuYCA6IGBWYXJpYWJsZSBcIiQke3ZhcmlhYmxlTmFtZX1cIiBpcyBuZXZlciB1c2VkLmAsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbm9kZXM6IHZhcmlhYmxlRGVmXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgVmFyaWFibGVEZWZpbml0aW9uKGRlZikge1xuICAgICAgdmFyaWFibGVEZWZzLnB1c2goZGVmKTtcbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC91dGlsaXRpZXMvc29ydFZhbHVlTm9kZS5tanNcbmZ1bmN0aW9uIHNvcnRWYWx1ZU5vZGUodmFsdWVOb2RlKSB7XG4gIHN3aXRjaCAodmFsdWVOb2RlLmtpbmQpIHtcbiAgICBjYXNlIEtpbmQuT0JKRUNUOlxuICAgICAgcmV0dXJuIHsgLi4udmFsdWVOb2RlLCBmaWVsZHM6IHNvcnRGaWVsZHModmFsdWVOb2RlLmZpZWxkcykgfTtcbiAgICBjYXNlIEtpbmQuTElTVDpcbiAgICAgIHJldHVybiB7IC4uLnZhbHVlTm9kZSwgdmFsdWVzOiB2YWx1ZU5vZGUudmFsdWVzLm1hcChzb3J0VmFsdWVOb2RlKSB9O1xuICAgIGNhc2UgS2luZC5JTlQ6XG4gICAgY2FzZSBLaW5kLkZMT0FUOlxuICAgIGNhc2UgS2luZC5TVFJJTkc6XG4gICAgY2FzZSBLaW5kLkJPT0xFQU46XG4gICAgY2FzZSBLaW5kLk5VTEw6XG4gICAgY2FzZSBLaW5kLkVOVU06XG4gICAgY2FzZSBLaW5kLlZBUklBQkxFOlxuICAgICAgcmV0dXJuIHZhbHVlTm9kZTtcbiAgfVxufVxuZnVuY3Rpb24gc29ydEZpZWxkcyhmaWVsZHMpIHtcbiAgcmV0dXJuIGZpZWxkcy5tYXAoKGZpZWxkTm9kZSkgPT4gKHtcbiAgICAuLi5maWVsZE5vZGUsXG4gICAgdmFsdWU6IHNvcnRWYWx1ZU5vZGUoZmllbGROb2RlLnZhbHVlKVxuICB9KSkuc29ydChcbiAgICAoZmllbGRBLCBmaWVsZEIpID0+IG5hdHVyYWxDb21wYXJlKGZpZWxkQS5uYW1lLnZhbHVlLCBmaWVsZEIubmFtZS52YWx1ZSlcbiAgKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvT3ZlcmxhcHBpbmdGaWVsZHNDYW5CZU1lcmdlZFJ1bGUubWpzXG5mdW5jdGlvbiByZWFzb25NZXNzYWdlKHJlYXNvbikge1xuICBpZiAoQXJyYXkuaXNBcnJheShyZWFzb24pKSB7XG4gICAgcmV0dXJuIHJlYXNvbi5tYXAoXG4gICAgICAoW3Jlc3BvbnNlTmFtZSwgc3ViUmVhc29uXSkgPT4gYHN1YmZpZWxkcyBcIiR7cmVzcG9uc2VOYW1lfVwiIGNvbmZsaWN0IGJlY2F1c2UgYCArIHJlYXNvbk1lc3NhZ2Uoc3ViUmVhc29uKVxuICAgICkuam9pbihcIiBhbmQgXCIpO1xuICB9XG4gIHJldHVybiByZWFzb247XG59XG5mdW5jdGlvbiBPdmVybGFwcGluZ0ZpZWxkc0NhbkJlTWVyZ2VkUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IGNvbXBhcmVkRnJhZ21lbnRQYWlycyA9IG5ldyBQYWlyU2V0KCk7XG4gIGNvbnN0IGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICByZXR1cm4ge1xuICAgIFNlbGVjdGlvblNldChzZWxlY3Rpb25TZXQpIHtcbiAgICAgIGNvbnN0IGNvbmZsaWN0cyA9IGZpbmRDb25mbGljdHNXaXRoaW5TZWxlY3Rpb25TZXQoXG4gICAgICAgIGNvbnRleHQsXG4gICAgICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgICAgY29udGV4dC5nZXRQYXJlbnRUeXBlKCksXG4gICAgICAgIHNlbGVjdGlvblNldFxuICAgICAgKTtcbiAgICAgIGZvciAoY29uc3QgW1tyZXNwb25zZU5hbWUsIHJlYXNvbl0sIGZpZWxkczEsIGZpZWxkczJdIG9mIGNvbmZsaWN0cykge1xuICAgICAgICBjb25zdCByZWFzb25Nc2cgPSByZWFzb25NZXNzYWdlKHJlYXNvbik7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBGaWVsZHMgXCIke3Jlc3BvbnNlTmFtZX1cIiBjb25mbGljdCBiZWNhdXNlICR7cmVhc29uTXNnfS4gVXNlIGRpZmZlcmVudCBhbGlhc2VzIG9uIHRoZSBmaWVsZHMgdG8gZmV0Y2ggYm90aCBpZiB0aGlzIHdhcyBpbnRlbnRpb25hbC5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogZmllbGRzMS5jb25jYXQoZmllbGRzMilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gZmluZENvbmZsaWN0c1dpdGhpblNlbGVjdGlvblNldChjb250ZXh0LCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLCBjb21wYXJlZEZyYWdtZW50UGFpcnMsIHBhcmVudFR5cGUsIHNlbGVjdGlvblNldCkge1xuICBjb25zdCBjb25mbGljdHMgPSBbXTtcbiAgY29uc3QgW2ZpZWxkTWFwLCBmcmFnbWVudE5hbWVzXSA9IGdldEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoXG4gICAgY29udGV4dCxcbiAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgIHBhcmVudFR5cGUsXG4gICAgc2VsZWN0aW9uU2V0XG4gICk7XG4gIGNvbGxlY3RDb25mbGljdHNXaXRoaW4oXG4gICAgY29udGV4dCxcbiAgICBjb25mbGljdHMsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgZmllbGRNYXBcbiAgKTtcbiAgaWYgKGZyYWdtZW50TmFtZXMubGVuZ3RoICE9PSAwKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmcmFnbWVudE5hbWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZpZWxkc0FuZEZyYWdtZW50KFxuICAgICAgICBjb250ZXh0LFxuICAgICAgICBjb25mbGljdHMsXG4gICAgICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgICAgZmFsc2UsXG4gICAgICAgIGZpZWxkTWFwLFxuICAgICAgICBmcmFnbWVudE5hbWVzW2ldXG4gICAgICApO1xuICAgICAgZm9yIChsZXQgaiA9IGkgKyAxOyBqIDwgZnJhZ21lbnROYW1lcy5sZW5ndGg7IGorKykge1xuICAgICAgICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZyYWdtZW50cyhcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIGNvbmZsaWN0cyxcbiAgICAgICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgICAgICBmYWxzZSxcbiAgICAgICAgICBmcmFnbWVudE5hbWVzW2ldLFxuICAgICAgICAgIGZyYWdtZW50TmFtZXNbal1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGNvbmZsaWN0cztcbn1cbmZ1bmN0aW9uIGNvbGxlY3RDb25mbGljdHNCZXR3ZWVuRmllbGRzQW5kRnJhZ21lbnQoY29udGV4dCwgY29uZmxpY3RzLCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLCBjb21wYXJlZEZyYWdtZW50UGFpcnMsIGFyZU11dHVhbGx5RXhjbHVzaXZlLCBmaWVsZE1hcCwgZnJhZ21lbnROYW1lKSB7XG4gIGNvbnN0IGZyYWdtZW50ID0gY29udGV4dC5nZXRGcmFnbWVudChmcmFnbWVudE5hbWUpO1xuICBpZiAoIWZyYWdtZW50KSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IFtmaWVsZE1hcDIsIHJlZmVyZW5jZWRGcmFnbWVudE5hbWVzXSA9IGdldFJlZmVyZW5jZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBmcmFnbWVudFxuICApO1xuICBpZiAoZmllbGRNYXAgPT09IGZpZWxkTWFwMikge1xuICAgIHJldHVybjtcbiAgfVxuICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbihcbiAgICBjb250ZXh0LFxuICAgIGNvbmZsaWN0cyxcbiAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZSxcbiAgICBmaWVsZE1hcCxcbiAgICBmaWVsZE1hcDJcbiAgKTtcbiAgZm9yIChjb25zdCByZWZlcmVuY2VkRnJhZ21lbnROYW1lIG9mIHJlZmVyZW5jZWRGcmFnbWVudE5hbWVzKSB7XG4gICAgaWYgKGNvbXBhcmVkRnJhZ21lbnRQYWlycy5oYXMoXG4gICAgICByZWZlcmVuY2VkRnJhZ21lbnROYW1lLFxuICAgICAgZnJhZ21lbnROYW1lLFxuICAgICAgYXJlTXV0dWFsbHlFeGNsdXNpdmVcbiAgICApKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLmFkZChcbiAgICAgIHJlZmVyZW5jZWRGcmFnbWVudE5hbWUsXG4gICAgICBmcmFnbWVudE5hbWUsXG4gICAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZVxuICAgICk7XG4gICAgY29sbGVjdENvbmZsaWN0c0JldHdlZW5GaWVsZHNBbmRGcmFnbWVudChcbiAgICAgIGNvbnRleHQsXG4gICAgICBjb25mbGljdHMsXG4gICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgICBmaWVsZE1hcCxcbiAgICAgIHJlZmVyZW5jZWRGcmFnbWVudE5hbWVcbiAgICApO1xuICB9XG59XG5mdW5jdGlvbiBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZyYWdtZW50cyhjb250ZXh0LCBjb25mbGljdHMsIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsIGNvbXBhcmVkRnJhZ21lbnRQYWlycywgYXJlTXV0dWFsbHlFeGNsdXNpdmUsIGZyYWdtZW50TmFtZTEsIGZyYWdtZW50TmFtZTIpIHtcbiAgaWYgKGZyYWdtZW50TmFtZTEgPT09IGZyYWdtZW50TmFtZTIpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGNvbXBhcmVkRnJhZ21lbnRQYWlycy5oYXMoXG4gICAgZnJhZ21lbnROYW1lMSxcbiAgICBmcmFnbWVudE5hbWUyLFxuICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlXG4gICkpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29tcGFyZWRGcmFnbWVudFBhaXJzLmFkZChmcmFnbWVudE5hbWUxLCBmcmFnbWVudE5hbWUyLCBhcmVNdXR1YWxseUV4Y2x1c2l2ZSk7XG4gIGNvbnN0IGZyYWdtZW50MSA9IGNvbnRleHQuZ2V0RnJhZ21lbnQoZnJhZ21lbnROYW1lMSk7XG4gIGNvbnN0IGZyYWdtZW50MiA9IGNvbnRleHQuZ2V0RnJhZ21lbnQoZnJhZ21lbnROYW1lMik7XG4gIGlmICghZnJhZ21lbnQxIHx8ICFmcmFnbWVudDIpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgW2ZpZWxkTWFwMSwgcmVmZXJlbmNlZEZyYWdtZW50TmFtZXMxXSA9IGdldFJlZmVyZW5jZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBmcmFnbWVudDFcbiAgKTtcbiAgY29uc3QgW2ZpZWxkTWFwMiwgcmVmZXJlbmNlZEZyYWdtZW50TmFtZXMyXSA9IGdldFJlZmVyZW5jZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBmcmFnbWVudDJcbiAgKTtcbiAgY29sbGVjdENvbmZsaWN0c0JldHdlZW4oXG4gICAgY29udGV4dCxcbiAgICBjb25mbGljdHMsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgZmllbGRNYXAxLFxuICAgIGZpZWxkTWFwMlxuICApO1xuICBmb3IgKGNvbnN0IHJlZmVyZW5jZWRGcmFnbWVudE5hbWUyIG9mIHJlZmVyZW5jZWRGcmFnbWVudE5hbWVzMikge1xuICAgIGNvbGxlY3RDb25mbGljdHNCZXR3ZWVuRnJhZ21lbnRzKFxuICAgICAgY29udGV4dCxcbiAgICAgIGNvbmZsaWN0cyxcbiAgICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZSxcbiAgICAgIGZyYWdtZW50TmFtZTEsXG4gICAgICByZWZlcmVuY2VkRnJhZ21lbnROYW1lMlxuICAgICk7XG4gIH1cbiAgZm9yIChjb25zdCByZWZlcmVuY2VkRnJhZ21lbnROYW1lMSBvZiByZWZlcmVuY2VkRnJhZ21lbnROYW1lczEpIHtcbiAgICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZyYWdtZW50cyhcbiAgICAgIGNvbnRleHQsXG4gICAgICBjb25mbGljdHMsXG4gICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgICByZWZlcmVuY2VkRnJhZ21lbnROYW1lMSxcbiAgICAgIGZyYWdtZW50TmFtZTJcbiAgICApO1xuICB9XG59XG5mdW5jdGlvbiBmaW5kQ29uZmxpY3RzQmV0d2VlblN1YlNlbGVjdGlvblNldHMoY29udGV4dCwgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcywgY29tcGFyZWRGcmFnbWVudFBhaXJzLCBhcmVNdXR1YWxseUV4Y2x1c2l2ZSwgcGFyZW50VHlwZTEsIHNlbGVjdGlvblNldDEsIHBhcmVudFR5cGUyLCBzZWxlY3Rpb25TZXQyKSB7XG4gIGNvbnN0IGNvbmZsaWN0cyA9IFtdO1xuICBjb25zdCBbZmllbGRNYXAxLCBmcmFnbWVudE5hbWVzMV0gPSBnZXRGaWVsZHNBbmRGcmFnbWVudE5hbWVzKFxuICAgIGNvbnRleHQsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBwYXJlbnRUeXBlMSxcbiAgICBzZWxlY3Rpb25TZXQxXG4gICk7XG4gIGNvbnN0IFtmaWVsZE1hcDIsIGZyYWdtZW50TmFtZXMyXSA9IGdldEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoXG4gICAgY29udGV4dCxcbiAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgIHBhcmVudFR5cGUyLFxuICAgIHNlbGVjdGlvblNldDJcbiAgKTtcbiAgY29sbGVjdENvbmZsaWN0c0JldHdlZW4oXG4gICAgY29udGV4dCxcbiAgICBjb25mbGljdHMsXG4gICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgYXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgZmllbGRNYXAxLFxuICAgIGZpZWxkTWFwMlxuICApO1xuICBmb3IgKGNvbnN0IGZyYWdtZW50TmFtZTIgb2YgZnJhZ21lbnROYW1lczIpIHtcbiAgICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZpZWxkc0FuZEZyYWdtZW50KFxuICAgICAgY29udGV4dCxcbiAgICAgIGNvbmZsaWN0cyxcbiAgICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZSxcbiAgICAgIGZpZWxkTWFwMSxcbiAgICAgIGZyYWdtZW50TmFtZTJcbiAgICApO1xuICB9XG4gIGZvciAoY29uc3QgZnJhZ21lbnROYW1lMSBvZiBmcmFnbWVudE5hbWVzMSkge1xuICAgIGNvbGxlY3RDb25mbGljdHNCZXR3ZWVuRmllbGRzQW5kRnJhZ21lbnQoXG4gICAgICBjb250ZXh0LFxuICAgICAgY29uZmxpY3RzLFxuICAgICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlLFxuICAgICAgZmllbGRNYXAyLFxuICAgICAgZnJhZ21lbnROYW1lMVxuICAgICk7XG4gIH1cbiAgZm9yIChjb25zdCBmcmFnbWVudE5hbWUxIG9mIGZyYWdtZW50TmFtZXMxKSB7XG4gICAgZm9yIChjb25zdCBmcmFnbWVudE5hbWUyIG9mIGZyYWdtZW50TmFtZXMyKSB7XG4gICAgICBjb2xsZWN0Q29uZmxpY3RzQmV0d2VlbkZyYWdtZW50cyhcbiAgICAgICAgY29udGV4dCxcbiAgICAgICAgY29uZmxpY3RzLFxuICAgICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICAgIGFyZU11dHVhbGx5RXhjbHVzaXZlLFxuICAgICAgICBmcmFnbWVudE5hbWUxLFxuICAgICAgICBmcmFnbWVudE5hbWUyXG4gICAgICApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gY29uZmxpY3RzO1xufVxuZnVuY3Rpb24gY29sbGVjdENvbmZsaWN0c1dpdGhpbihjb250ZXh0LCBjb25mbGljdHMsIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsIGNvbXBhcmVkRnJhZ21lbnRQYWlycywgZmllbGRNYXApIHtcbiAgZm9yIChjb25zdCBbcmVzcG9uc2VOYW1lLCBmaWVsZHNdIG9mIE9iamVjdC5lbnRyaWVzKGZpZWxkTWFwKSkge1xuICAgIGlmIChmaWVsZHMubGVuZ3RoID4gMSkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmaWVsZHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgZm9yIChsZXQgaiA9IGkgKyAxOyBqIDwgZmllbGRzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgY29uc3QgY29uZmxpY3QgPSBmaW5kQ29uZmxpY3QoXG4gICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcyxcbiAgICAgICAgICAgIGNvbXBhcmVkRnJhZ21lbnRQYWlycyxcbiAgICAgICAgICAgIGZhbHNlLFxuICAgICAgICAgICAgLy8gd2l0aGluIG9uZSBjb2xsZWN0aW9uIGlzIG5ldmVyIG11dHVhbGx5IGV4Y2x1c2l2ZVxuICAgICAgICAgICAgcmVzcG9uc2VOYW1lLFxuICAgICAgICAgICAgZmllbGRzW2ldLFxuICAgICAgICAgICAgZmllbGRzW2pdXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAoY29uZmxpY3QpIHtcbiAgICAgICAgICAgIGNvbmZsaWN0cy5wdXNoKGNvbmZsaWN0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGNvbGxlY3RDb25mbGljdHNCZXR3ZWVuKGNvbnRleHQsIGNvbmZsaWN0cywgY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcywgY29tcGFyZWRGcmFnbWVudFBhaXJzLCBwYXJlbnRGaWVsZHNBcmVNdXR1YWxseUV4Y2x1c2l2ZSwgZmllbGRNYXAxLCBmaWVsZE1hcDIpIHtcbiAgZm9yIChjb25zdCBbcmVzcG9uc2VOYW1lLCBmaWVsZHMxXSBvZiBPYmplY3QuZW50cmllcyhmaWVsZE1hcDEpKSB7XG4gICAgY29uc3QgZmllbGRzMiA9IGZpZWxkTWFwMltyZXNwb25zZU5hbWVdO1xuICAgIGlmIChmaWVsZHMyKSB7XG4gICAgICBmb3IgKGNvbnN0IGZpZWxkMSBvZiBmaWVsZHMxKSB7XG4gICAgICAgIGZvciAoY29uc3QgZmllbGQyIG9mIGZpZWxkczIpIHtcbiAgICAgICAgICBjb25zdCBjb25mbGljdCA9IGZpbmRDb25mbGljdChcbiAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgICAgICAgICAgY29tcGFyZWRGcmFnbWVudFBhaXJzLFxuICAgICAgICAgICAgcGFyZW50RmllbGRzQXJlTXV0dWFsbHlFeGNsdXNpdmUsXG4gICAgICAgICAgICByZXNwb25zZU5hbWUsXG4gICAgICAgICAgICBmaWVsZDEsXG4gICAgICAgICAgICBmaWVsZDJcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChjb25mbGljdCkge1xuICAgICAgICAgICAgY29uZmxpY3RzLnB1c2goY29uZmxpY3QpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gZmluZENvbmZsaWN0KGNvbnRleHQsIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsIGNvbXBhcmVkRnJhZ21lbnRQYWlycywgcGFyZW50RmllbGRzQXJlTXV0dWFsbHlFeGNsdXNpdmUsIHJlc3BvbnNlTmFtZSwgZmllbGQxLCBmaWVsZDIpIHtcbiAgY29uc3QgW3BhcmVudFR5cGUxLCBub2RlMSwgZGVmMV0gPSBmaWVsZDE7XG4gIGNvbnN0IFtwYXJlbnRUeXBlMiwgbm9kZTIsIGRlZjJdID0gZmllbGQyO1xuICBjb25zdCBhcmVNdXR1YWxseUV4Y2x1c2l2ZSA9IHBhcmVudEZpZWxkc0FyZU11dHVhbGx5RXhjbHVzaXZlIHx8IHBhcmVudFR5cGUxICE9PSBwYXJlbnRUeXBlMiAmJiBpc09iamVjdFR5cGUocGFyZW50VHlwZTEpICYmIGlzT2JqZWN0VHlwZShwYXJlbnRUeXBlMik7XG4gIGlmICghYXJlTXV0dWFsbHlFeGNsdXNpdmUpIHtcbiAgICBjb25zdCBuYW1lMSA9IG5vZGUxLm5hbWUudmFsdWU7XG4gICAgY29uc3QgbmFtZTIgPSBub2RlMi5uYW1lLnZhbHVlO1xuICAgIGlmIChuYW1lMSAhPT0gbmFtZTIpIHtcbiAgICAgIHJldHVybiBbXG4gICAgICAgIFtyZXNwb25zZU5hbWUsIGBcIiR7bmFtZTF9XCIgYW5kIFwiJHtuYW1lMn1cIiBhcmUgZGlmZmVyZW50IGZpZWxkc2BdLFxuICAgICAgICBbbm9kZTFdLFxuICAgICAgICBbbm9kZTJdXG4gICAgICBdO1xuICAgIH1cbiAgICBpZiAoIXNhbWVBcmd1bWVudHMobm9kZTEsIG5vZGUyKSkge1xuICAgICAgcmV0dXJuIFtcbiAgICAgICAgW3Jlc3BvbnNlTmFtZSwgXCJ0aGV5IGhhdmUgZGlmZmVyaW5nIGFyZ3VtZW50c1wiXSxcbiAgICAgICAgW25vZGUxXSxcbiAgICAgICAgW25vZGUyXVxuICAgICAgXTtcbiAgICB9XG4gIH1cbiAgY29uc3QgdHlwZTEgPSBkZWYxID09PSBudWxsIHx8IGRlZjEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRlZjEudHlwZTtcbiAgY29uc3QgdHlwZTIgPSBkZWYyID09PSBudWxsIHx8IGRlZjIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRlZjIudHlwZTtcbiAgaWYgKHR5cGUxICYmIHR5cGUyICYmIGRvVHlwZXNDb25mbGljdCh0eXBlMSwgdHlwZTIpKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgIFtcbiAgICAgICAgcmVzcG9uc2VOYW1lLFxuICAgICAgICBgdGhleSByZXR1cm4gY29uZmxpY3RpbmcgdHlwZXMgXCIke2luc3BlY3QodHlwZTEpfVwiIGFuZCBcIiR7aW5zcGVjdChcbiAgICAgICAgICB0eXBlMlxuICAgICAgICApfVwiYFxuICAgICAgXSxcbiAgICAgIFtub2RlMV0sXG4gICAgICBbbm9kZTJdXG4gICAgXTtcbiAgfVxuICBjb25zdCBzZWxlY3Rpb25TZXQxID0gbm9kZTEuc2VsZWN0aW9uU2V0O1xuICBjb25zdCBzZWxlY3Rpb25TZXQyID0gbm9kZTIuc2VsZWN0aW9uU2V0O1xuICBpZiAoc2VsZWN0aW9uU2V0MSAmJiBzZWxlY3Rpb25TZXQyKSB7XG4gICAgY29uc3QgY29uZmxpY3RzID0gZmluZENvbmZsaWN0c0JldHdlZW5TdWJTZWxlY3Rpb25TZXRzKFxuICAgICAgY29udGV4dCxcbiAgICAgIGNhY2hlZEZpZWxkc0FuZEZyYWdtZW50TmFtZXMsXG4gICAgICBjb21wYXJlZEZyYWdtZW50UGFpcnMsXG4gICAgICBhcmVNdXR1YWxseUV4Y2x1c2l2ZSxcbiAgICAgIGdldE5hbWVkVHlwZSh0eXBlMSksXG4gICAgICBzZWxlY3Rpb25TZXQxLFxuICAgICAgZ2V0TmFtZWRUeXBlKHR5cGUyKSxcbiAgICAgIHNlbGVjdGlvblNldDJcbiAgICApO1xuICAgIHJldHVybiBzdWJmaWVsZENvbmZsaWN0cyhjb25mbGljdHMsIHJlc3BvbnNlTmFtZSwgbm9kZTEsIG5vZGUyKTtcbiAgfVxufVxuZnVuY3Rpb24gc2FtZUFyZ3VtZW50cyhub2RlMSwgbm9kZTIpIHtcbiAgY29uc3QgYXJnczEgPSBub2RlMS5hcmd1bWVudHM7XG4gIGNvbnN0IGFyZ3MyID0gbm9kZTIuYXJndW1lbnRzO1xuICBpZiAoYXJnczEgPT09IHZvaWQgMCB8fCBhcmdzMS5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gYXJnczIgPT09IHZvaWQgMCB8fCBhcmdzMi5sZW5ndGggPT09IDA7XG4gIH1cbiAgaWYgKGFyZ3MyID09PSB2b2lkIDAgfHwgYXJnczIubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChhcmdzMS5sZW5ndGggIT09IGFyZ3MyLmxlbmd0aCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCB2YWx1ZXMyID0gbmV3IE1hcChhcmdzMi5tYXAoKHsgbmFtZSwgdmFsdWUgfSkgPT4gW25hbWUudmFsdWUsIHZhbHVlXSkpO1xuICByZXR1cm4gYXJnczEuZXZlcnkoKGFyZzEpID0+IHtcbiAgICBjb25zdCB2YWx1ZTEgPSBhcmcxLnZhbHVlO1xuICAgIGNvbnN0IHZhbHVlMiA9IHZhbHVlczIuZ2V0KGFyZzEubmFtZS52YWx1ZSk7XG4gICAgaWYgKHZhbHVlMiA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiBzdHJpbmdpZnlWYWx1ZSh2YWx1ZTEpID09PSBzdHJpbmdpZnlWYWx1ZSh2YWx1ZTIpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHN0cmluZ2lmeVZhbHVlKHZhbHVlKSB7XG4gIHJldHVybiBwcmludChzb3J0VmFsdWVOb2RlKHZhbHVlKSk7XG59XG5mdW5jdGlvbiBkb1R5cGVzQ29uZmxpY3QodHlwZTEsIHR5cGUyKSB7XG4gIGlmIChpc0xpc3RUeXBlKHR5cGUxKSkge1xuICAgIHJldHVybiBpc0xpc3RUeXBlKHR5cGUyKSA/IGRvVHlwZXNDb25mbGljdCh0eXBlMS5vZlR5cGUsIHR5cGUyLm9mVHlwZSkgOiB0cnVlO1xuICB9XG4gIGlmIChpc0xpc3RUeXBlKHR5cGUyKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChpc05vbk51bGxUeXBlKHR5cGUxKSkge1xuICAgIHJldHVybiBpc05vbk51bGxUeXBlKHR5cGUyKSA/IGRvVHlwZXNDb25mbGljdCh0eXBlMS5vZlR5cGUsIHR5cGUyLm9mVHlwZSkgOiB0cnVlO1xuICB9XG4gIGlmIChpc05vbk51bGxUeXBlKHR5cGUyKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChpc0xlYWZUeXBlKHR5cGUxKSB8fCBpc0xlYWZUeXBlKHR5cGUyKSkge1xuICAgIHJldHVybiB0eXBlMSAhPT0gdHlwZTI7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZnVuY3Rpb24gZ2V0RmllbGRzQW5kRnJhZ21lbnROYW1lcyhjb250ZXh0LCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLCBwYXJlbnRUeXBlLCBzZWxlY3Rpb25TZXQpIHtcbiAgY29uc3QgY2FjaGVkID0gY2FjaGVkRmllbGRzQW5kRnJhZ21lbnROYW1lcy5nZXQoc2VsZWN0aW9uU2V0KTtcbiAgaWYgKGNhY2hlZCkge1xuICAgIHJldHVybiBjYWNoZWQ7XG4gIH1cbiAgY29uc3Qgbm9kZUFuZERlZnMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgZnJhZ21lbnROYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBfY29sbGVjdEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoXG4gICAgY29udGV4dCxcbiAgICBwYXJlbnRUeXBlLFxuICAgIHNlbGVjdGlvblNldCxcbiAgICBub2RlQW5kRGVmcyxcbiAgICBmcmFnbWVudE5hbWVzXG4gICk7XG4gIGNvbnN0IHJlc3VsdCA9IFtub2RlQW5kRGVmcywgT2JqZWN0LmtleXMoZnJhZ21lbnROYW1lcyldO1xuICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLnNldChzZWxlY3Rpb25TZXQsIHJlc3VsdCk7XG4gIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBnZXRSZWZlcmVuY2VkRmllbGRzQW5kRnJhZ21lbnROYW1lcyhjb250ZXh0LCBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLCBmcmFnbWVudCkge1xuICBjb25zdCBjYWNoZWQgPSBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLmdldChmcmFnbWVudC5zZWxlY3Rpb25TZXQpO1xuICBpZiAoY2FjaGVkKSB7XG4gICAgcmV0dXJuIGNhY2hlZDtcbiAgfVxuICBjb25zdCBmcmFnbWVudFR5cGUgPSB0eXBlRnJvbUFTVChjb250ZXh0LmdldFNjaGVtYSgpLCBmcmFnbWVudC50eXBlQ29uZGl0aW9uKTtcbiAgcmV0dXJuIGdldEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoXG4gICAgY29udGV4dCxcbiAgICBjYWNoZWRGaWVsZHNBbmRGcmFnbWVudE5hbWVzLFxuICAgIGZyYWdtZW50VHlwZSxcbiAgICBmcmFnbWVudC5zZWxlY3Rpb25TZXRcbiAgKTtcbn1cbmZ1bmN0aW9uIF9jb2xsZWN0RmllbGRzQW5kRnJhZ21lbnROYW1lcyhjb250ZXh0LCBwYXJlbnRUeXBlLCBzZWxlY3Rpb25TZXQsIG5vZGVBbmREZWZzLCBmcmFnbWVudE5hbWVzKSB7XG4gIGZvciAoY29uc3Qgc2VsZWN0aW9uIG9mIHNlbGVjdGlvblNldC5zZWxlY3Rpb25zKSB7XG4gICAgc3dpdGNoIChzZWxlY3Rpb24ua2luZCkge1xuICAgICAgY2FzZSBLaW5kLkZJRUxEOiB7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IHNlbGVjdGlvbi5uYW1lLnZhbHVlO1xuICAgICAgICBsZXQgZmllbGREZWY7XG4gICAgICAgIGlmIChpc09iamVjdFR5cGUocGFyZW50VHlwZSkgfHwgaXNJbnRlcmZhY2VUeXBlKHBhcmVudFR5cGUpKSB7XG4gICAgICAgICAgZmllbGREZWYgPSBwYXJlbnRUeXBlLmdldEZpZWxkcygpW2ZpZWxkTmFtZV07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzcG9uc2VOYW1lID0gc2VsZWN0aW9uLmFsaWFzID8gc2VsZWN0aW9uLmFsaWFzLnZhbHVlIDogZmllbGROYW1lO1xuICAgICAgICBpZiAoIW5vZGVBbmREZWZzW3Jlc3BvbnNlTmFtZV0pIHtcbiAgICAgICAgICBub2RlQW5kRGVmc1tyZXNwb25zZU5hbWVdID0gW107XG4gICAgICAgIH1cbiAgICAgICAgbm9kZUFuZERlZnNbcmVzcG9uc2VOYW1lXS5wdXNoKFtwYXJlbnRUeXBlLCBzZWxlY3Rpb24sIGZpZWxkRGVmXSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBLaW5kLkZSQUdNRU5UX1NQUkVBRDpcbiAgICAgICAgZnJhZ21lbnROYW1lc1tzZWxlY3Rpb24ubmFtZS52YWx1ZV0gPSB0cnVlO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgS2luZC5JTkxJTkVfRlJBR01FTlQ6IHtcbiAgICAgICAgY29uc3QgdHlwZUNvbmRpdGlvbiA9IHNlbGVjdGlvbi50eXBlQ29uZGl0aW9uO1xuICAgICAgICBjb25zdCBpbmxpbmVGcmFnbWVudFR5cGUgPSB0eXBlQ29uZGl0aW9uID8gdHlwZUZyb21BU1QoY29udGV4dC5nZXRTY2hlbWEoKSwgdHlwZUNvbmRpdGlvbikgOiBwYXJlbnRUeXBlO1xuICAgICAgICBfY29sbGVjdEZpZWxkc0FuZEZyYWdtZW50TmFtZXMoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBpbmxpbmVGcmFnbWVudFR5cGUsXG4gICAgICAgICAgc2VsZWN0aW9uLnNlbGVjdGlvblNldCxcbiAgICAgICAgICBub2RlQW5kRGVmcyxcbiAgICAgICAgICBmcmFnbWVudE5hbWVzXG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gc3ViZmllbGRDb25mbGljdHMoY29uZmxpY3RzLCByZXNwb25zZU5hbWUsIG5vZGUxLCBub2RlMikge1xuICBpZiAoY29uZmxpY3RzLmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4gW1xuICAgICAgW3Jlc3BvbnNlTmFtZSwgY29uZmxpY3RzLm1hcCgoW3JlYXNvbl0pID0+IHJlYXNvbildLFxuICAgICAgW25vZGUxLCAuLi5jb25mbGljdHMubWFwKChbLCBmaWVsZHMxXSkgPT4gZmllbGRzMSkuZmxhdCgpXSxcbiAgICAgIFtub2RlMiwgLi4uY29uZmxpY3RzLm1hcCgoWywgLCBmaWVsZHMyXSkgPT4gZmllbGRzMikuZmxhdCgpXVxuICAgIF07XG4gIH1cbn1cbnZhciBQYWlyU2V0ID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLl9kYXRhID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgfVxuICBoYXMoYSwgYiwgYXJlTXV0dWFsbHlFeGNsdXNpdmUpIHtcbiAgICB2YXIgX3RoaXMkX2RhdGEkZ2V0O1xuICAgIGNvbnN0IFtrZXkxLCBrZXkyXSA9IGEgPCBiID8gW2EsIGJdIDogW2IsIGFdO1xuICAgIGNvbnN0IHJlc3VsdCA9IChfdGhpcyRfZGF0YSRnZXQgPSB0aGlzLl9kYXRhLmdldChrZXkxKSkgPT09IG51bGwgfHwgX3RoaXMkX2RhdGEkZ2V0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyRfZGF0YSRnZXQuZ2V0KGtleTIpO1xuICAgIGlmIChyZXN1bHQgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gYXJlTXV0dWFsbHlFeGNsdXNpdmUgPyB0cnVlIDogYXJlTXV0dWFsbHlFeGNsdXNpdmUgPT09IHJlc3VsdDtcbiAgfVxuICBhZGQoYSwgYiwgYXJlTXV0dWFsbHlFeGNsdXNpdmUpIHtcbiAgICBjb25zdCBba2V5MSwga2V5Ml0gPSBhIDwgYiA/IFthLCBiXSA6IFtiLCBhXTtcbiAgICBjb25zdCBtYXAgPSB0aGlzLl9kYXRhLmdldChrZXkxKTtcbiAgICBpZiAobWFwID09PSB2b2lkIDApIHtcbiAgICAgIHRoaXMuX2RhdGEuc2V0KGtleTEsIC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKFtba2V5MiwgYXJlTXV0dWFsbHlFeGNsdXNpdmVdXSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBtYXAuc2V0KGtleTIsIGFyZU11dHVhbGx5RXhjbHVzaXZlKTtcbiAgICB9XG4gIH1cbn07XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1Bvc3NpYmxlRnJhZ21lbnRTcHJlYWRzUnVsZS5tanNcbmZ1bmN0aW9uIFBvc3NpYmxlRnJhZ21lbnRTcHJlYWRzUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgSW5saW5lRnJhZ21lbnQobm9kZSkge1xuICAgICAgY29uc3QgZnJhZ1R5cGUgPSBjb250ZXh0LmdldFR5cGUoKTtcbiAgICAgIGNvbnN0IHBhcmVudFR5cGUgPSBjb250ZXh0LmdldFBhcmVudFR5cGUoKTtcbiAgICAgIGlmIChpc0NvbXBvc2l0ZVR5cGUoZnJhZ1R5cGUpICYmIGlzQ29tcG9zaXRlVHlwZShwYXJlbnRUeXBlKSAmJiAhZG9UeXBlc092ZXJsYXAoY29udGV4dC5nZXRTY2hlbWEoKSwgZnJhZ1R5cGUsIHBhcmVudFR5cGUpKSB7XG4gICAgICAgIGNvbnN0IHBhcmVudFR5cGVTdHIgPSBpbnNwZWN0KHBhcmVudFR5cGUpO1xuICAgICAgICBjb25zdCBmcmFnVHlwZVN0ciA9IGluc3BlY3QoZnJhZ1R5cGUpO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRnJhZ21lbnQgY2Fubm90IGJlIHNwcmVhZCBoZXJlIGFzIG9iamVjdHMgb2YgdHlwZSBcIiR7cGFyZW50VHlwZVN0cn1cIiBjYW4gbmV2ZXIgYmUgb2YgdHlwZSBcIiR7ZnJhZ1R5cGVTdHJ9XCIuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSxcbiAgICBGcmFnbWVudFNwcmVhZChub2RlKSB7XG4gICAgICBjb25zdCBmcmFnTmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgIGNvbnN0IGZyYWdUeXBlID0gZ2V0RnJhZ21lbnRUeXBlKGNvbnRleHQsIGZyYWdOYW1lKTtcbiAgICAgIGNvbnN0IHBhcmVudFR5cGUgPSBjb250ZXh0LmdldFBhcmVudFR5cGUoKTtcbiAgICAgIGlmIChmcmFnVHlwZSAmJiBwYXJlbnRUeXBlICYmICFkb1R5cGVzT3ZlcmxhcChjb250ZXh0LmdldFNjaGVtYSgpLCBmcmFnVHlwZSwgcGFyZW50VHlwZSkpIHtcbiAgICAgICAgY29uc3QgcGFyZW50VHlwZVN0ciA9IGluc3BlY3QocGFyZW50VHlwZSk7XG4gICAgICAgIGNvbnN0IGZyYWdUeXBlU3RyID0gaW5zcGVjdChmcmFnVHlwZSk7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBGcmFnbWVudCBcIiR7ZnJhZ05hbWV9XCIgY2Fubm90IGJlIHNwcmVhZCBoZXJlIGFzIG9iamVjdHMgb2YgdHlwZSBcIiR7cGFyZW50VHlwZVN0cn1cIiBjYW4gbmV2ZXIgYmUgb2YgdHlwZSBcIiR7ZnJhZ1R5cGVTdHJ9XCIuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0RnJhZ21lbnRUeXBlKGNvbnRleHQsIG5hbWUpIHtcbiAgY29uc3QgZnJhZyA9IGNvbnRleHQuZ2V0RnJhZ21lbnQobmFtZSk7XG4gIGlmIChmcmFnKSB7XG4gICAgY29uc3QgdHlwZSA9IHR5cGVGcm9tQVNUKGNvbnRleHQuZ2V0U2NoZW1hKCksIGZyYWcudHlwZUNvbmRpdGlvbik7XG4gICAgaWYgKGlzQ29tcG9zaXRlVHlwZSh0eXBlKSkge1xuICAgICAgcmV0dXJuIHR5cGU7XG4gICAgfVxuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1Bvc3NpYmxlVHlwZUV4dGVuc2lvbnNSdWxlLm1qc1xuZnVuY3Rpb24gUG9zc2libGVUeXBlRXh0ZW5zaW9uc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBkZWZpbmVkVHlwZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgZm9yIChjb25zdCBkZWYgb2YgY29udGV4dC5nZXREb2N1bWVudCgpLmRlZmluaXRpb25zKSB7XG4gICAgaWYgKGlzVHlwZURlZmluaXRpb25Ob2RlKGRlZikpIHtcbiAgICAgIGRlZmluZWRUeXBlc1tkZWYubmFtZS52YWx1ZV0gPSBkZWY7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgU2NhbGFyVHlwZUV4dGVuc2lvbjogY2hlY2tFeHRlbnNpb24sXG4gICAgT2JqZWN0VHlwZUV4dGVuc2lvbjogY2hlY2tFeHRlbnNpb24sXG4gICAgSW50ZXJmYWNlVHlwZUV4dGVuc2lvbjogY2hlY2tFeHRlbnNpb24sXG4gICAgVW5pb25UeXBlRXh0ZW5zaW9uOiBjaGVja0V4dGVuc2lvbixcbiAgICBFbnVtVHlwZUV4dGVuc2lvbjogY2hlY2tFeHRlbnNpb24sXG4gICAgSW5wdXRPYmplY3RUeXBlRXh0ZW5zaW9uOiBjaGVja0V4dGVuc2lvblxuICB9O1xuICBmdW5jdGlvbiBjaGVja0V4dGVuc2lvbihub2RlKSB7XG4gICAgY29uc3QgdHlwZU5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgY29uc3QgZGVmTm9kZSA9IGRlZmluZWRUeXBlc1t0eXBlTmFtZV07XG4gICAgY29uc3QgZXhpc3RpbmdUeXBlID0gc2NoZW1hID09PSBudWxsIHx8IHNjaGVtYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2NoZW1hLmdldFR5cGUodHlwZU5hbWUpO1xuICAgIGxldCBleHBlY3RlZEtpbmQ7XG4gICAgaWYgKGRlZk5vZGUpIHtcbiAgICAgIGV4cGVjdGVkS2luZCA9IGRlZktpbmRUb0V4dEtpbmRbZGVmTm9kZS5raW5kXTtcbiAgICB9IGVsc2UgaWYgKGV4aXN0aW5nVHlwZSkge1xuICAgICAgZXhwZWN0ZWRLaW5kID0gdHlwZVRvRXh0S2luZChleGlzdGluZ1R5cGUpO1xuICAgIH1cbiAgICBpZiAoZXhwZWN0ZWRLaW5kKSB7XG4gICAgICBpZiAoZXhwZWN0ZWRLaW5kICE9PSBub2RlLmtpbmQpIHtcbiAgICAgICAgY29uc3Qga2luZFN0ciA9IGV4dGVuc2lvbktpbmRUb1R5cGVOYW1lKG5vZGUua2luZCk7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihgQ2Fubm90IGV4dGVuZCBub24tJHtraW5kU3RyfSB0eXBlIFwiJHt0eXBlTmFtZX1cIi5gLCB7XG4gICAgICAgICAgICBub2RlczogZGVmTm9kZSA/IFtkZWZOb2RlLCBub2RlXSA6IG5vZGVcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBhbGxUeXBlTmFtZXMgPSBPYmplY3Qua2V5cyh7XG4gICAgICAgIC4uLmRlZmluZWRUeXBlcyxcbiAgICAgICAgLi4uc2NoZW1hID09PSBudWxsIHx8IHNjaGVtYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2NoZW1hLmdldFR5cGVNYXAoKVxuICAgICAgfSk7XG4gICAgICBjb25zdCBzdWdnZXN0ZWRUeXBlcyA9IHN1Z2dlc3Rpb25MaXN0KHR5cGVOYW1lLCBhbGxUeXBlTmFtZXMpO1xuICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICBgQ2Fubm90IGV4dGVuZCB0eXBlIFwiJHt0eXBlTmFtZX1cIiBiZWNhdXNlIGl0IGlzIG5vdCBkZWZpbmVkLmAgKyBkaWRZb3VNZWFuKHN1Z2dlc3RlZFR5cGVzKSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBub2Rlczogbm9kZS5uYW1lXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICApO1xuICAgIH1cbiAgfVxufVxudmFyIGRlZktpbmRUb0V4dEtpbmQgPSB7XG4gIFtLaW5kLlNDQUxBUl9UWVBFX0RFRklOSVRJT05dOiBLaW5kLlNDQUxBUl9UWVBFX0VYVEVOU0lPTixcbiAgW0tpbmQuT0JKRUNUX1RZUEVfREVGSU5JVElPTl06IEtpbmQuT0JKRUNUX1RZUEVfRVhURU5TSU9OLFxuICBbS2luZC5JTlRFUkZBQ0VfVFlQRV9ERUZJTklUSU9OXTogS2luZC5JTlRFUkZBQ0VfVFlQRV9FWFRFTlNJT04sXG4gIFtLaW5kLlVOSU9OX1RZUEVfREVGSU5JVElPTl06IEtpbmQuVU5JT05fVFlQRV9FWFRFTlNJT04sXG4gIFtLaW5kLkVOVU1fVFlQRV9ERUZJTklUSU9OXTogS2luZC5FTlVNX1RZUEVfRVhURU5TSU9OLFxuICBbS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9ERUZJTklUSU9OXTogS2luZC5JTlBVVF9PQkpFQ1RfVFlQRV9FWFRFTlNJT05cbn07XG5mdW5jdGlvbiB0eXBlVG9FeHRLaW5kKHR5cGUpIHtcbiAgaWYgKGlzU2NhbGFyVHlwZSh0eXBlKSkge1xuICAgIHJldHVybiBLaW5kLlNDQUxBUl9UWVBFX0VYVEVOU0lPTjtcbiAgfVxuICBpZiAoaXNPYmplY3RUeXBlKHR5cGUpKSB7XG4gICAgcmV0dXJuIEtpbmQuT0JKRUNUX1RZUEVfRVhURU5TSU9OO1xuICB9XG4gIGlmIChpc0ludGVyZmFjZVR5cGUodHlwZSkpIHtcbiAgICByZXR1cm4gS2luZC5JTlRFUkZBQ0VfVFlQRV9FWFRFTlNJT047XG4gIH1cbiAgaWYgKGlzVW5pb25UeXBlKHR5cGUpKSB7XG4gICAgcmV0dXJuIEtpbmQuVU5JT05fVFlQRV9FWFRFTlNJT047XG4gIH1cbiAgaWYgKGlzRW51bVR5cGUodHlwZSkpIHtcbiAgICByZXR1cm4gS2luZC5FTlVNX1RZUEVfRVhURU5TSU9OO1xuICB9XG4gIGlmIChpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSkge1xuICAgIHJldHVybiBLaW5kLklOUFVUX09CSkVDVF9UWVBFX0VYVEVOU0lPTjtcbiAgfVxuICBpbnZhcmlhbnQyKGZhbHNlLCBcIlVuZXhwZWN0ZWQgdHlwZTogXCIgKyBpbnNwZWN0KHR5cGUpKTtcbn1cbmZ1bmN0aW9uIGV4dGVuc2lvbktpbmRUb1R5cGVOYW1lKGtpbmQpIHtcbiAgc3dpdGNoIChraW5kKSB7XG4gICAgY2FzZSBLaW5kLlNDQUxBUl9UWVBFX0VYVEVOU0lPTjpcbiAgICAgIHJldHVybiBcInNjYWxhclwiO1xuICAgIGNhc2UgS2luZC5PQkpFQ1RfVFlQRV9FWFRFTlNJT046XG4gICAgICByZXR1cm4gXCJvYmplY3RcIjtcbiAgICBjYXNlIEtpbmQuSU5URVJGQUNFX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIFwiaW50ZXJmYWNlXCI7XG4gICAgY2FzZSBLaW5kLlVOSU9OX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIFwidW5pb25cIjtcbiAgICBjYXNlIEtpbmQuRU5VTV9UWVBFX0VYVEVOU0lPTjpcbiAgICAgIHJldHVybiBcImVudW1cIjtcbiAgICBjYXNlIEtpbmQuSU5QVVRfT0JKRUNUX1RZUEVfRVhURU5TSU9OOlxuICAgICAgcmV0dXJuIFwiaW5wdXQgb2JqZWN0XCI7XG4gICAgZGVmYXVsdDpcbiAgICAgIGludmFyaWFudDIoZmFsc2UsIFwiVW5leHBlY3RlZCBraW5kOiBcIiArIGluc3BlY3Qoa2luZCkpO1xuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1Byb3ZpZGVkUmVxdWlyZWRBcmd1bWVudHNSdWxlLm1qc1xuZnVuY3Rpb24gUHJvdmlkZWRSZXF1aXJlZEFyZ3VtZW50c1J1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuZXctY2FwXG4gICAgLi4uUHJvdmlkZWRSZXF1aXJlZEFyZ3VtZW50c09uRGlyZWN0aXZlc1J1bGUoY29udGV4dCksXG4gICAgRmllbGQ6IHtcbiAgICAgIC8vIFZhbGlkYXRlIG9uIGxlYXZlIHRvIGFsbG93IGZvciBkZWVwZXIgZXJyb3JzIHRvIGFwcGVhciBmaXJzdC5cbiAgICAgIGxlYXZlKGZpZWxkTm9kZSkge1xuICAgICAgICB2YXIgX2ZpZWxkTm9kZSRhcmd1bWVudHM7XG4gICAgICAgIGNvbnN0IGZpZWxkRGVmID0gY29udGV4dC5nZXRGaWVsZERlZigpO1xuICAgICAgICBpZiAoIWZpZWxkRGVmKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHByb3ZpZGVkQXJncyA9IG5ldyBTZXQoXG4gICAgICAgICAgLy8gRklYTUU6IGh0dHBzOi8vZ2l0aHViLmNvbS9ncmFwaHFsL2dyYXBocWwtanMvaXNzdWVzLzIyMDNcbiAgICAgICAgICAvKiBjOCBpZ25vcmUgbmV4dCAqL1xuICAgICAgICAgIChfZmllbGROb2RlJGFyZ3VtZW50cyA9IGZpZWxkTm9kZS5hcmd1bWVudHMpID09PSBudWxsIHx8IF9maWVsZE5vZGUkYXJndW1lbnRzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZmllbGROb2RlJGFyZ3VtZW50cy5tYXAoKGFyZykgPT4gYXJnLm5hbWUudmFsdWUpXG4gICAgICAgICk7XG4gICAgICAgIGZvciAoY29uc3QgYXJnRGVmIG9mIGZpZWxkRGVmLmFyZ3MpIHtcbiAgICAgICAgICBpZiAoIXByb3ZpZGVkQXJncy5oYXMoYXJnRGVmLm5hbWUpICYmIGlzUmVxdWlyZWRBcmd1bWVudChhcmdEZWYpKSB7XG4gICAgICAgICAgICBjb25zdCBhcmdUeXBlU3RyID0gaW5zcGVjdChhcmdEZWYudHlwZSk7XG4gICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICAgIGBGaWVsZCBcIiR7ZmllbGREZWYubmFtZX1cIiBhcmd1bWVudCBcIiR7YXJnRGVmLm5hbWV9XCIgb2YgdHlwZSBcIiR7YXJnVHlwZVN0cn1cIiBpcyByZXF1aXJlZCwgYnV0IGl0IHdhcyBub3QgcHJvdmlkZWQuYCxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBub2RlczogZmllbGROb2RlXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIFByb3ZpZGVkUmVxdWlyZWRBcmd1bWVudHNPbkRpcmVjdGl2ZXNSdWxlKGNvbnRleHQpIHtcbiAgdmFyIF9zY2hlbWEkZ2V0RGlyZWN0aXZlcztcbiAgY29uc3QgcmVxdWlyZWRBcmdzTWFwID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IHNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gIGNvbnN0IGRlZmluZWREaXJlY3RpdmVzID0gKF9zY2hlbWEkZ2V0RGlyZWN0aXZlcyA9IHNjaGVtYSA9PT0gbnVsbCB8fCBzY2hlbWEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNjaGVtYS5nZXREaXJlY3RpdmVzKCkpICE9PSBudWxsICYmIF9zY2hlbWEkZ2V0RGlyZWN0aXZlcyAhPT0gdm9pZCAwID8gX3NjaGVtYSRnZXREaXJlY3RpdmVzIDogc3BlY2lmaWVkRGlyZWN0aXZlcztcbiAgZm9yIChjb25zdCBkaXJlY3RpdmUgb2YgZGVmaW5lZERpcmVjdGl2ZXMpIHtcbiAgICByZXF1aXJlZEFyZ3NNYXBbZGlyZWN0aXZlLm5hbWVdID0ga2V5TWFwKFxuICAgICAgZGlyZWN0aXZlLmFyZ3MuZmlsdGVyKGlzUmVxdWlyZWRBcmd1bWVudCksXG4gICAgICAoYXJnKSA9PiBhcmcubmFtZVxuICAgICk7XG4gIH1cbiAgY29uc3QgYXN0RGVmaW5pdGlvbnMgPSBjb250ZXh0LmdldERvY3VtZW50KCkuZGVmaW5pdGlvbnM7XG4gIGZvciAoY29uc3QgZGVmIG9mIGFzdERlZmluaXRpb25zKSB7XG4gICAgaWYgKGRlZi5raW5kID09PSBLaW5kLkRJUkVDVElWRV9ERUZJTklUSU9OKSB7XG4gICAgICB2YXIgX2RlZiRhcmd1bWVudHM7XG4gICAgICBjb25zdCBhcmdOb2RlcyA9IChfZGVmJGFyZ3VtZW50cyA9IGRlZi5hcmd1bWVudHMpICE9PSBudWxsICYmIF9kZWYkYXJndW1lbnRzICE9PSB2b2lkIDAgPyBfZGVmJGFyZ3VtZW50cyA6IFtdO1xuICAgICAgcmVxdWlyZWRBcmdzTWFwW2RlZi5uYW1lLnZhbHVlXSA9IGtleU1hcChcbiAgICAgICAgYXJnTm9kZXMuZmlsdGVyKGlzUmVxdWlyZWRBcmd1bWVudE5vZGUpLFxuICAgICAgICAoYXJnKSA9PiBhcmcubmFtZS52YWx1ZVxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBEaXJlY3RpdmU6IHtcbiAgICAgIC8vIFZhbGlkYXRlIG9uIGxlYXZlIHRvIGFsbG93IGZvciBkZWVwZXIgZXJyb3JzIHRvIGFwcGVhciBmaXJzdC5cbiAgICAgIGxlYXZlKGRpcmVjdGl2ZU5vZGUpIHtcbiAgICAgICAgY29uc3QgZGlyZWN0aXZlTmFtZSA9IGRpcmVjdGl2ZU5vZGUubmFtZS52YWx1ZTtcbiAgICAgICAgY29uc3QgcmVxdWlyZWRBcmdzID0gcmVxdWlyZWRBcmdzTWFwW2RpcmVjdGl2ZU5hbWVdO1xuICAgICAgICBpZiAocmVxdWlyZWRBcmdzKSB7XG4gICAgICAgICAgdmFyIF9kaXJlY3RpdmVOb2RlJGFyZ3VtZTtcbiAgICAgICAgICBjb25zdCBhcmdOb2RlcyA9IChfZGlyZWN0aXZlTm9kZSRhcmd1bWUgPSBkaXJlY3RpdmVOb2RlLmFyZ3VtZW50cykgIT09IG51bGwgJiYgX2RpcmVjdGl2ZU5vZGUkYXJndW1lICE9PSB2b2lkIDAgPyBfZGlyZWN0aXZlTm9kZSRhcmd1bWUgOiBbXTtcbiAgICAgICAgICBjb25zdCBhcmdOb2RlTWFwID0gbmV3IFNldChhcmdOb2Rlcy5tYXAoKGFyZykgPT4gYXJnLm5hbWUudmFsdWUpKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IFthcmdOYW1lLCBhcmdEZWZdIG9mIE9iamVjdC5lbnRyaWVzKHJlcXVpcmVkQXJncykpIHtcbiAgICAgICAgICAgIGlmICghYXJnTm9kZU1hcC5oYXMoYXJnTmFtZSkpIHtcbiAgICAgICAgICAgICAgY29uc3QgYXJnVHlwZSA9IGlzVHlwZShhcmdEZWYudHlwZSkgPyBpbnNwZWN0KGFyZ0RlZi50eXBlKSA6IHByaW50KGFyZ0RlZi50eXBlKTtcbiAgICAgICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICAgICAgYERpcmVjdGl2ZSBcIkAke2RpcmVjdGl2ZU5hbWV9XCIgYXJndW1lbnQgXCIke2FyZ05hbWV9XCIgb2YgdHlwZSBcIiR7YXJnVHlwZX1cIiBpcyByZXF1aXJlZCwgYnV0IGl0IHdhcyBub3QgcHJvdmlkZWQuYCxcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbm9kZXM6IGRpcmVjdGl2ZU5vZGVcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gaXNSZXF1aXJlZEFyZ3VtZW50Tm9kZShhcmcpIHtcbiAgcmV0dXJuIGFyZy50eXBlLmtpbmQgPT09IEtpbmQuTk9OX05VTExfVFlQRSAmJiBhcmcuZGVmYXVsdFZhbHVlID09IG51bGw7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1NjYWxhckxlYWZzUnVsZS5tanNcbmZ1bmN0aW9uIFNjYWxhckxlYWZzUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgRmllbGQobm9kZSkge1xuICAgICAgY29uc3QgdHlwZSA9IGNvbnRleHQuZ2V0VHlwZSgpO1xuICAgICAgY29uc3Qgc2VsZWN0aW9uU2V0ID0gbm9kZS5zZWxlY3Rpb25TZXQ7XG4gICAgICBpZiAodHlwZSkge1xuICAgICAgICBpZiAoaXNMZWFmVHlwZShnZXROYW1lZFR5cGUodHlwZSkpKSB7XG4gICAgICAgICAgaWYgKHNlbGVjdGlvblNldCkge1xuICAgICAgICAgICAgY29uc3QgZmllbGROYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgICAgICAgY29uc3QgdHlwZVN0ciA9IGluc3BlY3QodHlwZSk7XG4gICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICAgIGBGaWVsZCBcIiR7ZmllbGROYW1lfVwiIG11c3Qgbm90IGhhdmUgYSBzZWxlY3Rpb24gc2luY2UgdHlwZSBcIiR7dHlwZVN0cn1cIiBoYXMgbm8gc3ViZmllbGRzLmAsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbm9kZXM6IHNlbGVjdGlvblNldFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoIXNlbGVjdGlvblNldCkge1xuICAgICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgICAgICBjb25zdCB0eXBlU3RyID0gaW5zcGVjdCh0eXBlKTtcbiAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgYEZpZWxkIFwiJHtmaWVsZE5hbWV9XCIgb2YgdHlwZSBcIiR7dHlwZVN0cn1cIiBtdXN0IGhhdmUgYSBzZWxlY3Rpb24gb2Ygc3ViZmllbGRzLiBEaWQgeW91IG1lYW4gXCIke2ZpZWxkTmFtZX0geyAuLi4gfVwiP2AsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBub2Rlczogbm9kZVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3V0aWxpdGllcy92YWx1ZUZyb21BU1QubWpzXG5mdW5jdGlvbiB2YWx1ZUZyb21BU1QodmFsdWVOb2RlLCB0eXBlLCB2YXJpYWJsZXMpIHtcbiAgaWYgKCF2YWx1ZU5vZGUpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHZhbHVlTm9kZS5raW5kID09PSBLaW5kLlZBUklBQkxFKSB7XG4gICAgY29uc3QgdmFyaWFibGVOYW1lID0gdmFsdWVOb2RlLm5hbWUudmFsdWU7XG4gICAgaWYgKHZhcmlhYmxlcyA9PSBudWxsIHx8IHZhcmlhYmxlc1t2YXJpYWJsZU5hbWVdID09PSB2b2lkIDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgdmFyaWFibGVWYWx1ZSA9IHZhcmlhYmxlc1t2YXJpYWJsZU5hbWVdO1xuICAgIGlmICh2YXJpYWJsZVZhbHVlID09PSBudWxsICYmIGlzTm9uTnVsbFR5cGUodHlwZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmV0dXJuIHZhcmlhYmxlVmFsdWU7XG4gIH1cbiAgaWYgKGlzTm9uTnVsbFR5cGUodHlwZSkpIHtcbiAgICBpZiAodmFsdWVOb2RlLmtpbmQgPT09IEtpbmQuTlVMTCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWVGcm9tQVNUKHZhbHVlTm9kZSwgdHlwZS5vZlR5cGUsIHZhcmlhYmxlcyk7XG4gIH1cbiAgaWYgKHZhbHVlTm9kZS5raW5kID09PSBLaW5kLk5VTEwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoaXNMaXN0VHlwZSh0eXBlKSkge1xuICAgIGNvbnN0IGl0ZW1UeXBlID0gdHlwZS5vZlR5cGU7XG4gICAgaWYgKHZhbHVlTm9kZS5raW5kID09PSBLaW5kLkxJU1QpIHtcbiAgICAgIGNvbnN0IGNvZXJjZWRWYWx1ZXMgPSBbXTtcbiAgICAgIGZvciAoY29uc3QgaXRlbU5vZGUgb2YgdmFsdWVOb2RlLnZhbHVlcykge1xuICAgICAgICBpZiAoaXNNaXNzaW5nVmFyaWFibGUoaXRlbU5vZGUsIHZhcmlhYmxlcykpIHtcbiAgICAgICAgICBpZiAoaXNOb25OdWxsVHlwZShpdGVtVHlwZSkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29lcmNlZFZhbHVlcy5wdXNoKG51bGwpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGl0ZW1WYWx1ZSA9IHZhbHVlRnJvbUFTVChpdGVtTm9kZSwgaXRlbVR5cGUsIHZhcmlhYmxlcyk7XG4gICAgICAgICAgaWYgKGl0ZW1WYWx1ZSA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvZXJjZWRWYWx1ZXMucHVzaChpdGVtVmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY29lcmNlZFZhbHVlcztcbiAgICB9XG4gICAgY29uc3QgY29lcmNlZFZhbHVlID0gdmFsdWVGcm9tQVNUKHZhbHVlTm9kZSwgaXRlbVR5cGUsIHZhcmlhYmxlcyk7XG4gICAgaWYgKGNvZXJjZWRWYWx1ZSA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJldHVybiBbY29lcmNlZFZhbHVlXTtcbiAgfVxuICBpZiAoaXNJbnB1dE9iamVjdFR5cGUodHlwZSkpIHtcbiAgICBpZiAodmFsdWVOb2RlLmtpbmQgIT09IEtpbmQuT0JKRUNUKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNvZXJjZWRPYmogPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICBjb25zdCBmaWVsZE5vZGVzID0ga2V5TWFwKHZhbHVlTm9kZS5maWVsZHMsIChmaWVsZCkgPT4gZmllbGQubmFtZS52YWx1ZSk7XG4gICAgZm9yIChjb25zdCBmaWVsZCBvZiBPYmplY3QudmFsdWVzKHR5cGUuZ2V0RmllbGRzKCkpKSB7XG4gICAgICBjb25zdCBmaWVsZE5vZGUgPSBmaWVsZE5vZGVzW2ZpZWxkLm5hbWVdO1xuICAgICAgaWYgKCFmaWVsZE5vZGUgfHwgaXNNaXNzaW5nVmFyaWFibGUoZmllbGROb2RlLnZhbHVlLCB2YXJpYWJsZXMpKSB7XG4gICAgICAgIGlmIChmaWVsZC5kZWZhdWx0VmFsdWUgIT09IHZvaWQgMCkge1xuICAgICAgICAgIGNvZXJjZWRPYmpbZmllbGQubmFtZV0gPSBmaWVsZC5kZWZhdWx0VmFsdWU7XG4gICAgICAgIH0gZWxzZSBpZiAoaXNOb25OdWxsVHlwZShmaWVsZC50eXBlKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZpZWxkVmFsdWUgPSB2YWx1ZUZyb21BU1QoZmllbGROb2RlLnZhbHVlLCBmaWVsZC50eXBlLCB2YXJpYWJsZXMpO1xuICAgICAgaWYgKGZpZWxkVmFsdWUgPT09IHZvaWQgMCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb2VyY2VkT2JqW2ZpZWxkLm5hbWVdID0gZmllbGRWYWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGNvZXJjZWRPYmo7XG4gIH1cbiAgaWYgKGlzTGVhZlR5cGUodHlwZSkpIHtcbiAgICBsZXQgcmVzdWx0O1xuICAgIHRyeSB7XG4gICAgICByZXN1bHQgPSB0eXBlLnBhcnNlTGl0ZXJhbCh2YWx1ZU5vZGUsIHZhcmlhYmxlcyk7XG4gICAgfSBjYXRjaCAoX2Vycm9yKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChyZXN1bHQgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGludmFyaWFudDIoZmFsc2UsIFwiVW5leHBlY3RlZCBpbnB1dCB0eXBlOiBcIiArIGluc3BlY3QodHlwZSkpO1xufVxuZnVuY3Rpb24gaXNNaXNzaW5nVmFyaWFibGUodmFsdWVOb2RlLCB2YXJpYWJsZXMpIHtcbiAgcmV0dXJuIHZhbHVlTm9kZS5raW5kID09PSBLaW5kLlZBUklBQkxFICYmICh2YXJpYWJsZXMgPT0gbnVsbCB8fCB2YXJpYWJsZXNbdmFsdWVOb2RlLm5hbWUudmFsdWVdID09PSB2b2lkIDApO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvZXhlY3V0aW9uL3ZhbHVlcy5tanNcbmZ1bmN0aW9uIGdldEFyZ3VtZW50VmFsdWVzKGRlZiwgbm9kZSwgdmFyaWFibGVWYWx1ZXMpIHtcbiAgdmFyIF9ub2RlJGFyZ3VtZW50cztcbiAgY29uc3QgY29lcmNlZFZhbHVlcyA9IHt9O1xuICBjb25zdCBhcmd1bWVudE5vZGVzID0gKF9ub2RlJGFyZ3VtZW50cyA9IG5vZGUuYXJndW1lbnRzKSAhPT0gbnVsbCAmJiBfbm9kZSRhcmd1bWVudHMgIT09IHZvaWQgMCA/IF9ub2RlJGFyZ3VtZW50cyA6IFtdO1xuICBjb25zdCBhcmdOb2RlTWFwID0ga2V5TWFwKGFyZ3VtZW50Tm9kZXMsIChhcmcpID0+IGFyZy5uYW1lLnZhbHVlKTtcbiAgZm9yIChjb25zdCBhcmdEZWYgb2YgZGVmLmFyZ3MpIHtcbiAgICBjb25zdCBuYW1lID0gYXJnRGVmLm5hbWU7XG4gICAgY29uc3QgYXJnVHlwZSA9IGFyZ0RlZi50eXBlO1xuICAgIGNvbnN0IGFyZ3VtZW50Tm9kZSA9IGFyZ05vZGVNYXBbbmFtZV07XG4gICAgaWYgKCFhcmd1bWVudE5vZGUpIHtcbiAgICAgIGlmIChhcmdEZWYuZGVmYXVsdFZhbHVlICE9PSB2b2lkIDApIHtcbiAgICAgICAgY29lcmNlZFZhbHVlc1tuYW1lXSA9IGFyZ0RlZi5kZWZhdWx0VmFsdWU7XG4gICAgICB9IGVsc2UgaWYgKGlzTm9uTnVsbFR5cGUoYXJnVHlwZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICBgQXJndW1lbnQgXCIke25hbWV9XCIgb2YgcmVxdWlyZWQgdHlwZSBcIiR7aW5zcGVjdChhcmdUeXBlKX1cIiB3YXMgbm90IHByb3ZpZGVkLmAsXG4gICAgICAgICAge1xuICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgdmFsdWVOb2RlID0gYXJndW1lbnROb2RlLnZhbHVlO1xuICAgIGxldCBpc051bGwgPSB2YWx1ZU5vZGUua2luZCA9PT0gS2luZC5OVUxMO1xuICAgIGlmICh2YWx1ZU5vZGUua2luZCA9PT0gS2luZC5WQVJJQUJMRSkge1xuICAgICAgY29uc3QgdmFyaWFibGVOYW1lID0gdmFsdWVOb2RlLm5hbWUudmFsdWU7XG4gICAgICBpZiAodmFyaWFibGVWYWx1ZXMgPT0gbnVsbCB8fCAhaGFzT3duUHJvcGVydHkodmFyaWFibGVWYWx1ZXMsIHZhcmlhYmxlTmFtZSkpIHtcbiAgICAgICAgaWYgKGFyZ0RlZi5kZWZhdWx0VmFsdWUgIT09IHZvaWQgMCkge1xuICAgICAgICAgIGNvZXJjZWRWYWx1ZXNbbmFtZV0gPSBhcmdEZWYuZGVmYXVsdFZhbHVlO1xuICAgICAgICB9IGVsc2UgaWYgKGlzTm9uTnVsbFR5cGUoYXJnVHlwZSkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYEFyZ3VtZW50IFwiJHtuYW1lfVwiIG9mIHJlcXVpcmVkIHR5cGUgXCIke2luc3BlY3QoYXJnVHlwZSl9XCIgd2FzIHByb3ZpZGVkIHRoZSB2YXJpYWJsZSBcIiQke3ZhcmlhYmxlTmFtZX1cIiB3aGljaCB3YXMgbm90IHByb3ZpZGVkIGEgcnVudGltZSB2YWx1ZS5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlzTnVsbCA9IHZhcmlhYmxlVmFsdWVzW3ZhcmlhYmxlTmFtZV0gPT0gbnVsbDtcbiAgICB9XG4gICAgaWYgKGlzTnVsbCAmJiBpc05vbk51bGxUeXBlKGFyZ1R5cGUpKSB7XG4gICAgICB0aHJvdyBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICBgQXJndW1lbnQgXCIke25hbWV9XCIgb2Ygbm9uLW51bGwgdHlwZSBcIiR7aW5zcGVjdChhcmdUeXBlKX1cIiBtdXN0IG5vdCBiZSBudWxsLmAsXG4gICAgICAgIHtcbiAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IGNvZXJjZWRWYWx1ZSA9IHZhbHVlRnJvbUFTVCh2YWx1ZU5vZGUsIGFyZ1R5cGUsIHZhcmlhYmxlVmFsdWVzKTtcbiAgICBpZiAoY29lcmNlZFZhbHVlID09PSB2b2lkIDApIHtcbiAgICAgIHRocm93IG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgIGBBcmd1bWVudCBcIiR7bmFtZX1cIiBoYXMgaW52YWxpZCB2YWx1ZSAke3ByaW50KHZhbHVlTm9kZSl9LmAsXG4gICAgICAgIHtcbiAgICAgICAgICBub2RlczogdmFsdWVOb2RlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIGNvZXJjZWRWYWx1ZXNbbmFtZV0gPSBjb2VyY2VkVmFsdWU7XG4gIH1cbiAgcmV0dXJuIGNvZXJjZWRWYWx1ZXM7XG59XG5mdW5jdGlvbiBnZXREaXJlY3RpdmVWYWx1ZXMoZGlyZWN0aXZlRGVmLCBub2RlLCB2YXJpYWJsZVZhbHVlcykge1xuICB2YXIgX25vZGUkZGlyZWN0aXZlcztcbiAgY29uc3QgZGlyZWN0aXZlTm9kZSA9IChfbm9kZSRkaXJlY3RpdmVzID0gbm9kZS5kaXJlY3RpdmVzKSA9PT0gbnVsbCB8fCBfbm9kZSRkaXJlY3RpdmVzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfbm9kZSRkaXJlY3RpdmVzLmZpbmQoXG4gICAgKGRpcmVjdGl2ZSkgPT4gZGlyZWN0aXZlLm5hbWUudmFsdWUgPT09IGRpcmVjdGl2ZURlZi5uYW1lXG4gICk7XG4gIGlmIChkaXJlY3RpdmVOb2RlKSB7XG4gICAgcmV0dXJuIGdldEFyZ3VtZW50VmFsdWVzKGRpcmVjdGl2ZURlZiwgZGlyZWN0aXZlTm9kZSwgdmFyaWFibGVWYWx1ZXMpO1xuICB9XG59XG5mdW5jdGlvbiBoYXNPd25Qcm9wZXJ0eShvYmosIHByb3ApIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvZXhlY3V0aW9uL2NvbGxlY3RGaWVsZHMubWpzXG5mdW5jdGlvbiBjb2xsZWN0RmllbGRzKHNjaGVtYSwgZnJhZ21lbnRzLCB2YXJpYWJsZVZhbHVlcywgcnVudGltZVR5cGUsIHNlbGVjdGlvblNldCkge1xuICBjb25zdCBmaWVsZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBjb2xsZWN0RmllbGRzSW1wbChcbiAgICBzY2hlbWEsXG4gICAgZnJhZ21lbnRzLFxuICAgIHZhcmlhYmxlVmFsdWVzLFxuICAgIHJ1bnRpbWVUeXBlLFxuICAgIHNlbGVjdGlvblNldCxcbiAgICBmaWVsZHMsXG4gICAgLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKVxuICApO1xuICByZXR1cm4gZmllbGRzO1xufVxuZnVuY3Rpb24gY29sbGVjdFN1YmZpZWxkcyhzY2hlbWEsIGZyYWdtZW50cywgdmFyaWFibGVWYWx1ZXMsIHJldHVyblR5cGUsIGZpZWxkTm9kZXMpIHtcbiAgY29uc3Qgc3ViRmllbGROb2RlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIGNvbnN0IHZpc2l0ZWRGcmFnbWVudE5hbWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgZm9yIChjb25zdCBub2RlIG9mIGZpZWxkTm9kZXMpIHtcbiAgICBpZiAobm9kZS5zZWxlY3Rpb25TZXQpIHtcbiAgICAgIGNvbGxlY3RGaWVsZHNJbXBsKFxuICAgICAgICBzY2hlbWEsXG4gICAgICAgIGZyYWdtZW50cyxcbiAgICAgICAgdmFyaWFibGVWYWx1ZXMsXG4gICAgICAgIHJldHVyblR5cGUsXG4gICAgICAgIG5vZGUuc2VsZWN0aW9uU2V0LFxuICAgICAgICBzdWJGaWVsZE5vZGVzLFxuICAgICAgICB2aXNpdGVkRnJhZ21lbnROYW1lc1xuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN1YkZpZWxkTm9kZXM7XG59XG5mdW5jdGlvbiBjb2xsZWN0RmllbGRzSW1wbChzY2hlbWEsIGZyYWdtZW50cywgdmFyaWFibGVWYWx1ZXMsIHJ1bnRpbWVUeXBlLCBzZWxlY3Rpb25TZXQsIGZpZWxkcywgdmlzaXRlZEZyYWdtZW50TmFtZXMpIHtcbiAgZm9yIChjb25zdCBzZWxlY3Rpb24gb2Ygc2VsZWN0aW9uU2V0LnNlbGVjdGlvbnMpIHtcbiAgICBzd2l0Y2ggKHNlbGVjdGlvbi5raW5kKSB7XG4gICAgICBjYXNlIEtpbmQuRklFTEQ6IHtcbiAgICAgICAgaWYgKCFzaG91bGRJbmNsdWRlTm9kZSh2YXJpYWJsZVZhbHVlcywgc2VsZWN0aW9uKSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5hbWUgPSBnZXRGaWVsZEVudHJ5S2V5KHNlbGVjdGlvbik7XG4gICAgICAgIGNvbnN0IGZpZWxkTGlzdCA9IGZpZWxkcy5nZXQobmFtZSk7XG4gICAgICAgIGlmIChmaWVsZExpc3QgIT09IHZvaWQgMCkge1xuICAgICAgICAgIGZpZWxkTGlzdC5wdXNoKHNlbGVjdGlvbik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZmllbGRzLnNldChuYW1lLCBbc2VsZWN0aW9uXSk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIEtpbmQuSU5MSU5FX0ZSQUdNRU5UOiB7XG4gICAgICAgIGlmICghc2hvdWxkSW5jbHVkZU5vZGUodmFyaWFibGVWYWx1ZXMsIHNlbGVjdGlvbikgfHwgIWRvZXNGcmFnbWVudENvbmRpdGlvbk1hdGNoKHNjaGVtYSwgc2VsZWN0aW9uLCBydW50aW1lVHlwZSkpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb2xsZWN0RmllbGRzSW1wbChcbiAgICAgICAgICBzY2hlbWEsXG4gICAgICAgICAgZnJhZ21lbnRzLFxuICAgICAgICAgIHZhcmlhYmxlVmFsdWVzLFxuICAgICAgICAgIHJ1bnRpbWVUeXBlLFxuICAgICAgICAgIHNlbGVjdGlvbi5zZWxlY3Rpb25TZXQsXG4gICAgICAgICAgZmllbGRzLFxuICAgICAgICAgIHZpc2l0ZWRGcmFnbWVudE5hbWVzXG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBLaW5kLkZSQUdNRU5UX1NQUkVBRDoge1xuICAgICAgICBjb25zdCBmcmFnTmFtZSA9IHNlbGVjdGlvbi5uYW1lLnZhbHVlO1xuICAgICAgICBpZiAodmlzaXRlZEZyYWdtZW50TmFtZXMuaGFzKGZyYWdOYW1lKSB8fCAhc2hvdWxkSW5jbHVkZU5vZGUodmFyaWFibGVWYWx1ZXMsIHNlbGVjdGlvbikpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB2aXNpdGVkRnJhZ21lbnROYW1lcy5hZGQoZnJhZ05hbWUpO1xuICAgICAgICBjb25zdCBmcmFnbWVudCA9IGZyYWdtZW50c1tmcmFnTmFtZV07XG4gICAgICAgIGlmICghZnJhZ21lbnQgfHwgIWRvZXNGcmFnbWVudENvbmRpdGlvbk1hdGNoKHNjaGVtYSwgZnJhZ21lbnQsIHJ1bnRpbWVUeXBlKSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbGxlY3RGaWVsZHNJbXBsKFxuICAgICAgICAgIHNjaGVtYSxcbiAgICAgICAgICBmcmFnbWVudHMsXG4gICAgICAgICAgdmFyaWFibGVWYWx1ZXMsXG4gICAgICAgICAgcnVudGltZVR5cGUsXG4gICAgICAgICAgZnJhZ21lbnQuc2VsZWN0aW9uU2V0LFxuICAgICAgICAgIGZpZWxkcyxcbiAgICAgICAgICB2aXNpdGVkRnJhZ21lbnROYW1lc1xuICAgICAgICApO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHNob3VsZEluY2x1ZGVOb2RlKHZhcmlhYmxlVmFsdWVzLCBub2RlKSB7XG4gIGNvbnN0IHNraXAgPSBnZXREaXJlY3RpdmVWYWx1ZXMoR3JhcGhRTFNraXBEaXJlY3RpdmUsIG5vZGUsIHZhcmlhYmxlVmFsdWVzKTtcbiAgaWYgKChza2lwID09PSBudWxsIHx8IHNraXAgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNraXAuaWYpID09PSB0cnVlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGNvbnN0IGluY2x1ZGUgPSBnZXREaXJlY3RpdmVWYWx1ZXMoXG4gICAgR3JhcGhRTEluY2x1ZGVEaXJlY3RpdmUsXG4gICAgbm9kZSxcbiAgICB2YXJpYWJsZVZhbHVlc1xuICApO1xuICBpZiAoKGluY2x1ZGUgPT09IG51bGwgfHwgaW5jbHVkZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogaW5jbHVkZS5pZikgPT09IGZhbHNlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gZG9lc0ZyYWdtZW50Q29uZGl0aW9uTWF0Y2goc2NoZW1hLCBmcmFnbWVudCwgdHlwZSkge1xuICBjb25zdCB0eXBlQ29uZGl0aW9uTm9kZSA9IGZyYWdtZW50LnR5cGVDb25kaXRpb247XG4gIGlmICghdHlwZUNvbmRpdGlvbk5vZGUpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBjb25zdCBjb25kaXRpb25hbFR5cGUgPSB0eXBlRnJvbUFTVChzY2hlbWEsIHR5cGVDb25kaXRpb25Ob2RlKTtcbiAgaWYgKGNvbmRpdGlvbmFsVHlwZSA9PT0gdHlwZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChpc0Fic3RyYWN0VHlwZShjb25kaXRpb25hbFR5cGUpKSB7XG4gICAgcmV0dXJuIHNjaGVtYS5pc1N1YlR5cGUoY29uZGl0aW9uYWxUeXBlLCB0eXBlKTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBnZXRGaWVsZEVudHJ5S2V5KG5vZGUpIHtcbiAgcmV0dXJuIG5vZGUuYWxpYXMgPyBub2RlLmFsaWFzLnZhbHVlIDogbm9kZS5uYW1lLnZhbHVlO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9TaW5nbGVGaWVsZFN1YnNjcmlwdGlvbnNSdWxlLm1qc1xuZnVuY3Rpb24gU2luZ2xlRmllbGRTdWJzY3JpcHRpb25zUnVsZShjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgT3BlcmF0aW9uRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBpZiAobm9kZS5vcGVyYXRpb24gPT09IFwic3Vic2NyaXB0aW9uXCIpIHtcbiAgICAgICAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgICAgICAgY29uc3Qgc3Vic2NyaXB0aW9uVHlwZSA9IHNjaGVtYS5nZXRTdWJzY3JpcHRpb25UeXBlKCk7XG4gICAgICAgIGlmIChzdWJzY3JpcHRpb25UeXBlKSB7XG4gICAgICAgICAgY29uc3Qgb3BlcmF0aW9uTmFtZSA9IG5vZGUubmFtZSA/IG5vZGUubmFtZS52YWx1ZSA6IG51bGw7XG4gICAgICAgICAgY29uc3QgdmFyaWFibGVWYWx1ZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgICBjb25zdCBkb2N1bWVudDIgPSBjb250ZXh0LmdldERvY3VtZW50KCk7XG4gICAgICAgICAgY29uc3QgZnJhZ21lbnRzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgICAgZm9yIChjb25zdCBkZWZpbml0aW9uIG9mIGRvY3VtZW50Mi5kZWZpbml0aW9ucykge1xuICAgICAgICAgICAgaWYgKGRlZmluaXRpb24ua2luZCA9PT0gS2luZC5GUkFHTUVOVF9ERUZJTklUSU9OKSB7XG4gICAgICAgICAgICAgIGZyYWdtZW50c1tkZWZpbml0aW9uLm5hbWUudmFsdWVdID0gZGVmaW5pdGlvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgZmllbGRzID0gY29sbGVjdEZpZWxkcyhcbiAgICAgICAgICAgIHNjaGVtYSxcbiAgICAgICAgICAgIGZyYWdtZW50cyxcbiAgICAgICAgICAgIHZhcmlhYmxlVmFsdWVzLFxuICAgICAgICAgICAgc3Vic2NyaXB0aW9uVHlwZSxcbiAgICAgICAgICAgIG5vZGUuc2VsZWN0aW9uU2V0XG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAoZmllbGRzLnNpemUgPiAxKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZFNlbGVjdGlvbkxpc3RzID0gWy4uLmZpZWxkcy52YWx1ZXMoKV07XG4gICAgICAgICAgICBjb25zdCBleHRyYUZpZWxkU2VsZWN0aW9uTGlzdHMgPSBmaWVsZFNlbGVjdGlvbkxpc3RzLnNsaWNlKDEpO1xuICAgICAgICAgICAgY29uc3QgZXh0cmFGaWVsZFNlbGVjdGlvbnMgPSBleHRyYUZpZWxkU2VsZWN0aW9uTGlzdHMuZmxhdCgpO1xuICAgICAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgICBvcGVyYXRpb25OYW1lICE9IG51bGwgPyBgU3Vic2NyaXB0aW9uIFwiJHtvcGVyYXRpb25OYW1lfVwiIG11c3Qgc2VsZWN0IG9ubHkgb25lIHRvcCBsZXZlbCBmaWVsZC5gIDogXCJBbm9ueW1vdXMgU3Vic2NyaXB0aW9uIG11c3Qgc2VsZWN0IG9ubHkgb25lIHRvcCBsZXZlbCBmaWVsZC5cIixcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBub2RlczogZXh0cmFGaWVsZFNlbGVjdGlvbnNcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGZvciAoY29uc3QgZmllbGROb2RlcyBvZiBmaWVsZHMudmFsdWVzKCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZmllbGROb2Rlc1swXTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IGZpZWxkLm5hbWUudmFsdWU7XG4gICAgICAgICAgICBpZiAoZmllbGROYW1lLnN0YXJ0c1dpdGgoXCJfX1wiKSkge1xuICAgICAgICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgICAgICBvcGVyYXRpb25OYW1lICE9IG51bGwgPyBgU3Vic2NyaXB0aW9uIFwiJHtvcGVyYXRpb25OYW1lfVwiIG11c3Qgbm90IHNlbGVjdCBhbiBpbnRyb3NwZWN0aW9uIHRvcCBsZXZlbCBmaWVsZC5gIDogXCJBbm9ueW1vdXMgU3Vic2NyaXB0aW9uIG11c3Qgbm90IHNlbGVjdCBhbiBpbnRyb3NwZWN0aW9uIHRvcCBsZXZlbCBmaWVsZC5cIixcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbm9kZXM6IGZpZWxkTm9kZXNcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvanN1dGlscy9ncm91cEJ5Lm1qc1xuZnVuY3Rpb24gZ3JvdXBCeShsaXN0LCBrZXlGbikge1xuICBjb25zdCByZXN1bHQgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBmb3IgKGNvbnN0IGl0ZW0gb2YgbGlzdCkge1xuICAgIGNvbnN0IGtleSA9IGtleUZuKGl0ZW0pO1xuICAgIGNvbnN0IGdyb3VwID0gcmVzdWx0LmdldChrZXkpO1xuICAgIGlmIChncm91cCA9PT0gdm9pZCAwKSB7XG4gICAgICByZXN1bHQuc2V0KGtleSwgW2l0ZW1dKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ3JvdXAucHVzaChpdGVtKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVW5pcXVlQXJndW1lbnREZWZpbml0aW9uTmFtZXNSdWxlLm1qc1xuZnVuY3Rpb24gVW5pcXVlQXJndW1lbnREZWZpbml0aW9uTmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBEaXJlY3RpdmVEZWZpbml0aW9uKGRpcmVjdGl2ZU5vZGUpIHtcbiAgICAgIHZhciBfZGlyZWN0aXZlTm9kZSRhcmd1bWU7XG4gICAgICBjb25zdCBhcmd1bWVudE5vZGVzID0gKF9kaXJlY3RpdmVOb2RlJGFyZ3VtZSA9IGRpcmVjdGl2ZU5vZGUuYXJndW1lbnRzKSAhPT0gbnVsbCAmJiBfZGlyZWN0aXZlTm9kZSRhcmd1bWUgIT09IHZvaWQgMCA/IF9kaXJlY3RpdmVOb2RlJGFyZ3VtZSA6IFtdO1xuICAgICAgcmV0dXJuIGNoZWNrQXJnVW5pcXVlbmVzcyhgQCR7ZGlyZWN0aXZlTm9kZS5uYW1lLnZhbHVlfWAsIGFyZ3VtZW50Tm9kZXMpO1xuICAgIH0sXG4gICAgSW50ZXJmYWNlVHlwZURlZmluaXRpb246IGNoZWNrQXJnVW5pcXVlbmVzc1BlckZpZWxkLFxuICAgIEludGVyZmFjZVR5cGVFeHRlbnNpb246IGNoZWNrQXJnVW5pcXVlbmVzc1BlckZpZWxkLFxuICAgIE9iamVjdFR5cGVEZWZpbml0aW9uOiBjaGVja0FyZ1VuaXF1ZW5lc3NQZXJGaWVsZCxcbiAgICBPYmplY3RUeXBlRXh0ZW5zaW9uOiBjaGVja0FyZ1VuaXF1ZW5lc3NQZXJGaWVsZFxuICB9O1xuICBmdW5jdGlvbiBjaGVja0FyZ1VuaXF1ZW5lc3NQZXJGaWVsZCh0eXBlTm9kZSkge1xuICAgIHZhciBfdHlwZU5vZGUkZmllbGRzO1xuICAgIGNvbnN0IHR5cGVOYW1lID0gdHlwZU5vZGUubmFtZS52YWx1ZTtcbiAgICBjb25zdCBmaWVsZE5vZGVzID0gKF90eXBlTm9kZSRmaWVsZHMgPSB0eXBlTm9kZS5maWVsZHMpICE9PSBudWxsICYmIF90eXBlTm9kZSRmaWVsZHMgIT09IHZvaWQgMCA/IF90eXBlTm9kZSRmaWVsZHMgOiBbXTtcbiAgICBmb3IgKGNvbnN0IGZpZWxkRGVmIG9mIGZpZWxkTm9kZXMpIHtcbiAgICAgIHZhciBfZmllbGREZWYkYXJndW1lbnRzO1xuICAgICAgY29uc3QgZmllbGROYW1lID0gZmllbGREZWYubmFtZS52YWx1ZTtcbiAgICAgIGNvbnN0IGFyZ3VtZW50Tm9kZXMgPSAoX2ZpZWxkRGVmJGFyZ3VtZW50cyA9IGZpZWxkRGVmLmFyZ3VtZW50cykgIT09IG51bGwgJiYgX2ZpZWxkRGVmJGFyZ3VtZW50cyAhPT0gdm9pZCAwID8gX2ZpZWxkRGVmJGFyZ3VtZW50cyA6IFtdO1xuICAgICAgY2hlY2tBcmdVbmlxdWVuZXNzKGAke3R5cGVOYW1lfS4ke2ZpZWxkTmFtZX1gLCBhcmd1bWVudE5vZGVzKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZ1bmN0aW9uIGNoZWNrQXJnVW5pcXVlbmVzcyhwYXJlbnROYW1lLCBhcmd1bWVudE5vZGVzKSB7XG4gICAgY29uc3Qgc2VlbkFyZ3MgPSBncm91cEJ5KGFyZ3VtZW50Tm9kZXMsIChhcmcpID0+IGFyZy5uYW1lLnZhbHVlKTtcbiAgICBmb3IgKGNvbnN0IFthcmdOYW1lLCBhcmdOb2Rlc10gb2Ygc2VlbkFyZ3MpIHtcbiAgICAgIGlmIChhcmdOb2Rlcy5sZW5ndGggPiAxKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBBcmd1bWVudCBcIiR7cGFyZW50TmFtZX0oJHthcmdOYW1lfTopXCIgY2FuIG9ubHkgYmUgZGVmaW5lZCBvbmNlLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBhcmdOb2Rlcy5tYXAoKG5vZGUpID0+IG5vZGUubmFtZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVBcmd1bWVudE5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZUFyZ3VtZW50TmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBGaWVsZDogY2hlY2tBcmdVbmlxdWVuZXNzLFxuICAgIERpcmVjdGl2ZTogY2hlY2tBcmdVbmlxdWVuZXNzXG4gIH07XG4gIGZ1bmN0aW9uIGNoZWNrQXJnVW5pcXVlbmVzcyhwYXJlbnROb2RlKSB7XG4gICAgdmFyIF9wYXJlbnROb2RlJGFyZ3VtZW50cztcbiAgICBjb25zdCBhcmd1bWVudE5vZGVzID0gKF9wYXJlbnROb2RlJGFyZ3VtZW50cyA9IHBhcmVudE5vZGUuYXJndW1lbnRzKSAhPT0gbnVsbCAmJiBfcGFyZW50Tm9kZSRhcmd1bWVudHMgIT09IHZvaWQgMCA/IF9wYXJlbnROb2RlJGFyZ3VtZW50cyA6IFtdO1xuICAgIGNvbnN0IHNlZW5BcmdzID0gZ3JvdXBCeShhcmd1bWVudE5vZGVzLCAoYXJnKSA9PiBhcmcubmFtZS52YWx1ZSk7XG4gICAgZm9yIChjb25zdCBbYXJnTmFtZSwgYXJnTm9kZXNdIG9mIHNlZW5BcmdzKSB7XG4gICAgICBpZiAoYXJnTm9kZXMubGVuZ3RoID4gMSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVGhlcmUgY2FuIGJlIG9ubHkgb25lIGFyZ3VtZW50IG5hbWVkIFwiJHthcmdOYW1lfVwiLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBhcmdOb2Rlcy5tYXAoKG5vZGUpID0+IG5vZGUubmFtZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1VuaXF1ZURpcmVjdGl2ZU5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZURpcmVjdGl2ZU5hbWVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IGtub3duRGlyZWN0aXZlTmFtZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3Qgc2NoZW1hID0gY29udGV4dC5nZXRTY2hlbWEoKTtcbiAgcmV0dXJuIHtcbiAgICBEaXJlY3RpdmVEZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIGNvbnN0IGRpcmVjdGl2ZU5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICBpZiAoc2NoZW1hICE9PSBudWxsICYmIHNjaGVtYSAhPT0gdm9pZCAwICYmIHNjaGVtYS5nZXREaXJlY3RpdmUoZGlyZWN0aXZlTmFtZSkpIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYERpcmVjdGl2ZSBcIkAke2RpcmVjdGl2ZU5hbWV9XCIgYWxyZWFkeSBleGlzdHMgaW4gdGhlIHNjaGVtYS4gSXQgY2Fubm90IGJlIHJlZGVmaW5lZC5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2Rlczogbm9kZS5uYW1lXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoa25vd25EaXJlY3RpdmVOYW1lc1tkaXJlY3RpdmVOYW1lXSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVGhlcmUgY2FuIGJlIG9ubHkgb25lIGRpcmVjdGl2ZSBuYW1lZCBcIkAke2RpcmVjdGl2ZU5hbWV9XCIuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IFtrbm93bkRpcmVjdGl2ZU5hbWVzW2RpcmVjdGl2ZU5hbWVdLCBub2RlLm5hbWVdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAga25vd25EaXJlY3RpdmVOYW1lc1tkaXJlY3RpdmVOYW1lXSA9IG5vZGUubmFtZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1VuaXF1ZURpcmVjdGl2ZXNQZXJMb2NhdGlvblJ1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVEaXJlY3RpdmVzUGVyTG9jYXRpb25SdWxlKGNvbnRleHQpIHtcbiAgY29uc3QgdW5pcXVlRGlyZWN0aXZlTWFwID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IHNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gIGNvbnN0IGRlZmluZWREaXJlY3RpdmVzID0gc2NoZW1hID8gc2NoZW1hLmdldERpcmVjdGl2ZXMoKSA6IHNwZWNpZmllZERpcmVjdGl2ZXM7XG4gIGZvciAoY29uc3QgZGlyZWN0aXZlIG9mIGRlZmluZWREaXJlY3RpdmVzKSB7XG4gICAgdW5pcXVlRGlyZWN0aXZlTWFwW2RpcmVjdGl2ZS5uYW1lXSA9ICFkaXJlY3RpdmUuaXNSZXBlYXRhYmxlO1xuICB9XG4gIGNvbnN0IGFzdERlZmluaXRpb25zID0gY29udGV4dC5nZXREb2N1bWVudCgpLmRlZmluaXRpb25zO1xuICBmb3IgKGNvbnN0IGRlZiBvZiBhc3REZWZpbml0aW9ucykge1xuICAgIGlmIChkZWYua2luZCA9PT0gS2luZC5ESVJFQ1RJVkVfREVGSU5JVElPTikge1xuICAgICAgdW5pcXVlRGlyZWN0aXZlTWFwW2RlZi5uYW1lLnZhbHVlXSA9ICFkZWYucmVwZWF0YWJsZTtcbiAgICB9XG4gIH1cbiAgY29uc3Qgc2NoZW1hRGlyZWN0aXZlcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCB0eXBlRGlyZWN0aXZlc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4ge1xuICAgIC8vIE1hbnkgZGlmZmVyZW50IEFTVCBub2RlcyBtYXkgY29udGFpbiBkaXJlY3RpdmVzLiBSYXRoZXIgdGhhbiBsaXN0aW5nXG4gICAgLy8gdGhlbSBhbGwsIGp1c3QgbGlzdGVuIGZvciBlbnRlcmluZyBhbnkgbm9kZSwgYW5kIGNoZWNrIHRvIHNlZSBpZiBpdFxuICAgIC8vIGRlZmluZXMgYW55IGRpcmVjdGl2ZXMuXG4gICAgZW50ZXIobm9kZSkge1xuICAgICAgaWYgKCEoXCJkaXJlY3RpdmVzXCIgaW4gbm9kZSkgfHwgIW5vZGUuZGlyZWN0aXZlcykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBsZXQgc2VlbkRpcmVjdGl2ZXM7XG4gICAgICBpZiAobm9kZS5raW5kID09PSBLaW5kLlNDSEVNQV9ERUZJTklUSU9OIHx8IG5vZGUua2luZCA9PT0gS2luZC5TQ0hFTUFfRVhURU5TSU9OKSB7XG4gICAgICAgIHNlZW5EaXJlY3RpdmVzID0gc2NoZW1hRGlyZWN0aXZlcztcbiAgICAgIH0gZWxzZSBpZiAoaXNUeXBlRGVmaW5pdGlvbk5vZGUobm9kZSkgfHwgaXNUeXBlRXh0ZW5zaW9uTm9kZShub2RlKSkge1xuICAgICAgICBjb25zdCB0eXBlTmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgICAgc2VlbkRpcmVjdGl2ZXMgPSB0eXBlRGlyZWN0aXZlc01hcFt0eXBlTmFtZV07XG4gICAgICAgIGlmIChzZWVuRGlyZWN0aXZlcyA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgdHlwZURpcmVjdGl2ZXNNYXBbdHlwZU5hbWVdID0gc2VlbkRpcmVjdGl2ZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2VlbkRpcmVjdGl2ZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgZGlyZWN0aXZlIG9mIG5vZGUuZGlyZWN0aXZlcykge1xuICAgICAgICBjb25zdCBkaXJlY3RpdmVOYW1lID0gZGlyZWN0aXZlLm5hbWUudmFsdWU7XG4gICAgICAgIGlmICh1bmlxdWVEaXJlY3RpdmVNYXBbZGlyZWN0aXZlTmFtZV0pIHtcbiAgICAgICAgICBpZiAoc2VlbkRpcmVjdGl2ZXNbZGlyZWN0aXZlTmFtZV0pIHtcbiAgICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICAgICAgYFRoZSBkaXJlY3RpdmUgXCJAJHtkaXJlY3RpdmVOYW1lfVwiIGNhbiBvbmx5IGJlIHVzZWQgb25jZSBhdCB0aGlzIGxvY2F0aW9uLmAsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgbm9kZXM6IFtzZWVuRGlyZWN0aXZlc1tkaXJlY3RpdmVOYW1lXSwgZGlyZWN0aXZlXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2VlbkRpcmVjdGl2ZXNbZGlyZWN0aXZlTmFtZV0gPSBkaXJlY3RpdmU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVFbnVtVmFsdWVOYW1lc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVFbnVtVmFsdWVOYW1lc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBleGlzdGluZ1R5cGVNYXAgPSBzY2hlbWEgPyBzY2hlbWEuZ2V0VHlwZU1hcCgpIDogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IGtub3duVmFsdWVOYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4ge1xuICAgIEVudW1UeXBlRGVmaW5pdGlvbjogY2hlY2tWYWx1ZVVuaXF1ZW5lc3MsXG4gICAgRW51bVR5cGVFeHRlbnNpb246IGNoZWNrVmFsdWVVbmlxdWVuZXNzXG4gIH07XG4gIGZ1bmN0aW9uIGNoZWNrVmFsdWVVbmlxdWVuZXNzKG5vZGUpIHtcbiAgICB2YXIgX25vZGUkdmFsdWVzO1xuICAgIGNvbnN0IHR5cGVOYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgIGlmICgha25vd25WYWx1ZU5hbWVzW3R5cGVOYW1lXSkge1xuICAgICAga25vd25WYWx1ZU5hbWVzW3R5cGVOYW1lXSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIH1cbiAgICBjb25zdCB2YWx1ZU5vZGVzID0gKF9ub2RlJHZhbHVlcyA9IG5vZGUudmFsdWVzKSAhPT0gbnVsbCAmJiBfbm9kZSR2YWx1ZXMgIT09IHZvaWQgMCA/IF9ub2RlJHZhbHVlcyA6IFtdO1xuICAgIGNvbnN0IHZhbHVlTmFtZXMgPSBrbm93blZhbHVlTmFtZXNbdHlwZU5hbWVdO1xuICAgIGZvciAoY29uc3QgdmFsdWVEZWYgb2YgdmFsdWVOb2Rlcykge1xuICAgICAgY29uc3QgdmFsdWVOYW1lID0gdmFsdWVEZWYubmFtZS52YWx1ZTtcbiAgICAgIGNvbnN0IGV4aXN0aW5nVHlwZSA9IGV4aXN0aW5nVHlwZU1hcFt0eXBlTmFtZV07XG4gICAgICBpZiAoaXNFbnVtVHlwZShleGlzdGluZ1R5cGUpICYmIGV4aXN0aW5nVHlwZS5nZXRWYWx1ZSh2YWx1ZU5hbWUpKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBFbnVtIHZhbHVlIFwiJHt0eXBlTmFtZX0uJHt2YWx1ZU5hbWV9XCIgYWxyZWFkeSBleGlzdHMgaW4gdGhlIHNjaGVtYS4gSXQgY2Fubm90IGFsc28gYmUgZGVmaW5lZCBpbiB0aGlzIHR5cGUgZXh0ZW5zaW9uLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiB2YWx1ZURlZi5uYW1lXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIGlmICh2YWx1ZU5hbWVzW3ZhbHVlTmFtZV0pIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYEVudW0gdmFsdWUgXCIke3R5cGVOYW1lfS4ke3ZhbHVlTmFtZX1cIiBjYW4gb25seSBiZSBkZWZpbmVkIG9uY2UuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IFt2YWx1ZU5hbWVzW3ZhbHVlTmFtZV0sIHZhbHVlRGVmLm5hbWVdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFsdWVOYW1lc1t2YWx1ZU5hbWVdID0gdmFsdWVEZWYubmFtZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1VuaXF1ZUZpZWxkRGVmaW5pdGlvbk5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZUZpZWxkRGVmaW5pdGlvbk5hbWVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IHNjaGVtYSA9IGNvbnRleHQuZ2V0U2NoZW1hKCk7XG4gIGNvbnN0IGV4aXN0aW5nVHlwZU1hcCA9IHNjaGVtYSA/IHNjaGVtYS5nZXRUeXBlTWFwKCkgOiAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3Qga25vd25GaWVsZE5hbWVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiB7XG4gICAgSW5wdXRPYmplY3RUeXBlRGVmaW5pdGlvbjogY2hlY2tGaWVsZFVuaXF1ZW5lc3MsXG4gICAgSW5wdXRPYmplY3RUeXBlRXh0ZW5zaW9uOiBjaGVja0ZpZWxkVW5pcXVlbmVzcyxcbiAgICBJbnRlcmZhY2VUeXBlRGVmaW5pdGlvbjogY2hlY2tGaWVsZFVuaXF1ZW5lc3MsXG4gICAgSW50ZXJmYWNlVHlwZUV4dGVuc2lvbjogY2hlY2tGaWVsZFVuaXF1ZW5lc3MsXG4gICAgT2JqZWN0VHlwZURlZmluaXRpb246IGNoZWNrRmllbGRVbmlxdWVuZXNzLFxuICAgIE9iamVjdFR5cGVFeHRlbnNpb246IGNoZWNrRmllbGRVbmlxdWVuZXNzXG4gIH07XG4gIGZ1bmN0aW9uIGNoZWNrRmllbGRVbmlxdWVuZXNzKG5vZGUpIHtcbiAgICB2YXIgX25vZGUkZmllbGRzO1xuICAgIGNvbnN0IHR5cGVOYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgIGlmICgha25vd25GaWVsZE5hbWVzW3R5cGVOYW1lXSkge1xuICAgICAga25vd25GaWVsZE5hbWVzW3R5cGVOYW1lXSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIH1cbiAgICBjb25zdCBmaWVsZE5vZGVzID0gKF9ub2RlJGZpZWxkcyA9IG5vZGUuZmllbGRzKSAhPT0gbnVsbCAmJiBfbm9kZSRmaWVsZHMgIT09IHZvaWQgMCA/IF9ub2RlJGZpZWxkcyA6IFtdO1xuICAgIGNvbnN0IGZpZWxkTmFtZXMgPSBrbm93bkZpZWxkTmFtZXNbdHlwZU5hbWVdO1xuICAgIGZvciAoY29uc3QgZmllbGREZWYgb2YgZmllbGROb2Rlcykge1xuICAgICAgY29uc3QgZmllbGROYW1lID0gZmllbGREZWYubmFtZS52YWx1ZTtcbiAgICAgIGlmIChoYXNGaWVsZChleGlzdGluZ1R5cGVNYXBbdHlwZU5hbWVdLCBmaWVsZE5hbWUpKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBGaWVsZCBcIiR7dHlwZU5hbWV9LiR7ZmllbGROYW1lfVwiIGFscmVhZHkgZXhpc3RzIGluIHRoZSBzY2hlbWEuIEl0IGNhbm5vdCBhbHNvIGJlIGRlZmluZWQgaW4gdGhpcyB0eXBlIGV4dGVuc2lvbi5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogZmllbGREZWYubmFtZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSBpZiAoZmllbGROYW1lc1tmaWVsZE5hbWVdKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBGaWVsZCBcIiR7dHlwZU5hbWV9LiR7ZmllbGROYW1lfVwiIGNhbiBvbmx5IGJlIGRlZmluZWQgb25jZS5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogW2ZpZWxkTmFtZXNbZmllbGROYW1lXSwgZmllbGREZWYubmFtZV1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmaWVsZE5hbWVzW2ZpZWxkTmFtZV0gPSBmaWVsZERlZi5uYW1lO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cbmZ1bmN0aW9uIGhhc0ZpZWxkKHR5cGUsIGZpZWxkTmFtZSkge1xuICBpZiAoaXNPYmplY3RUeXBlKHR5cGUpIHx8IGlzSW50ZXJmYWNlVHlwZSh0eXBlKSB8fCBpc0lucHV0T2JqZWN0VHlwZSh0eXBlKSkge1xuICAgIHJldHVybiB0eXBlLmdldEZpZWxkcygpW2ZpZWxkTmFtZV0gIT0gbnVsbDtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1VuaXF1ZUZyYWdtZW50TmFtZXNSdWxlLm1qc1xuZnVuY3Rpb24gVW5pcXVlRnJhZ21lbnROYW1lc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBrbm93bkZyYWdtZW50TmFtZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgcmV0dXJuIHtcbiAgICBPcGVyYXRpb25EZWZpbml0aW9uOiAoKSA9PiBmYWxzZSxcbiAgICBGcmFnbWVudERlZmluaXRpb24obm9kZSkge1xuICAgICAgY29uc3QgZnJhZ21lbnROYW1lID0gbm9kZS5uYW1lLnZhbHVlO1xuICAgICAgaWYgKGtub3duRnJhZ21lbnROYW1lc1tmcmFnbWVudE5hbWVdKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBUaGVyZSBjYW4gYmUgb25seSBvbmUgZnJhZ21lbnQgbmFtZWQgXCIke2ZyYWdtZW50TmFtZX1cIi5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogW2tub3duRnJhZ21lbnROYW1lc1tmcmFnbWVudE5hbWVdLCBub2RlLm5hbWVdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAga25vd25GcmFnbWVudE5hbWVzW2ZyYWdtZW50TmFtZV0gPSBub2RlLm5hbWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVJbnB1dEZpZWxkTmFtZXNSdWxlLm1qc1xuZnVuY3Rpb24gVW5pcXVlSW5wdXRGaWVsZE5hbWVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IGtub3duTmFtZVN0YWNrID0gW107XG4gIGxldCBrbm93bk5hbWVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJldHVybiB7XG4gICAgT2JqZWN0VmFsdWU6IHtcbiAgICAgIGVudGVyKCkge1xuICAgICAgICBrbm93bk5hbWVTdGFjay5wdXNoKGtub3duTmFtZXMpO1xuICAgICAgICBrbm93bk5hbWVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICB9LFxuICAgICAgbGVhdmUoKSB7XG4gICAgICAgIGNvbnN0IHByZXZLbm93bk5hbWVzID0ga25vd25OYW1lU3RhY2sucG9wKCk7XG4gICAgICAgIHByZXZLbm93bk5hbWVzIHx8IGludmFyaWFudDIoZmFsc2UpO1xuICAgICAgICBrbm93bk5hbWVzID0gcHJldktub3duTmFtZXM7XG4gICAgICB9XG4gICAgfSxcbiAgICBPYmplY3RGaWVsZChub2RlKSB7XG4gICAgICBjb25zdCBmaWVsZE5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgICBpZiAoa25vd25OYW1lc1tmaWVsZE5hbWVdKSB7XG4gICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgIGBUaGVyZSBjYW4gYmUgb25seSBvbmUgaW5wdXQgZmllbGQgbmFtZWQgXCIke2ZpZWxkTmFtZX1cIi5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2RlczogW2tub3duTmFtZXNbZmllbGROYW1lXSwgbm9kZS5uYW1lXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGtub3duTmFtZXNbZmllbGROYW1lXSA9IG5vZGUubmFtZTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1VuaXF1ZU9wZXJhdGlvbk5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZU9wZXJhdGlvbk5hbWVzUnVsZShjb250ZXh0KSB7XG4gIGNvbnN0IGtub3duT3BlcmF0aW9uTmFtZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgcmV0dXJuIHtcbiAgICBPcGVyYXRpb25EZWZpbml0aW9uKG5vZGUpIHtcbiAgICAgIGNvbnN0IG9wZXJhdGlvbk5hbWUgPSBub2RlLm5hbWU7XG4gICAgICBpZiAob3BlcmF0aW9uTmFtZSkge1xuICAgICAgICBpZiAoa25vd25PcGVyYXRpb25OYW1lc1tvcGVyYXRpb25OYW1lLnZhbHVlXSkge1xuICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICBgVGhlcmUgY2FuIGJlIG9ubHkgb25lIG9wZXJhdGlvbiBuYW1lZCBcIiR7b3BlcmF0aW9uTmFtZS52YWx1ZX1cIi5gLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbm9kZXM6IFtcbiAgICAgICAgICAgICAgICAgIGtub3duT3BlcmF0aW9uTmFtZXNbb3BlcmF0aW9uTmFtZS52YWx1ZV0sXG4gICAgICAgICAgICAgICAgICBvcGVyYXRpb25OYW1lXG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBrbm93bk9wZXJhdGlvbk5hbWVzW29wZXJhdGlvbk5hbWUudmFsdWVdID0gb3BlcmF0aW9uTmFtZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgRnJhZ21lbnREZWZpbml0aW9uOiAoKSA9PiBmYWxzZVxuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVPcGVyYXRpb25UeXBlc1J1bGUubWpzXG5mdW5jdGlvbiBVbmlxdWVPcGVyYXRpb25UeXBlc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICBjb25zdCBkZWZpbmVkT3BlcmF0aW9uVHlwZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgZXhpc3RpbmdPcGVyYXRpb25UeXBlcyA9IHNjaGVtYSA/IHtcbiAgICBxdWVyeTogc2NoZW1hLmdldFF1ZXJ5VHlwZSgpLFxuICAgIG11dGF0aW9uOiBzY2hlbWEuZ2V0TXV0YXRpb25UeXBlKCksXG4gICAgc3Vic2NyaXB0aW9uOiBzY2hlbWEuZ2V0U3Vic2NyaXB0aW9uVHlwZSgpXG4gIH0gOiB7fTtcbiAgcmV0dXJuIHtcbiAgICBTY2hlbWFEZWZpbml0aW9uOiBjaGVja09wZXJhdGlvblR5cGVzLFxuICAgIFNjaGVtYUV4dGVuc2lvbjogY2hlY2tPcGVyYXRpb25UeXBlc1xuICB9O1xuICBmdW5jdGlvbiBjaGVja09wZXJhdGlvblR5cGVzKG5vZGUpIHtcbiAgICB2YXIgX25vZGUkb3BlcmF0aW9uVHlwZXM7XG4gICAgY29uc3Qgb3BlcmF0aW9uVHlwZXNOb2RlcyA9IChfbm9kZSRvcGVyYXRpb25UeXBlcyA9IG5vZGUub3BlcmF0aW9uVHlwZXMpICE9PSBudWxsICYmIF9ub2RlJG9wZXJhdGlvblR5cGVzICE9PSB2b2lkIDAgPyBfbm9kZSRvcGVyYXRpb25UeXBlcyA6IFtdO1xuICAgIGZvciAoY29uc3Qgb3BlcmF0aW9uVHlwZSBvZiBvcGVyYXRpb25UeXBlc05vZGVzKSB7XG4gICAgICBjb25zdCBvcGVyYXRpb24gPSBvcGVyYXRpb25UeXBlLm9wZXJhdGlvbjtcbiAgICAgIGNvbnN0IGFscmVhZHlEZWZpbmVkT3BlcmF0aW9uVHlwZSA9IGRlZmluZWRPcGVyYXRpb25UeXBlc1tvcGVyYXRpb25dO1xuICAgICAgaWYgKGV4aXN0aW5nT3BlcmF0aW9uVHlwZXNbb3BlcmF0aW9uXSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVHlwZSBmb3IgJHtvcGVyYXRpb259IGFscmVhZHkgZGVmaW5lZCBpbiB0aGUgc2NoZW1hLiBJdCBjYW5ub3QgYmUgcmVkZWZpbmVkLmAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5vZGVzOiBvcGVyYXRpb25UeXBlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIGlmIChhbHJlYWR5RGVmaW5lZE9wZXJhdGlvblR5cGUpIHtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYFRoZXJlIGNhbiBiZSBvbmx5IG9uZSAke29wZXJhdGlvbn0gdHlwZSBpbiBzY2hlbWEuYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IFthbHJlYWR5RGVmaW5lZE9wZXJhdGlvblR5cGUsIG9wZXJhdGlvblR5cGVdXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZGVmaW5lZE9wZXJhdGlvblR5cGVzW29wZXJhdGlvbl0gPSBvcGVyYXRpb25UeXBlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVW5pcXVlVHlwZU5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZVR5cGVOYW1lc1J1bGUoY29udGV4dCkge1xuICBjb25zdCBrbm93blR5cGVOYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICByZXR1cm4ge1xuICAgIFNjYWxhclR5cGVEZWZpbml0aW9uOiBjaGVja1R5cGVOYW1lLFxuICAgIE9iamVjdFR5cGVEZWZpbml0aW9uOiBjaGVja1R5cGVOYW1lLFxuICAgIEludGVyZmFjZVR5cGVEZWZpbml0aW9uOiBjaGVja1R5cGVOYW1lLFxuICAgIFVuaW9uVHlwZURlZmluaXRpb246IGNoZWNrVHlwZU5hbWUsXG4gICAgRW51bVR5cGVEZWZpbml0aW9uOiBjaGVja1R5cGVOYW1lLFxuICAgIElucHV0T2JqZWN0VHlwZURlZmluaXRpb246IGNoZWNrVHlwZU5hbWVcbiAgfTtcbiAgZnVuY3Rpb24gY2hlY2tUeXBlTmFtZShub2RlKSB7XG4gICAgY29uc3QgdHlwZU5hbWUgPSBub2RlLm5hbWUudmFsdWU7XG4gICAgaWYgKHNjaGVtYSAhPT0gbnVsbCAmJiBzY2hlbWEgIT09IHZvaWQgMCAmJiBzY2hlbWEuZ2V0VHlwZSh0eXBlTmFtZSkpIHtcbiAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgYFR5cGUgXCIke3R5cGVOYW1lfVwiIGFscmVhZHkgZXhpc3RzIGluIHRoZSBzY2hlbWEuIEl0IGNhbm5vdCBhbHNvIGJlIGRlZmluZWQgaW4gdGhpcyB0eXBlIGRlZmluaXRpb24uYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBub2Rlczogbm9kZS5uYW1lXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoa25vd25UeXBlTmFtZXNbdHlwZU5hbWVdKSB7XG4gICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICBuZXcgR3JhcGhRTEVycm9yKGBUaGVyZSBjYW4gYmUgb25seSBvbmUgdHlwZSBuYW1lZCBcIiR7dHlwZU5hbWV9XCIuYCwge1xuICAgICAgICAgIG5vZGVzOiBba25vd25UeXBlTmFtZXNbdHlwZU5hbWVdLCBub2RlLm5hbWVdXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBrbm93blR5cGVOYW1lc1t0eXBlTmFtZV0gPSBub2RlLm5hbWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdmFsaWRhdGlvbi9ydWxlcy9VbmlxdWVWYXJpYWJsZU5hbWVzUnVsZS5tanNcbmZ1bmN0aW9uIFVuaXF1ZVZhcmlhYmxlTmFtZXNSdWxlKGNvbnRleHQpIHtcbiAgcmV0dXJuIHtcbiAgICBPcGVyYXRpb25EZWZpbml0aW9uKG9wZXJhdGlvbk5vZGUpIHtcbiAgICAgIHZhciBfb3BlcmF0aW9uTm9kZSR2YXJpYWI7XG4gICAgICBjb25zdCB2YXJpYWJsZURlZmluaXRpb25zID0gKF9vcGVyYXRpb25Ob2RlJHZhcmlhYiA9IG9wZXJhdGlvbk5vZGUudmFyaWFibGVEZWZpbml0aW9ucykgIT09IG51bGwgJiYgX29wZXJhdGlvbk5vZGUkdmFyaWFiICE9PSB2b2lkIDAgPyBfb3BlcmF0aW9uTm9kZSR2YXJpYWIgOiBbXTtcbiAgICAgIGNvbnN0IHNlZW5WYXJpYWJsZURlZmluaXRpb25zID0gZ3JvdXBCeShcbiAgICAgICAgdmFyaWFibGVEZWZpbml0aW9ucyxcbiAgICAgICAgKG5vZGUpID0+IG5vZGUudmFyaWFibGUubmFtZS52YWx1ZVxuICAgICAgKTtcbiAgICAgIGZvciAoY29uc3QgW3ZhcmlhYmxlTmFtZSwgdmFyaWFibGVOb2Rlc10gb2Ygc2VlblZhcmlhYmxlRGVmaW5pdGlvbnMpIHtcbiAgICAgICAgaWYgKHZhcmlhYmxlTm9kZXMubGVuZ3RoID4gMSkge1xuICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICBgVGhlcmUgY2FuIGJlIG9ubHkgb25lIHZhcmlhYmxlIG5hbWVkIFwiJCR7dmFyaWFibGVOYW1lfVwiLmAsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBub2RlczogdmFyaWFibGVOb2Rlcy5tYXAoKG5vZGUpID0+IG5vZGUudmFyaWFibGUubmFtZSlcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1ZhbHVlc09mQ29ycmVjdFR5cGVSdWxlLm1qc1xuZnVuY3Rpb24gVmFsdWVzT2ZDb3JyZWN0VHlwZVJ1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIExpc3RWYWx1ZShub2RlKSB7XG4gICAgICBjb25zdCB0eXBlID0gZ2V0TnVsbGFibGVUeXBlKGNvbnRleHQuZ2V0UGFyZW50SW5wdXRUeXBlKCkpO1xuICAgICAgaWYgKCFpc0xpc3RUeXBlKHR5cGUpKSB7XG4gICAgICAgIGlzVmFsaWRWYWx1ZU5vZGUoY29udGV4dCwgbm9kZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9LFxuICAgIE9iamVjdFZhbHVlKG5vZGUpIHtcbiAgICAgIGNvbnN0IHR5cGUgPSBnZXROYW1lZFR5cGUoY29udGV4dC5nZXRJbnB1dFR5cGUoKSk7XG4gICAgICBpZiAoIWlzSW5wdXRPYmplY3RUeXBlKHR5cGUpKSB7XG4gICAgICAgIGlzVmFsaWRWYWx1ZU5vZGUoY29udGV4dCwgbm9kZSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZpZWxkTm9kZU1hcCA9IGtleU1hcChub2RlLmZpZWxkcywgKGZpZWxkKSA9PiBmaWVsZC5uYW1lLnZhbHVlKTtcbiAgICAgIGZvciAoY29uc3QgZmllbGREZWYgb2YgT2JqZWN0LnZhbHVlcyh0eXBlLmdldEZpZWxkcygpKSkge1xuICAgICAgICBjb25zdCBmaWVsZE5vZGUgPSBmaWVsZE5vZGVNYXBbZmllbGREZWYubmFtZV07XG4gICAgICAgIGlmICghZmllbGROb2RlICYmIGlzUmVxdWlyZWRJbnB1dEZpZWxkKGZpZWxkRGVmKSkge1xuICAgICAgICAgIGNvbnN0IHR5cGVTdHIgPSBpbnNwZWN0KGZpZWxkRGVmLnR5cGUpO1xuICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgICBgRmllbGQgXCIke3R5cGUubmFtZX0uJHtmaWVsZERlZi5uYW1lfVwiIG9mIHJlcXVpcmVkIHR5cGUgXCIke3R5cGVTdHJ9XCIgd2FzIG5vdCBwcm92aWRlZC5gLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIE9iamVjdEZpZWxkKG5vZGUpIHtcbiAgICAgIGNvbnN0IHBhcmVudFR5cGUgPSBnZXROYW1lZFR5cGUoY29udGV4dC5nZXRQYXJlbnRJbnB1dFR5cGUoKSk7XG4gICAgICBjb25zdCBmaWVsZFR5cGUgPSBjb250ZXh0LmdldElucHV0VHlwZSgpO1xuICAgICAgaWYgKCFmaWVsZFR5cGUgJiYgaXNJbnB1dE9iamVjdFR5cGUocGFyZW50VHlwZSkpIHtcbiAgICAgICAgY29uc3Qgc3VnZ2VzdGlvbnMgPSBzdWdnZXN0aW9uTGlzdChcbiAgICAgICAgICBub2RlLm5hbWUudmFsdWUsXG4gICAgICAgICAgT2JqZWN0LmtleXMocGFyZW50VHlwZS5nZXRGaWVsZHMoKSlcbiAgICAgICAgKTtcbiAgICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgICBuZXcgR3JhcGhRTEVycm9yKFxuICAgICAgICAgICAgYEZpZWxkIFwiJHtub2RlLm5hbWUudmFsdWV9XCIgaXMgbm90IGRlZmluZWQgYnkgdHlwZSBcIiR7cGFyZW50VHlwZS5uYW1lfVwiLmAgKyBkaWRZb3VNZWFuKHN1Z2dlc3Rpb25zKSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSxcbiAgICBOdWxsVmFsdWUobm9kZSkge1xuICAgICAgY29uc3QgdHlwZSA9IGNvbnRleHQuZ2V0SW5wdXRUeXBlKCk7XG4gICAgICBpZiAoaXNOb25OdWxsVHlwZSh0eXBlKSkge1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgRXhwZWN0ZWQgdmFsdWUgb2YgdHlwZSBcIiR7aW5zcGVjdCh0eXBlKX1cIiwgZm91bmQgJHtwcmludChub2RlKX0uYCxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSxcbiAgICBFbnVtVmFsdWU6IChub2RlKSA9PiBpc1ZhbGlkVmFsdWVOb2RlKGNvbnRleHQsIG5vZGUpLFxuICAgIEludFZhbHVlOiAobm9kZSkgPT4gaXNWYWxpZFZhbHVlTm9kZShjb250ZXh0LCBub2RlKSxcbiAgICBGbG9hdFZhbHVlOiAobm9kZSkgPT4gaXNWYWxpZFZhbHVlTm9kZShjb250ZXh0LCBub2RlKSxcbiAgICBTdHJpbmdWYWx1ZTogKG5vZGUpID0+IGlzVmFsaWRWYWx1ZU5vZGUoY29udGV4dCwgbm9kZSksXG4gICAgQm9vbGVhblZhbHVlOiAobm9kZSkgPT4gaXNWYWxpZFZhbHVlTm9kZShjb250ZXh0LCBub2RlKVxuICB9O1xufVxuZnVuY3Rpb24gaXNWYWxpZFZhbHVlTm9kZShjb250ZXh0LCBub2RlKSB7XG4gIGNvbnN0IGxvY2F0aW9uVHlwZSA9IGNvbnRleHQuZ2V0SW5wdXRUeXBlKCk7XG4gIGlmICghbG9jYXRpb25UeXBlKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHR5cGUgPSBnZXROYW1lZFR5cGUobG9jYXRpb25UeXBlKTtcbiAgaWYgKCFpc0xlYWZUeXBlKHR5cGUpKSB7XG4gICAgY29uc3QgdHlwZVN0ciA9IGluc3BlY3QobG9jYXRpb25UeXBlKTtcbiAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgYEV4cGVjdGVkIHZhbHVlIG9mIHR5cGUgXCIke3R5cGVTdHJ9XCIsIGZvdW5kICR7cHJpbnQobm9kZSl9LmAsXG4gICAgICAgIHtcbiAgICAgICAgICBub2Rlczogbm9kZVxuICAgICAgICB9XG4gICAgICApXG4gICAgKTtcbiAgICByZXR1cm47XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZVJlc3VsdCA9IHR5cGUucGFyc2VMaXRlcmFsKFxuICAgICAgbm9kZSxcbiAgICAgIHZvaWQgMFxuICAgICAgLyogdmFyaWFibGVzICovXG4gICAgKTtcbiAgICBpZiAocGFyc2VSZXN1bHQgPT09IHZvaWQgMCkge1xuICAgICAgY29uc3QgdHlwZVN0ciA9IGluc3BlY3QobG9jYXRpb25UeXBlKTtcbiAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgYEV4cGVjdGVkIHZhbHVlIG9mIHR5cGUgXCIke3R5cGVTdHJ9XCIsIGZvdW5kICR7cHJpbnQobm9kZSl9LmAsXG4gICAgICAgICAge1xuICAgICAgICAgICAgbm9kZXM6IG5vZGVcbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IHR5cGVTdHIgPSBpbnNwZWN0KGxvY2F0aW9uVHlwZSk7XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgR3JhcGhRTEVycm9yKSB7XG4gICAgICBjb250ZXh0LnJlcG9ydEVycm9yKGVycm9yKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29udGV4dC5yZXBvcnRFcnJvcihcbiAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICBgRXhwZWN0ZWQgdmFsdWUgb2YgdHlwZSBcIiR7dHlwZVN0cn1cIiwgZm91bmQgJHtwcmludChub2RlKX07IGAgKyBlcnJvci5tZXNzYWdlLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG5vZGVzOiBub2RlLFxuICAgICAgICAgICAgb3JpZ2luYWxFcnJvcjogZXJyb3JcbiAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuICB9XG59XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9ncmFwaHFsQDE2LjguMS9ub2RlX21vZHVsZXMvZ3JhcGhxbC92YWxpZGF0aW9uL3J1bGVzL1ZhcmlhYmxlc0FyZUlucHV0VHlwZXNSdWxlLm1qc1xuZnVuY3Rpb24gVmFyaWFibGVzQXJlSW5wdXRUeXBlc1J1bGUoY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIFZhcmlhYmxlRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICBjb25zdCB0eXBlID0gdHlwZUZyb21BU1QoY29udGV4dC5nZXRTY2hlbWEoKSwgbm9kZS50eXBlKTtcbiAgICAgIGlmICh0eXBlICE9PSB2b2lkIDAgJiYgIWlzSW5wdXRUeXBlKHR5cGUpKSB7XG4gICAgICAgIGNvbnN0IHZhcmlhYmxlTmFtZSA9IG5vZGUudmFyaWFibGUubmFtZS52YWx1ZTtcbiAgICAgICAgY29uc3QgdHlwZU5hbWUgPSBwcmludChub2RlLnR5cGUpO1xuICAgICAgICBjb250ZXh0LnJlcG9ydEVycm9yKFxuICAgICAgICAgIG5ldyBHcmFwaFFMRXJyb3IoXG4gICAgICAgICAgICBgVmFyaWFibGUgXCIkJHt2YXJpYWJsZU5hbWV9XCIgY2Fubm90IGJlIG5vbi1pbnB1dCB0eXBlIFwiJHt0eXBlTmFtZX1cIi5gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBub2Rlczogbm9kZS50eXBlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vcnVsZXMvVmFyaWFibGVzSW5BbGxvd2VkUG9zaXRpb25SdWxlLm1qc1xuZnVuY3Rpb24gVmFyaWFibGVzSW5BbGxvd2VkUG9zaXRpb25SdWxlKGNvbnRleHQpIHtcbiAgbGV0IHZhckRlZk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4ge1xuICAgIE9wZXJhdGlvbkRlZmluaXRpb246IHtcbiAgICAgIGVudGVyKCkge1xuICAgICAgICB2YXJEZWZNYXAgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgIH0sXG4gICAgICBsZWF2ZShvcGVyYXRpb24pIHtcbiAgICAgICAgY29uc3QgdXNhZ2VzID0gY29udGV4dC5nZXRSZWN1cnNpdmVWYXJpYWJsZVVzYWdlcyhvcGVyYXRpb24pO1xuICAgICAgICBmb3IgKGNvbnN0IHsgbm9kZSwgdHlwZSwgZGVmYXVsdFZhbHVlIH0gb2YgdXNhZ2VzKSB7XG4gICAgICAgICAgY29uc3QgdmFyTmFtZSA9IG5vZGUubmFtZS52YWx1ZTtcbiAgICAgICAgICBjb25zdCB2YXJEZWYgPSB2YXJEZWZNYXBbdmFyTmFtZV07XG4gICAgICAgICAgaWYgKHZhckRlZiAmJiB0eXBlKSB7XG4gICAgICAgICAgICBjb25zdCBzY2hlbWEgPSBjb250ZXh0LmdldFNjaGVtYSgpO1xuICAgICAgICAgICAgY29uc3QgdmFyVHlwZSA9IHR5cGVGcm9tQVNUKHNjaGVtYSwgdmFyRGVmLnR5cGUpO1xuICAgICAgICAgICAgaWYgKHZhclR5cGUgJiYgIWFsbG93ZWRWYXJpYWJsZVVzYWdlKFxuICAgICAgICAgICAgICBzY2hlbWEsXG4gICAgICAgICAgICAgIHZhclR5cGUsXG4gICAgICAgICAgICAgIHZhckRlZi5kZWZhdWx0VmFsdWUsXG4gICAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZVxuICAgICAgICAgICAgKSkge1xuICAgICAgICAgICAgICBjb25zdCB2YXJUeXBlU3RyID0gaW5zcGVjdCh2YXJUeXBlKTtcbiAgICAgICAgICAgICAgY29uc3QgdHlwZVN0ciA9IGluc3BlY3QodHlwZSk7XG4gICAgICAgICAgICAgIGNvbnRleHQucmVwb3J0RXJyb3IoXG4gICAgICAgICAgICAgICAgbmV3IEdyYXBoUUxFcnJvcihcbiAgICAgICAgICAgICAgICAgIGBWYXJpYWJsZSBcIiQke3Zhck5hbWV9XCIgb2YgdHlwZSBcIiR7dmFyVHlwZVN0cn1cIiB1c2VkIGluIHBvc2l0aW9uIGV4cGVjdGluZyB0eXBlIFwiJHt0eXBlU3RyfVwiLmAsXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGVzOiBbdmFyRGVmLCBub2RlXVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIFZhcmlhYmxlRGVmaW5pdGlvbihub2RlKSB7XG4gICAgICB2YXJEZWZNYXBbbm9kZS52YXJpYWJsZS5uYW1lLnZhbHVlXSA9IG5vZGU7XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gYWxsb3dlZFZhcmlhYmxlVXNhZ2Uoc2NoZW1hLCB2YXJUeXBlLCB2YXJEZWZhdWx0VmFsdWUsIGxvY2F0aW9uVHlwZSwgbG9jYXRpb25EZWZhdWx0VmFsdWUpIHtcbiAgaWYgKGlzTm9uTnVsbFR5cGUobG9jYXRpb25UeXBlKSAmJiAhaXNOb25OdWxsVHlwZSh2YXJUeXBlKSkge1xuICAgIGNvbnN0IGhhc05vbk51bGxWYXJpYWJsZURlZmF1bHRWYWx1ZSA9IHZhckRlZmF1bHRWYWx1ZSAhPSBudWxsICYmIHZhckRlZmF1bHRWYWx1ZS5raW5kICE9PSBLaW5kLk5VTEw7XG4gICAgY29uc3QgaGFzTG9jYXRpb25EZWZhdWx0VmFsdWUgPSBsb2NhdGlvbkRlZmF1bHRWYWx1ZSAhPT0gdm9pZCAwO1xuICAgIGlmICghaGFzTm9uTnVsbFZhcmlhYmxlRGVmYXVsdFZhbHVlICYmICFoYXNMb2NhdGlvbkRlZmF1bHRWYWx1ZSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBudWxsYWJsZUxvY2F0aW9uVHlwZSA9IGxvY2F0aW9uVHlwZS5vZlR5cGU7XG4gICAgcmV0dXJuIGlzVHlwZVN1YlR5cGVPZihzY2hlbWEsIHZhclR5cGUsIG51bGxhYmxlTG9jYXRpb25UeXBlKTtcbiAgfVxuICByZXR1cm4gaXNUeXBlU3ViVHlwZU9mKHNjaGVtYSwgdmFyVHlwZSwgbG9jYXRpb25UeXBlKTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3ZhbGlkYXRpb24vc3BlY2lmaWVkUnVsZXMubWpzXG52YXIgc3BlY2lmaWVkUnVsZXMgPSBPYmplY3QuZnJlZXplKFtcbiAgRXhlY3V0YWJsZURlZmluaXRpb25zUnVsZSxcbiAgVW5pcXVlT3BlcmF0aW9uTmFtZXNSdWxlLFxuICBMb25lQW5vbnltb3VzT3BlcmF0aW9uUnVsZSxcbiAgU2luZ2xlRmllbGRTdWJzY3JpcHRpb25zUnVsZSxcbiAgS25vd25UeXBlTmFtZXNSdWxlLFxuICBGcmFnbWVudHNPbkNvbXBvc2l0ZVR5cGVzUnVsZSxcbiAgVmFyaWFibGVzQXJlSW5wdXRUeXBlc1J1bGUsXG4gIFNjYWxhckxlYWZzUnVsZSxcbiAgRmllbGRzT25Db3JyZWN0VHlwZVJ1bGUsXG4gIFVuaXF1ZUZyYWdtZW50TmFtZXNSdWxlLFxuICBLbm93bkZyYWdtZW50TmFtZXNSdWxlLFxuICBOb1VudXNlZEZyYWdtZW50c1J1bGUsXG4gIFBvc3NpYmxlRnJhZ21lbnRTcHJlYWRzUnVsZSxcbiAgTm9GcmFnbWVudEN5Y2xlc1J1bGUsXG4gIFVuaXF1ZVZhcmlhYmxlTmFtZXNSdWxlLFxuICBOb1VuZGVmaW5lZFZhcmlhYmxlc1J1bGUsXG4gIE5vVW51c2VkVmFyaWFibGVzUnVsZSxcbiAgS25vd25EaXJlY3RpdmVzUnVsZSxcbiAgVW5pcXVlRGlyZWN0aXZlc1BlckxvY2F0aW9uUnVsZSxcbiAgS25vd25Bcmd1bWVudE5hbWVzUnVsZSxcbiAgVW5pcXVlQXJndW1lbnROYW1lc1J1bGUsXG4gIFZhbHVlc09mQ29ycmVjdFR5cGVSdWxlLFxuICBQcm92aWRlZFJlcXVpcmVkQXJndW1lbnRzUnVsZSxcbiAgVmFyaWFibGVzSW5BbGxvd2VkUG9zaXRpb25SdWxlLFxuICBPdmVybGFwcGluZ0ZpZWxkc0NhbkJlTWVyZ2VkUnVsZSxcbiAgVW5pcXVlSW5wdXRGaWVsZE5hbWVzUnVsZVxuXSk7XG52YXIgc3BlY2lmaWVkU0RMUnVsZXMgPSBPYmplY3QuZnJlZXplKFtcbiAgTG9uZVNjaGVtYURlZmluaXRpb25SdWxlLFxuICBVbmlxdWVPcGVyYXRpb25UeXBlc1J1bGUsXG4gIFVuaXF1ZVR5cGVOYW1lc1J1bGUsXG4gIFVuaXF1ZUVudW1WYWx1ZU5hbWVzUnVsZSxcbiAgVW5pcXVlRmllbGREZWZpbml0aW9uTmFtZXNSdWxlLFxuICBVbmlxdWVBcmd1bWVudERlZmluaXRpb25OYW1lc1J1bGUsXG4gIFVuaXF1ZURpcmVjdGl2ZU5hbWVzUnVsZSxcbiAgS25vd25UeXBlTmFtZXNSdWxlLFxuICBLbm93bkRpcmVjdGl2ZXNSdWxlLFxuICBVbmlxdWVEaXJlY3RpdmVzUGVyTG9jYXRpb25SdWxlLFxuICBQb3NzaWJsZVR5cGVFeHRlbnNpb25zUnVsZSxcbiAgS25vd25Bcmd1bWVudE5hbWVzT25EaXJlY3RpdmVzUnVsZSxcbiAgVW5pcXVlQXJndW1lbnROYW1lc1J1bGUsXG4gIFVuaXF1ZUlucHV0RmllbGROYW1lc1J1bGUsXG4gIFByb3ZpZGVkUmVxdWlyZWRBcmd1bWVudHNPbkRpcmVjdGl2ZXNSdWxlXG5dKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL2pzdXRpbHMvbWVtb2l6ZTMubWpzXG5mdW5jdGlvbiBtZW1vaXplMyhmbikge1xuICBsZXQgY2FjaGUwO1xuICByZXR1cm4gZnVuY3Rpb24gbWVtb2l6ZWQoYTEsIGEyLCBhMykge1xuICAgIGlmIChjYWNoZTAgPT09IHZvaWQgMCkge1xuICAgICAgY2FjaGUwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4gICAgfVxuICAgIGxldCBjYWNoZTEgPSBjYWNoZTAuZ2V0KGExKTtcbiAgICBpZiAoY2FjaGUxID09PSB2b2lkIDApIHtcbiAgICAgIGNhY2hlMSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICAgICAgY2FjaGUwLnNldChhMSwgY2FjaGUxKTtcbiAgICB9XG4gICAgbGV0IGNhY2hlMiA9IGNhY2hlMS5nZXQoYTIpO1xuICAgIGlmIChjYWNoZTIgPT09IHZvaWQgMCkge1xuICAgICAgY2FjaGUyID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4gICAgICBjYWNoZTEuc2V0KGEyLCBjYWNoZTIpO1xuICAgIH1cbiAgICBsZXQgZm5SZXN1bHQgPSBjYWNoZTIuZ2V0KGEzKTtcbiAgICBpZiAoZm5SZXN1bHQgPT09IHZvaWQgMCkge1xuICAgICAgZm5SZXN1bHQgPSBmbihhMSwgYTIsIGEzKTtcbiAgICAgIGNhY2hlMi5zZXQoYTMsIGZuUmVzdWx0KTtcbiAgICB9XG4gICAgcmV0dXJuIGZuUmVzdWx0O1xuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvZXhlY3V0aW9uL2V4ZWN1dGUubWpzXG52YXIgY29sbGVjdFN1YmZpZWxkczIgPSBtZW1vaXplMyhcbiAgKGV4ZUNvbnRleHQsIHJldHVyblR5cGUsIGZpZWxkTm9kZXMpID0+IGNvbGxlY3RTdWJmaWVsZHMoXG4gICAgZXhlQ29udGV4dC5zY2hlbWEsXG4gICAgZXhlQ29udGV4dC5mcmFnbWVudHMsXG4gICAgZXhlQ29udGV4dC52YXJpYWJsZVZhbHVlcyxcbiAgICByZXR1cm5UeXBlLFxuICAgIGZpZWxkTm9kZXNcbiAgKVxuKTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL2dyYXBocWxAMTYuOC4xL25vZGVfbW9kdWxlcy9ncmFwaHFsL3V0aWxpdGllcy9leHRlbmRTY2hlbWEubWpzXG52YXIgc3RkVHlwZU1hcCA9IGtleU1hcChcbiAgWy4uLnNwZWNpZmllZFNjYWxhclR5cGVzLCAuLi5pbnRyb3NwZWN0aW9uVHlwZXNdLFxuICAodHlwZSkgPT4gdHlwZS5uYW1lXG4pO1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vZ3JhcGhxbEAxNi44LjEvbm9kZV9tb2R1bGVzL2dyYXBocWwvdXRpbGl0aWVzL2ZpbmRCcmVha2luZ0NoYW5nZXMubWpzXG52YXIgQnJlYWtpbmdDaGFuZ2VUeXBlO1xuKGZ1bmN0aW9uKEJyZWFraW5nQ2hhbmdlVHlwZTIpIHtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIlRZUEVfUkVNT1ZFRFwiXSA9IFwiVFlQRV9SRU1PVkVEXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJUWVBFX0NIQU5HRURfS0lORFwiXSA9IFwiVFlQRV9DSEFOR0VEX0tJTkRcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIlRZUEVfUkVNT1ZFRF9GUk9NX1VOSU9OXCJdID0gXCJUWVBFX1JFTU9WRURfRlJPTV9VTklPTlwiO1xuICBCcmVha2luZ0NoYW5nZVR5cGUyW1wiVkFMVUVfUkVNT1ZFRF9GUk9NX0VOVU1cIl0gPSBcIlZBTFVFX1JFTU9WRURfRlJPTV9FTlVNXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJSRVFVSVJFRF9JTlBVVF9GSUVMRF9BRERFRFwiXSA9IFwiUkVRVUlSRURfSU5QVVRfRklFTERfQURERURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIklNUExFTUVOVEVEX0lOVEVSRkFDRV9SRU1PVkVEXCJdID0gXCJJTVBMRU1FTlRFRF9JTlRFUkZBQ0VfUkVNT1ZFRFwiO1xuICBCcmVha2luZ0NoYW5nZVR5cGUyW1wiRklFTERfUkVNT1ZFRFwiXSA9IFwiRklFTERfUkVNT1ZFRFwiO1xuICBCcmVha2luZ0NoYW5nZVR5cGUyW1wiRklFTERfQ0hBTkdFRF9LSU5EXCJdID0gXCJGSUVMRF9DSEFOR0VEX0tJTkRcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIlJFUVVJUkVEX0FSR19BRERFRFwiXSA9IFwiUkVRVUlSRURfQVJHX0FEREVEXCI7XG4gIEJyZWFraW5nQ2hhbmdlVHlwZTJbXCJBUkdfUkVNT1ZFRFwiXSA9IFwiQVJHX1JFTU9WRURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIkFSR19DSEFOR0VEX0tJTkRcIl0gPSBcIkFSR19DSEFOR0VEX0tJTkRcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIkRJUkVDVElWRV9SRU1PVkVEXCJdID0gXCJESVJFQ1RJVkVfUkVNT1ZFRFwiO1xuICBCcmVha2luZ0NoYW5nZVR5cGUyW1wiRElSRUNUSVZFX0FSR19SRU1PVkVEXCJdID0gXCJESVJFQ1RJVkVfQVJHX1JFTU9WRURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIlJFUVVJUkVEX0RJUkVDVElWRV9BUkdfQURERURcIl0gPSBcIlJFUVVJUkVEX0RJUkVDVElWRV9BUkdfQURERURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIkRJUkVDVElWRV9SRVBFQVRBQkxFX1JFTU9WRURcIl0gPSBcIkRJUkVDVElWRV9SRVBFQVRBQkxFX1JFTU9WRURcIjtcbiAgQnJlYWtpbmdDaGFuZ2VUeXBlMltcIkRJUkVDVElWRV9MT0NBVElPTl9SRU1PVkVEXCJdID0gXCJESVJFQ1RJVkVfTE9DQVRJT05fUkVNT1ZFRFwiO1xufSkoQnJlYWtpbmdDaGFuZ2VUeXBlIHx8IChCcmVha2luZ0NoYW5nZVR5cGUgPSB7fSkpO1xudmFyIERhbmdlcm91c0NoYW5nZVR5cGU7XG4oZnVuY3Rpb24oRGFuZ2Vyb3VzQ2hhbmdlVHlwZTIpIHtcbiAgRGFuZ2Vyb3VzQ2hhbmdlVHlwZTJbXCJWQUxVRV9BRERFRF9UT19FTlVNXCJdID0gXCJWQUxVRV9BRERFRF9UT19FTlVNXCI7XG4gIERhbmdlcm91c0NoYW5nZVR5cGUyW1wiVFlQRV9BRERFRF9UT19VTklPTlwiXSA9IFwiVFlQRV9BRERFRF9UT19VTklPTlwiO1xuICBEYW5nZXJvdXNDaGFuZ2VUeXBlMltcIk9QVElPTkFMX0lOUFVUX0ZJRUxEX0FEREVEXCJdID0gXCJPUFRJT05BTF9JTlBVVF9GSUVMRF9BRERFRFwiO1xuICBEYW5nZXJvdXNDaGFuZ2VUeXBlMltcIk9QVElPTkFMX0FSR19BRERFRFwiXSA9IFwiT1BUSU9OQUxfQVJHX0FEREVEXCI7XG4gIERhbmdlcm91c0NoYW5nZVR5cGUyW1wiSU1QTEVNRU5URURfSU5URVJGQUNFX0FEREVEXCJdID0gXCJJTVBMRU1FTlRFRF9JTlRFUkZBQ0VfQURERURcIjtcbiAgRGFuZ2Vyb3VzQ2hhbmdlVHlwZTJbXCJBUkdfREVGQVVMVF9WQUxVRV9DSEFOR0VcIl0gPSBcIkFSR19ERUZBVUxUX1ZBTFVFX0NIQU5HRVwiO1xufSkoRGFuZ2Vyb3VzQ2hhbmdlVHlwZSB8fCAoRGFuZ2Vyb3VzQ2hhbmdlVHlwZSA9IHt9KSk7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjEzX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS91dGlscy9pbnRlcm5hbC9qc29uUGFyc2UubWpzXG5mdW5jdGlvbiBqc29uUGFyc2UodmFsdWUpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfVxufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vaGVhZGVycy1wb2x5ZmlsbEA0LjAuMy9ub2RlX21vZHVsZXMvaGVhZGVycy1wb2x5ZmlsbC9saWIvaW5kZXgubWpzXG52YXIgX19jcmVhdGUzID0gT2JqZWN0LmNyZWF0ZTtcbnZhciBfX2RlZlByb3A0ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZ2V0T3duUHJvcERlc2MzID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcbnZhciBfX2dldE93blByb3BOYW1lczMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcztcbnZhciBfX2dldFByb3RvT2YzID0gT2JqZWN0LmdldFByb3RvdHlwZU9mO1xudmFyIF9faGFzT3duUHJvcDMgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xudmFyIF9fY29tbW9uSlMzID0gKGNiLCBtb2QpID0+IGZ1bmN0aW9uIF9fcmVxdWlyZSgpIHtcbiAgcmV0dXJuIG1vZCB8fCAoMCwgY2JbX19nZXRPd25Qcm9wTmFtZXMzKGNiKVswXV0pKChtb2QgPSB7IGV4cG9ydHM6IHt9IH0pLmV4cG9ydHMsIG1vZCksIG1vZC5leHBvcnRzO1xufTtcbnZhciBfX2NvcHlQcm9wczMgPSAodG8sIGZyb20sIGV4Y2VwdCwgZGVzYykgPT4ge1xuICBpZiAoZnJvbSAmJiB0eXBlb2YgZnJvbSA9PT0gXCJvYmplY3RcIiB8fCB0eXBlb2YgZnJvbSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgZm9yIChsZXQga2V5IG9mIF9fZ2V0T3duUHJvcE5hbWVzMyhmcm9tKSlcbiAgICAgIGlmICghX19oYXNPd25Qcm9wMy5jYWxsKHRvLCBrZXkpICYmIGtleSAhPT0gZXhjZXB0KVxuICAgICAgICBfX2RlZlByb3A0KHRvLCBrZXksIHsgZ2V0OiAoKSA9PiBmcm9tW2tleV0sIGVudW1lcmFibGU6ICEoZGVzYyA9IF9fZ2V0T3duUHJvcERlc2MzKGZyb20sIGtleSkpIHx8IGRlc2MuZW51bWVyYWJsZSB9KTtcbiAgfVxuICByZXR1cm4gdG87XG59O1xudmFyIF9fdG9FU00zID0gKG1vZCwgaXNOb2RlTW9kZSwgdGFyZ2V0KSA9PiAodGFyZ2V0ID0gbW9kICE9IG51bGwgPyBfX2NyZWF0ZTMoX19nZXRQcm90b09mMyhtb2QpKSA6IHt9LCBfX2NvcHlQcm9wczMoXG4gIC8vIElmIHRoZSBpbXBvcnRlciBpcyBpbiBub2RlIGNvbXBhdGliaWxpdHkgbW9kZSBvciB0aGlzIGlzIG5vdCBhbiBFU01cbiAgLy8gZmlsZSB0aGF0IGhhcyBiZWVuIGNvbnZlcnRlZCB0byBhIENvbW1vbkpTIGZpbGUgdXNpbmcgYSBCYWJlbC1cbiAgLy8gY29tcGF0aWJsZSB0cmFuc2Zvcm0gKGkuZS4gXCJfX2VzTW9kdWxlXCIgaGFzIG5vdCBiZWVuIHNldCksIHRoZW4gc2V0XG4gIC8vIFwiZGVmYXVsdFwiIHRvIHRoZSBDb21tb25KUyBcIm1vZHVsZS5leHBvcnRzXCIgZm9yIG5vZGUgY29tcGF0aWJpbGl0eS5cbiAgaXNOb2RlTW9kZSB8fCAhbW9kIHx8ICFtb2QuX19lc01vZHVsZSA/IF9fZGVmUHJvcDQodGFyZ2V0LCBcImRlZmF1bHRcIiwgeyB2YWx1ZTogbW9kLCBlbnVtZXJhYmxlOiB0cnVlIH0pIDogdGFyZ2V0LFxuICBtb2RcbikpO1xudmFyIHJlcXVpcmVfc2V0X2Nvb2tpZSA9IF9fY29tbW9uSlMzKHtcbiAgXCJub2RlX21vZHVsZXMvc2V0LWNvb2tpZS1wYXJzZXIvbGliL3NldC1jb29raWUuanNcIihleHBvcnRzLCBtb2R1bGUpIHtcbiAgICBcInVzZSBzdHJpY3RcIjtcbiAgICB2YXIgZGVmYXVsdFBhcnNlT3B0aW9ucyA9IHtcbiAgICAgIGRlY29kZVZhbHVlczogdHJ1ZSxcbiAgICAgIG1hcDogZmFsc2UsXG4gICAgICBzaWxlbnQ6IGZhbHNlXG4gICAgfTtcbiAgICBmdW5jdGlvbiBpc05vbkVtcHR5U3RyaW5nKHN0cikge1xuICAgICAgcmV0dXJuIHR5cGVvZiBzdHIgPT09IFwic3RyaW5nXCIgJiYgISFzdHIudHJpbSgpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZVN0cmluZyhzZXRDb29raWVWYWx1ZSwgb3B0aW9ucykge1xuICAgICAgdmFyIHBhcnRzID0gc2V0Q29va2llVmFsdWUuc3BsaXQoXCI7XCIpLmZpbHRlcihpc05vbkVtcHR5U3RyaW5nKTtcbiAgICAgIHZhciBuYW1lVmFsdWVQYWlyU3RyID0gcGFydHMuc2hpZnQoKTtcbiAgICAgIHZhciBwYXJzZWQgPSBwYXJzZU5hbWVWYWx1ZVBhaXIobmFtZVZhbHVlUGFpclN0cik7XG4gICAgICB2YXIgbmFtZSA9IHBhcnNlZC5uYW1lO1xuICAgICAgdmFyIHZhbHVlID0gcGFyc2VkLnZhbHVlO1xuICAgICAgb3B0aW9ucyA9IG9wdGlvbnMgPyBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0UGFyc2VPcHRpb25zLCBvcHRpb25zKSA6IGRlZmF1bHRQYXJzZU9wdGlvbnM7XG4gICAgICB0cnkge1xuICAgICAgICB2YWx1ZSA9IG9wdGlvbnMuZGVjb2RlVmFsdWVzID8gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKSA6IHZhbHVlO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAgIFwic2V0LWNvb2tpZS1wYXJzZXIgZW5jb3VudGVyZWQgYW4gZXJyb3Igd2hpbGUgZGVjb2RpbmcgYSBjb29raWUgd2l0aCB2YWx1ZSAnXCIgKyB2YWx1ZSArIFwiJy4gU2V0IG9wdGlvbnMuZGVjb2RlVmFsdWVzIHRvIGZhbHNlIHRvIGRpc2FibGUgdGhpcyBmZWF0dXJlLlwiLFxuICAgICAgICAgIGVcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHZhciBjb29raWUgPSB7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIHZhbHVlXG4gICAgICB9O1xuICAgICAgcGFydHMuZm9yRWFjaChmdW5jdGlvbihwYXJ0KSB7XG4gICAgICAgIHZhciBzaWRlcyA9IHBhcnQuc3BsaXQoXCI9XCIpO1xuICAgICAgICB2YXIga2V5ID0gc2lkZXMuc2hpZnQoKS50cmltTGVmdCgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHZhciB2YWx1ZTIgPSBzaWRlcy5qb2luKFwiPVwiKTtcbiAgICAgICAgaWYgKGtleSA9PT0gXCJleHBpcmVzXCIpIHtcbiAgICAgICAgICBjb29raWUuZXhwaXJlcyA9IG5ldyBEYXRlKHZhbHVlMik7XG4gICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcIm1heC1hZ2VcIikge1xuICAgICAgICAgIGNvb2tpZS5tYXhBZ2UgPSBwYXJzZUludCh2YWx1ZTIsIDEwKTtcbiAgICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwic2VjdXJlXCIpIHtcbiAgICAgICAgICBjb29raWUuc2VjdXJlID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwiaHR0cG9ubHlcIikge1xuICAgICAgICAgIGNvb2tpZS5odHRwT25seSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcInNhbWVzaXRlXCIpIHtcbiAgICAgICAgICBjb29raWUuc2FtZVNpdGUgPSB2YWx1ZTI7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29va2llW2tleV0gPSB2YWx1ZTI7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGNvb2tpZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGFyc2VOYW1lVmFsdWVQYWlyKG5hbWVWYWx1ZVBhaXJTdHIpIHtcbiAgICAgIHZhciBuYW1lID0gXCJcIjtcbiAgICAgIHZhciB2YWx1ZSA9IFwiXCI7XG4gICAgICB2YXIgbmFtZVZhbHVlQXJyID0gbmFtZVZhbHVlUGFpclN0ci5zcGxpdChcIj1cIik7XG4gICAgICBpZiAobmFtZVZhbHVlQXJyLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgbmFtZSA9IG5hbWVWYWx1ZUFyci5zaGlmdCgpO1xuICAgICAgICB2YWx1ZSA9IG5hbWVWYWx1ZUFyci5qb2luKFwiPVwiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhbHVlID0gbmFtZVZhbHVlUGFpclN0cjtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG5hbWUsIHZhbHVlIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBhcnNlMyhpbnB1dCwgb3B0aW9ucykge1xuICAgICAgb3B0aW9ucyA9IG9wdGlvbnMgPyBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0UGFyc2VPcHRpb25zLCBvcHRpb25zKSA6IGRlZmF1bHRQYXJzZU9wdGlvbnM7XG4gICAgICBpZiAoIWlucHV0KSB7XG4gICAgICAgIGlmICghb3B0aW9ucy5tYXApIHtcbiAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoaW5wdXQuaGVhZGVycykge1xuICAgICAgICBpZiAodHlwZW9mIGlucHV0LmhlYWRlcnMuZ2V0U2V0Q29va2llID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICBpbnB1dCA9IGlucHV0LmhlYWRlcnMuZ2V0U2V0Q29va2llKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoaW5wdXQuaGVhZGVyc1tcInNldC1jb29raWVcIl0pIHtcbiAgICAgICAgICBpbnB1dCA9IGlucHV0LmhlYWRlcnNbXCJzZXQtY29va2llXCJdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZhciBzY2ggPSBpbnB1dC5oZWFkZXJzW09iamVjdC5rZXlzKGlucHV0LmhlYWRlcnMpLmZpbmQoZnVuY3Rpb24oa2V5KSB7XG4gICAgICAgICAgICByZXR1cm4ga2V5LnRvTG93ZXJDYXNlKCkgPT09IFwic2V0LWNvb2tpZVwiO1xuICAgICAgICAgIH0pXTtcbiAgICAgICAgICBpZiAoIXNjaCAmJiBpbnB1dC5oZWFkZXJzLmNvb2tpZSAmJiAhb3B0aW9ucy5zaWxlbnQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgXCJXYXJuaW5nOiBzZXQtY29va2llLXBhcnNlciBhcHBlYXJzIHRvIGhhdmUgYmVlbiBjYWxsZWQgb24gYSByZXF1ZXN0IG9iamVjdC4gSXQgaXMgZGVzaWduZWQgdG8gcGFyc2UgU2V0LUNvb2tpZSBoZWFkZXJzIGZyb20gcmVzcG9uc2VzLCBub3QgQ29va2llIGhlYWRlcnMgZnJvbSByZXF1ZXN0cy4gU2V0IHRoZSBvcHRpb24ge3NpbGVudDogdHJ1ZX0gdG8gc3VwcHJlc3MgdGhpcyB3YXJuaW5nLlwiXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpbnB1dCA9IHNjaDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGlucHV0KSkge1xuICAgICAgICBpbnB1dCA9IFtpbnB1dF07XG4gICAgICB9XG4gICAgICBvcHRpb25zID0gb3B0aW9ucyA/IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRQYXJzZU9wdGlvbnMsIG9wdGlvbnMpIDogZGVmYXVsdFBhcnNlT3B0aW9ucztcbiAgICAgIGlmICghb3B0aW9ucy5tYXApIHtcbiAgICAgICAgcmV0dXJuIGlucHV0LmZpbHRlcihpc05vbkVtcHR5U3RyaW5nKS5tYXAoZnVuY3Rpb24oc3RyKSB7XG4gICAgICAgICAgcmV0dXJuIHBhcnNlU3RyaW5nKHN0ciwgb3B0aW9ucyk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIGNvb2tpZXMgPSB7fTtcbiAgICAgICAgcmV0dXJuIGlucHV0LmZpbHRlcihpc05vbkVtcHR5U3RyaW5nKS5yZWR1Y2UoZnVuY3Rpb24oY29va2llczIsIHN0cikge1xuICAgICAgICAgIHZhciBjb29raWUgPSBwYXJzZVN0cmluZyhzdHIsIG9wdGlvbnMpO1xuICAgICAgICAgIGNvb2tpZXMyW2Nvb2tpZS5uYW1lXSA9IGNvb2tpZTtcbiAgICAgICAgICByZXR1cm4gY29va2llczI7XG4gICAgICAgIH0sIGNvb2tpZXMpO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBzcGxpdENvb2tpZXNTdHJpbmcyKGNvb2tpZXNTdHJpbmcpIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGNvb2tpZXNTdHJpbmcpKSB7XG4gICAgICAgIHJldHVybiBjb29raWVzU3RyaW5nO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBjb29raWVzU3RyaW5nICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH1cbiAgICAgIHZhciBjb29raWVzU3RyaW5ncyA9IFtdO1xuICAgICAgdmFyIHBvcyA9IDA7XG4gICAgICB2YXIgc3RhcnQ7XG4gICAgICB2YXIgY2g7XG4gICAgICB2YXIgbGFzdENvbW1hO1xuICAgICAgdmFyIG5leHRTdGFydDtcbiAgICAgIHZhciBjb29raWVzU2VwYXJhdG9yRm91bmQ7XG4gICAgICBmdW5jdGlvbiBza2lwV2hpdGVzcGFjZSgpIHtcbiAgICAgICAgd2hpbGUgKHBvcyA8IGNvb2tpZXNTdHJpbmcubGVuZ3RoICYmIC9cXHMvLnRlc3QoY29va2llc1N0cmluZy5jaGFyQXQocG9zKSkpIHtcbiAgICAgICAgICBwb3MgKz0gMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcG9zIDwgY29va2llc1N0cmluZy5sZW5ndGg7XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiBub3RTcGVjaWFsQ2hhcigpIHtcbiAgICAgICAgY2ggPSBjb29raWVzU3RyaW5nLmNoYXJBdChwb3MpO1xuICAgICAgICByZXR1cm4gY2ggIT09IFwiPVwiICYmIGNoICE9PSBcIjtcIiAmJiBjaCAhPT0gXCIsXCI7XG4gICAgICB9XG4gICAgICB3aGlsZSAocG9zIDwgY29va2llc1N0cmluZy5sZW5ndGgpIHtcbiAgICAgICAgc3RhcnQgPSBwb3M7XG4gICAgICAgIGNvb2tpZXNTZXBhcmF0b3JGb3VuZCA9IGZhbHNlO1xuICAgICAgICB3aGlsZSAoc2tpcFdoaXRlc3BhY2UoKSkge1xuICAgICAgICAgIGNoID0gY29va2llc1N0cmluZy5jaGFyQXQocG9zKTtcbiAgICAgICAgICBpZiAoY2ggPT09IFwiLFwiKSB7XG4gICAgICAgICAgICBsYXN0Q29tbWEgPSBwb3M7XG4gICAgICAgICAgICBwb3MgKz0gMTtcbiAgICAgICAgICAgIHNraXBXaGl0ZXNwYWNlKCk7XG4gICAgICAgICAgICBuZXh0U3RhcnQgPSBwb3M7XG4gICAgICAgICAgICB3aGlsZSAocG9zIDwgY29va2llc1N0cmluZy5sZW5ndGggJiYgbm90U3BlY2lhbENoYXIoKSkge1xuICAgICAgICAgICAgICBwb3MgKz0gMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwb3MgPCBjb29raWVzU3RyaW5nLmxlbmd0aCAmJiBjb29raWVzU3RyaW5nLmNoYXJBdChwb3MpID09PSBcIj1cIikge1xuICAgICAgICAgICAgICBjb29raWVzU2VwYXJhdG9yRm91bmQgPSB0cnVlO1xuICAgICAgICAgICAgICBwb3MgPSBuZXh0U3RhcnQ7XG4gICAgICAgICAgICAgIGNvb2tpZXNTdHJpbmdzLnB1c2goY29va2llc1N0cmluZy5zdWJzdHJpbmcoc3RhcnQsIGxhc3RDb21tYSkpO1xuICAgICAgICAgICAgICBzdGFydCA9IHBvcztcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHBvcyA9IGxhc3RDb21tYSArIDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHBvcyArPSAxO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWNvb2tpZXNTZXBhcmF0b3JGb3VuZCB8fCBwb3MgPj0gY29va2llc1N0cmluZy5sZW5ndGgpIHtcbiAgICAgICAgICBjb29raWVzU3RyaW5ncy5wdXNoKGNvb2tpZXNTdHJpbmcuc3Vic3RyaW5nKHN0YXJ0LCBjb29raWVzU3RyaW5nLmxlbmd0aCkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY29va2llc1N0cmluZ3M7XG4gICAgfVxuICAgIG1vZHVsZS5leHBvcnRzID0gcGFyc2UzO1xuICAgIG1vZHVsZS5leHBvcnRzLnBhcnNlID0gcGFyc2UzO1xuICAgIG1vZHVsZS5leHBvcnRzLnBhcnNlU3RyaW5nID0gcGFyc2VTdHJpbmc7XG4gICAgbW9kdWxlLmV4cG9ydHMuc3BsaXRDb29raWVzU3RyaW5nID0gc3BsaXRDb29raWVzU3RyaW5nMjtcbiAgfVxufSk7XG52YXIgaW1wb3J0X3NldF9jb29raWVfcGFyc2VyID0gX190b0VTTTMocmVxdWlyZV9zZXRfY29va2llKCkpO1xudmFyIEhFQURFUlNfSU5WQUxJRF9DSEFSQUNURVJTID0gL1teYS16MC05XFwtIyQlJicqKy5eX2B8fl0vaTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZUhlYWRlck5hbWUobmFtZSkge1xuICBpZiAoSEVBREVSU19JTlZBTElEX0NIQVJBQ1RFUlMudGVzdChuYW1lKSB8fCBuYW1lLnRyaW0oKSA9PT0gXCJcIikge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGNoYXJhY3RlciBpbiBoZWFkZXIgZmllbGQgbmFtZVwiKTtcbiAgfVxuICByZXR1cm4gbmFtZS50cmltKCkudG9Mb3dlckNhc2UoKTtcbn1cbnZhciBjaGFyQ29kZXNUb1JlbW92ZSA9IFtcbiAgU3RyaW5nLmZyb21DaGFyQ29kZSgxMCksXG4gIFN0cmluZy5mcm9tQ2hhckNvZGUoMTMpLFxuICBTdHJpbmcuZnJvbUNoYXJDb2RlKDkpLFxuICBTdHJpbmcuZnJvbUNoYXJDb2RlKDMyKVxuXTtcbnZhciBIRUFERVJfVkFMVUVfUkVNT1ZFX1JFR0VYUCA9IG5ldyBSZWdFeHAoXG4gIGAoXlske2NoYXJDb2Rlc1RvUmVtb3ZlLmpvaW4oXCJcIil9XXwkWyR7Y2hhckNvZGVzVG9SZW1vdmUuam9pbihcIlwiKX1dKWAsXG4gIFwiZ1wiXG4pO1xuZnVuY3Rpb24gbm9ybWFsaXplSGVhZGVyVmFsdWUodmFsdWUpIHtcbiAgY29uc3QgbmV4dFZhbHVlID0gdmFsdWUucmVwbGFjZShIRUFERVJfVkFMVUVfUkVNT1ZFX1JFR0VYUCwgXCJcIik7XG4gIHJldHVybiBuZXh0VmFsdWU7XG59XG5mdW5jdGlvbiBpc1ZhbGlkSGVhZGVyTmFtZSh2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh2YWx1ZS5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNoYXJhY3RlciA9IHZhbHVlLmNoYXJDb2RlQXQoaSk7XG4gICAgaWYgKGNoYXJhY3RlciA+IDEyNyB8fCAhaXNUb2tlbihjaGFyYWN0ZXIpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNUb2tlbih2YWx1ZSkge1xuICByZXR1cm4gIVtcbiAgICAxMjcsXG4gICAgMzIsXG4gICAgXCIoXCIsXG4gICAgXCIpXCIsXG4gICAgXCI8XCIsXG4gICAgXCI+XCIsXG4gICAgXCJAXCIsXG4gICAgXCIsXCIsXG4gICAgXCI7XCIsXG4gICAgXCI6XCIsXG4gICAgXCJcXFxcXCIsXG4gICAgJ1wiJyxcbiAgICBcIi9cIixcbiAgICBcIltcIixcbiAgICBcIl1cIixcbiAgICBcIj9cIixcbiAgICBcIj1cIixcbiAgICBcIntcIixcbiAgICBcIn1cIlxuICBdLmluY2x1ZGVzKHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGlzVmFsaWRIZWFkZXJWYWx1ZSh2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh2YWx1ZS50cmltKCkgIT09IHZhbHVlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjaGFyYWN0ZXIgPSB2YWx1ZS5jaGFyQ29kZUF0KGkpO1xuICAgIGlmIChcbiAgICAgIC8vIE5VTC5cbiAgICAgIGNoYXJhY3RlciA9PT0gMCB8fCAvLyBIVFRQIG5ld2xpbmUgYnl0ZXMuXG4gICAgICBjaGFyYWN0ZXIgPT09IDEwIHx8IGNoYXJhY3RlciA9PT0gMTNcbiAgICApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG52YXIgTk9STUFMSVpFRF9IRUFERVJTID0gU3ltYm9sKFwibm9ybWFsaXplZEhlYWRlcnNcIik7XG52YXIgUkFXX0hFQURFUl9OQU1FUyA9IFN5bWJvbChcInJhd0hlYWRlck5hbWVzXCIpO1xudmFyIEhFQURFUl9WQUxVRV9ERUxJTUlURVIgPSBcIiwgXCI7XG52YXIgX2E7XG52YXIgX2I7XG52YXIgX2M7XG52YXIgSGVhZGVyczIgPSBjbGFzcyBfSGVhZGVycyB7XG4gIGNvbnN0cnVjdG9yKGluaXQpIHtcbiAgICB0aGlzW19hXSA9IHt9O1xuICAgIHRoaXNbX2JdID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICB0aGlzW19jXSA9IFwiSGVhZGVyc1wiO1xuICAgIGlmIChbXCJIZWFkZXJzXCIsIFwiSGVhZGVyc1BvbHlmaWxsXCJdLmluY2x1ZGVzKGluaXQgPT0gbnVsbCA/IHZvaWQgMCA6IGluaXQuY29uc3RydWN0b3IubmFtZSkgfHwgaW5pdCBpbnN0YW5jZW9mIF9IZWFkZXJzIHx8IHR5cGVvZiBnbG9iYWxUaGlzLkhlYWRlcnMgIT09IFwidW5kZWZpbmVkXCIgJiYgaW5pdCBpbnN0YW5jZW9mIGdsb2JhbFRoaXMuSGVhZGVycykge1xuICAgICAgY29uc3QgaW5pdGlhbEhlYWRlcnMgPSBpbml0O1xuICAgICAgaW5pdGlhbEhlYWRlcnMuZm9yRWFjaCgodmFsdWUsIG5hbWUpID0+IHtcbiAgICAgICAgdGhpcy5hcHBlbmQobmFtZSwgdmFsdWUpO1xuICAgICAgfSwgdGhpcyk7XG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KGluaXQpKSB7XG4gICAgICBpbml0LmZvckVhY2goKFtuYW1lLCB2YWx1ZV0pID0+IHtcbiAgICAgICAgdGhpcy5hcHBlbmQoXG4gICAgICAgICAgbmFtZSxcbiAgICAgICAgICBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmpvaW4oSEVBREVSX1ZBTFVFX0RFTElNSVRFUikgOiB2YWx1ZVxuICAgICAgICApO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChpbml0KSB7XG4gICAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhpbml0KS5mb3JFYWNoKChuYW1lKSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gaW5pdFtuYW1lXTtcbiAgICAgICAgdGhpcy5hcHBlbmQoXG4gICAgICAgICAgbmFtZSxcbiAgICAgICAgICBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmpvaW4oSEVBREVSX1ZBTFVFX0RFTElNSVRFUikgOiB2YWx1ZVxuICAgICAgICApO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIFsoX2EgPSBOT1JNQUxJWkVEX0hFQURFUlMsIF9iID0gUkFXX0hFQURFUl9OQU1FUywgX2MgPSBTeW1ib2wudG9TdHJpbmdUYWcsIFN5bWJvbC5pdGVyYXRvcildKCkge1xuICAgIHJldHVybiB0aGlzLmVudHJpZXMoKTtcbiAgfVxuICAqa2V5cygpIHtcbiAgICBmb3IgKGNvbnN0IFtuYW1lXSBvZiB0aGlzLmVudHJpZXMoKSkge1xuICAgICAgeWllbGQgbmFtZTtcbiAgICB9XG4gIH1cbiAgKnZhbHVlcygpIHtcbiAgICBmb3IgKGNvbnN0IFssIHZhbHVlXSBvZiB0aGlzLmVudHJpZXMoKSkge1xuICAgICAgeWllbGQgdmFsdWU7XG4gICAgfVxuICB9XG4gICplbnRyaWVzKCkge1xuICAgIGxldCBzb3J0ZWRLZXlzID0gT2JqZWN0LmtleXModGhpc1tOT1JNQUxJWkVEX0hFQURFUlNdKS5zb3J0KFxuICAgICAgKGEsIGIpID0+IGEubG9jYWxlQ29tcGFyZShiKVxuICAgICk7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIHNvcnRlZEtleXMpIHtcbiAgICAgIGlmIChuYW1lID09PSBcInNldC1jb29raWVcIikge1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIHRoaXMuZ2V0U2V0Q29va2llKCkpIHtcbiAgICAgICAgICB5aWVsZCBbbmFtZSwgdmFsdWVdO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB5aWVsZCBbbmFtZSwgdGhpcy5nZXQobmFtZSldO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhIGJvb2xlYW4gc3RhdGluZyB3aGV0aGVyIGEgYEhlYWRlcnNgIG9iamVjdCBjb250YWlucyBhIGNlcnRhaW4gaGVhZGVyLlxuICAgKi9cbiAgaGFzKG5hbWUpIHtcbiAgICBpZiAoIWlzVmFsaWRIZWFkZXJOYW1lKG5hbWUpKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIGhlYWRlciBuYW1lIFwiJHtuYW1lfVwiYCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzW05PUk1BTElaRURfSEVBREVSU10uaGFzT3duUHJvcGVydHkobm9ybWFsaXplSGVhZGVyTmFtZShuYW1lKSk7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYSBgQnl0ZVN0cmluZ2Agc2VxdWVuY2Ugb2YgYWxsIHRoZSB2YWx1ZXMgb2YgYSBoZWFkZXIgd2l0aCBhIGdpdmVuIG5hbWUuXG4gICAqL1xuICBnZXQobmFtZSkge1xuICAgIGlmICghaXNWYWxpZEhlYWRlck5hbWUobmFtZSkpIHtcbiAgICAgIHRocm93IFR5cGVFcnJvcihgSW52YWxpZCBoZWFkZXIgbmFtZSBcIiR7bmFtZX1cImApO1xuICAgIH1cbiAgICByZXR1cm4gdGhpc1tOT1JNQUxJWkVEX0hFQURFUlNdW25vcm1hbGl6ZUhlYWRlck5hbWUobmFtZSldID8/IG51bGw7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgYSBuZXcgdmFsdWUgZm9yIGFuIGV4aXN0aW5nIGhlYWRlciBpbnNpZGUgYSBgSGVhZGVyc2Agb2JqZWN0LCBvciBhZGRzIHRoZSBoZWFkZXIgaWYgaXQgZG9lcyBub3QgYWxyZWFkeSBleGlzdC5cbiAgICovXG4gIHNldChuYW1lLCB2YWx1ZSkge1xuICAgIGlmICghaXNWYWxpZEhlYWRlck5hbWUobmFtZSkgfHwgIWlzVmFsaWRIZWFkZXJWYWx1ZSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgbm9ybWFsaXplZE5hbWUgPSBub3JtYWxpemVIZWFkZXJOYW1lKG5hbWUpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRWYWx1ZSA9IG5vcm1hbGl6ZUhlYWRlclZhbHVlKHZhbHVlKTtcbiAgICB0aGlzW05PUk1BTElaRURfSEVBREVSU11bbm9ybWFsaXplZE5hbWVdID0gbm9ybWFsaXplSGVhZGVyVmFsdWUobm9ybWFsaXplZFZhbHVlKTtcbiAgICB0aGlzW1JBV19IRUFERVJfTkFNRVNdLnNldChub3JtYWxpemVkTmFtZSwgbmFtZSk7XG4gIH1cbiAgLyoqXG4gICAqIEFwcGVuZHMgYSBuZXcgdmFsdWUgb250byBhbiBleGlzdGluZyBoZWFkZXIgaW5zaWRlIGEgYEhlYWRlcnNgIG9iamVjdCwgb3IgYWRkcyB0aGUgaGVhZGVyIGlmIGl0IGRvZXMgbm90IGFscmVhZHkgZXhpc3QuXG4gICAqL1xuICBhcHBlbmQobmFtZSwgdmFsdWUpIHtcbiAgICBpZiAoIWlzVmFsaWRIZWFkZXJOYW1lKG5hbWUpIHx8ICFpc1ZhbGlkSGVhZGVyVmFsdWUodmFsdWUpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG5vcm1hbGl6ZWROYW1lID0gbm9ybWFsaXplSGVhZGVyTmFtZShuYW1lKTtcbiAgICBjb25zdCBub3JtYWxpemVkVmFsdWUgPSBub3JtYWxpemVIZWFkZXJWYWx1ZSh2YWx1ZSk7XG4gICAgbGV0IHJlc29sdmVkVmFsdWUgPSB0aGlzLmhhcyhub3JtYWxpemVkTmFtZSkgPyBgJHt0aGlzLmdldChub3JtYWxpemVkTmFtZSl9LCAke25vcm1hbGl6ZWRWYWx1ZX1gIDogbm9ybWFsaXplZFZhbHVlO1xuICAgIHRoaXMuc2V0KG5hbWUsIHJlc29sdmVkVmFsdWUpO1xuICB9XG4gIC8qKlxuICAgKiBEZWxldGVzIGEgaGVhZGVyIGZyb20gdGhlIGBIZWFkZXJzYCBvYmplY3QuXG4gICAqL1xuICBkZWxldGUobmFtZSkge1xuICAgIGlmICghaXNWYWxpZEhlYWRlck5hbWUobmFtZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCF0aGlzLmhhcyhuYW1lKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBub3JtYWxpemVkTmFtZSA9IG5vcm1hbGl6ZUhlYWRlck5hbWUobmFtZSk7XG4gICAgZGVsZXRlIHRoaXNbTk9STUFMSVpFRF9IRUFERVJTXVtub3JtYWxpemVkTmFtZV07XG4gICAgdGhpc1tSQVdfSEVBREVSX05BTUVTXS5kZWxldGUobm9ybWFsaXplZE5hbWUpO1xuICB9XG4gIC8qKlxuICAgKiBUcmF2ZXJzZXMgdGhlIGBIZWFkZXJzYCBvYmplY3QsXG4gICAqIGNhbGxpbmcgdGhlIGdpdmVuIGNhbGxiYWNrIGZvciBlYWNoIGhlYWRlci5cbiAgICovXG4gIGZvckVhY2goY2FsbGJhY2ssIHRoaXNBcmcpIHtcbiAgICBmb3IgKGNvbnN0IFtuYW1lLCB2YWx1ZV0gb2YgdGhpcy5lbnRyaWVzKCkpIHtcbiAgICAgIGNhbGxiYWNrLmNhbGwodGhpc0FyZywgdmFsdWUsIG5hbWUsIHRoaXMpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhbiBhcnJheSBjb250YWluaW5nIHRoZSB2YWx1ZXNcbiAgICogb2YgYWxsIFNldC1Db29raWUgaGVhZGVycyBhc3NvY2lhdGVkXG4gICAqIHdpdGggYSByZXNwb25zZVxuICAgKi9cbiAgZ2V0U2V0Q29va2llKCkge1xuICAgIGNvbnN0IHNldENvb2tpZUhlYWRlciA9IHRoaXMuZ2V0KFwic2V0LWNvb2tpZVwiKTtcbiAgICBpZiAoc2V0Q29va2llSGVhZGVyID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGlmIChzZXRDb29raWVIZWFkZXIgPT09IFwiXCIpIHtcbiAgICAgIHJldHVybiBbXCJcIl07XG4gICAgfVxuICAgIHJldHVybiAoMCwgaW1wb3J0X3NldF9jb29raWVfcGFyc2VyLnNwbGl0Q29va2llc1N0cmluZykoc2V0Q29va2llSGVhZGVyKTtcbiAgfVxufTtcbmZ1bmN0aW9uIHN0cmluZ1RvSGVhZGVycyhzdHIpIHtcbiAgY29uc3QgbGluZXMgPSBzdHIudHJpbSgpLnNwbGl0KC9bXFxyXFxuXSsvKTtcbiAgcmV0dXJuIGxpbmVzLnJlZHVjZSgoaGVhZGVycywgbGluZSkgPT4ge1xuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gXCJcIikge1xuICAgICAgcmV0dXJuIGhlYWRlcnM7XG4gICAgfVxuICAgIGNvbnN0IHBhcnRzID0gbGluZS5zcGxpdChcIjogXCIpO1xuICAgIGNvbnN0IG5hbWUgPSBwYXJ0cy5zaGlmdCgpO1xuICAgIGNvbnN0IHZhbHVlID0gcGFydHMuam9pbihcIjogXCIpO1xuICAgIGhlYWRlcnMuYXBwZW5kKG5hbWUsIHZhbHVlKTtcbiAgICByZXR1cm4gaGVhZGVycztcbiAgfSwgbmV3IEhlYWRlcnMyKCkpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvaW50ZXJuYWwvcGFyc2VNdWx0aXBhcnREYXRhLm1qc1xuZnVuY3Rpb24gcGFyc2VDb250ZW50SGVhZGVycyhoZWFkZXJzU3RyaW5nKSB7XG4gIHZhciBfYTIsIF9iMjtcbiAgY29uc3QgaGVhZGVycyA9IHN0cmluZ1RvSGVhZGVycyhoZWFkZXJzU3RyaW5nKTtcbiAgY29uc3QgY29udGVudFR5cGUgPSBoZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSB8fCBcInRleHQvcGxhaW5cIjtcbiAgY29uc3QgZGlzcG9zaXRpb24gPSBoZWFkZXJzLmdldChcImNvbnRlbnQtZGlzcG9zaXRpb25cIik7XG4gIGlmICghZGlzcG9zaXRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1wiQ29udGVudC1EaXNwb3NpdGlvblwiIGhlYWRlciBpcyByZXF1aXJlZC4nKTtcbiAgfVxuICBjb25zdCBkaXJlY3RpdmVzID0gZGlzcG9zaXRpb24uc3BsaXQoXCI7XCIpLnJlZHVjZSgoYWNjLCBjaHVuaykgPT4ge1xuICAgIGNvbnN0IFtuYW1lMiwgLi4ucmVzdF0gPSBjaHVuay50cmltKCkuc3BsaXQoXCI9XCIpO1xuICAgIGFjY1tuYW1lMl0gPSByZXN0LmpvaW4oXCI9XCIpO1xuICAgIHJldHVybiBhY2M7XG4gIH0sIHt9KTtcbiAgY29uc3QgbmFtZSA9IChfYTIgPSBkaXJlY3RpdmVzLm5hbWUpID09IG51bGwgPyB2b2lkIDAgOiBfYTIuc2xpY2UoMSwgLTEpO1xuICBjb25zdCBmaWxlbmFtZSA9IChfYjIgPSBkaXJlY3RpdmVzLmZpbGVuYW1lKSA9PSBudWxsID8gdm9pZCAwIDogX2IyLnNsaWNlKDEsIC0xKTtcbiAgcmV0dXJuIHtcbiAgICBuYW1lLFxuICAgIGZpbGVuYW1lLFxuICAgIGNvbnRlbnRUeXBlXG4gIH07XG59XG5mdW5jdGlvbiBwYXJzZU11bHRpcGFydERhdGEoZGF0YSwgaGVhZGVycykge1xuICBjb25zdCBjb250ZW50VHlwZSA9IGhlYWRlcnMgPT0gbnVsbCA/IHZvaWQgMCA6IGhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpO1xuICBpZiAoIWNvbnRlbnRUeXBlKSB7XG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgfVxuICBjb25zdCBbLCAuLi5kaXJlY3RpdmVzXSA9IGNvbnRlbnRUeXBlLnNwbGl0KC87ICovKTtcbiAgY29uc3QgYm91bmRhcnkgPSBkaXJlY3RpdmVzLmZpbHRlcigoZCkgPT4gZC5zdGFydHNXaXRoKFwiYm91bmRhcnk9XCIpKS5tYXAoKHMpID0+IHMucmVwbGFjZSgvXmJvdW5kYXJ5PS8sIFwiXCIpKVswXTtcbiAgaWYgKCFib3VuZGFyeSkge1xuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cbiAgY29uc3QgYm91bmRhcnlSZWdFeHAgPSBuZXcgUmVnRXhwKGAtLSske2JvdW5kYXJ5fWApO1xuICBjb25zdCBmaWVsZHMgPSBkYXRhLnNwbGl0KGJvdW5kYXJ5UmVnRXhwKS5maWx0ZXIoKGNodW5rKSA9PiBjaHVuay5zdGFydHNXaXRoKFwiXFxyXFxuXCIpICYmIGNodW5rLmVuZHNXaXRoKFwiXFxyXFxuXCIpKS5tYXAoKGNodW5rKSA9PiBjaHVuay50cmltU3RhcnQoKS5yZXBsYWNlKC9cXHJcXG4kLywgXCJcIikpO1xuICBpZiAoIWZpZWxkcy5sZW5ndGgpIHtcbiAgICByZXR1cm4gdm9pZCAwO1xuICB9XG4gIGNvbnN0IHBhcnNlZEJvZHkgPSB7fTtcbiAgdHJ5IHtcbiAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIGZpZWxkcykge1xuICAgICAgY29uc3QgW2NvbnRlbnRIZWFkZXJzLCAuLi5yZXN0XSA9IGZpZWxkLnNwbGl0KFwiXFxyXFxuXFxyXFxuXCIpO1xuICAgICAgY29uc3QgY29udGVudEJvZHkgPSByZXN0LmpvaW4oXCJcXHJcXG5cXHJcXG5cIik7XG4gICAgICBjb25zdCB7IGNvbnRlbnRUeXBlOiBjb250ZW50VHlwZTIsIGZpbGVuYW1lLCBuYW1lIH0gPSBwYXJzZUNvbnRlbnRIZWFkZXJzKGNvbnRlbnRIZWFkZXJzKTtcbiAgICAgIGNvbnN0IHZhbHVlID0gZmlsZW5hbWUgPT09IHZvaWQgMCA/IGNvbnRlbnRCb2R5IDogbmV3IEZpbGUoW2NvbnRlbnRCb2R5XSwgZmlsZW5hbWUsIHsgdHlwZTogY29udGVudFR5cGUyIH0pO1xuICAgICAgY29uc3QgcGFyc2VkVmFsdWUgPSBwYXJzZWRCb2R5W25hbWVdO1xuICAgICAgaWYgKHBhcnNlZFZhbHVlID09PSB2b2lkIDApIHtcbiAgICAgICAgcGFyc2VkQm9keVtuYW1lXSA9IHZhbHVlO1xuICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHBhcnNlZFZhbHVlKSkge1xuICAgICAgICBwYXJzZWRCb2R5W25hbWVdID0gWy4uLnBhcnNlZFZhbHVlLCB2YWx1ZV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJzZWRCb2R5W25hbWVdID0gW3BhcnNlZFZhbHVlLCB2YWx1ZV07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBwYXJzZWRCb2R5O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3V0aWxzL2ludGVybmFsL3BhcnNlR3JhcGhRTFJlcXVlc3QubWpzXG5mdW5jdGlvbiBwYXJzZURvY3VtZW50Tm9kZShub2RlKSB7XG4gIHZhciBfYTI7XG4gIGNvbnN0IG9wZXJhdGlvbkRlZiA9IG5vZGUuZGVmaW5pdGlvbnMuZmluZCgoZGVmaW5pdGlvbikgPT4ge1xuICAgIHJldHVybiBkZWZpbml0aW9uLmtpbmQgPT09IFwiT3BlcmF0aW9uRGVmaW5pdGlvblwiO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBvcGVyYXRpb25UeXBlOiBvcGVyYXRpb25EZWYgPT0gbnVsbCA/IHZvaWQgMCA6IG9wZXJhdGlvbkRlZi5vcGVyYXRpb24sXG4gICAgb3BlcmF0aW9uTmFtZTogKF9hMiA9IG9wZXJhdGlvbkRlZiA9PSBudWxsID8gdm9pZCAwIDogb3BlcmF0aW9uRGVmLm5hbWUpID09IG51bGwgPyB2b2lkIDAgOiBfYTIudmFsdWVcbiAgfTtcbn1cbmZ1bmN0aW9uIHBhcnNlUXVlcnkocXVlcnkpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBhc3QgPSBwYXJzZTIocXVlcnkpO1xuICAgIHJldHVybiBwYXJzZURvY3VtZW50Tm9kZShhc3QpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiBlcnJvcjtcbiAgfVxufVxuZnVuY3Rpb24gZXh0cmFjdE11bHRpcGFydFZhcmlhYmxlcyh2YXJpYWJsZXMsIG1hcCwgZmlsZXMpIHtcbiAgY29uc3Qgb3BlcmF0aW9ucyA9IHsgdmFyaWFibGVzIH07XG4gIGZvciAoY29uc3QgW2tleSwgcGF0aEFycmF5XSBvZiBPYmplY3QuZW50cmllcyhtYXApKSB7XG4gICAgaWYgKCEoa2V5IGluIGZpbGVzKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBHaXZlbiBmaWxlcyBkbyBub3QgaGF2ZSBhIGtleSAnJHtrZXl9JyAuYCk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgZG90UGF0aCBvZiBwYXRoQXJyYXkpIHtcbiAgICAgIGNvbnN0IFtsYXN0UGF0aCwgLi4ucmV2ZXJzZWRQYXRoc10gPSBkb3RQYXRoLnNwbGl0KFwiLlwiKS5yZXZlcnNlKCk7XG4gICAgICBjb25zdCBwYXRocyA9IHJldmVyc2VkUGF0aHMucmV2ZXJzZSgpO1xuICAgICAgbGV0IHRhcmdldCA9IG9wZXJhdGlvbnM7XG4gICAgICBmb3IgKGNvbnN0IHBhdGggb2YgcGF0aHMpIHtcbiAgICAgICAgaWYgKCEocGF0aCBpbiB0YXJnZXQpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBQcm9wZXJ0eSAnJHtwYXRoc30nIGlzIG5vdCBpbiBvcGVyYXRpb25zLmApO1xuICAgICAgICB9XG4gICAgICAgIHRhcmdldCA9IHRhcmdldFtwYXRoXTtcbiAgICAgIH1cbiAgICAgIHRhcmdldFtsYXN0UGF0aF0gPSBmaWxlc1trZXldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3BlcmF0aW9ucy52YXJpYWJsZXM7XG59XG5hc3luYyBmdW5jdGlvbiBnZXRHcmFwaFFMSW5wdXQocmVxdWVzdCkge1xuICB2YXIgX2EyO1xuICBzd2l0Y2ggKHJlcXVlc3QubWV0aG9kKSB7XG4gICAgY2FzZSBcIkdFVFwiOiB7XG4gICAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJlcXVlc3QudXJsKTtcbiAgICAgIGNvbnN0IHF1ZXJ5ID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJxdWVyeVwiKTtcbiAgICAgIGNvbnN0IHZhcmlhYmxlcyA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwidmFyaWFibGVzXCIpIHx8IFwiXCI7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBxdWVyeSxcbiAgICAgICAgdmFyaWFibGVzOiBqc29uUGFyc2UodmFyaWFibGVzKVxuICAgICAgfTtcbiAgICB9XG4gICAgY2FzZSBcIlBPU1RcIjoge1xuICAgICAgY29uc3QgcmVxdWVzdENsb25lID0gcmVxdWVzdC5jbG9uZSgpO1xuICAgICAgaWYgKChfYTIgPSByZXF1ZXN0LmhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmluY2x1ZGVzKFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiKSkge1xuICAgICAgICBjb25zdCByZXNwb25zZUpzb24gPSBwYXJzZU11bHRpcGFydERhdGEoXG4gICAgICAgICAgYXdhaXQgcmVxdWVzdENsb25lLnRleHQoKSxcbiAgICAgICAgICByZXF1ZXN0LmhlYWRlcnNcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZUpzb24pIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IG9wZXJhdGlvbnMsIG1hcCwgLi4uZmlsZXMgfSA9IHJlc3BvbnNlSnNvbjtcbiAgICAgICAgY29uc3QgcGFyc2VkT3BlcmF0aW9ucyA9IGpzb25QYXJzZShcbiAgICAgICAgICBvcGVyYXRpb25zXG4gICAgICAgICkgfHwge307XG4gICAgICAgIGlmICghcGFyc2VkT3BlcmF0aW9ucy5xdWVyeSkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHBhcnNlZE1hcCA9IGpzb25QYXJzZShtYXAgfHwgXCJcIikgfHwge307XG4gICAgICAgIGNvbnN0IHZhcmlhYmxlcyA9IHBhcnNlZE9wZXJhdGlvbnMudmFyaWFibGVzID8gZXh0cmFjdE11bHRpcGFydFZhcmlhYmxlcyhcbiAgICAgICAgICBwYXJzZWRPcGVyYXRpb25zLnZhcmlhYmxlcyxcbiAgICAgICAgICBwYXJzZWRNYXAsXG4gICAgICAgICAgZmlsZXNcbiAgICAgICAgKSA6IHt9O1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHF1ZXJ5OiBwYXJzZWRPcGVyYXRpb25zLnF1ZXJ5LFxuICAgICAgICAgIHZhcmlhYmxlc1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgY29uc3QgcmVxdWVzdEpzb24gPSBhd2FpdCByZXF1ZXN0Q2xvbmUuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgICAgaWYgKHJlcXVlc3RKc29uID09IG51bGwgPyB2b2lkIDAgOiByZXF1ZXN0SnNvbi5xdWVyeSkge1xuICAgICAgICBjb25zdCB7IHF1ZXJ5LCB2YXJpYWJsZXMgfSA9IHJlcXVlc3RKc29uO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgIHZhcmlhYmxlc1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlR3JhcGhRTFJlcXVlc3QocmVxdWVzdCkge1xuICBjb25zdCBpbnB1dCA9IGF3YWl0IGdldEdyYXBoUUxJbnB1dChyZXF1ZXN0KTtcbiAgaWYgKCFpbnB1dCB8fCAhaW5wdXQucXVlcnkpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgeyBxdWVyeSwgdmFyaWFibGVzIH0gPSBpbnB1dDtcbiAgY29uc3QgcGFyc2VkUmVzdWx0ID0gcGFyc2VRdWVyeShxdWVyeSk7XG4gIGlmIChwYXJzZWRSZXN1bHQgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIGNvbnN0IHJlcXVlc3RQdWJsaWNVcmwgPSB0b1B1YmxpY1VybChyZXF1ZXN0LnVybCk7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcbiAgICAgICAgJ0ZhaWxlZCB0byBpbnRlcmNlcHQgYSBHcmFwaFFMIHJlcXVlc3QgdG8gXCIlcyAlc1wiOiBjYW5ub3QgcGFyc2UgcXVlcnkuIFNlZSB0aGUgZXJyb3IgbWVzc2FnZSBmcm9tIHRoZSBwYXJzZXIgYmVsb3cuXFxuXFxuJXMnLFxuICAgICAgICByZXF1ZXN0Lm1ldGhvZCxcbiAgICAgICAgcmVxdWVzdFB1YmxpY1VybCxcbiAgICAgICAgcGFyc2VkUmVzdWx0Lm1lc3NhZ2VcbiAgICAgIClcbiAgICApO1xuICB9XG4gIHJldHVybiB7XG4gICAgcXVlcnk6IGlucHV0LnF1ZXJ5LFxuICAgIG9wZXJhdGlvblR5cGU6IHBhcnNlZFJlc3VsdC5vcGVyYXRpb25UeXBlLFxuICAgIG9wZXJhdGlvbk5hbWU6IHBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lLFxuICAgIHZhcmlhYmxlc1xuICB9O1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvaGFuZGxlcnMvR3JhcGhRTEhhbmRsZXIubWpzXG5mdW5jdGlvbiBpc0RvY3VtZW50Tm9kZSh2YWx1ZSkge1xuICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIFwia2luZFwiIGluIHZhbHVlICYmIFwiZGVmaW5pdGlvbnNcIiBpbiB2YWx1ZTtcbn1cbnZhciBfR3JhcGhRTEhhbmRsZXIgPSBjbGFzcyBfR3JhcGhRTEhhbmRsZXIgZXh0ZW5kcyBSZXF1ZXN0SGFuZGxlciB7XG4gIGNvbnN0cnVjdG9yKG9wZXJhdGlvblR5cGUsIG9wZXJhdGlvbk5hbWUsIGVuZHBvaW50LCByZXNvbHZlciwgb3B0aW9ucykge1xuICAgIGxldCByZXNvbHZlZE9wZXJhdGlvbk5hbWUgPSBvcGVyYXRpb25OYW1lO1xuICAgIGlmIChpc0RvY3VtZW50Tm9kZShvcGVyYXRpb25OYW1lKSkge1xuICAgICAgY29uc3QgcGFyc2VkTm9kZSA9IHBhcnNlRG9jdW1lbnROb2RlKG9wZXJhdGlvbk5hbWUpO1xuICAgICAgaWYgKHBhcnNlZE5vZGUub3BlcmF0aW9uVHlwZSAhPT0gb3BlcmF0aW9uVHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byBjcmVhdGUgYSBHcmFwaFFMIGhhbmRsZXI6IHByb3ZpZGVkIGEgRG9jdW1lbnROb2RlIHdpdGggYSBtaXNtYXRjaGVkIG9wZXJhdGlvbiB0eXBlIChleHBlY3RlZCBcIiR7b3BlcmF0aW9uVHlwZX1cIiwgYnV0IGdvdCBcIiR7cGFyc2VkTm9kZS5vcGVyYXRpb25UeXBlfVwiKS5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoIXBhcnNlZE5vZGUub3BlcmF0aW9uTmFtZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byBjcmVhdGUgYSBHcmFwaFFMIGhhbmRsZXI6IHByb3ZpZGVkIGEgRG9jdW1lbnROb2RlIHdpdGggbm8gb3BlcmF0aW9uIG5hbWUuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmVzb2x2ZWRPcGVyYXRpb25OYW1lID0gcGFyc2VkTm9kZS5vcGVyYXRpb25OYW1lO1xuICAgIH1cbiAgICBjb25zdCBoZWFkZXIgPSBvcGVyYXRpb25UeXBlID09PSBcImFsbFwiID8gYCR7b3BlcmF0aW9uVHlwZX0gKG9yaWdpbjogJHtlbmRwb2ludC50b1N0cmluZygpfSlgIDogYCR7b3BlcmF0aW9uVHlwZX0gJHtyZXNvbHZlZE9wZXJhdGlvbk5hbWV9IChvcmlnaW46ICR7ZW5kcG9pbnQudG9TdHJpbmcoKX0pYDtcbiAgICBzdXBlcih7XG4gICAgICBpbmZvOiB7XG4gICAgICAgIGhlYWRlcixcbiAgICAgICAgb3BlcmF0aW9uVHlwZSxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogcmVzb2x2ZWRPcGVyYXRpb25OYW1lXG4gICAgICB9LFxuICAgICAgcmVzb2x2ZXIsXG4gICAgICBvcHRpb25zXG4gICAgfSk7XG4gICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcImVuZHBvaW50XCIpO1xuICAgIHRoaXMuZW5kcG9pbnQgPSBlbmRwb2ludDtcbiAgfVxuICAvKipcbiAgICogUGFyc2VzIHRoZSByZXF1ZXN0IGJvZHksIG9uY2UgcGVyIHJlcXVlc3QsIGNhY2hlZCBhY3Jvc3MgYWxsXG4gICAqIEdyYXBoUUwgaGFuZGxlcnMuIFRoaXMgaXMgZG9uZSB0byBhdm9pZCBtdWx0aXBsZSBwYXJzaW5nIG9mIHRoZVxuICAgKiByZXF1ZXN0IGJvZHksIHdoaWNoIGVhY2ggcmVxdWlyZXMgYSBjbG9uZSBvZiB0aGUgcmVxdWVzdC5cbiAgICovXG4gIGFzeW5jIHBhcnNlR3JhcGhRTFJlcXVlc3RPckdldEZyb21DYWNoZShyZXF1ZXN0KSB7XG4gICAgaWYgKCFfR3JhcGhRTEhhbmRsZXIucGFyc2VkUmVxdWVzdENhY2hlLmhhcyhyZXF1ZXN0KSkge1xuICAgICAgX0dyYXBoUUxIYW5kbGVyLnBhcnNlZFJlcXVlc3RDYWNoZS5zZXQoXG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIGF3YWl0IHBhcnNlR3JhcGhRTFJlcXVlc3QocmVxdWVzdCkuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBfR3JhcGhRTEhhbmRsZXIucGFyc2VkUmVxdWVzdENhY2hlLmdldChyZXF1ZXN0KTtcbiAgfVxuICBhc3luYyBwYXJzZShhcmdzKSB7XG4gICAgY29uc3QgbWF0Y2gyID0gbWF0Y2hSZXF1ZXN0VXJsKG5ldyBVUkwoYXJncy5yZXF1ZXN0LnVybCksIHRoaXMuZW5kcG9pbnQpO1xuICAgIGNvbnN0IGNvb2tpZXMgPSBnZXRBbGxSZXF1ZXN0Q29va2llcyhhcmdzLnJlcXVlc3QpO1xuICAgIGlmICghbWF0Y2gyLm1hdGNoZXMpIHtcbiAgICAgIHJldHVybiB7IG1hdGNoOiBtYXRjaDIsIGNvb2tpZXMgfTtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkUmVzdWx0ID0gYXdhaXQgdGhpcy5wYXJzZUdyYXBoUUxSZXF1ZXN0T3JHZXRGcm9tQ2FjaGUoXG4gICAgICBhcmdzLnJlcXVlc3RcbiAgICApO1xuICAgIGlmICh0eXBlb2YgcGFyc2VkUmVzdWx0ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICByZXR1cm4geyBtYXRjaDogbWF0Y2gyLCBjb29raWVzIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBtYXRjaDogbWF0Y2gyLFxuICAgICAgY29va2llcyxcbiAgICAgIHF1ZXJ5OiBwYXJzZWRSZXN1bHQucXVlcnksXG4gICAgICBvcGVyYXRpb25UeXBlOiBwYXJzZWRSZXN1bHQub3BlcmF0aW9uVHlwZSxcbiAgICAgIG9wZXJhdGlvbk5hbWU6IHBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lLFxuICAgICAgdmFyaWFibGVzOiBwYXJzZWRSZXN1bHQudmFyaWFibGVzXG4gICAgfTtcbiAgfVxuICBwcmVkaWNhdGUoYXJncykge1xuICAgIGlmIChhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25UeXBlID09PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKCFhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lICYmIHRoaXMuaW5mby5vcGVyYXRpb25UeXBlICE9PSBcImFsbFwiKSB7XG4gICAgICBjb25zdCBwdWJsaWNVcmwgPSB0b1B1YmxpY1VybChhcmdzLnJlcXVlc3QudXJsKTtcbiAgICAgIGRldlV0aWxzLndhcm4oYEZhaWxlZCB0byBpbnRlcmNlcHQgYSBHcmFwaFFMIHJlcXVlc3QgYXQgXCIke2FyZ3MucmVxdWVzdC5tZXRob2R9ICR7cHVibGljVXJsfVwiOiBhbm9ueW1vdXMgR3JhcGhRTCBvcGVyYXRpb25zIGFyZSBub3Qgc3VwcG9ydGVkLlxuXG5Db25zaWRlciBuYW1pbmcgdGhpcyBvcGVyYXRpb24gb3IgdXNpbmcgXCJncmFwaHFsLm9wZXJhdGlvbigpXCIgcmVxdWVzdCBoYW5kbGVyIHRvIGludGVyY2VwdCBHcmFwaFFMIHJlcXVlc3RzIHJlZ2FyZGxlc3Mgb2YgdGhlaXIgb3BlcmF0aW9uIG5hbWUvdHlwZS4gUmVhZCBtb3JlOiBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL2dyYXBocWwvI2dyYXBocWxvcGVyYXRpb25yZXNvbHZlcmApO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBoYXNNYXRjaGluZ09wZXJhdGlvblR5cGUgPSB0aGlzLmluZm8ub3BlcmF0aW9uVHlwZSA9PT0gXCJhbGxcIiB8fCBhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25UeXBlID09PSB0aGlzLmluZm8ub3BlcmF0aW9uVHlwZTtcbiAgICBjb25zdCBoYXNNYXRjaGluZ09wZXJhdGlvbk5hbWUgPSB0aGlzLmluZm8ub3BlcmF0aW9uTmFtZSBpbnN0YW5jZW9mIFJlZ0V4cCA/IHRoaXMuaW5mby5vcGVyYXRpb25OYW1lLnRlc3QoYXJncy5wYXJzZWRSZXN1bHQub3BlcmF0aW9uTmFtZSB8fCBcIlwiKSA6IGFyZ3MucGFyc2VkUmVzdWx0Lm9wZXJhdGlvbk5hbWUgPT09IHRoaXMuaW5mby5vcGVyYXRpb25OYW1lO1xuICAgIHJldHVybiBhcmdzLnBhcnNlZFJlc3VsdC5tYXRjaC5tYXRjaGVzICYmIGhhc01hdGNoaW5nT3BlcmF0aW9uVHlwZSAmJiBoYXNNYXRjaGluZ09wZXJhdGlvbk5hbWU7XG4gIH1cbiAgZXh0ZW5kUmVzb2x2ZXJBcmdzKGFyZ3MpIHtcbiAgICByZXR1cm4ge1xuICAgICAgcXVlcnk6IGFyZ3MucGFyc2VkUmVzdWx0LnF1ZXJ5IHx8IFwiXCIsXG4gICAgICBvcGVyYXRpb25OYW1lOiBhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lIHx8IFwiXCIsXG4gICAgICB2YXJpYWJsZXM6IGFyZ3MucGFyc2VkUmVzdWx0LnZhcmlhYmxlcyB8fCB7fSxcbiAgICAgIGNvb2tpZXM6IGFyZ3MucGFyc2VkUmVzdWx0LmNvb2tpZXNcbiAgICB9O1xuICB9XG4gIGFzeW5jIGxvZyhhcmdzKSB7XG4gICAgY29uc3QgbG9nZ2VkUmVxdWVzdCA9IGF3YWl0IHNlcmlhbGl6ZVJlcXVlc3QoYXJncy5yZXF1ZXN0KTtcbiAgICBjb25zdCBsb2dnZWRSZXNwb25zZSA9IGF3YWl0IHNlcmlhbGl6ZVJlc3BvbnNlKGFyZ3MucmVzcG9uc2UpO1xuICAgIGNvbnN0IHN0YXR1c0NvbG9yID0gZ2V0U3RhdHVzQ29kZUNvbG9yKGxvZ2dlZFJlc3BvbnNlLnN0YXR1cyk7XG4gICAgY29uc3QgcmVxdWVzdEluZm8gPSBhcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lID8gYCR7YXJncy5wYXJzZWRSZXN1bHQub3BlcmF0aW9uVHlwZX0gJHthcmdzLnBhcnNlZFJlc3VsdC5vcGVyYXRpb25OYW1lfWAgOiBgYW5vbnltb3VzICR7YXJncy5wYXJzZWRSZXN1bHQub3BlcmF0aW9uVHlwZX1gO1xuICAgIGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQoXG4gICAgICBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFxuICAgICAgICBgJHtnZXRUaW1lc3RhbXAoKX0gJHtyZXF1ZXN0SW5mb30gKCVjJHtsb2dnZWRSZXNwb25zZS5zdGF0dXN9ICR7bG9nZ2VkUmVzcG9uc2Uuc3RhdHVzVGV4dH0lYylgXG4gICAgICApLFxuICAgICAgYGNvbG9yOiR7c3RhdHVzQ29sb3J9YCxcbiAgICAgIFwiY29sb3I6aW5oZXJpdFwiXG4gICAgKTtcbiAgICBjb25zb2xlLmxvZyhcIlJlcXVlc3Q6XCIsIGxvZ2dlZFJlcXVlc3QpO1xuICAgIGNvbnNvbGUubG9nKFwiSGFuZGxlcjpcIiwgdGhpcyk7XG4gICAgY29uc29sZS5sb2coXCJSZXNwb25zZTpcIiwgbG9nZ2VkUmVzcG9uc2UpO1xuICAgIGNvbnNvbGUuZ3JvdXBFbmQoKTtcbiAgfVxufTtcbl9fcHVibGljRmllbGQoX0dyYXBoUUxIYW5kbGVyLCBcInBhcnNlZFJlcXVlc3RDYWNoZVwiLCAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKSk7XG52YXIgR3JhcGhRTEhhbmRsZXIgPSBfR3JhcGhRTEhhbmRsZXI7XG5cbi8vIG5vZGVfbW9kdWxlcy8ucG5wbS9tc3dAMi4yLjEzX3R5cGVzY3JpcHRANS4zLjMvbm9kZV9tb2R1bGVzL21zdy9saWIvY29yZS9ncmFwaHFsLm1qc1xuZnVuY3Rpb24gY3JlYXRlU2NvcGVkR3JhcGhRTEhhbmRsZXIob3BlcmF0aW9uVHlwZSwgdXJsKSB7XG4gIHJldHVybiAob3BlcmF0aW9uTmFtZSwgcmVzb2x2ZXIsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgIHJldHVybiBuZXcgR3JhcGhRTEhhbmRsZXIoXG4gICAgICBvcGVyYXRpb25UeXBlLFxuICAgICAgb3BlcmF0aW9uTmFtZSxcbiAgICAgIHVybCxcbiAgICAgIHJlc29sdmVyLFxuICAgICAgb3B0aW9uc1xuICAgICk7XG4gIH07XG59XG5mdW5jdGlvbiBjcmVhdGVHcmFwaFFMT3BlcmF0aW9uSGFuZGxlcih1cmwpIHtcbiAgcmV0dXJuIChyZXNvbHZlcikgPT4ge1xuICAgIHJldHVybiBuZXcgR3JhcGhRTEhhbmRsZXIoXCJhbGxcIiwgbmV3IFJlZ0V4cChcIi4qXCIpLCB1cmwsIHJlc29sdmVyKTtcbiAgfTtcbn1cbnZhciBzdGFuZGFyZEdyYXBoUUxIYW5kbGVycyA9IHtcbiAgLyoqXG4gICAqIEludGVyY2VwdHMgYSBHcmFwaFFMIHF1ZXJ5IGJ5IGEgZ2l2ZW4gbmFtZS5cbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogZ3JhcGhxbC5xdWVyeSgnR2V0VXNlcicsICgpID0+IHtcbiAgICogICByZXR1cm4gSHR0cFJlc3BvbnNlLmpzb24oeyBkYXRhOiB7IHVzZXI6IHsgbmFtZTogJ0pvaG4nIH0gfSB9KVxuICAgKiB9KVxuICAgKlxuICAgKiBAc2VlIHtAbGluayBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL2dyYXBocWwjZ3JhcGhxbHF1ZXJ5cXVlcnluYW1lLXJlc29sdmVyIGBncmFwaHFsLnF1ZXJ5KClgIEFQSSByZWZlcmVuY2V9XG4gICAqL1xuICBxdWVyeTogY3JlYXRlU2NvcGVkR3JhcGhRTEhhbmRsZXIoXCJxdWVyeVwiLCBcIipcIiksXG4gIC8qKlxuICAgKiBJbnRlcmNlcHRzIGEgR3JhcGhRTCBtdXRhdGlvbiBieSBpdHMgbmFtZS5cbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogZ3JhcGhxbC5tdXRhdGlvbignU2F2ZVBvc3QnLCAoKSA9PiB7XG4gICAqICAgcmV0dXJuIEh0dHBSZXNwb25zZS5qc29uKHsgZGF0YTogeyBwb3N0OiB7IGlkOiAnYWJjLTEyMyB9IH0gfSlcbiAgICogfSlcbiAgICpcbiAgICogQHNlZSB7QGxpbmsgaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2FwaS9ncmFwaHFsI2dyYXBocWxtdXRhdGlvbm11dGF0aW9ubmFtZS1yZXNvbHZlciBgZ3JhcGhxbC5xdWVyeSgpYCBBUEkgcmVmZXJlbmNlfVxuICAgKlxuICAgKi9cbiAgbXV0YXRpb246IGNyZWF0ZVNjb3BlZEdyYXBoUUxIYW5kbGVyKFwibXV0YXRpb25cIiwgXCIqXCIpLFxuICAvKipcbiAgICogSW50ZXJjZXB0cyBhbnkgR3JhcGhRTCBvcGVyYXRpb24sIHJlZ2FyZGxlc3Mgb2YgaXRzIHR5cGUgb3IgbmFtZS5cbiAgICpcbiAgICogQGV4YW1wbGVcbiAgICogZ3JhcGhxbC5vcGVyYXRpb24oKCkgPT4ge1xuICAgKiAgIHJldHVybiBIdHRwUmVzcG9uc2UuanNvbih7IGRhdGE6IHsgbmFtZTogJ0pvaG4nIH0gfSlcbiAgICogfSlcbiAgICpcbiAgICogQHNlZSB7QGxpbmsgaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2FwaS9ncmFwaHFsI2dyYXBobG9wZXJhdGlvbnJlc29sdmVyIGBncmFwaHFsLm9wZXJhdGlvbigpYCBBUEkgcmVmZXJlbmNlfVxuICAgKi9cbiAgb3BlcmF0aW9uOiBjcmVhdGVHcmFwaFFMT3BlcmF0aW9uSGFuZGxlcihcIipcIilcbn07XG5mdW5jdGlvbiBjcmVhdGVHcmFwaFFMTGluayh1cmwpIHtcbiAgcmV0dXJuIHtcbiAgICBvcGVyYXRpb246IGNyZWF0ZUdyYXBoUUxPcGVyYXRpb25IYW5kbGVyKHVybCksXG4gICAgcXVlcnk6IGNyZWF0ZVNjb3BlZEdyYXBoUUxIYW5kbGVyKFwicXVlcnlcIiwgdXJsKSxcbiAgICBtdXRhdGlvbjogY3JlYXRlU2NvcGVkR3JhcGhRTEhhbmRsZXIoXCJtdXRhdGlvblwiLCB1cmwpXG4gIH07XG59XG52YXIgZ3JhcGhxbDIgPSB7XG4gIC4uLnN0YW5kYXJkR3JhcGhRTEhhbmRsZXJzLFxuICAvKipcbiAgICogSW50ZXJjZXB0cyBHcmFwaFFMIG9wZXJhdGlvbnMgc2NvcGVkIGJ5IHRoZSBnaXZlbiBVUkwuXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIGNvbnN0IGdpdGh1YiA9IGdyYXBocWwubGluaygnaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS9ncmFwaHFsJylcbiAgICogZ2l0aHViLnF1ZXJ5KCdHZXRSZXBvJywgcmVzb2x2ZXIpXG4gICAqXG4gICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvZ3JhcGhxbCNncmFwaHFsbGlua3VybCBgZ3JhcGhxbC5saW5rKClgIEFQSSByZWZlcmVuY2V9XG4gICAqL1xuICBsaW5rOiBjcmVhdGVHcmFwaFFMTGlua1xufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2dldFJlc3BvbnNlLm1qc1xudmFyIGdldFJlc3BvbnNlID0gYXN5bmMgKGhhbmRsZXJzLCByZXF1ZXN0KSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGV4ZWN1dGVIYW5kbGVycyh7XG4gICAgcmVxdWVzdCxcbiAgICByZXF1ZXN0SWQ6IGNyZWF0ZVJlcXVlc3RJZCgpLFxuICAgIGhhbmRsZXJzXG4gIH0pO1xuICByZXR1cm4gcmVzdWx0ID09IG51bGwgPyB2b2lkIDAgOiByZXN1bHQucmVzcG9uc2U7XG59O1xuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvdXRpbHMvSHR0cFJlc3BvbnNlL2RlY29yYXRvcnMubWpzXG52YXIgeyBtZXNzYWdlOiBtZXNzYWdlMiB9ID0gc291cmNlX2RlZmF1bHQ7XG5mdW5jdGlvbiBub3JtYWxpemVSZXNwb25zZUluaXQoaW5pdCA9IHt9KSB7XG4gIGNvbnN0IHN0YXR1cyA9IChpbml0ID09IG51bGwgPyB2b2lkIDAgOiBpbml0LnN0YXR1cykgfHwgMjAwO1xuICBjb25zdCBzdGF0dXNUZXh0ID0gKGluaXQgPT0gbnVsbCA/IHZvaWQgMCA6IGluaXQuc3RhdHVzVGV4dCkgfHwgbWVzc2FnZTJbc3RhdHVzXSB8fCBcIlwiO1xuICBjb25zdCBoZWFkZXJzID0gbmV3IEhlYWRlcnMoaW5pdCA9PSBudWxsID8gdm9pZCAwIDogaW5pdC5oZWFkZXJzKTtcbiAgcmV0dXJuIHtcbiAgICAuLi5pbml0LFxuICAgIGhlYWRlcnMsXG4gICAgc3RhdHVzLFxuICAgIHN0YXR1c1RleHRcbiAgfTtcbn1cbmZ1bmN0aW9uIGRlY29yYXRlUmVzcG9uc2UocmVzcG9uc2UsIGluaXQpIHtcbiAgaWYgKGluaXQudHlwZSkge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXNwb25zZSwgXCJ0eXBlXCIsIHtcbiAgICAgIHZhbHVlOiBpbml0LnR5cGUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgd3JpdGFibGU6IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGNvbnN0IHJlc3BvbnNlQ29va2llcyA9IEhlYWRlcnMyLnByb3RvdHlwZS5nZXRTZXRDb29raWUuY2FsbChcbiAgICAgIGluaXQuaGVhZGVyc1xuICAgICk7XG4gICAgZm9yIChjb25zdCBjb29raWVTdHJpbmcgb2YgcmVzcG9uc2VDb29raWVzKSB7XG4gICAgICBkb2N1bWVudC5jb29raWUgPSBjb29raWVTdHJpbmc7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXNwb25zZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL0h0dHBSZXNwb25zZS5tanNcbnZhciBIdHRwUmVzcG9uc2UgPSBjbGFzcyBfSHR0cFJlc3BvbnNlIGV4dGVuZHMgUmVzcG9uc2Uge1xuICBjb25zdHJ1Y3Rvcihib2R5LCBpbml0KSB7XG4gICAgY29uc3QgcmVzcG9uc2VJbml0ID0gbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQpO1xuICAgIHN1cGVyKGJvZHksIHJlc3BvbnNlSW5pdCk7XG4gICAgZGVjb3JhdGVSZXNwb25zZSh0aGlzLCByZXNwb25zZUluaXQpO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBgUmVzcG9uc2VgIHdpdGggYSBgQ29udGVudC1UeXBlOiBcInRleHQvcGxhaW5cImAgYm9keS5cbiAgICogQGV4YW1wbGVcbiAgICogSHR0cFJlc3BvbnNlLnRleHQoJ2hlbGxvIHdvcmxkJylcbiAgICogSHR0cFJlc3BvbnNlLnRleHQoJ0Vycm9yJywgeyBzdGF0dXM6IDUwMCB9KVxuICAgKi9cbiAgc3RhdGljIHRleHQoYm9keSwgaW5pdCkge1xuICAgIGNvbnN0IHJlc3BvbnNlSW5pdCA9IG5vcm1hbGl6ZVJlc3BvbnNlSW5pdChpbml0KTtcbiAgICBpZiAoIXJlc3BvbnNlSW5pdC5oZWFkZXJzLmhhcyhcIkNvbnRlbnQtVHlwZVwiKSkge1xuICAgICAgcmVzcG9uc2VJbml0LmhlYWRlcnMuc2V0KFwiQ29udGVudC1UeXBlXCIsIFwidGV4dC9wbGFpblwiKTtcbiAgICB9XG4gICAgaWYgKCFyZXNwb25zZUluaXQuaGVhZGVycy5oYXMoXCJDb250ZW50LUxlbmd0aFwiKSkge1xuICAgICAgcmVzcG9uc2VJbml0LmhlYWRlcnMuc2V0KFxuICAgICAgICBcIkNvbnRlbnQtTGVuZ3RoXCIsXG4gICAgICAgIGJvZHkgPyBuZXcgQmxvYihbYm9keV0pLnNpemUudG9TdHJpbmcoKSA6IFwiMFwiXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IF9IdHRwUmVzcG9uc2UoYm9keSwgcmVzcG9uc2VJbml0KTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlIGEgYFJlc3BvbnNlYCB3aXRoIGEgYENvbnRlbnQtVHlwZTogXCJhcHBsaWNhdGlvbi9qc29uXCJgIGJvZHkuXG4gICAqIEBleGFtcGxlXG4gICAqIEh0dHBSZXNwb25zZS5qc29uKHsgZmlyc3ROYW1lOiAnSm9obicgfSlcbiAgICogSHR0cFJlc3BvbnNlLmpzb24oeyBlcnJvcjogJ05vdCBBdXRob3JpemVkJyB9LCB7IHN0YXR1czogNDAxIH0pXG4gICAqL1xuICBzdGF0aWMganNvbihib2R5LCBpbml0KSB7XG4gICAgY29uc3QgcmVzcG9uc2VJbml0ID0gbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQpO1xuICAgIGlmICghcmVzcG9uc2VJbml0LmhlYWRlcnMuaGFzKFwiQ29udGVudC1UeXBlXCIpKSB7XG4gICAgICByZXNwb25zZUluaXQuaGVhZGVycy5zZXQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi9qc29uXCIpO1xuICAgIH1cbiAgICBjb25zdCByZXNwb25zZVRleHQgPSBKU09OLnN0cmluZ2lmeShib2R5KTtcbiAgICBpZiAoIXJlc3BvbnNlSW5pdC5oZWFkZXJzLmhhcyhcIkNvbnRlbnQtTGVuZ3RoXCIpKSB7XG4gICAgICByZXNwb25zZUluaXQuaGVhZGVycy5zZXQoXG4gICAgICAgIFwiQ29udGVudC1MZW5ndGhcIixcbiAgICAgICAgcmVzcG9uc2VUZXh0ID8gbmV3IEJsb2IoW3Jlc3BvbnNlVGV4dF0pLnNpemUudG9TdHJpbmcoKSA6IFwiMFwiXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IF9IdHRwUmVzcG9uc2UoXG4gICAgICByZXNwb25zZVRleHQsXG4gICAgICByZXNwb25zZUluaXRcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBgUmVzcG9uc2VgIHdpdGggYSBgQ29udGVudC1UeXBlOiBcImFwcGxpY2F0aW9uL3htbFwiYCBib2R5LlxuICAgKiBAZXhhbXBsZVxuICAgKiBIdHRwUmVzcG9uc2UueG1sKGA8dXNlciBuYW1lPVwiSm9oblwiIC8+YClcbiAgICogSHR0cFJlc3BvbnNlLnhtbChgPGFydGljbGUgaWQ9XCJhYmMtMTIzXCIgLz5gLCB7IHN0YXR1czogMjAxIH0pXG4gICAqL1xuICBzdGF0aWMgeG1sKGJvZHksIGluaXQpIHtcbiAgICBjb25zdCByZXNwb25zZUluaXQgPSBub3JtYWxpemVSZXNwb25zZUluaXQoaW5pdCk7XG4gICAgaWYgKCFyZXNwb25zZUluaXQuaGVhZGVycy5oYXMoXCJDb250ZW50LVR5cGVcIikpIHtcbiAgICAgIHJlc3BvbnNlSW5pdC5oZWFkZXJzLnNldChcIkNvbnRlbnQtVHlwZVwiLCBcInRleHQveG1sXCIpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IF9IdHRwUmVzcG9uc2UoYm9keSwgcmVzcG9uc2VJbml0KTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlIGEgYFJlc3BvbnNlYCB3aXRoIGFuIGBBcnJheUJ1ZmZlcmAgYm9keS5cbiAgICogQGV4YW1wbGVcbiAgICogY29uc3QgYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKDMpXG4gICAqIGNvbnN0IHZpZXcgPSBuZXcgVWludDhBcnJheShidWZmZXIpXG4gICAqIHZpZXcuc2V0KFsxLCAyLCAzXSlcbiAgICpcbiAgICogSHR0cFJlc3BvbnNlLmFycmF5QnVmZmVyKGJ1ZmZlcilcbiAgICovXG4gIHN0YXRpYyBhcnJheUJ1ZmZlcihib2R5LCBpbml0KSB7XG4gICAgY29uc3QgcmVzcG9uc2VJbml0ID0gbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQpO1xuICAgIGlmIChib2R5KSB7XG4gICAgICByZXNwb25zZUluaXQuaGVhZGVycy5zZXQoXCJDb250ZW50LUxlbmd0aFwiLCBib2R5LmJ5dGVMZW5ndGgudG9TdHJpbmcoKSk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgX0h0dHBSZXNwb25zZShib2R5LCByZXNwb25zZUluaXQpO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBgUmVzcG9uc2VgIHdpdGggYSBgRm9ybURhdGFgIGJvZHkuXG4gICAqIEBleGFtcGxlXG4gICAqIGNvbnN0IGRhdGEgPSBuZXcgRm9ybURhdGEoKVxuICAgKiBkYXRhLnNldCgnbmFtZScsICdBbGljZScpXG4gICAqXG4gICAqIEh0dHBSZXNwb25zZS5mb3JtRGF0YShkYXRhKVxuICAgKi9cbiAgc3RhdGljIGZvcm1EYXRhKGJvZHksIGluaXQpIHtcbiAgICByZXR1cm4gbmV3IF9IdHRwUmVzcG9uc2UoYm9keSwgbm9ybWFsaXplUmVzcG9uc2VJbml0KGluaXQpKTtcbiAgfVxufTtcblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL2RlbGF5Lm1qc1xudmFyIFNFVF9USU1FT1VUX01BWF9BTExPV0VEX0lOVCA9IDIxNDc0ODM2NDc7XG52YXIgTUlOX1NFUlZFUl9SRVNQT05TRV9USU1FID0gMTAwO1xudmFyIE1BWF9TRVJWRVJfUkVTUE9OU0VfVElNRSA9IDQwMDtcbnZhciBOT0RFX1NFUlZFUl9SRVNQT05TRV9USU1FID0gNTtcbmZ1bmN0aW9uIGdldFJlYWxpc3RpY1Jlc3BvbnNlVGltZSgpIHtcbiAgaWYgKGlzTm9kZVByb2Nlc3MoKSkge1xuICAgIHJldHVybiBOT0RFX1NFUlZFUl9SRVNQT05TRV9USU1FO1xuICB9XG4gIHJldHVybiBNYXRoLmZsb29yKFxuICAgIE1hdGgucmFuZG9tKCkgKiAoTUFYX1NFUlZFUl9SRVNQT05TRV9USU1FIC0gTUlOX1NFUlZFUl9SRVNQT05TRV9USU1FKSArIE1JTl9TRVJWRVJfUkVTUE9OU0VfVElNRVxuICApO1xufVxuYXN5bmMgZnVuY3Rpb24gZGVsYXkoZHVyYXRpb25Pck1vZGUpIHtcbiAgbGV0IGRlbGF5VGltZTtcbiAgaWYgKHR5cGVvZiBkdXJhdGlvbk9yTW9kZSA9PT0gXCJzdHJpbmdcIikge1xuICAgIHN3aXRjaCAoZHVyYXRpb25Pck1vZGUpIHtcbiAgICAgIGNhc2UgXCJpbmZpbml0ZVwiOiB7XG4gICAgICAgIGRlbGF5VGltZSA9IFNFVF9USU1FT1VUX01BWF9BTExPV0VEX0lOVDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIFwicmVhbFwiOiB7XG4gICAgICAgIGRlbGF5VGltZSA9IGdldFJlYWxpc3RpY1Jlc3BvbnNlVGltZSgpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBGYWlsZWQgdG8gZGVsYXkgYSByZXNwb25zZTogdW5rbm93biBkZWxheSBtb2RlIFwiJHtkdXJhdGlvbk9yTW9kZX1cIi4gUGxlYXNlIG1ha2Ugc3VyZSB5b3UgcHJvdmlkZSBvbmUgb2YgdGhlIHN1cHBvcnRlZCBtb2RlcyAoXCJyZWFsXCIsIFwiaW5maW5pdGVcIikgb3IgYSBudW1iZXIuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmICh0eXBlb2YgZHVyYXRpb25Pck1vZGUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBkZWxheVRpbWUgPSBnZXRSZWFsaXN0aWNSZXNwb25zZVRpbWUoKTtcbiAgfSBlbHNlIHtcbiAgICBpZiAoZHVyYXRpb25Pck1vZGUgPiBTRVRfVElNRU9VVF9NQVhfQUxMT1dFRF9JTlQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEZhaWxlZCB0byBkZWxheSBhIHJlc3BvbnNlOiBwcm92aWRlZCBkZWxheSBkdXJhdGlvbiAoJHtkdXJhdGlvbk9yTW9kZX0pIGV4Y2VlZHMgdGhlIG1heGltdW0gYWxsb3dlZCBkdXJhdGlvbiBmb3IgXCJzZXRUaW1lb3V0XCIgKCR7U0VUX1RJTUVPVVRfTUFYX0FMTE9XRURfSU5UfSkuIFRoaXMgd2lsbCBjYXVzZSB0aGUgcmVzcG9uc2UgdG8gYmUgcmV0dXJuZWQgaW1tZWRpYXRlbHkuIFBsZWFzZSB1c2UgYSBudW1iZXIgd2l0aGluIHRoZSBhbGxvd2VkIHJhbmdlIHRvIGRlbGF5IHRoZSByZXNwb25zZSBieSBleGFjdCBkdXJhdGlvbiwgb3IgY29uc2lkZXIgdGhlIFwiaW5maW5pdGVcIiBkZWxheSBtb2RlIHRvIGRlbGF5IHRoZSByZXNwb25zZSBpbmRlZmluaXRlbHkuYFxuICAgICAgKTtcbiAgICB9XG4gICAgZGVsYXlUaW1lID0gZHVyYXRpb25Pck1vZGU7XG4gIH1cbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIGRlbGF5VGltZSkpO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvYnlwYXNzLm1qc1xuZnVuY3Rpb24gYnlwYXNzKGlucHV0LCBpbml0KSB7XG4gIGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdChcbiAgICAvLyBJZiBnaXZlbiBhIFJlcXVlc3QgaW5zdGFuY2UsIGNsb25lIGl0IG5vdCB0byBleGhhdXN0XG4gICAgLy8gdGhlIG9yaWdpbmFsIHJlcXVlc3QncyBib2R5LlxuICAgIGlucHV0IGluc3RhbmNlb2YgUmVxdWVzdCA/IGlucHV0LmNsb25lKCkgOiBpbnB1dCxcbiAgICBpbml0XG4gICk7XG4gIGludmFyaWFudChcbiAgICAhcmVxdWVzdC5ib2R5VXNlZCxcbiAgICAnRmFpbGVkIHRvIGNyZWF0ZSBhIGJ5cGFzc2VkIHJlcXVlc3QgdG8gXCIlcyAlc1wiOiBnaXZlbiByZXF1ZXN0IGluc3RhbmNlIGFscmVhZHkgaGFzIGl0cyBib2R5IHJlYWQuIE1ha2Ugc3VyZSB0byBjbG9uZSB0aGUgaW50ZXJjZXB0ZWQgcmVxdWVzdCBpZiB5b3Ugd2lzaCB0byByZWFkIGl0cyBib2R5IGJlZm9yZSBieXBhc3NpbmcgaXQuJyxcbiAgICByZXF1ZXN0Lm1ldGhvZCxcbiAgICByZXF1ZXN0LnVybFxuICApO1xuICBjb25zdCByZXF1ZXN0Q2xvbmUgPSByZXF1ZXN0LmNsb25lKCk7XG4gIHJlcXVlc3RDbG9uZS5oZWFkZXJzLnNldChcIngtbXN3LWludGVudGlvblwiLCBcImJ5cGFzc1wiKTtcbiAgcmV0dXJuIHJlcXVlc3RDbG9uZTtcbn1cblxuLy8gbm9kZV9tb2R1bGVzLy5wbnBtL21zd0AyLjIuMTNfdHlwZXNjcmlwdEA1LjMuMy9ub2RlX21vZHVsZXMvbXN3L2xpYi9jb3JlL3Bhc3N0aHJvdWdoLm1qc1xuZnVuY3Rpb24gcGFzc3Rocm91Z2goKSB7XG4gIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwge1xuICAgIHN0YXR1czogMzAyLFxuICAgIHN0YXR1c1RleHQ6IFwiUGFzc3Rocm91Z2hcIixcbiAgICBoZWFkZXJzOiB7XG4gICAgICBcIngtbXN3LWludGVudGlvblwiOiBcInBhc3N0aHJvdWdoXCJcbiAgICB9XG4gIH0pO1xufVxuXG4vLyBub2RlX21vZHVsZXMvLnBucG0vbXN3QDIuMi4xM190eXBlc2NyaXB0QDUuMy4zL25vZGVfbW9kdWxlcy9tc3cvbGliL2NvcmUvaW5kZXgubWpzXG5jaGVja0dsb2JhbHMoKTtcbmV4cG9ydCB7XG4gIEdyYXBoUUxIYW5kbGVyLFxuICBIdHRwSGFuZGxlcixcbiAgSHR0cE1ldGhvZHMsXG4gIEh0dHBSZXNwb25zZSxcbiAgTUFYX1NFUlZFUl9SRVNQT05TRV9USU1FLFxuICBNSU5fU0VSVkVSX1JFU1BPTlNFX1RJTUUsXG4gIE5PREVfU0VSVkVSX1JFU1BPTlNFX1RJTUUsXG4gIFJlcXVlc3RIYW5kbGVyLFxuICBTRVRfVElNRU9VVF9NQVhfQUxMT1dFRF9JTlQsXG4gIFNldHVwQXBpLFxuICBieXBhc3MsXG4gIGNsZWFuVXJsLFxuICBkZWxheSxcbiAgZ2V0UmVzcG9uc2UsXG4gIGdyYXBocWwyIGFzIGdyYXBocWwsXG4gIGhhbmRsZVJlcXVlc3QsXG4gIGh0dHAsXG4gIG1hdGNoUmVxdWVzdFVybCxcbiAgcGFzc3Rocm91Z2hcbn07XG4vKiEgQnVuZGxlZCBsaWNlbnNlIGluZm9ybWF0aW9uOlxuXG5AYnVuZGxlZC1lcy1tb2R1bGVzL3N0YXR1c2VzL2luZGV4LWVzbS5qczpcbiAgKCohIEJ1bmRsZWQgbGljZW5zZSBpbmZvcm1hdGlvbjpcbiAgXG4gIHN0YXR1c2VzL2luZGV4LmpzOlxuICAgICgqIVxuICAgICAqIHN0YXR1c2VzXG4gICAgICogQ29weXJpZ2h0KGMpIDIwMTQgSm9uYXRoYW4gT25nXG4gICAgICogQ29weXJpZ2h0KGMpIDIwMTYgRG91Z2xhcyBDaHJpc3RvcGhlciBXaWxzb25cbiAgICAgKiBNSVQgTGljZW5zZWRcbiAgICAgKilcbiAgKilcblxuQGJ1bmRsZWQtZXMtbW9kdWxlcy9jb29raWUvaW5kZXgtZXNtLmpzOlxuICAoKiEgQnVuZGxlZCBsaWNlbnNlIGluZm9ybWF0aW9uOlxuICBcbiAgY29va2llL2luZGV4LmpzOlxuICAgICgqIVxuICAgICAqIGNvb2tpZVxuICAgICAqIENvcHlyaWdodChjKSAyMDEyLTIwMTQgUm9tYW4gU2h0eWxtYW5cbiAgICAgKiBDb3B5cmlnaHQoYykgMjAxNSBEb3VnbGFzIENocmlzdG9waGVyIFdpbHNvblxuICAgICAqIE1JVCBMaWNlbnNlZFxuICAgICAqKVxuICAqKVxuKi9cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1zdy5qcy5tYXBcbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0U7QUFBQSxPQUNLO0FBR1AsU0FBUyxlQUFlO0FBQ3RCO0FBQUEsSUFDRSxPQUFPLFFBQVE7QUFBQSxJQUNmLFNBQVM7QUFBQSxNQUNQO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsY0FBYyxRQUFRLFVBQVU7QUFDdkMsU0FBTyxPQUFPLFlBQVksTUFBTSxTQUFTLFlBQVk7QUFDdkQ7QUFHQSxJQUFJLG1CQUFtQixDQUFDLHFCQUFxQjtBQUMzQyxtQkFBaUIsU0FBUyxJQUFJO0FBQzlCLG1CQUFpQixTQUFTLElBQUk7QUFDOUIsbUJBQWlCLFFBQVEsSUFBSTtBQUM3QixTQUFPO0FBQ1QsR0FBRyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3hCLFNBQVMsbUJBQW1CLFFBQVE7QUFDbEMsTUFBSSxTQUFTLEtBQUs7QUFDaEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFNBQVMsS0FBSztBQUNoQixXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsZUFBZTtBQUN0QixRQUFNLE1BQXNCLG9CQUFJLEtBQUs7QUFDckMsU0FBTyxDQUFDLElBQUksU0FBUyxHQUFHLElBQUksV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQVUsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHO0FBQzNKO0FBR0EsZUFBZSxpQkFBaUIsU0FBUztBQUN2QyxRQUFNLGVBQWUsUUFBUSxNQUFNO0FBQ25DLFFBQU0sY0FBYyxNQUFNLGFBQWEsS0FBSztBQUM1QyxTQUFPO0FBQUEsSUFDTCxLQUFLLElBQUksSUFBSSxRQUFRLEdBQUc7QUFBQSxJQUN4QixRQUFRLFFBQVE7QUFBQSxJQUNoQixTQUFTLE9BQU8sWUFBWSxRQUFRLFFBQVEsUUFBUSxDQUFDO0FBQUEsSUFDckQsTUFBTTtBQUFBLEVBQ1I7QUFDRjtBQUdBLElBQUksV0FBVyxPQUFPO0FBQ3RCLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksbUJBQW1CLE9BQU87QUFDOUIsSUFBSSxvQkFBb0IsT0FBTztBQUMvQixJQUFJLGVBQWUsT0FBTztBQUMxQixJQUFJLGVBQWUsT0FBTyxVQUFVO0FBQ3BDLElBQUksYUFBYSxDQUFDLElBQUksUUFBUSxTQUFTLFlBQVk7QUFDakQsU0FBTyxRQUFRLEdBQUcsR0FBRyxrQkFBa0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLE1BQU0sRUFBRSxTQUFTLENBQUMsRUFBRSxHQUFHLFNBQVMsR0FBRyxHQUFHLElBQUk7QUFDN0Y7QUFDQSxJQUFJLGNBQWMsQ0FBQyxJQUFJLE1BQU0sUUFBUSxTQUFTO0FBQzVDLE1BQUksUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLFNBQVMsWUFBWTtBQUNsRSxhQUFTLE9BQU8sa0JBQWtCLElBQUk7QUFDcEMsVUFBSSxDQUFDLGFBQWEsS0FBSyxJQUFJLEdBQUcsS0FBSyxRQUFRO0FBQ3pDLGtCQUFVLElBQUksS0FBSyxFQUFFLEtBQUssTUFBTSxLQUFLLEdBQUcsR0FBRyxZQUFZLEVBQUUsT0FBTyxpQkFBaUIsTUFBTSxHQUFHLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxFQUN2SDtBQUNBLFNBQU87QUFDVDtBQUNBLElBQUksVUFBVSxDQUFDLEtBQUssWUFBWSxZQUFZLFNBQVMsT0FBTyxPQUFPLFNBQVMsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS25HLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxhQUFhLFVBQVUsUUFBUSxXQUFXLEVBQUUsT0FBTyxLQUFLLFlBQVksS0FBSyxDQUFDLElBQUk7QUFBQSxFQUN6RztBQUNGO0FBQ0EsSUFBSSxnQkFBZ0IsV0FBVztBQUFBLEVBQzdCLG1DQUFtQyxTQUFTLFFBQVE7QUFDbEQsV0FBTyxVQUFVO0FBQUEsTUFDZixPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxtQkFBbUIsV0FBVztBQUFBLEVBQ2hDLGlDQUFpQyxTQUFTLFFBQVE7QUFDaEQ7QUFDQSxRQUFJLFFBQVEsY0FBYztBQUMxQixXQUFPLFVBQVU7QUFDakIsWUFBUSxVQUFVO0FBQ2xCLFlBQVEsT0FBTyw2QkFBNkIsS0FBSztBQUNqRCxZQUFRLFFBQVEscUJBQXFCLEtBQUs7QUFDMUMsWUFBUSxXQUFXO0FBQUEsTUFDakIsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLElBQ1A7QUFDQSxZQUFRLFFBQVE7QUFBQSxNQUNkLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxJQUNQO0FBQ0EsWUFBUSxRQUFRO0FBQUEsTUFDZCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsSUFDUDtBQUNBLGFBQVMsNkJBQTZCLFFBQVE7QUFDNUMsVUFBSSxNQUFNLENBQUM7QUFDWCxhQUFPLEtBQUssTUFBTSxFQUFFLFFBQVEsU0FBUyxZQUFZLE1BQU07QUFDckQsWUFBSSxXQUFXLE9BQU8sSUFBSTtBQUMxQixZQUFJLFVBQVUsT0FBTyxJQUFJO0FBQ3pCLFlBQUksU0FBUyxZQUFZLENBQUMsSUFBSTtBQUFBLE1BQ2hDLENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQUNBLGFBQVMscUJBQXFCLFFBQVE7QUFDcEMsYUFBTyxPQUFPLEtBQUssTUFBTSxFQUFFLElBQUksU0FBUyxRQUFRLE1BQU07QUFDcEQsZUFBTyxPQUFPLElBQUk7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUNBLGFBQVMsY0FBYyxVQUFVO0FBQy9CLFVBQUksTUFBTSxTQUFTLFlBQVk7QUFDL0IsVUFBSSxDQUFDLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxNQUFNLEdBQUcsR0FBRztBQUM1RCxjQUFNLElBQUksTUFBTSw4QkFBOEIsV0FBVyxHQUFHO0FBQUEsTUFDOUQ7QUFDQSxhQUFPLFFBQVEsS0FBSyxHQUFHO0FBQUEsSUFDekI7QUFDQSxhQUFTLGlCQUFpQixNQUFNO0FBQzlCLFVBQUksQ0FBQyxPQUFPLFVBQVUsZUFBZSxLQUFLLFFBQVEsU0FBUyxJQUFJLEdBQUc7QUFDaEUsY0FBTSxJQUFJLE1BQU0sMEJBQTBCLElBQUk7QUFBQSxNQUNoRDtBQUNBLGFBQU8sUUFBUSxRQUFRLElBQUk7QUFBQSxJQUM3QjtBQUNBLGFBQVMsUUFBUSxNQUFNO0FBQ3JCLFVBQUksT0FBTyxTQUFTLFVBQVU7QUFDNUIsZUFBTyxpQkFBaUIsSUFBSTtBQUFBLE1BQzlCO0FBQ0EsVUFBSSxPQUFPLFNBQVMsVUFBVTtBQUM1QixjQUFNLElBQUksVUFBVSxpQ0FBaUM7QUFBQSxNQUN2RDtBQUNBLFVBQUksSUFBSSxTQUFTLE1BQU0sRUFBRTtBQUN6QixVQUFJLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDYixlQUFPLGlCQUFpQixDQUFDO0FBQUEsTUFDM0I7QUFDQSxhQUFPLGNBQWMsSUFBSTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLGtCQUFrQixRQUFRLGlCQUFpQixHQUFHLENBQUM7QUFDbkQsSUFBSSxpQkFBaUIsZ0JBQWdCO0FBR3JDLElBQUksRUFBRSxRQUFRLElBQUk7QUFDbEIsZUFBZSxrQkFBa0IsVUFBVTtBQUN6QyxRQUFNLGdCQUFnQixTQUFTLE1BQU07QUFDckMsUUFBTSxlQUFlLE1BQU0sY0FBYyxLQUFLO0FBQzlDLFFBQU0saUJBQWlCLGNBQWMsVUFBVTtBQUMvQyxRQUFNLHFCQUFxQixjQUFjLGNBQWMsUUFBUSxjQUFjLEtBQUs7QUFDbEYsU0FBTztBQUFBLElBQ0wsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osU0FBUyxPQUFPLFlBQVksY0FBYyxRQUFRLFFBQVEsQ0FBQztBQUFBLElBQzNELE1BQU07QUFBQSxFQUNSO0FBQ0Y7QUFHQSxTQUFTLE1BQU0sS0FBSztBQUNsQixNQUFJLFNBQVMsQ0FBQztBQUNkLE1BQUksSUFBSTtBQUNSLFNBQU8sSUFBSSxJQUFJLFFBQVE7QUFDckIsUUFBSSxPQUFPLElBQUksQ0FBQztBQUNoQixRQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLO0FBQ2hELGFBQU8sS0FBSyxFQUFFLE1BQU0sWUFBWSxPQUFPLEdBQUcsT0FBTyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQzNEO0FBQUEsSUFDRjtBQUNBLFFBQUksU0FBUyxNQUFNO0FBQ2pCLGFBQU8sS0FBSyxFQUFFLE1BQU0sZ0JBQWdCLE9BQU8sS0FBSyxPQUFPLElBQUksR0FBRyxFQUFFLENBQUM7QUFDakU7QUFBQSxJQUNGO0FBQ0EsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLLEVBQUUsTUFBTSxRQUFRLE9BQU8sR0FBRyxPQUFPLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdkQ7QUFBQSxJQUNGO0FBQ0EsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLLEVBQUUsTUFBTSxTQUFTLE9BQU8sR0FBRyxPQUFPLElBQUksR0FBRyxFQUFFLENBQUM7QUFDeEQ7QUFBQSxJQUNGO0FBQ0EsUUFBSSxTQUFTLEtBQUs7QUFDaEIsVUFBSSxPQUFPO0FBQ1gsVUFBSSxJQUFJLElBQUk7QUFDWixhQUFPLElBQUksSUFBSSxRQUFRO0FBQ3JCLFlBQUksT0FBTyxJQUFJLFdBQVcsQ0FBQztBQUMzQjtBQUFBO0FBQUEsVUFFRSxRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQ3RCLFFBQVEsTUFBTSxRQUFRO0FBQUEsVUFDdEIsUUFBUSxNQUFNLFFBQVE7QUFBQSxVQUN0QixTQUFTO0FBQUEsVUFDVDtBQUNBLGtCQUFRLElBQUksR0FBRztBQUNmO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUNBLFVBQUksQ0FBQztBQUNILGNBQU0sSUFBSSxVQUFVLDZCQUE2QixPQUFPLENBQUMsQ0FBQztBQUM1RCxhQUFPLEtBQUssRUFBRSxNQUFNLFFBQVEsT0FBTyxHQUFHLE9BQU8sS0FBSyxDQUFDO0FBQ25ELFVBQUk7QUFDSjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsS0FBSztBQUNoQixVQUFJLFFBQVE7QUFDWixVQUFJLFVBQVU7QUFDZCxVQUFJLElBQUksSUFBSTtBQUNaLFVBQUksSUFBSSxDQUFDLE1BQU0sS0FBSztBQUNsQixjQUFNLElBQUksVUFBVSxvQ0FBb0MsT0FBTyxDQUFDLENBQUM7QUFBQSxNQUNuRTtBQUNBLGFBQU8sSUFBSSxJQUFJLFFBQVE7QUFDckIsWUFBSSxJQUFJLENBQUMsTUFBTSxNQUFNO0FBQ25CLHFCQUFXLElBQUksR0FBRyxJQUFJLElBQUksR0FBRztBQUM3QjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLElBQUksQ0FBQyxNQUFNLEtBQUs7QUFDbEI7QUFDQSxjQUFJLFVBQVUsR0FBRztBQUNmO0FBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRixXQUFXLElBQUksQ0FBQyxNQUFNLEtBQUs7QUFDekI7QUFDQSxjQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSztBQUN0QixrQkFBTSxJQUFJLFVBQVUsdUNBQXVDLE9BQU8sQ0FBQyxDQUFDO0FBQUEsVUFDdEU7QUFBQSxRQUNGO0FBQ0EsbUJBQVcsSUFBSSxHQUFHO0FBQUEsTUFDcEI7QUFDQSxVQUFJO0FBQ0YsY0FBTSxJQUFJLFVBQVUseUJBQXlCLE9BQU8sQ0FBQyxDQUFDO0FBQ3hELFVBQUksQ0FBQztBQUNILGNBQU0sSUFBSSxVQUFVLHNCQUFzQixPQUFPLENBQUMsQ0FBQztBQUNyRCxhQUFPLEtBQUssRUFBRSxNQUFNLFdBQVcsT0FBTyxHQUFHLE9BQU8sUUFBUSxDQUFDO0FBQ3pELFVBQUk7QUFDSjtBQUFBLElBQ0Y7QUFDQSxXQUFPLEtBQUssRUFBRSxNQUFNLFFBQVEsT0FBTyxHQUFHLE9BQU8sSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3pEO0FBQ0EsU0FBTyxLQUFLLEVBQUUsTUFBTSxPQUFPLE9BQU8sR0FBRyxPQUFPLEdBQUcsQ0FBQztBQUNoRCxTQUFPO0FBQ1Q7QUFDQSxTQUFTLE1BQU0sS0FBSyxTQUFTO0FBQzNCLE1BQUksWUFBWSxRQUFRO0FBQ3RCLGNBQVUsQ0FBQztBQUFBLEVBQ2I7QUFDQSxNQUFJLFNBQVMsTUFBTSxHQUFHO0FBQ3RCLE1BQUksTUFBTSxRQUFRLFVBQVUsV0FBVyxRQUFRLFNBQVMsT0FBTztBQUMvRCxNQUFJLGlCQUFpQixLQUFLLE9BQU8sYUFBYSxRQUFRLGFBQWEsS0FBSyxHQUFHLEtBQUs7QUFDaEYsTUFBSSxTQUFTLENBQUM7QUFDZCxNQUFJLE1BQU07QUFDVixNQUFJLElBQUk7QUFDUixNQUFJLE9BQU87QUFDWCxNQUFJLGFBQWEsU0FBUyxNQUFNO0FBQzlCLFFBQUksSUFBSSxPQUFPLFVBQVUsT0FBTyxDQUFDLEVBQUUsU0FBUztBQUMxQyxhQUFPLE9BQU8sR0FBRyxFQUFFO0FBQUEsRUFDdkI7QUFDQSxNQUFJLGNBQWMsU0FBUyxNQUFNO0FBQy9CLFFBQUksU0FBUyxXQUFXLElBQUk7QUFDNUIsUUFBSSxXQUFXO0FBQ2IsYUFBTztBQUNULFFBQUksTUFBTSxPQUFPLENBQUMsR0FBRyxXQUFXLElBQUksTUFBTSxRQUFRLElBQUk7QUFDdEQsVUFBTSxJQUFJLFVBQVUsY0FBYyxPQUFPLFVBQVUsTUFBTSxFQUFFLE9BQU8sT0FBTyxhQUFhLEVBQUUsT0FBTyxJQUFJLENBQUM7QUFBQSxFQUN0RztBQUNBLE1BQUksY0FBYyxXQUFXO0FBQzNCLFFBQUksVUFBVTtBQUNkLFFBQUk7QUFDSixXQUFPLFNBQVMsV0FBVyxNQUFNLEtBQUssV0FBVyxjQUFjLEdBQUc7QUFDaEUsaUJBQVc7QUFBQSxJQUNiO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPLElBQUksT0FBTyxRQUFRO0FBQ3hCLFFBQUksT0FBTyxXQUFXLE1BQU07QUFDNUIsUUFBSSxPQUFPLFdBQVcsTUFBTTtBQUM1QixRQUFJLFVBQVUsV0FBVyxTQUFTO0FBQ2xDLFFBQUksUUFBUSxTQUFTO0FBQ25CLFVBQUksU0FBUyxRQUFRO0FBQ3JCLFVBQUksU0FBUyxRQUFRLE1BQU0sTUFBTSxJQUFJO0FBQ25DLGdCQUFRO0FBQ1IsaUJBQVM7QUFBQSxNQUNYO0FBQ0EsVUFBSSxNQUFNO0FBQ1IsZUFBTyxLQUFLLElBQUk7QUFDaEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLEtBQUs7QUFBQSxRQUNWLE1BQU0sUUFBUTtBQUFBLFFBQ2Q7QUFBQSxRQUNBLFFBQVE7QUFBQSxRQUNSLFNBQVMsV0FBVztBQUFBLFFBQ3BCLFVBQVUsV0FBVyxVQUFVLEtBQUs7QUFBQSxNQUN0QyxDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFFBQVEsV0FBVyxjQUFjO0FBQzdDLFFBQUksT0FBTztBQUNULGNBQVE7QUFDUjtBQUFBLElBQ0Y7QUFDQSxRQUFJLE1BQU07QUFDUixhQUFPLEtBQUssSUFBSTtBQUNoQixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksT0FBTyxXQUFXLE1BQU07QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSSxTQUFTLFlBQVk7QUFDekIsVUFBSSxTQUFTLFdBQVcsTUFBTSxLQUFLO0FBQ25DLFVBQUksWUFBWSxXQUFXLFNBQVMsS0FBSztBQUN6QyxVQUFJLFNBQVMsWUFBWTtBQUN6QixrQkFBWSxPQUFPO0FBQ25CLGFBQU8sS0FBSztBQUFBLFFBQ1YsTUFBTSxXQUFXLFlBQVksUUFBUTtBQUFBLFFBQ3JDLFNBQVMsVUFBVSxDQUFDLFlBQVksaUJBQWlCO0FBQUEsUUFDakQ7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVLFdBQVcsVUFBVSxLQUFLO0FBQUEsTUFDdEMsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUNBLGdCQUFZLEtBQUs7QUFBQSxFQUNuQjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsTUFBTSxLQUFLLFNBQVM7QUFDM0IsTUFBSSxPQUFPLENBQUM7QUFDWixNQUFJLEtBQUssYUFBYSxLQUFLLE1BQU0sT0FBTztBQUN4QyxTQUFPLGlCQUFpQixJQUFJLE1BQU0sT0FBTztBQUMzQztBQUNBLFNBQVMsaUJBQWlCLElBQUksTUFBTSxTQUFTO0FBQzNDLE1BQUksWUFBWSxRQUFRO0FBQ3RCLGNBQVUsQ0FBQztBQUFBLEVBQ2I7QUFDQSxNQUFJLE1BQU0sUUFBUSxRQUFRLFNBQVMsUUFBUSxTQUFTLFNBQVMsR0FBRztBQUM5RCxXQUFPO0FBQUEsRUFDVCxJQUFJO0FBQ0osU0FBTyxTQUFTLFVBQVU7QUFDeEIsUUFBSSxJQUFJLEdBQUcsS0FBSyxRQUFRO0FBQ3hCLFFBQUksQ0FBQztBQUNILGFBQU87QUFDVCxRQUFJLE9BQU8sRUFBRSxDQUFDLEdBQUcsUUFBUSxFQUFFO0FBQzNCLFFBQUksU0FBeUIsdUJBQU8sT0FBTyxJQUFJO0FBQy9DLFFBQUksVUFBVSxTQUFTLElBQUk7QUFDekIsVUFBSSxFQUFFLEVBQUUsTUFBTTtBQUNaLGVBQU87QUFDVCxVQUFJLE1BQU0sS0FBSyxLQUFLLENBQUM7QUFDckIsVUFBSSxJQUFJLGFBQWEsT0FBTyxJQUFJLGFBQWEsS0FBSztBQUNoRCxlQUFPLElBQUksSUFBSSxJQUFJLEVBQUUsRUFBRSxFQUFFLE1BQU0sSUFBSSxTQUFTLElBQUksTUFBTSxFQUFFLElBQUksU0FBUyxPQUFPO0FBQzFFLGlCQUFPLE9BQU8sT0FBTyxHQUFHO0FBQUEsUUFDMUIsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMLGVBQU8sSUFBSSxJQUFJLElBQUksT0FBTyxFQUFFLEVBQUUsR0FBRyxHQUFHO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQ0EsYUFBUyxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztBQUNqQyxjQUFRLENBQUM7QUFBQSxJQUNYO0FBQ0EsV0FBTyxFQUFFLE1BQU0sT0FBTyxPQUFPO0FBQUEsRUFDL0I7QUFDRjtBQUNBLFNBQVMsYUFBYSxLQUFLO0FBQ3pCLFNBQU8sSUFBSSxRQUFRLDZCQUE2QixNQUFNO0FBQ3hEO0FBQ0EsU0FBUyxNQUFNLFNBQVM7QUFDdEIsU0FBTyxXQUFXLFFBQVEsWUFBWSxLQUFLO0FBQzdDO0FBQ0EsU0FBUyxlQUFlLE1BQU0sTUFBTTtBQUNsQyxNQUFJLENBQUM7QUFDSCxXQUFPO0FBQ1QsTUFBSSxjQUFjO0FBQ2xCLE1BQUksUUFBUTtBQUNaLE1BQUksYUFBYSxZQUFZLEtBQUssS0FBSyxNQUFNO0FBQzdDLFNBQU8sWUFBWTtBQUNqQixTQUFLLEtBQUs7QUFBQTtBQUFBLE1BRVIsTUFBTSxXQUFXLENBQUMsS0FBSztBQUFBLE1BQ3ZCLFFBQVE7QUFBQSxNQUNSLFFBQVE7QUFBQSxNQUNSLFVBQVU7QUFBQSxNQUNWLFNBQVM7QUFBQSxJQUNYLENBQUM7QUFDRCxpQkFBYSxZQUFZLEtBQUssS0FBSyxNQUFNO0FBQUEsRUFDM0M7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWMsT0FBTyxNQUFNLFNBQVM7QUFDM0MsTUFBSSxRQUFRLE1BQU0sSUFBSSxTQUFTLE1BQU07QUFDbkMsV0FBTyxhQUFhLE1BQU0sTUFBTSxPQUFPLEVBQUU7QUFBQSxFQUMzQyxDQUFDO0FBQ0QsU0FBTyxJQUFJLE9BQU8sTUFBTSxPQUFPLE1BQU0sS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFHLE1BQU0sT0FBTyxDQUFDO0FBQ3RFO0FBQ0EsU0FBUyxlQUFlLE1BQU0sTUFBTSxTQUFTO0FBQzNDLFNBQU8sZUFBZSxNQUFNLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTztBQUMzRDtBQUNBLFNBQVMsZUFBZSxRQUFRLE1BQU0sU0FBUztBQUM3QyxNQUFJLFlBQVksUUFBUTtBQUN0QixjQUFVLENBQUM7QUFBQSxFQUNiO0FBQ0EsTUFBSSxNQUFNLFFBQVEsUUFBUSxTQUFTLFFBQVEsU0FBUyxRQUFRLEtBQUssTUFBTSxRQUFRLE9BQU8sUUFBUSxRQUFRLFNBQVMsT0FBTyxLQUFLLE1BQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxTQUFTLE9BQU8sS0FBSyxLQUFLLFFBQVEsUUFBUSxTQUFTLE9BQU8sU0FBUyxTQUFTLEdBQUc7QUFDek8sV0FBTztBQUFBLEVBQ1QsSUFBSSxJQUFJLEtBQUssUUFBUSxXQUFXLFlBQVksT0FBTyxTQUFTLFFBQVEsSUFBSSxLQUFLLFFBQVEsVUFBVSxXQUFXLE9BQU8sU0FBUyxLQUFLO0FBQy9ILE1BQUksYUFBYSxJQUFJLE9BQU8sYUFBYSxRQUFRLEdBQUcsS0FBSztBQUN6RCxNQUFJLGNBQWMsSUFBSSxPQUFPLGFBQWEsU0FBUyxHQUFHLEdBQUc7QUFDekQsTUFBSSxRQUFRLFFBQVEsTUFBTTtBQUMxQixXQUFTLEtBQUssR0FBRyxXQUFXLFFBQVEsS0FBSyxTQUFTLFFBQVEsTUFBTTtBQUM5RCxRQUFJLFFBQVEsU0FBUyxFQUFFO0FBQ3ZCLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDN0IsZUFBUyxhQUFhLE9BQU8sS0FBSyxDQUFDO0FBQUEsSUFDckMsT0FBTztBQUNMLFVBQUksU0FBUyxhQUFhLE9BQU8sTUFBTSxNQUFNLENBQUM7QUFDOUMsVUFBSSxTQUFTLGFBQWEsT0FBTyxNQUFNLE1BQU0sQ0FBQztBQUM5QyxVQUFJLE1BQU0sU0FBUztBQUNqQixZQUFJO0FBQ0YsZUFBSyxLQUFLLEtBQUs7QUFDakIsWUFBSSxVQUFVLFFBQVE7QUFDcEIsY0FBSSxNQUFNLGFBQWEsT0FBTyxNQUFNLGFBQWEsS0FBSztBQUNwRCxnQkFBSSxNQUFNLE1BQU0sYUFBYSxNQUFNLE1BQU07QUFDekMscUJBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxFQUFFLE9BQU8sTUFBTSxTQUFTLE1BQU0sRUFBRSxPQUFPLE1BQU0sRUFBRSxPQUFPLFFBQVEsS0FBSyxFQUFFLE9BQU8sTUFBTSxTQUFTLE1BQU0sRUFBRSxPQUFPLFFBQVEsR0FBRyxFQUFFLE9BQU8sR0FBRztBQUFBLFVBQ3ZLLE9BQU87QUFDTCxxQkFBUyxNQUFNLE9BQU8sUUFBUSxHQUFHLEVBQUUsT0FBTyxNQUFNLFNBQVMsR0FBRyxFQUFFLE9BQU8sUUFBUSxHQUFHLEVBQUUsT0FBTyxNQUFNLFFBQVE7QUFBQSxVQUN6RztBQUFBLFFBQ0YsT0FBTztBQUNMLGNBQUksTUFBTSxhQUFhLE9BQU8sTUFBTSxhQUFhLEtBQUs7QUFDcEQscUJBQVMsT0FBTyxPQUFPLE1BQU0sU0FBUyxHQUFHLEVBQUUsT0FBTyxNQUFNLFVBQVUsR0FBRztBQUFBLFVBQ3ZFLE9BQU87QUFDTCxxQkFBUyxJQUFJLE9BQU8sTUFBTSxTQUFTLEdBQUcsRUFBRSxPQUFPLE1BQU0sUUFBUTtBQUFBLFVBQy9EO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGlCQUFTLE1BQU0sT0FBTyxNQUFNLEVBQUUsT0FBTyxRQUFRLEdBQUcsRUFBRSxPQUFPLE1BQU0sUUFBUTtBQUFBLE1BQ3pFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUs7QUFDUCxRQUFJLENBQUM7QUFDSCxlQUFTLEdBQUcsT0FBTyxhQUFhLEdBQUc7QUFDckMsYUFBUyxDQUFDLFFBQVEsV0FBVyxNQUFNLE1BQU0sT0FBTyxZQUFZLEdBQUc7QUFBQSxFQUNqRSxPQUFPO0FBQ0wsUUFBSSxXQUFXLE9BQU8sT0FBTyxTQUFTLENBQUM7QUFDdkMsUUFBSSxpQkFBaUIsT0FBTyxhQUFhLFdBQVcsWUFBWSxRQUFRLFNBQVMsU0FBUyxTQUFTLENBQUMsQ0FBQyxJQUFJLEtBQUssYUFBYTtBQUMzSCxRQUFJLENBQUMsUUFBUTtBQUNYLGVBQVMsTUFBTSxPQUFPLGFBQWEsS0FBSyxFQUFFLE9BQU8sWUFBWSxLQUFLO0FBQUEsSUFDcEU7QUFDQSxRQUFJLENBQUMsZ0JBQWdCO0FBQ25CLGVBQVMsTUFBTSxPQUFPLGFBQWEsR0FBRyxFQUFFLE9BQU8sWUFBWSxHQUFHO0FBQUEsSUFDaEU7QUFBQSxFQUNGO0FBQ0EsU0FBTyxJQUFJLE9BQU8sT0FBTyxNQUFNLE9BQU8sQ0FBQztBQUN6QztBQUNBLFNBQVMsYUFBYSxNQUFNLE1BQU0sU0FBUztBQUN6QyxNQUFJLGdCQUFnQjtBQUNsQixXQUFPLGVBQWUsTUFBTSxJQUFJO0FBQ2xDLE1BQUksTUFBTSxRQUFRLElBQUk7QUFDcEIsV0FBTyxjQUFjLE1BQU0sTUFBTSxPQUFPO0FBQzFDLFNBQU8sZUFBZSxNQUFNLE1BQU0sT0FBTztBQUMzQztBQUdBLElBQUksVUFBVSxJQUFJLFlBQVk7QUFHOUIsSUFBSSxvQkFBb0IsT0FBTyxpQkFBaUI7QUFHaEQsU0FBUyxnQkFBZ0I7QUFDdkIsTUFBSSxPQUFPLGNBQWMsZUFBZSxVQUFVLFlBQVksZUFBZTtBQUMzRSxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksT0FBTyxZQUFZLGFBQWE7QUFDbEMsVUFBTSxPQUFPLFFBQVE7QUFDckIsUUFBSSxTQUFTLGNBQWMsU0FBUyxVQUFVO0FBQzVDLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTyxDQUFDLEVBQUUsUUFBUSxZQUFZLFFBQVEsU0FBUztBQUFBLEVBQ2pEO0FBQ0EsU0FBTztBQUNUO0FBR0EsSUFBSSxhQUFhLE9BQU87QUFDeEIsSUFBSSxXQUFXLENBQUMsUUFBUSxRQUFRO0FBQzlCLFdBQVMsUUFBUTtBQUNmLGVBQVcsUUFBUSxNQUFNLEVBQUUsS0FBSyxJQUFJLElBQUksR0FBRyxZQUFZLEtBQUssQ0FBQztBQUNqRTtBQUNBLElBQUksaUJBQWlCLENBQUM7QUFDdEIsU0FBUyxnQkFBZ0I7QUFBQSxFQUN2QixNQUFNLE1BQU07QUFBQSxFQUNaLE1BQU0sTUFBTTtBQUFBLEVBQ1osT0FBTyxNQUFNO0FBQUEsRUFDYixLQUFLLE1BQU07QUFBQSxFQUNYLFFBQVEsTUFBTTtBQUNoQixDQUFDO0FBQ0QsU0FBUyxPQUFPLE1BQU07QUFDcEIsU0FBTyxXQUFXLElBQUk7QUFDeEI7QUFDQSxTQUFTLEtBQUssTUFBTTtBQUNsQixTQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUNBLFNBQVMsS0FBSyxNQUFNO0FBQ2xCLFNBQU8sV0FBVyxJQUFJO0FBQ3hCO0FBQ0EsU0FBUyxJQUFJLE1BQU07QUFDakIsU0FBTyxXQUFXLElBQUk7QUFDeEI7QUFDQSxTQUFTLE1BQU0sTUFBTTtBQUNuQixTQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUNBLElBQUksVUFBVSxjQUFjO0FBRzVCLElBQUkseUJBQXlCLENBQUMsMkJBQTJCO0FBQ3ZELHlCQUF1QixVQUFVLElBQUk7QUFDckMseUJBQXVCLFVBQVUsSUFBSTtBQUNyQyx5QkFBdUIsU0FBUyxJQUFJO0FBQ3BDLHlCQUF1QixXQUFXLElBQUk7QUFDdEMseUJBQXVCLFVBQVUsSUFBSTtBQUNyQyxTQUFPO0FBQ1QsR0FBRyx5QkFBeUIsQ0FBQyxDQUFDO0FBQzlCLFNBQVMsa0JBQWtCO0FBQ3pCLFNBQU8sS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDO0FBQzNDO0FBR0EsU0FBUyxZQUFZLEtBQUssYUFBYSxNQUFNO0FBQzNDLFNBQU8sQ0FBQyxjQUFjLElBQUksUUFBUSxJQUFJLFFBQVEsRUFBRSxPQUFPLE9BQU8sRUFBRSxLQUFLLEVBQUU7QUFDekU7QUFHQSxJQUFJLDJCQUEyQjtBQUMvQixTQUFTLGdCQUFnQixNQUFNO0FBQzdCLFNBQU8sSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLGtCQUFrQixFQUFFO0FBQ2pEO0FBQ0EsU0FBUyxTQUFTLE1BQU07QUFDdEIsU0FBTyxLQUFLLFFBQVEsMEJBQTBCLEVBQUU7QUFDbEQ7QUFHQSxTQUFTLGNBQWMsS0FBSztBQUMxQixTQUFPLGdDQUFnQyxLQUFLLEdBQUc7QUFDakQ7QUFHQSxTQUFTLGVBQWUsTUFBTSxTQUFTO0FBQ3JDLE1BQUksY0FBYyxJQUFJLEdBQUc7QUFDdkIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLEtBQUssV0FBVyxHQUFHLEdBQUc7QUFDeEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFNBQVMsV0FBVyxPQUFPLGFBQWEsZUFBZSxTQUFTO0FBQ3RFLFNBQU87QUFBQTtBQUFBLElBRUwsVUFBVSxJQUFJLElBQUksVUFBVSxJQUFJLEdBQUcsTUFBTSxFQUFFLElBQUk7QUFBQSxNQUM3QztBQUNOO0FBR0EsU0FBUyxjQUFjLE1BQU0sU0FBUztBQUNwQyxNQUFJLGdCQUFnQixRQUFRO0FBQzFCLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxtQkFBbUIsZUFBZSxNQUFNLE9BQU87QUFDckQsU0FBTyxTQUFTLGdCQUFnQjtBQUNsQztBQUdBLFNBQVMsV0FBVyxNQUFNO0FBQ3hCLFNBQU8sS0FBSztBQUFBLElBQ1Y7QUFBQSxJQUNBLENBQUMsR0FBRyxlQUFlLGFBQWE7QUFDOUIsWUFBTSxhQUFhO0FBQ25CLFVBQUksQ0FBQyxlQUFlO0FBQ2xCLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxjQUFjLFdBQVcsR0FBRyxJQUFJLEdBQUcsYUFBYSxHQUFHLFFBQVEsS0FBSyxHQUFHLGFBQWEsR0FBRyxVQUFVO0FBQUEsSUFDdEc7QUFBQSxFQUNGLEVBQUUsUUFBUSxxQkFBcUIsUUFBUSxFQUFFLFFBQVEsd0JBQXdCLFFBQVE7QUFDbkY7QUFDQSxTQUFTLGdCQUFnQixLQUFLLE1BQU0sU0FBUztBQUMzQyxRQUFNLGlCQUFpQixjQUFjLE1BQU0sT0FBTztBQUNsRCxRQUFNLFlBQVksT0FBTyxtQkFBbUIsV0FBVyxXQUFXLGNBQWMsSUFBSTtBQUNwRixRQUFNLFlBQVksWUFBWSxHQUFHO0FBQ2pDLFFBQU0sU0FBUyxNQUFNLFdBQVcsRUFBRSxRQUFRLG1CQUFtQixDQUFDLEVBQUUsU0FBUztBQUN6RSxRQUFNLFNBQVMsVUFBVSxPQUFPLFVBQVUsQ0FBQztBQUMzQyxTQUFPO0FBQUEsSUFDTCxTQUFTLFdBQVc7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksYUFBYSxPQUFPO0FBQ3hCLElBQUksb0JBQW9CLE9BQU87QUFDL0IsSUFBSSxxQkFBcUIsT0FBTztBQUNoQyxJQUFJLGdCQUFnQixPQUFPO0FBQzNCLElBQUksZ0JBQWdCLE9BQU8sVUFBVTtBQUNyQyxJQUFJLGNBQWMsQ0FBQyxJQUFJLFFBQVEsU0FBUyxZQUFZO0FBQ2xELFNBQU8sUUFBUSxHQUFHLEdBQUcsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNLEVBQUUsU0FBUyxDQUFDLEVBQUUsR0FBRyxTQUFTLEdBQUcsR0FBRyxJQUFJO0FBQzlGO0FBQ0EsSUFBSSxlQUFlLENBQUMsSUFBSSxNQUFNLFFBQVEsU0FBUztBQUM3QyxNQUFJLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLFlBQVk7QUFDbEUsYUFBUyxPQUFPLG1CQUFtQixJQUFJO0FBQ3JDLFVBQUksQ0FBQyxjQUFjLEtBQUssSUFBSSxHQUFHLEtBQUssUUFBUTtBQUMxQyxtQkFBVyxJQUFJLEtBQUssRUFBRSxLQUFLLE1BQU0sS0FBSyxHQUFHLEdBQUcsWUFBWSxFQUFFLE9BQU8sa0JBQWtCLE1BQU0sR0FBRyxNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsRUFDekg7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxJQUFJLFdBQVcsQ0FBQyxLQUFLLFlBQVksWUFBWSxTQUFTLE9BQU8sT0FBTyxVQUFVLGNBQWMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUt0RyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksYUFBYSxXQUFXLFFBQVEsV0FBVyxFQUFFLE9BQU8sS0FBSyxZQUFZLEtBQUssQ0FBQyxJQUFJO0FBQUEsRUFDMUc7QUFDRjtBQUNBLElBQUksaUJBQWlCLFlBQVk7QUFBQSxFQUMvQiwrQkFBK0IsU0FBUztBQUN0QztBQUNBLFlBQVEsUUFBUTtBQUNoQixZQUFRLFlBQVk7QUFDcEIsUUFBSSxhQUFhLE9BQU8sVUFBVTtBQUNsQyxRQUFJLHFCQUFxQjtBQUN6QixhQUFTLE9BQU8sS0FBSyxTQUFTO0FBQzVCLFVBQUksT0FBTyxRQUFRLFVBQVU7QUFDM0IsY0FBTSxJQUFJLFVBQVUsK0JBQStCO0FBQUEsTUFDckQ7QUFDQSxVQUFJLE1BQU0sQ0FBQztBQUNYLFVBQUksTUFBTSxXQUFXLENBQUM7QUFDdEIsVUFBSSxNQUFNLElBQUksVUFBVTtBQUN4QixVQUFJLFFBQVE7QUFDWixhQUFPLFFBQVEsSUFBSSxRQUFRO0FBQ3pCLFlBQUksUUFBUSxJQUFJLFFBQVEsS0FBSyxLQUFLO0FBQ2xDLFlBQUksVUFBVSxJQUFJO0FBQ2hCO0FBQUEsUUFDRjtBQUNBLFlBQUksU0FBUyxJQUFJLFFBQVEsS0FBSyxLQUFLO0FBQ25DLFlBQUksV0FBVyxJQUFJO0FBQ2pCLG1CQUFTLElBQUk7QUFBQSxRQUNmLFdBQVcsU0FBUyxPQUFPO0FBQ3pCLGtCQUFRLElBQUksWUFBWSxLQUFLLFFBQVEsQ0FBQyxJQUFJO0FBQzFDO0FBQUEsUUFDRjtBQUNBLFlBQUksTUFBTSxJQUFJLE1BQU0sT0FBTyxLQUFLLEVBQUUsS0FBSztBQUN2QyxZQUFJLFdBQVcsSUFBSSxHQUFHLEdBQUc7QUFDdkIsY0FBSSxNQUFNLElBQUksTUFBTSxRQUFRLEdBQUcsTUFBTSxFQUFFLEtBQUs7QUFDNUMsY0FBSSxJQUFJLFdBQVcsQ0FBQyxNQUFNLElBQUk7QUFDNUIsa0JBQU0sSUFBSSxNQUFNLEdBQUcsRUFBRTtBQUFBLFVBQ3ZCO0FBQ0EsY0FBSSxHQUFHLElBQUksVUFBVSxLQUFLLEdBQUc7QUFBQSxRQUMvQjtBQUNBLGdCQUFRLFNBQVM7QUFBQSxNQUNuQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsYUFBUyxVQUFVLE1BQU0sS0FBSyxTQUFTO0FBQ3JDLFVBQUksTUFBTSxXQUFXLENBQUM7QUFDdEIsVUFBSSxNQUFNLElBQUksVUFBVTtBQUN4QixVQUFJLE9BQU8sUUFBUSxZQUFZO0FBQzdCLGNBQU0sSUFBSSxVQUFVLDBCQUEwQjtBQUFBLE1BQ2hEO0FBQ0EsVUFBSSxDQUFDLG1CQUFtQixLQUFLLElBQUksR0FBRztBQUNsQyxjQUFNLElBQUksVUFBVSwwQkFBMEI7QUFBQSxNQUNoRDtBQUNBLFVBQUksUUFBUSxJQUFJLEdBQUc7QUFDbkIsVUFBSSxTQUFTLENBQUMsbUJBQW1CLEtBQUssS0FBSyxHQUFHO0FBQzVDLGNBQU0sSUFBSSxVQUFVLHlCQUF5QjtBQUFBLE1BQy9DO0FBQ0EsVUFBSSxNQUFNLE9BQU8sTUFBTTtBQUN2QixVQUFJLFFBQVEsSUFBSSxRQUFRO0FBQ3RCLFlBQUksU0FBUyxJQUFJLFNBQVM7QUFDMUIsWUFBSSxNQUFNLE1BQU0sS0FBSyxDQUFDLFNBQVMsTUFBTSxHQUFHO0FBQ3RDLGdCQUFNLElBQUksVUFBVSwwQkFBMEI7QUFBQSxRQUNoRDtBQUNBLGVBQU8sZUFBZSxLQUFLLE1BQU0sTUFBTTtBQUFBLE1BQ3pDO0FBQ0EsVUFBSSxJQUFJLFFBQVE7QUFDZCxZQUFJLENBQUMsbUJBQW1CLEtBQUssSUFBSSxNQUFNLEdBQUc7QUFDeEMsZ0JBQU0sSUFBSSxVQUFVLDBCQUEwQjtBQUFBLFFBQ2hEO0FBQ0EsZUFBTyxjQUFjLElBQUk7QUFBQSxNQUMzQjtBQUNBLFVBQUksSUFBSSxNQUFNO0FBQ1osWUFBSSxDQUFDLG1CQUFtQixLQUFLLElBQUksSUFBSSxHQUFHO0FBQ3RDLGdCQUFNLElBQUksVUFBVSx3QkFBd0I7QUFBQSxRQUM5QztBQUNBLGVBQU8sWUFBWSxJQUFJO0FBQUEsTUFDekI7QUFDQSxVQUFJLElBQUksU0FBUztBQUNmLFlBQUksVUFBVSxJQUFJO0FBQ2xCLFlBQUksQ0FBQyxPQUFPLE9BQU8sS0FBSyxNQUFNLFFBQVEsUUFBUSxDQUFDLEdBQUc7QUFDaEQsZ0JBQU0sSUFBSSxVQUFVLDJCQUEyQjtBQUFBLFFBQ2pEO0FBQ0EsZUFBTyxlQUFlLFFBQVEsWUFBWTtBQUFBLE1BQzVDO0FBQ0EsVUFBSSxJQUFJLFVBQVU7QUFDaEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLElBQUksUUFBUTtBQUNkLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxJQUFJLFVBQVU7QUFDaEIsWUFBSSxXQUFXLE9BQU8sSUFBSSxhQUFhLFdBQVcsSUFBSSxTQUFTLFlBQVksSUFBSSxJQUFJO0FBQ25GLGdCQUFRLFVBQVU7QUFBQSxVQUNoQixLQUFLO0FBQ0gsbUJBQU87QUFDUDtBQUFBLFVBQ0YsS0FBSztBQUNILG1CQUFPO0FBQ1A7QUFBQSxVQUNGLEtBQUs7QUFDSCxtQkFBTztBQUNQO0FBQUEsVUFDRjtBQUNFLGtCQUFNLElBQUksVUFBVSw0QkFBNEI7QUFBQSxRQUNwRDtBQUFBLE1BQ0Y7QUFDQSxVQUFJLElBQUksVUFBVTtBQUNoQixZQUFJLFdBQVcsT0FBTyxJQUFJLGFBQWEsV0FBVyxJQUFJLFNBQVMsWUFBWSxJQUFJLElBQUk7QUFDbkYsZ0JBQVEsVUFBVTtBQUFBLFVBQ2hCLEtBQUs7QUFDSCxtQkFBTztBQUNQO0FBQUEsVUFDRixLQUFLO0FBQ0gsbUJBQU87QUFDUDtBQUFBLFVBQ0YsS0FBSztBQUNILG1CQUFPO0FBQ1A7QUFBQSxVQUNGLEtBQUs7QUFDSCxtQkFBTztBQUNQO0FBQUEsVUFDRjtBQUNFLGtCQUFNLElBQUksVUFBVSw0QkFBNEI7QUFBQSxRQUNwRDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLGFBQVMsT0FBTyxLQUFLO0FBQ25CLGFBQU8sSUFBSSxRQUFRLEdBQUcsTUFBTSxLQUFLLG1CQUFtQixHQUFHLElBQUk7QUFBQSxJQUM3RDtBQUNBLGFBQVMsT0FBTyxLQUFLO0FBQ25CLGFBQU8sbUJBQW1CLEdBQUc7QUFBQSxJQUMvQjtBQUNBLGFBQVMsT0FBTyxLQUFLO0FBQ25CLGFBQU8sV0FBVyxLQUFLLEdBQUcsTUFBTSxtQkFBbUIsZUFBZTtBQUFBLElBQ3BFO0FBQ0EsYUFBUyxVQUFVLEtBQUssU0FBUztBQUMvQixVQUFJO0FBQ0YsZUFBTyxRQUFRLEdBQUc7QUFBQSxNQUNwQixTQUFTLEdBQUc7QUFDVixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUksZ0JBQWdCLFNBQVMsZUFBZSxHQUFHLENBQUM7QUFDaEQsSUFBSSxrQkFBa0IsY0FBYztBQUdwQyxTQUFTLHdCQUF3QjtBQUMvQixTQUFPLGdCQUFnQixNQUFNLFNBQVMsTUFBTTtBQUM5QztBQUNBLFNBQVMsa0JBQWtCLFNBQVM7QUFDbEMsTUFBSSxPQUFPLGFBQWEsZUFBZSxPQUFPLGFBQWEsYUFBYTtBQUN0RSxXQUFPLENBQUM7QUFBQSxFQUNWO0FBQ0EsVUFBUSxRQUFRLGFBQWE7QUFBQSxJQUMzQixLQUFLLGVBQWU7QUFDbEIsWUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLEdBQUc7QUFDL0IsYUFBTyxTQUFTLFdBQVcsSUFBSSxTQUFTLHNCQUFzQixJQUFJLENBQUM7QUFBQSxJQUNyRTtBQUFBLElBQ0EsS0FBSyxXQUFXO0FBQ2QsYUFBTyxzQkFBc0I7QUFBQSxJQUMvQjtBQUFBLElBQ0EsU0FBUztBQUNQLGFBQU8sQ0FBQztBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixTQUFTO0FBQ3JDLE1BQUk7QUFDSixRQUFNLHVCQUF1QixRQUFRLFFBQVEsSUFBSSxRQUFRO0FBQ3pELFFBQU0scUJBQXFCLHVCQUF1QixnQkFBZ0IsTUFBTSxvQkFBb0IsSUFBSSxDQUFDO0FBQ2pHLFFBQU0sUUFBUTtBQUNkLFFBQU0sbUJBQW1CLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxPQUFPLE1BQU0sT0FBTyxTQUFTLElBQUksUUFBUSxDQUFDLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDdEksV0FBTyxPQUFPLE9BQU8sU0FBUyxFQUFFLENBQUMsS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLENBQUM7QUFBQSxFQUN4RCxHQUFHLENBQUMsQ0FBQztBQUNMLFFBQU0sc0JBQXNCLGtCQUFrQixPQUFPO0FBQ3JELFFBQU0sbUJBQW1CO0FBQUEsSUFDdkIsR0FBRztBQUFBLElBQ0gsR0FBRztBQUFBLEVBQ0w7QUFDQSxhQUFXLENBQUMsTUFBTSxLQUFLLEtBQUssT0FBTyxRQUFRLGdCQUFnQixHQUFHO0FBQzVELFlBQVEsUUFBUSxPQUFPLFVBQVUsZ0JBQWdCLFVBQVUsTUFBTSxLQUFLLENBQUM7QUFBQSxFQUN6RTtBQUNBLFNBQU87QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILEdBQUc7QUFBQSxFQUNMO0FBQ0Y7QUFHQSxJQUFJLGVBQWUsQ0FBQyxpQkFBaUI7QUFDbkMsZUFBYSxNQUFNLElBQUk7QUFDdkIsZUFBYSxLQUFLLElBQUk7QUFDdEIsZUFBYSxNQUFNLElBQUk7QUFDdkIsZUFBYSxLQUFLLElBQUk7QUFDdEIsZUFBYSxPQUFPLElBQUk7QUFDeEIsZUFBYSxTQUFTLElBQUk7QUFDMUIsZUFBYSxRQUFRLElBQUk7QUFDekIsU0FBTztBQUNULEdBQUcsZUFBZSxDQUFDLENBQUM7QUFDcEIsSUFBSSxjQUFjLGNBQWMsZUFBZTtBQUFBLEVBQzdDLFlBQVksUUFBUSxNQUFNLFVBQVUsU0FBUztBQUMzQyxVQUFNO0FBQUEsTUFDSixNQUFNO0FBQUEsUUFDSixRQUFRLEdBQUcsTUFBTSxJQUFJLElBQUk7QUFBQSxRQUN6QjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFDRCxTQUFLLDhCQUE4QjtBQUFBLEVBQ3JDO0FBQUEsRUFDQSxnQ0FBZ0M7QUFDOUIsVUFBTSxFQUFFLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFDOUIsUUFBSSxnQkFBZ0IsUUFBUTtBQUMxQjtBQUFBLElBQ0Y7QUFDQSxVQUFNLE1BQU0sU0FBUyxJQUFJO0FBQ3pCLFFBQUksUUFBUSxNQUFNO0FBQ2hCO0FBQUEsSUFDRjtBQUNBLFVBQU0sZUFBZSxnQkFBZ0IsSUFBSTtBQUN6QyxVQUFNLGNBQWMsQ0FBQztBQUNyQixpQkFBYSxRQUFRLENBQUMsR0FBRyxjQUFjO0FBQ3JDLGtCQUFZLEtBQUssU0FBUztBQUFBLElBQzVCLENBQUM7QUFDRCxhQUFTO0FBQUEsTUFDUCwrRUFBK0UsTUFBTSxJQUFJLElBQUk7QUFBQSxJQUMvRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQU0sTUFBTSxNQUFNO0FBQ2hCLFFBQUk7QUFDSixVQUFNLE1BQU0sSUFBSSxJQUFJLEtBQUssUUFBUSxHQUFHO0FBQ3BDLFVBQU0sU0FBUztBQUFBLE1BQ2I7QUFBQSxNQUNBLEtBQUssS0FBSztBQUFBLE9BQ1QsTUFBTSxLQUFLLHNCQUFzQixPQUFPLFNBQVMsSUFBSTtBQUFBLElBQ3hEO0FBQ0EsVUFBTSxVQUFVLHFCQUFxQixLQUFLLE9BQU87QUFDakQsV0FBTztBQUFBLE1BQ0wsT0FBTztBQUFBLE1BQ1A7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0EsVUFBVSxNQUFNO0FBQ2QsVUFBTSxvQkFBb0IsS0FBSyxZQUFZLEtBQUssUUFBUSxNQUFNO0FBQzlELFVBQU0saUJBQWlCLEtBQUssYUFBYSxNQUFNO0FBQy9DLFdBQU8scUJBQXFCO0FBQUEsRUFDOUI7QUFBQSxFQUNBLFlBQVksY0FBYztBQUN4QixXQUFPLEtBQUssS0FBSyxrQkFBa0IsU0FBUyxLQUFLLEtBQUssT0FBTyxLQUFLLFlBQVksSUFBSSxjQUFjLEtBQUssS0FBSyxRQUFRLFlBQVk7QUFBQSxFQUNoSTtBQUFBLEVBQ0EsbUJBQW1CLE1BQU07QUFDdkIsUUFBSTtBQUNKLFdBQU87QUFBQSxNQUNMLFVBQVUsTUFBTSxLQUFLLGFBQWEsVUFBVSxPQUFPLFNBQVMsSUFBSSxXQUFXLENBQUM7QUFBQSxNQUM1RSxTQUFTLEtBQUssYUFBYTtBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBTSxJQUFJLE1BQU07QUFDZCxVQUFNLFlBQVksWUFBWSxLQUFLLFFBQVEsR0FBRztBQUM5QyxVQUFNLGdCQUFnQixNQUFNLGlCQUFpQixLQUFLLE9BQU87QUFDekQsVUFBTSxpQkFBaUIsTUFBTSxrQkFBa0IsS0FBSyxRQUFRO0FBQzVELFVBQU0sY0FBYyxtQkFBbUIsZUFBZSxNQUFNO0FBQzVELFlBQVE7QUFBQSxNQUNOLFNBQVM7QUFBQSxRQUNQLEdBQUcsYUFBYSxDQUFDLElBQUksS0FBSyxRQUFRLE1BQU0sSUFBSSxTQUFTLE9BQU8sZUFBZSxNQUFNLElBQUksZUFBZSxVQUFVO0FBQUEsTUFDaEg7QUFBQSxNQUNBLFNBQVMsV0FBVztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBLFlBQVEsSUFBSSxXQUFXLGFBQWE7QUFDcEMsWUFBUSxJQUFJLFlBQVksSUFBSTtBQUM1QixZQUFRLElBQUksWUFBWSxjQUFjO0FBQ3RDLFlBQVEsU0FBUztBQUFBLEVBQ25CO0FBQ0Y7QUFHQSxTQUFTLGtCQUFrQixRQUFRO0FBQ2pDLFNBQU8sQ0FBQyxNQUFNLFVBQVUsVUFBVSxDQUFDLE1BQU07QUFDdkMsV0FBTyxJQUFJLFlBQVksUUFBUSxNQUFNLFVBQVUsT0FBTztBQUFBLEVBQ3hEO0FBQ0Y7QUFDQSxJQUFJLE9BQU87QUFBQSxFQUNULEtBQUssa0JBQWtCLElBQUk7QUFBQSxFQUMzQixNQUFNLGtCQUFrQixZQUFZLElBQUk7QUFBQSxFQUN4QyxLQUFLLGtCQUFrQixZQUFZLEdBQUc7QUFBQSxFQUN0QyxNQUFNLGtCQUFrQixZQUFZLElBQUk7QUFBQSxFQUN4QyxLQUFLLGtCQUFrQixZQUFZLEdBQUc7QUFBQSxFQUN0QyxRQUFRLGtCQUFrQixZQUFZLE1BQU07QUFBQSxFQUM1QyxPQUFPLGtCQUFrQixZQUFZLEtBQUs7QUFBQSxFQUMxQyxTQUFTLGtCQUFrQixZQUFZLE9BQU87QUFDaEQ7QUFHQSxJQUFJLGNBQWMsT0FBTyxPQUFPO0FBQUEsRUFDOUIsT0FBTztBQUFBLEVBQ1AsT0FBTztBQUFBLEVBQ1AsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUNqQixDQUFDO0FBR0QsU0FBUyxVQUFVLFdBQVcsVUFBVTtBQUN0QyxRQUFNLG1CQUFtQixRQUFRLFNBQVM7QUFDMUMsTUFBSSxDQUFDLGtCQUFrQjtBQUNyQixVQUFNLElBQUksTUFBTSxRQUFRO0FBQUEsRUFDMUI7QUFDRjtBQUdBLFNBQVMsYUFBYSxPQUFPO0FBQzNCLFNBQU8sT0FBTyxTQUFTLFlBQVksVUFBVTtBQUMvQztBQUdBLFNBQVMsV0FBVyxXQUFXLFVBQVU7QUFDdkMsUUFBTSxtQkFBbUIsUUFBUSxTQUFTO0FBQzFDLE1BQUksQ0FBQyxrQkFBa0I7QUFDckIsVUFBTSxJQUFJO0FBQUEsTUFDUixZQUFZLE9BQU8sV0FBVztBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQUNGO0FBR0EsSUFBSSxhQUFhO0FBQ2pCLFNBQVMsWUFBWSxRQUFRLFVBQVU7QUFDckMsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSxPQUFPO0FBQ1gsYUFBVyxVQUFVLE9BQU8sS0FBSyxTQUFTLFVBQVUsR0FBRztBQUNyRCxXQUFPLE9BQU8sVUFBVSxZQUFZLFdBQVcsS0FBSztBQUNwRCxRQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzVCO0FBQUEsSUFDRjtBQUNBLG9CQUFnQixPQUFPLFFBQVEsT0FBTyxDQUFDLEVBQUU7QUFDekMsWUFBUTtBQUFBLEVBQ1Y7QUFDQSxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0EsUUFBUSxXQUFXLElBQUk7QUFBQSxFQUN6QjtBQUNGO0FBR0EsU0FBUyxjQUFjLFdBQVc7QUFDaEMsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBWSxVQUFVLFFBQVEsVUFBVSxLQUFLO0FBQUEsRUFDL0M7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLFFBQVEsZ0JBQWdCO0FBQ25ELFFBQU0sd0JBQXdCLE9BQU8sZUFBZSxTQUFTO0FBQzdELFFBQU0sT0FBTyxHQUFHLFNBQVMscUJBQXFCLElBQUksT0FBTztBQUN6RCxRQUFNLFlBQVksZUFBZSxPQUFPO0FBQ3hDLFFBQU0sYUFBYSxPQUFPLGVBQWUsT0FBTztBQUNoRCxRQUFNLFVBQVUsZUFBZSxPQUFPO0FBQ3RDLFFBQU0sZUFBZSxlQUFlLFNBQVMsSUFBSSx3QkFBd0I7QUFDekUsUUFBTSxZQUFZLGVBQWUsU0FBUztBQUMxQyxRQUFNLGNBQWMsR0FBRyxPQUFPLElBQUksSUFBSSxPQUFPLElBQUksU0FBUztBQUFBO0FBRTFELFFBQU0sUUFBUSxLQUFLLE1BQU0sY0FBYztBQUN2QyxRQUFNLGVBQWUsTUFBTSxTQUFTO0FBQ3BDLE1BQUksYUFBYSxTQUFTLEtBQUs7QUFDN0IsVUFBTSxlQUFlLEtBQUssTUFBTSxZQUFZLEVBQUU7QUFDOUMsVUFBTSxtQkFBbUIsWUFBWTtBQUNyQyxVQUFNLFdBQVcsQ0FBQztBQUNsQixhQUFTLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLLElBQUk7QUFDaEQsZUFBUyxLQUFLLGFBQWEsTUFBTSxHQUFHLElBQUksRUFBRSxDQUFDO0FBQUEsSUFDN0M7QUFDQSxXQUFPLGNBQWMsbUJBQW1CO0FBQUEsTUFDdEMsQ0FBQyxHQUFHLE9BQU8sTUFBTSxTQUFTLENBQUMsQ0FBQztBQUFBLE1BQzVCLEdBQUcsU0FBUyxNQUFNLEdBQUcsZUFBZSxDQUFDLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLE9BQU8sQ0FBQztBQUFBLE1BQ3RFLENBQUMsS0FBSyxJQUFJLFNBQVMsZ0JBQWdCLENBQUM7QUFBQSxNQUNwQyxDQUFDLEtBQUssU0FBUyxlQUFlLENBQUMsQ0FBQztBQUFBLElBQ2xDLENBQUM7QUFBQSxFQUNIO0FBQ0EsU0FBTyxjQUFjLG1CQUFtQjtBQUFBO0FBQUEsSUFFdEMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLE1BQU0sWUFBWSxDQUFDLENBQUM7QUFBQSxJQUN6QyxDQUFDLEdBQUcsT0FBTyxNQUFNLFlBQVk7QUFBQSxJQUM3QixDQUFDLEtBQUssSUFBSSxTQUFTLFNBQVMsQ0FBQztBQUFBLElBQzdCLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxNQUFNLFlBQVksQ0FBQyxDQUFDO0FBQUEsRUFDM0MsQ0FBQztBQUNIO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTztBQUNqQyxRQUFNLGdCQUFnQixNQUFNLE9BQU8sQ0FBQyxDQUFDLEdBQUcsSUFBSSxNQUFNLFNBQVMsTUFBTTtBQUNqRSxRQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsY0FBYyxJQUFJLENBQUMsQ0FBQyxNQUFNLE1BQU0sT0FBTyxNQUFNLENBQUM7QUFDekUsU0FBTyxjQUFjLElBQUksQ0FBQyxDQUFDLFFBQVEsSUFBSSxNQUFNLE9BQU8sU0FBUyxNQUFNLEtBQUssT0FBTyxNQUFNLE9BQU8sR0FBRyxFQUFFLEtBQUssSUFBSTtBQUM1RztBQUdBLFNBQVMsb0JBQW9CLE1BQU07QUFDakMsUUFBTSxXQUFXLEtBQUssQ0FBQztBQUN2QixNQUFJLFlBQVksUUFBUSxVQUFVLFlBQVksWUFBWSxVQUFVO0FBQ2xFLFdBQU87QUFBQSxNQUNMLE9BQU87QUFBQSxNQUNQLFFBQVEsS0FBSyxDQUFDO0FBQUEsTUFDZCxXQUFXLEtBQUssQ0FBQztBQUFBLE1BQ2pCLE1BQU0sS0FBSyxDQUFDO0FBQUEsTUFDWixlQUFlLEtBQUssQ0FBQztBQUFBLE1BQ3JCLFlBQVksS0FBSyxDQUFDO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsSUFBSSxlQUFlLE1BQU0sc0JBQXNCLE1BQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF1Q25ELFlBQVksYUFBYSxTQUFTO0FBQ2hDLFFBQUksYUFBYSxpQkFBaUI7QUFDbEMsVUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLE1BQU0sZUFBZSxXQUFXLElBQUksb0JBQW9CLE9BQU87QUFDakcsVUFBTSxRQUFRO0FBQ2QsU0FBSyxPQUFPO0FBQ1osU0FBSyxPQUFPLFNBQVMsUUFBUSxTQUFTLFNBQVMsT0FBTztBQUN0RCxTQUFLLGdCQUFnQixrQkFBa0IsUUFBUSxrQkFBa0IsU0FBUyxnQkFBZ0I7QUFDMUYsU0FBSyxRQUFRO0FBQUEsTUFDWCxNQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsUUFBUSxDQUFDLEtBQUssSUFBSTtBQUFBLElBQ25EO0FBQ0EsVUFBTSxnQkFBZ0I7QUFBQSxPQUNuQixjQUFjLEtBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFNBQVMsWUFBWSxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUcsRUFBRSxPQUFPLENBQUMsUUFBUSxPQUFPLElBQUk7QUFBQSxJQUMxSTtBQUNBLFNBQUssU0FBUyxXQUFXLFFBQVEsV0FBVyxTQUFTLFNBQVMsa0JBQWtCLFFBQVEsa0JBQWtCLFNBQVMsVUFBVSxrQkFBa0IsY0FBYyxDQUFDLE9BQU8sUUFBUSxvQkFBb0IsU0FBUyxTQUFTLGdCQUFnQjtBQUNuTyxTQUFLLFlBQVksY0FBYyxRQUFRLGNBQWMsU0FBUyxZQUFZLGtCQUFrQixRQUFRLGtCQUFrQixTQUFTLFNBQVMsY0FBYyxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUs7QUFDNUssU0FBSyxZQUFZLGFBQWEsU0FBUyxVQUFVLElBQUksQ0FBQyxRQUFRLFlBQVksUUFBUSxHQUFHLENBQUMsSUFBSSxrQkFBa0IsUUFBUSxrQkFBa0IsU0FBUyxTQUFTLGNBQWMsSUFBSSxDQUFDLFFBQVEsWUFBWSxJQUFJLFFBQVEsSUFBSSxLQUFLLENBQUM7QUFDck4sVUFBTSxxQkFBcUI7QUFBQSxNQUN6QixrQkFBa0IsUUFBUSxrQkFBa0IsU0FBUyxTQUFTLGNBQWM7QUFBQSxJQUM5RSxJQUFJLGtCQUFrQixRQUFRLGtCQUFrQixTQUFTLFNBQVMsY0FBYyxhQUFhO0FBQzdGLFNBQUssY0FBYyxPQUFPLGVBQWUsUUFBUSxlQUFlLFNBQVMsYUFBYSx3QkFBd0IsUUFBUSxTQUFTLFNBQVMsT0FBdUIsdUJBQU8sT0FBTyxJQUFJO0FBQ2pMLFdBQU8saUJBQWlCLE1BQU07QUFBQSxNQUM1QixTQUFTO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixZQUFZO0FBQUEsTUFDZDtBQUFBLE1BQ0EsTUFBTTtBQUFBLFFBQ0osWUFBWTtBQUFBLE1BQ2Q7QUFBQSxNQUNBLE9BQU87QUFBQSxRQUNMLFlBQVk7QUFBQSxNQUNkO0FBQUEsTUFDQSxRQUFRO0FBQUEsUUFDTixZQUFZO0FBQUEsTUFDZDtBQUFBLE1BQ0EsV0FBVztBQUFBLFFBQ1QsWUFBWTtBQUFBLE1BQ2Q7QUFBQSxNQUNBLGVBQWU7QUFBQSxRQUNiLFlBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRixDQUFDO0FBQ0QsUUFBSSxrQkFBa0IsUUFBUSxrQkFBa0IsVUFBVSxjQUFjLE9BQU87QUFDN0UsYUFBTyxlQUFlLE1BQU0sU0FBUztBQUFBLFFBQ25DLE9BQU8sY0FBYztBQUFBLFFBQ3JCLFVBQVU7QUFBQSxRQUNWLGNBQWM7QUFBQSxNQUNoQixDQUFDO0FBQUEsSUFDSCxXQUFXLE1BQU0sbUJBQW1CO0FBQ2xDLFlBQU0sa0JBQWtCLE1BQU0sYUFBYTtBQUFBLElBQzdDLE9BQU87QUFDTCxhQUFPLGVBQWUsTUFBTSxTQUFTO0FBQUEsUUFDbkMsT0FBTyxNQUFNLEVBQUU7QUFBQSxRQUNmLFVBQVU7QUFBQSxRQUNWLGNBQWM7QUFBQSxNQUNoQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVc7QUFDVCxRQUFJLFNBQVMsS0FBSztBQUNsQixRQUFJLEtBQUssT0FBTztBQUNkLGlCQUFXLFFBQVEsS0FBSyxPQUFPO0FBQzdCLFlBQUksS0FBSyxLQUFLO0FBQ1osb0JBQVUsU0FBUyxjQUFjLEtBQUssR0FBRztBQUFBLFFBQzNDO0FBQUEsTUFDRjtBQUFBLElBQ0YsV0FBVyxLQUFLLFVBQVUsS0FBSyxXQUFXO0FBQ3hDLGlCQUFXLGFBQWEsS0FBSyxXQUFXO0FBQ3RDLGtCQUFVLFNBQVMsb0JBQW9CLEtBQUssUUFBUSxTQUFTO0FBQUEsTUFDL0Q7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxVQUFNLGlCQUFpQjtBQUFBLE1BQ3JCLFNBQVMsS0FBSztBQUFBLElBQ2hCO0FBQ0EsUUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixxQkFBZSxZQUFZLEtBQUs7QUFBQSxJQUNsQztBQUNBLFFBQUksS0FBSyxRQUFRLE1BQU07QUFDckIscUJBQWUsT0FBTyxLQUFLO0FBQUEsSUFDN0I7QUFDQSxRQUFJLEtBQUssY0FBYyxRQUFRLE9BQU8sS0FBSyxLQUFLLFVBQVUsRUFBRSxTQUFTLEdBQUc7QUFDdEUscUJBQWUsYUFBYSxLQUFLO0FBQUEsSUFDbkM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztBQUMvQixTQUFPLFVBQVUsVUFBVSxNQUFNLFdBQVcsSUFBSSxTQUFTO0FBQzNEO0FBR0EsU0FBUyxZQUFZLFFBQVEsVUFBVSxhQUFhO0FBQ2xELFNBQU8sSUFBSSxhQUFhLGlCQUFpQixXQUFXLElBQUk7QUFBQSxJQUN0RDtBQUFBLElBQ0EsV0FBVyxDQUFDLFFBQVE7QUFBQSxFQUN0QixDQUFDO0FBQ0g7QUFHQSxJQUFJLFdBQVcsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZ0JuQixZQUFZLFlBQVksVUFBVSxRQUFRO0FBQ3hDLFNBQUssUUFBUSxXQUFXO0FBQ3hCLFNBQUssTUFBTSxTQUFTO0FBQ3BCLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsU0FBSyxTQUFTO0FBQUEsRUFDaEI7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPO0FBQUEsTUFDTCxPQUFPLEtBQUs7QUFBQSxNQUNaLEtBQUssS0FBSztBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxJQUFJLFFBQVEsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTJCaEIsWUFBWSxNQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsT0FBTztBQUNqRCxTQUFLLE9BQU87QUFDWixTQUFLLFFBQVE7QUFDYixTQUFLLE1BQU07QUFDWCxTQUFLLE9BQU87QUFDWixTQUFLLFNBQVM7QUFDZCxTQUFLLFFBQVE7QUFDYixTQUFLLE9BQU87QUFDWixTQUFLLE9BQU87QUFBQSxFQUNkO0FBQUEsRUFDQSxLQUFLLE9BQU8sV0FBVyxJQUFJO0FBQ3pCLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxTQUFTO0FBQ1AsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLO0FBQUEsTUFDWCxPQUFPLEtBQUs7QUFBQSxNQUNaLE1BQU0sS0FBSztBQUFBLE1BQ1gsUUFBUSxLQUFLO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLElBQUksb0JBQW9CO0FBQUEsRUFDdEIsTUFBTSxDQUFDO0FBQUEsRUFDUCxVQUFVLENBQUMsYUFBYTtBQUFBLEVBQ3hCLHFCQUFxQjtBQUFBLElBQ25CO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0Esb0JBQW9CLENBQUMsWUFBWSxRQUFRLGdCQUFnQixZQUFZO0FBQUEsRUFDckUsVUFBVSxDQUFDLE1BQU07QUFBQSxFQUNqQixjQUFjLENBQUMsWUFBWTtBQUFBLEVBQzNCLE9BQU8sQ0FBQyxTQUFTLFFBQVEsYUFBYSxjQUFjLGNBQWM7QUFBQSxFQUNsRSxVQUFVLENBQUMsUUFBUSxPQUFPO0FBQUEsRUFDMUIsZ0JBQWdCLENBQUMsUUFBUSxZQUFZO0FBQUEsRUFDckMsZ0JBQWdCLENBQUMsaUJBQWlCLGNBQWMsY0FBYztBQUFBLEVBQzlELG9CQUFvQjtBQUFBLElBQ2xCO0FBQUE7QUFBQSxJQUVBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUFBLEVBQ0EsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLGFBQWEsQ0FBQztBQUFBLEVBQ2QsY0FBYyxDQUFDO0FBQUEsRUFDZixXQUFXLENBQUM7QUFBQSxFQUNaLFdBQVcsQ0FBQztBQUFBLEVBQ1osV0FBVyxDQUFDLFFBQVE7QUFBQSxFQUNwQixhQUFhLENBQUMsUUFBUTtBQUFBLEVBQ3RCLGFBQWEsQ0FBQyxRQUFRLE9BQU87QUFBQSxFQUM3QixXQUFXLENBQUMsUUFBUSxXQUFXO0FBQUEsRUFDL0IsV0FBVyxDQUFDLE1BQU07QUFBQSxFQUNsQixVQUFVLENBQUMsTUFBTTtBQUFBLEVBQ2pCLGFBQWEsQ0FBQyxNQUFNO0FBQUEsRUFDcEIsa0JBQWtCLENBQUMsZUFBZSxjQUFjLGdCQUFnQjtBQUFBLEVBQ2hFLHlCQUF5QixDQUFDLE1BQU07QUFBQSxFQUNoQyxzQkFBc0IsQ0FBQyxlQUFlLFFBQVEsWUFBWTtBQUFBLEVBQzFELHNCQUFzQjtBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLGlCQUFpQixDQUFDLGVBQWUsUUFBUSxhQUFhLFFBQVEsWUFBWTtBQUFBLEVBQzFFLHNCQUFzQjtBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLHlCQUF5QjtBQUFBLElBQ3ZCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLHFCQUFxQixDQUFDLGVBQWUsUUFBUSxjQUFjLE9BQU87QUFBQSxFQUNsRSxvQkFBb0IsQ0FBQyxlQUFlLFFBQVEsY0FBYyxRQUFRO0FBQUEsRUFDbEUscUJBQXFCLENBQUMsZUFBZSxRQUFRLFlBQVk7QUFBQSxFQUN6RCwyQkFBMkIsQ0FBQyxlQUFlLFFBQVEsY0FBYyxRQUFRO0FBQUEsRUFDekUscUJBQXFCLENBQUMsZUFBZSxRQUFRLGFBQWEsV0FBVztBQUFBLEVBQ3JFLGlCQUFpQixDQUFDLGNBQWMsZ0JBQWdCO0FBQUEsRUFDaEQscUJBQXFCLENBQUMsUUFBUSxZQUFZO0FBQUEsRUFDMUMscUJBQXFCLENBQUMsUUFBUSxjQUFjLGNBQWMsUUFBUTtBQUFBLEVBQ2xFLHdCQUF3QixDQUFDLFFBQVEsY0FBYyxjQUFjLFFBQVE7QUFBQSxFQUNyRSxvQkFBb0IsQ0FBQyxRQUFRLGNBQWMsT0FBTztBQUFBLEVBQ2xELG1CQUFtQixDQUFDLFFBQVEsY0FBYyxRQUFRO0FBQUEsRUFDbEQsMEJBQTBCLENBQUMsUUFBUSxjQUFjLFFBQVE7QUFDM0Q7QUFDQSxJQUFJLGFBQWEsSUFBSSxJQUFJLE9BQU8sS0FBSyxpQkFBaUIsQ0FBQztBQUN2RCxTQUFTLE9BQU8sV0FBVztBQUN6QixRQUFNLFlBQVksY0FBYyxRQUFRLGNBQWMsU0FBUyxTQUFTLFVBQVU7QUFDbEYsU0FBTyxPQUFPLGNBQWMsWUFBWSxXQUFXLElBQUksU0FBUztBQUNsRTtBQUNBLElBQUk7QUFBQSxDQUNILFNBQVMsb0JBQW9CO0FBQzVCLHFCQUFtQixPQUFPLElBQUk7QUFDOUIscUJBQW1CLFVBQVUsSUFBSTtBQUNqQyxxQkFBbUIsY0FBYyxJQUFJO0FBQ3ZDLEdBQUcsc0JBQXNCLG9CQUFvQixDQUFDLEVBQUU7QUFHaEQsSUFBSTtBQUFBLENBQ0gsU0FBUyxvQkFBb0I7QUFDNUIscUJBQW1CLE9BQU8sSUFBSTtBQUM5QixxQkFBbUIsVUFBVSxJQUFJO0FBQ2pDLHFCQUFtQixjQUFjLElBQUk7QUFDckMscUJBQW1CLE9BQU8sSUFBSTtBQUM5QixxQkFBbUIscUJBQXFCLElBQUk7QUFDNUMscUJBQW1CLGlCQUFpQixJQUFJO0FBQ3hDLHFCQUFtQixpQkFBaUIsSUFBSTtBQUN4QyxxQkFBbUIscUJBQXFCLElBQUk7QUFDNUMscUJBQW1CLFFBQVEsSUFBSTtBQUMvQixxQkFBbUIsUUFBUSxJQUFJO0FBQy9CLHFCQUFtQixRQUFRLElBQUk7QUFDL0IscUJBQW1CLGtCQUFrQixJQUFJO0FBQ3pDLHFCQUFtQixxQkFBcUIsSUFBSTtBQUM1QyxxQkFBbUIsV0FBVyxJQUFJO0FBQ2xDLHFCQUFtQixPQUFPLElBQUk7QUFDOUIscUJBQW1CLE1BQU0sSUFBSTtBQUM3QixxQkFBbUIsWUFBWSxJQUFJO0FBQ25DLHFCQUFtQixjQUFjLElBQUk7QUFDckMscUJBQW1CLHdCQUF3QixJQUFJO0FBQ2pELEdBQUcsc0JBQXNCLG9CQUFvQixDQUFDLEVBQUU7QUFHaEQsSUFBSTtBQUFBLENBQ0gsU0FBUyxPQUFPO0FBQ2YsUUFBTSxNQUFNLElBQUk7QUFDaEIsUUFBTSxVQUFVLElBQUk7QUFDcEIsUUFBTSxzQkFBc0IsSUFBSTtBQUNoQyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sZUFBZSxJQUFJO0FBQ3pCLFFBQU0sT0FBTyxJQUFJO0FBQ2pCLFFBQU0sVUFBVSxJQUFJO0FBQ3BCLFFBQU0saUJBQWlCLElBQUk7QUFDM0IsUUFBTSxpQkFBaUIsSUFBSTtBQUMzQixRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sVUFBVSxJQUFJO0FBQ3BCLFFBQU0sS0FBSyxJQUFJO0FBQ2YsUUFBTSxPQUFPLElBQUk7QUFDakIsUUFBTSxRQUFRLElBQUk7QUFDbEIsUUFBTSxTQUFTLElBQUk7QUFDbkIsUUFBTSxNQUFNLElBQUk7QUFDaEIsUUFBTSxNQUFNLElBQUk7QUFDaEIsUUFBTSxNQUFNLElBQUk7QUFDaEIsUUFBTSxRQUFRLElBQUk7QUFDbEIsUUFBTSxjQUFjLElBQUk7QUFDeEIsUUFBTSxXQUFXLElBQUk7QUFDckIsUUFBTSxZQUFZLElBQUk7QUFDdEIsUUFBTSxXQUFXLElBQUk7QUFDckIsUUFBTSxlQUFlLElBQUk7QUFDekIsUUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFNLDJCQUEyQixJQUFJO0FBQ3JDLFFBQU0sd0JBQXdCLElBQUk7QUFDbEMsUUFBTSx3QkFBd0IsSUFBSTtBQUNsQyxRQUFNLGtCQUFrQixJQUFJO0FBQzVCLFFBQU0sd0JBQXdCLElBQUk7QUFDbEMsUUFBTSwyQkFBMkIsSUFBSTtBQUNyQyxRQUFNLHVCQUF1QixJQUFJO0FBQ2pDLFFBQU0sc0JBQXNCLElBQUk7QUFDaEMsUUFBTSx1QkFBdUIsSUFBSTtBQUNqQyxRQUFNLDhCQUE4QixJQUFJO0FBQ3hDLFFBQU0sc0JBQXNCLElBQUk7QUFDaEMsUUFBTSxrQkFBa0IsSUFBSTtBQUM1QixRQUFNLHVCQUF1QixJQUFJO0FBQ2pDLFFBQU0sdUJBQXVCLElBQUk7QUFDakMsUUFBTSwwQkFBMEIsSUFBSTtBQUNwQyxRQUFNLHNCQUFzQixJQUFJO0FBQ2hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSw2QkFBNkIsSUFBSTtBQUN6QyxHQUFHLFNBQVMsT0FBTyxDQUFDLEVBQUU7QUFHdEIsU0FBUyxhQUFhLE1BQU07QUFDMUIsU0FBTyxTQUFTLEtBQUssU0FBUztBQUNoQztBQUNBLFNBQVMsUUFBUSxNQUFNO0FBQ3JCLFNBQU8sUUFBUSxNQUFNLFFBQVE7QUFDL0I7QUFDQSxTQUFTLFNBQVMsTUFBTTtBQUN0QixTQUFPLFFBQVEsTUFBTSxRQUFRO0FBQUEsRUFDN0IsUUFBUSxNQUFNLFFBQVE7QUFDeEI7QUFDQSxTQUFTLFlBQVksTUFBTTtBQUN6QixTQUFPLFNBQVMsSUFBSSxLQUFLLFNBQVM7QUFDcEM7QUFDQSxTQUFTLGVBQWUsTUFBTTtBQUM1QixTQUFPLFNBQVMsSUFBSSxLQUFLLFFBQVEsSUFBSSxLQUFLLFNBQVM7QUFDckQ7QUFHQSxTQUFTLHVCQUF1QixPQUFPO0FBQ3JDLE1BQUk7QUFDSixNQUFJLGVBQWUsT0FBTztBQUMxQixNQUFJLG9CQUFvQjtBQUN4QixNQUFJLG1CQUFtQjtBQUN2QixXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxFQUFFLEdBQUc7QUFDckMsUUFBSTtBQUNKLFVBQU0sT0FBTyxNQUFNLENBQUM7QUFDcEIsVUFBTSxVQUFVLGtCQUFrQixJQUFJO0FBQ3RDLFFBQUksWUFBWSxLQUFLLFFBQVE7QUFDM0I7QUFBQSxJQUNGO0FBQ0EseUJBQXFCLHFCQUFxQix1QkFBdUIsUUFBUSx1QkFBdUIsU0FBUyxxQkFBcUI7QUFDOUgsdUJBQW1CO0FBQ25CLFFBQUksTUFBTSxLQUFLLFVBQVUsY0FBYztBQUNyQyxxQkFBZTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUNBLFNBQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxNQUFNLE1BQU0sSUFBSSxPQUFPLEtBQUssTUFBTSxZQUFZLENBQUMsRUFBRTtBQUFBLEtBQ3RFLHNCQUFzQix1QkFBdUIsUUFBUSx3QkFBd0IsU0FBUyxzQkFBc0I7QUFBQSxJQUM3RyxtQkFBbUI7QUFBQSxFQUNyQjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsS0FBSztBQUM5QixNQUFJLElBQUk7QUFDUixTQUFPLElBQUksSUFBSSxVQUFVLGFBQWEsSUFBSSxXQUFXLENBQUMsQ0FBQyxHQUFHO0FBQ3hELE1BQUU7QUFBQSxFQUNKO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTyxTQUFTO0FBQ3hDLFFBQU0sZUFBZSxNQUFNLFFBQVEsUUFBUSxPQUFPO0FBQ2xELFFBQU0sUUFBUSxhQUFhLE1BQU0sY0FBYztBQUMvQyxRQUFNLGVBQWUsTUFBTSxXQUFXO0FBQ3RDLFFBQU0sc0JBQXNCLE1BQU0sU0FBUyxLQUFLLE1BQU0sTUFBTSxDQUFDLEVBQUUsTUFBTSxDQUFDLFNBQVMsS0FBSyxXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDcEksUUFBTSwwQkFBMEIsYUFBYSxTQUFTLE9BQU87QUFDN0QsUUFBTSxtQkFBbUIsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDO0FBQ2pELFFBQU0sbUJBQW1CLE1BQU0sU0FBUyxJQUFJO0FBQzVDLFFBQU0sdUJBQXVCLG9CQUFvQjtBQUNqRCxRQUFNLHVCQUF1QixFQUFFLFlBQVksUUFBUSxZQUFZLFVBQVUsUUFBUTtBQUFBLEdBQ2hGLENBQUMsZ0JBQWdCLE1BQU0sU0FBUyxNQUFNLHdCQUF3Qix1QkFBdUI7QUFDdEYsTUFBSSxTQUFTO0FBQ2IsUUFBTSxxQkFBcUIsZ0JBQWdCLGFBQWEsTUFBTSxXQUFXLENBQUMsQ0FBQztBQUMzRSxNQUFJLHdCQUF3QixDQUFDLHNCQUFzQixxQkFBcUI7QUFDdEUsY0FBVTtBQUFBLEVBQ1o7QUFDQSxZQUFVO0FBQ1YsTUFBSSx3QkFBd0Isc0JBQXNCO0FBQ2hELGNBQVU7QUFBQSxFQUNaO0FBQ0EsU0FBTyxRQUFRLFNBQVM7QUFDMUI7QUFHQSxJQUFJO0FBQUEsQ0FDSCxTQUFTLFlBQVk7QUFDcEIsYUFBVyxLQUFLLElBQUk7QUFDcEIsYUFBVyxLQUFLLElBQUk7QUFDcEIsYUFBVyxNQUFNLElBQUk7QUFDckIsYUFBVyxRQUFRLElBQUk7QUFDdkIsYUFBVyxLQUFLLElBQUk7QUFDcEIsYUFBVyxTQUFTLElBQUk7QUFDeEIsYUFBVyxTQUFTLElBQUk7QUFDeEIsYUFBVyxRQUFRLElBQUk7QUFDdkIsYUFBVyxPQUFPLElBQUk7QUFDdEIsYUFBVyxRQUFRLElBQUk7QUFDdkIsYUFBVyxJQUFJLElBQUk7QUFDbkIsYUFBVyxXQUFXLElBQUk7QUFDMUIsYUFBVyxXQUFXLElBQUk7QUFDMUIsYUFBVyxTQUFTLElBQUk7QUFDeEIsYUFBVyxNQUFNLElBQUk7QUFDckIsYUFBVyxTQUFTLElBQUk7QUFDeEIsYUFBVyxNQUFNLElBQUk7QUFDckIsYUFBVyxLQUFLLElBQUk7QUFDcEIsYUFBVyxPQUFPLElBQUk7QUFDdEIsYUFBVyxRQUFRLElBQUk7QUFDdkIsYUFBVyxjQUFjLElBQUk7QUFDN0IsYUFBVyxTQUFTLElBQUk7QUFDMUIsR0FBRyxjQUFjLFlBQVksQ0FBQyxFQUFFO0FBR2hDLElBQUksUUFBUSxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFhaEIsWUFBWSxRQUFRO0FBQ2xCLFVBQU0sbUJBQW1CLElBQUksTUFBTSxVQUFVLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUM1RCxTQUFLLFNBQVM7QUFDZCxTQUFLLFlBQVk7QUFDakIsU0FBSyxRQUFRO0FBQ2IsU0FBSyxPQUFPO0FBQ1osU0FBSyxZQUFZO0FBQUEsRUFDbkI7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLFVBQVU7QUFDUixTQUFLLFlBQVksS0FBSztBQUN0QixVQUFNLFFBQVEsS0FBSyxRQUFRLEtBQUssVUFBVTtBQUMxQyxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxZQUFZO0FBQ1YsUUFBSSxRQUFRLEtBQUs7QUFDakIsUUFBSSxNQUFNLFNBQVMsVUFBVSxLQUFLO0FBQ2hDLFNBQUc7QUFDRCxZQUFJLE1BQU0sTUFBTTtBQUNkLGtCQUFRLE1BQU07QUFBQSxRQUNoQixPQUFPO0FBQ0wsZ0JBQU0sWUFBWSxjQUFjLE1BQU0sTUFBTSxHQUFHO0FBQy9DLGdCQUFNLE9BQU87QUFDYixvQkFBVSxPQUFPO0FBQ2pCLGtCQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0YsU0FBUyxNQUFNLFNBQVMsVUFBVTtBQUFBLElBQ3BDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLE1BQU07QUFDbkMsU0FBTyxTQUFTLFVBQVUsUUFBUSxTQUFTLFVBQVUsVUFBVSxTQUFTLFVBQVUsT0FBTyxTQUFTLFVBQVUsV0FBVyxTQUFTLFVBQVUsV0FBVyxTQUFTLFVBQVUsVUFBVSxTQUFTLFVBQVUsU0FBUyxTQUFTLFVBQVUsVUFBVSxTQUFTLFVBQVUsTUFBTSxTQUFTLFVBQVUsYUFBYSxTQUFTLFVBQVUsYUFBYSxTQUFTLFVBQVUsV0FBVyxTQUFTLFVBQVUsUUFBUSxTQUFTLFVBQVU7QUFDbFo7QUFDQSxTQUFTLHFCQUFxQixNQUFNO0FBQ2xDLFNBQU8sUUFBUSxLQUFLLFFBQVEsU0FBUyxRQUFRLFNBQVMsUUFBUTtBQUNoRTtBQUNBLFNBQVMseUJBQXlCLE1BQU0sV0FBVztBQUNqRCxTQUFPLG1CQUFtQixLQUFLLFdBQVcsU0FBUyxDQUFDLEtBQUssb0JBQW9CLEtBQUssV0FBVyxZQUFZLENBQUMsQ0FBQztBQUM3RztBQUNBLFNBQVMsbUJBQW1CLE1BQU07QUFDaEMsU0FBTyxRQUFRLFNBQVMsUUFBUTtBQUNsQztBQUNBLFNBQVMsb0JBQW9CLE1BQU07QUFDakMsU0FBTyxRQUFRLFNBQVMsUUFBUTtBQUNsQztBQUNBLFNBQVMsaUJBQWlCLFFBQVEsV0FBVztBQUMzQyxRQUFNLE9BQU8sT0FBTyxPQUFPLEtBQUssWUFBWSxTQUFTO0FBQ3JELE1BQUksU0FBUyxRQUFRO0FBQ25CLFdBQU8sVUFBVTtBQUFBLEVBQ25CLFdBQVcsUUFBUSxNQUFNLFFBQVEsS0FBSztBQUNwQyxVQUFNLE9BQU8sT0FBTyxjQUFjLElBQUk7QUFDdEMsV0FBTyxTQUFTLE1BQU0sUUFBUSxJQUFJLElBQUk7QUFBQSxFQUN4QztBQUNBLFNBQU8sT0FBTyxLQUFLLFNBQVMsRUFBRSxFQUFFLFlBQVksRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMvRDtBQUNBLFNBQVMsWUFBWSxRQUFRLE1BQU0sT0FBTyxLQUFLLE9BQU87QUFDcEQsUUFBTSxPQUFPLE9BQU87QUFDcEIsUUFBTSxNQUFNLElBQUksUUFBUSxPQUFPO0FBQy9CLFNBQU8sSUFBSSxNQUFNLE1BQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLO0FBQ3JEO0FBQ0EsU0FBUyxjQUFjLFFBQVEsT0FBTztBQUNwQyxRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLFFBQU0sYUFBYSxLQUFLO0FBQ3hCLE1BQUksV0FBVztBQUNmLFNBQU8sV0FBVyxZQUFZO0FBQzVCLFVBQU0sT0FBTyxLQUFLLFdBQVcsUUFBUTtBQUNyQyxZQUFRLE1BQU07QUFBQSxNQUNaLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFDSCxVQUFFO0FBQ0Y7QUFBQSxNQUNGLEtBQUs7QUFDSCxVQUFFO0FBQ0YsVUFBRSxPQUFPO0FBQ1QsZUFBTyxZQUFZO0FBQ25CO0FBQUEsTUFDRixLQUFLO0FBQ0gsWUFBSSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sSUFBSTtBQUN4QyxzQkFBWTtBQUFBLFFBQ2QsT0FBTztBQUNMLFlBQUU7QUFBQSxRQUNKO0FBQ0EsVUFBRSxPQUFPO0FBQ1QsZUFBTyxZQUFZO0FBQ25CO0FBQUEsTUFDRixLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsUUFBUTtBQUFBLE1BQ3JDLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLE1BQU0sVUFBVSxXQUFXLENBQUM7QUFBQSxNQUNuRSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxRQUFRLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDckUsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsS0FBSyxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ2xFLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLFNBQVMsVUFBVSxXQUFXLENBQUM7QUFBQSxNQUN0RSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxTQUFTLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDdEUsS0FBSztBQUNILFlBQUksS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLElBQUk7QUFDaEYsaUJBQU8sWUFBWSxRQUFRLFVBQVUsUUFBUSxVQUFVLFdBQVcsQ0FBQztBQUFBLFFBQ3JFO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLE9BQU8sVUFBVSxXQUFXLENBQUM7QUFBQSxNQUNwRSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxRQUFRLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDckUsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsSUFBSSxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ2pFLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLFdBQVcsVUFBVSxXQUFXLENBQUM7QUFBQSxNQUN4RSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxXQUFXLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDeEUsS0FBSztBQUNILGVBQU8sWUFBWSxRQUFRLFVBQVUsU0FBUyxVQUFVLFdBQVcsQ0FBQztBQUFBLE1BQ3RFLEtBQUs7QUFDSCxlQUFPLFlBQVksUUFBUSxVQUFVLE1BQU0sVUFBVSxXQUFXLENBQUM7QUFBQSxNQUNuRSxLQUFLO0FBQ0gsZUFBTyxZQUFZLFFBQVEsVUFBVSxTQUFTLFVBQVUsV0FBVyxDQUFDO0FBQUEsTUFDdEUsS0FBSztBQUNILFlBQUksS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLElBQUk7QUFDaEYsaUJBQU8sZ0JBQWdCLFFBQVEsUUFBUTtBQUFBLFFBQ3pDO0FBQ0EsZUFBTyxXQUFXLFFBQVEsUUFBUTtBQUFBLElBQ3RDO0FBQ0EsUUFBSSxRQUFRLElBQUksS0FBSyxTQUFTLElBQUk7QUFDaEMsYUFBTyxXQUFXLFFBQVEsVUFBVSxJQUFJO0FBQUEsSUFDMUM7QUFDQSxRQUFJLFlBQVksSUFBSSxHQUFHO0FBQ3JCLGFBQU8sU0FBUyxRQUFRLFFBQVE7QUFBQSxJQUNsQztBQUNBLFVBQU07QUFBQSxNQUNKLE9BQU87QUFBQSxNQUNQO0FBQUEsTUFDQSxTQUFTLEtBQUssbUZBQW1GLHFCQUFxQixJQUFJLEtBQUsseUJBQXlCLE1BQU0sUUFBUSxJQUFJLHlCQUF5QixpQkFBaUIsUUFBUSxRQUFRLENBQUMsTUFBTSxzQkFBc0IsaUJBQWlCLFFBQVEsUUFBUSxDQUFDO0FBQUEsSUFDclM7QUFBQSxFQUNGO0FBQ0EsU0FBTyxZQUFZLFFBQVEsVUFBVSxLQUFLLFlBQVksVUFBVTtBQUNsRTtBQUNBLFNBQVMsWUFBWSxRQUFRLE9BQU87QUFDbEMsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixRQUFNLGFBQWEsS0FBSztBQUN4QixNQUFJLFdBQVcsUUFBUTtBQUN2QixTQUFPLFdBQVcsWUFBWTtBQUM1QixVQUFNLE9BQU8sS0FBSyxXQUFXLFFBQVE7QUFDckMsUUFBSSxTQUFTLE1BQU0sU0FBUyxJQUFJO0FBQzlCO0FBQUEsSUFDRjtBQUNBLFFBQUkscUJBQXFCLElBQUksR0FBRztBQUM5QixRQUFFO0FBQUEsSUFDSixXQUFXLHlCQUF5QixNQUFNLFFBQVEsR0FBRztBQUNuRCxrQkFBWTtBQUFBLElBQ2QsT0FBTztBQUNMO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0EsVUFBVTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsSUFDQSxLQUFLLE1BQU0sUUFBUSxHQUFHLFFBQVE7QUFBQSxFQUNoQztBQUNGO0FBQ0EsU0FBUyxXQUFXLFFBQVEsT0FBTyxXQUFXO0FBQzVDLFFBQU0sT0FBTyxPQUFPLE9BQU87QUFDM0IsTUFBSSxXQUFXO0FBQ2YsTUFBSSxPQUFPO0FBQ1gsTUFBSSxVQUFVO0FBQ2QsTUFBSSxTQUFTLElBQUk7QUFDZixXQUFPLEtBQUssV0FBVyxFQUFFLFFBQVE7QUFBQSxFQUNuQztBQUNBLE1BQUksU0FBUyxJQUFJO0FBQ2YsV0FBTyxLQUFLLFdBQVcsRUFBRSxRQUFRO0FBQ2pDLFFBQUksUUFBUSxJQUFJLEdBQUc7QUFDakIsWUFBTTtBQUFBLFFBQ0osT0FBTztBQUFBLFFBQ1A7QUFBQSxRQUNBLDZDQUE2QztBQUFBLFVBQzNDO0FBQUEsVUFDQTtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRixPQUFPO0FBQ0wsZUFBVyxXQUFXLFFBQVEsVUFBVSxJQUFJO0FBQzVDLFdBQU8sS0FBSyxXQUFXLFFBQVE7QUFBQSxFQUNqQztBQUNBLE1BQUksU0FBUyxJQUFJO0FBQ2YsY0FBVTtBQUNWLFdBQU8sS0FBSyxXQUFXLEVBQUUsUUFBUTtBQUNqQyxlQUFXLFdBQVcsUUFBUSxVQUFVLElBQUk7QUFDNUMsV0FBTyxLQUFLLFdBQVcsUUFBUTtBQUFBLEVBQ2pDO0FBQ0EsTUFBSSxTQUFTLE1BQU0sU0FBUyxLQUFLO0FBQy9CLGNBQVU7QUFDVixXQUFPLEtBQUssV0FBVyxFQUFFLFFBQVE7QUFDakMsUUFBSSxTQUFTLE1BQU0sU0FBUyxJQUFJO0FBQzlCLGFBQU8sS0FBSyxXQUFXLEVBQUUsUUFBUTtBQUFBLElBQ25DO0FBQ0EsZUFBVyxXQUFXLFFBQVEsVUFBVSxJQUFJO0FBQzVDLFdBQU8sS0FBSyxXQUFXLFFBQVE7QUFBQSxFQUNqQztBQUNBLE1BQUksU0FBUyxNQUFNLFlBQVksSUFBSSxHQUFHO0FBQ3BDLFVBQU07QUFBQSxNQUNKLE9BQU87QUFBQSxNQUNQO0FBQUEsTUFDQSwyQ0FBMkM7QUFBQSxRQUN6QztBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVLFVBQVUsUUFBUSxVQUFVO0FBQUEsSUFDdEM7QUFBQSxJQUNBO0FBQUEsSUFDQSxLQUFLLE1BQU0sT0FBTyxRQUFRO0FBQUEsRUFDNUI7QUFDRjtBQUNBLFNBQVMsV0FBVyxRQUFRLE9BQU8sV0FBVztBQUM1QyxNQUFJLENBQUMsUUFBUSxTQUFTLEdBQUc7QUFDdkIsVUFBTTtBQUFBLE1BQ0osT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLDJDQUEyQztBQUFBLFFBQ3pDO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixNQUFJLFdBQVcsUUFBUTtBQUN2QixTQUFPLFFBQVEsS0FBSyxXQUFXLFFBQVEsQ0FBQyxHQUFHO0FBQ3pDLE1BQUU7QUFBQSxFQUNKO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxXQUFXLFFBQVEsT0FBTztBQUNqQyxRQUFNLE9BQU8sT0FBTyxPQUFPO0FBQzNCLFFBQU0sYUFBYSxLQUFLO0FBQ3hCLE1BQUksV0FBVyxRQUFRO0FBQ3ZCLE1BQUksYUFBYTtBQUNqQixNQUFJLFFBQVE7QUFDWixTQUFPLFdBQVcsWUFBWTtBQUM1QixVQUFNLE9BQU8sS0FBSyxXQUFXLFFBQVE7QUFDckMsUUFBSSxTQUFTLElBQUk7QUFDZixlQUFTLEtBQUssTUFBTSxZQUFZLFFBQVE7QUFDeEMsYUFBTyxZQUFZLFFBQVEsVUFBVSxRQUFRLE9BQU8sV0FBVyxHQUFHLEtBQUs7QUFBQSxJQUN6RTtBQUNBLFFBQUksU0FBUyxJQUFJO0FBQ2YsZUFBUyxLQUFLLE1BQU0sWUFBWSxRQUFRO0FBQ3hDLFlBQU0sU0FBUyxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxDQUFDLE1BQU0sTUFBTSxnQ0FBZ0MsUUFBUSxRQUFRLElBQUksNkJBQTZCLFFBQVEsUUFBUSxJQUFJLHFCQUFxQixRQUFRLFFBQVE7QUFDek8sZUFBUyxPQUFPO0FBQ2hCLGtCQUFZLE9BQU87QUFDbkIsbUJBQWE7QUFDYjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFDOUI7QUFBQSxJQUNGO0FBQ0EsUUFBSSxxQkFBcUIsSUFBSSxHQUFHO0FBQzlCLFFBQUU7QUFBQSxJQUNKLFdBQVcseUJBQXlCLE1BQU0sUUFBUSxHQUFHO0FBQ25ELGtCQUFZO0FBQUEsSUFDZCxPQUFPO0FBQ0wsWUFBTTtBQUFBLFFBQ0osT0FBTztBQUFBLFFBQ1A7QUFBQSxRQUNBLG9DQUFvQztBQUFBLFVBQ2xDO0FBQUEsVUFDQTtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU0sWUFBWSxPQUFPLFFBQVEsVUFBVSxzQkFBc0I7QUFDbkU7QUFDQSxTQUFTLGdDQUFnQyxRQUFRLFVBQVU7QUFDekQsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixNQUFJLFFBQVE7QUFDWixNQUFJLE9BQU87QUFDWCxTQUFPLE9BQU8sSUFBSTtBQUNoQixVQUFNLE9BQU8sS0FBSyxXQUFXLFdBQVcsTUFBTTtBQUM5QyxRQUFJLFNBQVMsS0FBSztBQUNoQixVQUFJLE9BQU8sS0FBSyxDQUFDLHFCQUFxQixLQUFLLEdBQUc7QUFDNUM7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLFFBQ0wsT0FBTyxPQUFPLGNBQWMsS0FBSztBQUFBLFFBQ2pDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxZQUFRLFNBQVMsSUFBSSxhQUFhLElBQUk7QUFDdEMsUUFBSSxRQUFRLEdBQUc7QUFDYjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTtBQUFBLElBQ0osT0FBTztBQUFBLElBQ1A7QUFBQSxJQUNBLHFDQUFxQyxLQUFLO0FBQUEsTUFDeEM7QUFBQSxNQUNBLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFDQSxTQUFTLDZCQUE2QixRQUFRLFVBQVU7QUFDdEQsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixRQUFNLE9BQU8saUJBQWlCLE1BQU0sV0FBVyxDQUFDO0FBQ2hELE1BQUkscUJBQXFCLElBQUksR0FBRztBQUM5QixXQUFPO0FBQUEsTUFDTCxPQUFPLE9BQU8sY0FBYyxJQUFJO0FBQUEsTUFDaEMsTUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQ0EsTUFBSSxtQkFBbUIsSUFBSSxHQUFHO0FBQzVCLFFBQUksS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLEtBQUs7QUFDakYsWUFBTSxlQUFlLGlCQUFpQixNQUFNLFdBQVcsQ0FBQztBQUN4RCxVQUFJLG9CQUFvQixZQUFZLEdBQUc7QUFDckMsZUFBTztBQUFBLFVBQ0wsT0FBTyxPQUFPLGNBQWMsTUFBTSxZQUFZO0FBQUEsVUFDOUMsTUFBTTtBQUFBLFFBQ1I7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNO0FBQUEsSUFDSixPQUFPO0FBQUEsSUFDUDtBQUFBLElBQ0EscUNBQXFDLEtBQUssTUFBTSxVQUFVLFdBQVcsQ0FBQyxDQUFDO0FBQUEsRUFDekU7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLE1BQU0sVUFBVTtBQUN4QyxTQUFPLGFBQWEsS0FBSyxXQUFXLFFBQVEsQ0FBQyxLQUFLLEtBQUssYUFBYSxLQUFLLFdBQVcsV0FBVyxDQUFDLENBQUMsS0FBSyxJQUFJLGFBQWEsS0FBSyxXQUFXLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSSxhQUFhLEtBQUssV0FBVyxXQUFXLENBQUMsQ0FBQztBQUN6TTtBQUNBLFNBQVMsYUFBYSxNQUFNO0FBQzFCLFNBQU8sUUFBUSxNQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssUUFBUSxNQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssUUFBUSxNQUFNLFFBQVEsTUFBTSxPQUFPLEtBQUs7QUFDL0g7QUFDQSxTQUFTLHFCQUFxQixRQUFRLFVBQVU7QUFDOUMsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixRQUFNLE9BQU8sS0FBSyxXQUFXLFdBQVcsQ0FBQztBQUN6QyxVQUFRLE1BQU07QUFBQSxJQUNaLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0YsS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLE9BQU87QUFBQSxRQUNQLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRixLQUFLO0FBQ0gsYUFBTztBQUFBLFFBQ0wsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0YsS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLE9BQU87QUFBQSxRQUNQLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRixLQUFLO0FBQ0gsYUFBTztBQUFBLFFBQ0wsT0FBTztBQUFBLFFBQ1AsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0YsS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLE9BQU87QUFBQSxRQUNQLE1BQU07QUFBQSxNQUNSO0FBQUEsRUFDSjtBQUNBLFFBQU07QUFBQSxJQUNKLE9BQU87QUFBQSxJQUNQO0FBQUEsSUFDQSx1Q0FBdUMsS0FBSztBQUFBLE1BQzFDO0FBQUEsTUFDQSxXQUFXO0FBQUEsSUFDYixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsUUFBUSxPQUFPO0FBQ3RDLFFBQU0sT0FBTyxPQUFPLE9BQU87QUFDM0IsUUFBTSxhQUFhLEtBQUs7QUFDeEIsTUFBSSxZQUFZLE9BQU87QUFDdkIsTUFBSSxXQUFXLFFBQVE7QUFDdkIsTUFBSSxhQUFhO0FBQ2pCLE1BQUksY0FBYztBQUNsQixRQUFNLGFBQWEsQ0FBQztBQUNwQixTQUFPLFdBQVcsWUFBWTtBQUM1QixVQUFNLE9BQU8sS0FBSyxXQUFXLFFBQVE7QUFDckMsUUFBSSxTQUFTLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLElBQUk7QUFDL0YscUJBQWUsS0FBSyxNQUFNLFlBQVksUUFBUTtBQUM5QyxpQkFBVyxLQUFLLFdBQVc7QUFDM0IsWUFBTSxRQUFRO0FBQUEsUUFDWjtBQUFBLFFBQ0EsVUFBVTtBQUFBLFFBQ1Y7QUFBQSxRQUNBLFdBQVc7QUFBQTtBQUFBLFFBRVgsdUJBQXVCLFVBQVUsRUFBRSxLQUFLLElBQUk7QUFBQSxNQUM5QztBQUNBLGFBQU8sUUFBUSxXQUFXLFNBQVM7QUFDbkMsYUFBTyxZQUFZO0FBQ25CLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxTQUFTLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLE1BQU0sS0FBSyxXQUFXLFdBQVcsQ0FBQyxNQUFNLElBQUk7QUFDdkkscUJBQWUsS0FBSyxNQUFNLFlBQVksUUFBUTtBQUM5QyxtQkFBYSxXQUFXO0FBQ3hCLGtCQUFZO0FBQ1o7QUFBQSxJQUNGO0FBQ0EsUUFBSSxTQUFTLE1BQU0sU0FBUyxJQUFJO0FBQzlCLHFCQUFlLEtBQUssTUFBTSxZQUFZLFFBQVE7QUFDOUMsaUJBQVcsS0FBSyxXQUFXO0FBQzNCLFVBQUksU0FBUyxNQUFNLEtBQUssV0FBVyxXQUFXLENBQUMsTUFBTSxJQUFJO0FBQ3ZELG9CQUFZO0FBQUEsTUFDZCxPQUFPO0FBQ0wsVUFBRTtBQUFBLE1BQ0o7QUFDQSxvQkFBYztBQUNkLG1CQUFhO0FBQ2Isa0JBQVk7QUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLHFCQUFxQixJQUFJLEdBQUc7QUFDOUIsUUFBRTtBQUFBLElBQ0osV0FBVyx5QkFBeUIsTUFBTSxRQUFRLEdBQUc7QUFDbkQsa0JBQVk7QUFBQSxJQUNkLE9BQU87QUFDTCxZQUFNO0FBQUEsUUFDSixPQUFPO0FBQUEsUUFDUDtBQUFBLFFBQ0Esb0NBQW9DO0FBQUEsVUFDbEM7QUFBQSxVQUNBO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZLE9BQU8sUUFBUSxVQUFVLHNCQUFzQjtBQUNuRTtBQUNBLFNBQVMsU0FBUyxRQUFRLE9BQU87QUFDL0IsUUFBTSxPQUFPLE9BQU8sT0FBTztBQUMzQixRQUFNLGFBQWEsS0FBSztBQUN4QixNQUFJLFdBQVcsUUFBUTtBQUN2QixTQUFPLFdBQVcsWUFBWTtBQUM1QixVQUFNLE9BQU8sS0FBSyxXQUFXLFFBQVE7QUFDckMsUUFBSSxlQUFlLElBQUksR0FBRztBQUN4QixRQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0w7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVjtBQUFBLElBQ0E7QUFBQSxJQUNBLEtBQUssTUFBTSxPQUFPLFFBQVE7QUFBQSxFQUM1QjtBQUNGO0FBR0EsSUFBSSxtQkFBbUI7QUFDdkIsSUFBSSxzQkFBc0I7QUFDMUIsU0FBUyxRQUFRLE9BQU87QUFDdEIsU0FBTyxZQUFZLE9BQU8sQ0FBQyxDQUFDO0FBQzlCO0FBQ0EsU0FBUyxZQUFZLE9BQU8sWUFBWTtBQUN0QyxVQUFRLE9BQU8sT0FBTztBQUFBLElBQ3BCLEtBQUs7QUFDSCxhQUFPLEtBQUssVUFBVSxLQUFLO0FBQUEsSUFDN0IsS0FBSztBQUNILGFBQU8sTUFBTSxPQUFPLGFBQWEsTUFBTSxJQUFJLE1BQU07QUFBQSxJQUNuRCxLQUFLO0FBQ0gsYUFBTyxrQkFBa0IsT0FBTyxVQUFVO0FBQUEsSUFDNUM7QUFDRSxhQUFPLE9BQU8sS0FBSztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixPQUFPLHNCQUFzQjtBQUN0RCxNQUFJLFVBQVUsTUFBTTtBQUNsQixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUkscUJBQXFCLFNBQVMsS0FBSyxHQUFHO0FBQ3hDLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxhQUFhLENBQUMsR0FBRyxzQkFBc0IsS0FBSztBQUNsRCxNQUFJLFdBQVcsS0FBSyxHQUFHO0FBQ3JCLFVBQU0sWUFBWSxNQUFNLE9BQU87QUFDL0IsUUFBSSxjQUFjLE9BQU87QUFDdkIsYUFBTyxPQUFPLGNBQWMsV0FBVyxZQUFZLFlBQVksV0FBVyxVQUFVO0FBQUEsSUFDdEY7QUFBQSxFQUNGLFdBQVcsTUFBTSxRQUFRLEtBQUssR0FBRztBQUMvQixXQUFPLFlBQVksT0FBTyxVQUFVO0FBQUEsRUFDdEM7QUFDQSxTQUFPLGFBQWEsT0FBTyxVQUFVO0FBQ3ZDO0FBQ0EsU0FBUyxXQUFXLE9BQU87QUFDekIsU0FBTyxPQUFPLE1BQU0sV0FBVztBQUNqQztBQUNBLFNBQVMsYUFBYSxRQUFRLFlBQVk7QUFDeEMsUUFBTSxVQUFVLE9BQU8sUUFBUSxNQUFNO0FBQ3JDLE1BQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFdBQVcsU0FBUyxxQkFBcUI7QUFDM0MsV0FBTyxNQUFNLGFBQWEsTUFBTSxJQUFJO0FBQUEsRUFDdEM7QUFDQSxRQUFNLGFBQWEsUUFBUTtBQUFBLElBQ3pCLENBQUMsQ0FBQyxLQUFLLEtBQUssTUFBTSxNQUFNLE9BQU8sWUFBWSxPQUFPLFVBQVU7QUFBQSxFQUM5RDtBQUNBLFNBQU8sT0FBTyxXQUFXLEtBQUssSUFBSSxJQUFJO0FBQ3hDO0FBQ0EsU0FBUyxZQUFZLE9BQU8sWUFBWTtBQUN0QyxNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxXQUFXLFNBQVMscUJBQXFCO0FBQzNDLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxNQUFNLEtBQUssSUFBSSxrQkFBa0IsTUFBTSxNQUFNO0FBQ25ELFFBQU0sWUFBWSxNQUFNLFNBQVM7QUFDakMsUUFBTSxRQUFRLENBQUM7QUFDZixXQUFTLElBQUksR0FBRyxJQUFJLEtBQUssRUFBRSxHQUFHO0FBQzVCLFVBQU0sS0FBSyxZQUFZLE1BQU0sQ0FBQyxHQUFHLFVBQVUsQ0FBQztBQUFBLEVBQzlDO0FBQ0EsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxLQUFLLGlCQUFpQjtBQUFBLEVBQzlCLFdBQVcsWUFBWSxHQUFHO0FBQ3hCLFVBQU0sS0FBSyxPQUFPLFNBQVMsYUFBYTtBQUFBLEVBQzFDO0FBQ0EsU0FBTyxNQUFNLE1BQU0sS0FBSyxJQUFJLElBQUk7QUFDbEM7QUFDQSxTQUFTLGFBQWEsUUFBUTtBQUM1QixRQUFNLE1BQU0sT0FBTyxVQUFVLFNBQVMsS0FBSyxNQUFNLEVBQUUsUUFBUSxjQUFjLEVBQUUsRUFBRSxRQUFRLE1BQU0sRUFBRTtBQUM3RixNQUFJLFFBQVEsWUFBWSxPQUFPLE9BQU8sZ0JBQWdCLFlBQVk7QUFDaEUsVUFBTSxPQUFPLE9BQU8sWUFBWTtBQUNoQyxRQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsSUFBSTtBQUMzQyxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxJQUFJO0FBQUE7QUFBQTtBQUFBLEVBR0YsV0FBVyxXQUFXLFFBQW1ELFNBQVMsWUFBWSxPQUFPLGFBQWE7QUFDaEgsV0FBTyxpQkFBaUI7QUFBQSxFQUMxQixJQUFJLFNBQVMsWUFBWSxPQUFPLGFBQWE7QUFDM0MsUUFBSSxpQkFBaUIsYUFBYTtBQUNoQyxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksT0FBTyxVQUFVLFlBQVksVUFBVSxNQUFNO0FBQy9DLFVBQUk7QUFDSixZQUFNLFlBQVksWUFBWSxVQUFVLE9BQU8sV0FBVztBQUMxRCxZQUFNO0FBQUE7QUFBQSxRQUVKLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxXQUFXLEtBQUsscUJBQXFCLE1BQU0saUJBQWlCLFFBQVEsdUJBQXVCLFNBQVMsU0FBUyxtQkFBbUI7QUFBQTtBQUU3SyxVQUFJLGNBQWMsZ0JBQWdCO0FBQ2hDLGNBQU0sbUJBQW1CLFFBQVEsS0FBSztBQUN0QyxjQUFNLElBQUksTUFBTSxjQUFjLFNBQVMsS0FBSyxnQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVdsRDtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUlGLElBQUksU0FBUyxNQUFNO0FBQUEsRUFDakIsWUFBWSxNQUFNLE9BQU8sbUJBQW1CLGlCQUFpQjtBQUFBLElBQzNELE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxFQUNWLEdBQUc7QUFDRCxXQUFPLFNBQVMsWUFBWSxVQUFVLE9BQU8sb0NBQW9DLFFBQVEsSUFBSSxDQUFDLEdBQUc7QUFDakcsU0FBSyxPQUFPO0FBQ1osU0FBSyxPQUFPO0FBQ1osU0FBSyxpQkFBaUI7QUFDdEIsU0FBSyxlQUFlLE9BQU8sS0FBSztBQUFBLE1BQzlCO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxTQUFLLGVBQWUsU0FBUyxLQUFLO0FBQUEsTUFDaEM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLFNBQVMsU0FBUyxRQUFRO0FBQ3hCLFNBQU8sV0FBVyxRQUFRLE1BQU07QUFDbEM7QUFHQSxTQUFTLE9BQU8sUUFBUSxTQUFTO0FBQy9CLFFBQU0sU0FBUyxJQUFJLE9BQU8sUUFBUSxPQUFPO0FBQ3pDLFNBQU8sT0FBTyxjQUFjO0FBQzlCO0FBQ0EsSUFBSSxTQUFTLE1BQU07QUFBQSxFQUNqQixZQUFZLFFBQVEsVUFBVSxDQUFDLEdBQUc7QUFDaEMsVUFBTSxZQUFZLFNBQVMsTUFBTSxJQUFJLFNBQVMsSUFBSSxPQUFPLE1BQU07QUFDL0QsU0FBSyxTQUFTLElBQUksTUFBTSxTQUFTO0FBQ2pDLFNBQUssV0FBVztBQUNoQixTQUFLLGdCQUFnQjtBQUFBLEVBQ3ZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxZQUFZO0FBQ1YsVUFBTSxRQUFRLEtBQUssWUFBWSxVQUFVLElBQUk7QUFDN0MsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1gsT0FBTyxNQUFNO0FBQUEsSUFDZixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxnQkFBZ0I7QUFDZCxXQUFPLEtBQUssS0FBSyxLQUFLLE9BQU8sT0FBTztBQUFBLE1BQ2xDLE1BQU0sS0FBSztBQUFBLE1BQ1gsYUFBYSxLQUFLO0FBQUEsUUFDaEIsVUFBVTtBQUFBLFFBQ1YsS0FBSztBQUFBLFFBQ0wsVUFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBd0JBLGtCQUFrQjtBQUNoQixRQUFJLEtBQUssS0FBSyxVQUFVLE9BQU8sR0FBRztBQUNoQyxhQUFPLEtBQUsseUJBQXlCO0FBQUEsSUFDdkM7QUFDQSxVQUFNLGlCQUFpQixLQUFLLGdCQUFnQjtBQUM1QyxVQUFNLGVBQWUsaUJBQWlCLEtBQUssT0FBTyxVQUFVLElBQUksS0FBSyxPQUFPO0FBQzVFLFFBQUksYUFBYSxTQUFTLFVBQVUsTUFBTTtBQUN4QyxjQUFRLGFBQWEsT0FBTztBQUFBLFFBQzFCLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHNCQUFzQjtBQUFBLFFBQ3BDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLDBCQUEwQjtBQUFBLFFBQ3hDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLDBCQUEwQjtBQUFBLFFBQ3hDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLDZCQUE2QjtBQUFBLFFBQzNDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHlCQUF5QjtBQUFBLFFBQ3ZDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHdCQUF3QjtBQUFBLFFBQ3RDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLCtCQUErQjtBQUFBLFFBQzdDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHlCQUF5QjtBQUFBLE1BQ3pDO0FBQ0EsVUFBSSxnQkFBZ0I7QUFDbEIsY0FBTTtBQUFBLFVBQ0osS0FBSyxPQUFPO0FBQUEsVUFDWixLQUFLLE9BQU8sTUFBTTtBQUFBLFVBQ2xCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxjQUFRLGFBQWEsT0FBTztBQUFBLFFBQzFCLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHlCQUF5QjtBQUFBLFFBQ3ZDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHdCQUF3QjtBQUFBLFFBQ3RDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHlCQUF5QjtBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxXQUFXLFlBQVk7QUFBQSxFQUNwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsMkJBQTJCO0FBQ3pCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsUUFBSSxLQUFLLEtBQUssVUFBVSxPQUFPLEdBQUc7QUFDaEMsYUFBTyxLQUFLLEtBQUssT0FBTztBQUFBLFFBQ3RCLE1BQU0sS0FBSztBQUFBLFFBQ1gsV0FBVyxrQkFBa0I7QUFBQSxRQUM3QixNQUFNO0FBQUEsUUFDTixxQkFBcUIsQ0FBQztBQUFBLFFBQ3RCLFlBQVksQ0FBQztBQUFBLFFBQ2IsY0FBYyxLQUFLLGtCQUFrQjtBQUFBLE1BQ3ZDLENBQUM7QUFBQSxJQUNIO0FBQ0EsVUFBTSxZQUFZLEtBQUssbUJBQW1CO0FBQzFDLFFBQUk7QUFDSixRQUFJLEtBQUssS0FBSyxVQUFVLElBQUksR0FBRztBQUM3QixhQUFPLEtBQUssVUFBVTtBQUFBLElBQ3hCO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQSxxQkFBcUIsS0FBSyx5QkFBeUI7QUFBQSxNQUNuRCxZQUFZLEtBQUssZ0JBQWdCLEtBQUs7QUFBQSxNQUN0QyxjQUFjLEtBQUssa0JBQWtCO0FBQUEsSUFDdkMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLHFCQUFxQjtBQUNuQixVQUFNLGlCQUFpQixLQUFLLFlBQVksVUFBVSxJQUFJO0FBQ3RELFlBQVEsZUFBZSxPQUFPO0FBQUEsTUFDNUIsS0FBSztBQUNILGVBQU8sa0JBQWtCO0FBQUEsTUFDM0IsS0FBSztBQUNILGVBQU8sa0JBQWtCO0FBQUEsTUFDM0IsS0FBSztBQUNILGVBQU8sa0JBQWtCO0FBQUEsSUFDN0I7QUFDQSxVQUFNLEtBQUssV0FBVyxjQUFjO0FBQUEsRUFDdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLDJCQUEyQjtBQUN6QixXQUFPLEtBQUs7QUFBQSxNQUNWLFVBQVU7QUFBQSxNQUNWLEtBQUs7QUFBQSxNQUNMLFVBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsMEJBQTBCO0FBQ3hCLFdBQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxPQUFPO0FBQUEsTUFDbEMsTUFBTSxLQUFLO0FBQUEsTUFDWCxVQUFVLEtBQUssY0FBYztBQUFBLE1BQzdCLE9BQU8sS0FBSyxZQUFZLFVBQVUsS0FBSyxHQUFHLEtBQUssbUJBQW1CO0FBQUEsTUFDbEUsY0FBYyxLQUFLLG9CQUFvQixVQUFVLE1BQU0sSUFBSSxLQUFLLHVCQUF1QixJQUFJO0FBQUEsTUFDM0YsWUFBWSxLQUFLLHFCQUFxQjtBQUFBLElBQ3hDLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxnQkFBZ0I7QUFDZCxVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssWUFBWSxVQUFVLE1BQU07QUFDakMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1gsTUFBTSxLQUFLLFVBQVU7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLG9CQUFvQjtBQUNsQixXQUFPLEtBQUssS0FBSyxLQUFLLE9BQU8sT0FBTztBQUFBLE1BQ2xDLE1BQU0sS0FBSztBQUFBLE1BQ1gsWUFBWSxLQUFLO0FBQUEsUUFDZixVQUFVO0FBQUEsUUFDVixLQUFLO0FBQUEsUUFDTCxVQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLGlCQUFpQjtBQUNmLFdBQU8sS0FBSyxLQUFLLFVBQVUsTUFBTSxJQUFJLEtBQUssY0FBYyxJQUFJLEtBQUssV0FBVztBQUFBLEVBQzlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsYUFBYTtBQUNYLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsVUFBTSxjQUFjLEtBQUssVUFBVTtBQUNuQyxRQUFJO0FBQ0osUUFBSTtBQUNKLFFBQUksS0FBSyxvQkFBb0IsVUFBVSxLQUFLLEdBQUc7QUFDN0MsY0FBUTtBQUNSLGFBQU8sS0FBSyxVQUFVO0FBQUEsSUFDeEIsT0FBTztBQUNMLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQSxXQUFXLEtBQUssZUFBZSxLQUFLO0FBQUEsTUFDcEMsWUFBWSxLQUFLLGdCQUFnQixLQUFLO0FBQUEsTUFDdEMsY0FBYyxLQUFLLEtBQUssVUFBVSxPQUFPLElBQUksS0FBSyxrQkFBa0IsSUFBSTtBQUFBLElBQzFFLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxlQUFlLFNBQVM7QUFDdEIsVUFBTSxPQUFPLFVBQVUsS0FBSyxxQkFBcUIsS0FBSztBQUN0RCxXQUFPLEtBQUssYUFBYSxVQUFVLFNBQVMsTUFBTSxVQUFVLE9BQU87QUFBQSxFQUNyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsY0FBYyxVQUFVLE9BQU87QUFDN0IsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFNBQUssWUFBWSxVQUFVLEtBQUs7QUFDaEMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBLE9BQU8sS0FBSyxrQkFBa0IsT0FBTztBQUFBLElBQ3ZDLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFDQSxxQkFBcUI7QUFDbkIsV0FBTyxLQUFLLGNBQWMsSUFBSTtBQUFBLEVBQ2hDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0EsZ0JBQWdCO0FBQ2QsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLFlBQVksVUFBVSxNQUFNO0FBQ2pDLFVBQU0sbUJBQW1CLEtBQUssc0JBQXNCLElBQUk7QUFDeEQsUUFBSSxDQUFDLG9CQUFvQixLQUFLLEtBQUssVUFBVSxJQUFJLEdBQUc7QUFDbEQsYUFBTyxLQUFLLEtBQUssT0FBTztBQUFBLFFBQ3RCLE1BQU0sS0FBSztBQUFBLFFBQ1gsTUFBTSxLQUFLLGtCQUFrQjtBQUFBLFFBQzdCLFlBQVksS0FBSyxnQkFBZ0IsS0FBSztBQUFBLE1BQ3hDLENBQUM7QUFBQSxJQUNIO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1gsZUFBZSxtQkFBbUIsS0FBSyxlQUFlLElBQUk7QUFBQSxNQUMxRCxZQUFZLEtBQUssZ0JBQWdCLEtBQUs7QUFBQSxNQUN0QyxjQUFjLEtBQUssa0JBQWtCO0FBQUEsSUFDdkMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLDBCQUEwQjtBQUN4QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssY0FBYyxVQUFVO0FBQzdCLFFBQUksS0FBSyxTQUFTLGlDQUFpQyxNQUFNO0FBQ3ZELGFBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxRQUN0QixNQUFNLEtBQUs7QUFBQSxRQUNYLE1BQU0sS0FBSyxrQkFBa0I7QUFBQSxRQUM3QixxQkFBcUIsS0FBSyx5QkFBeUI7QUFBQSxRQUNuRCxnQkFBZ0IsS0FBSyxjQUFjLElBQUksR0FBRyxLQUFLLGVBQWU7QUFBQSxRQUM5RCxZQUFZLEtBQUssZ0JBQWdCLEtBQUs7QUFBQSxRQUN0QyxjQUFjLEtBQUssa0JBQWtCO0FBQUEsTUFDdkMsQ0FBQztBQUFBLElBQ0g7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWCxNQUFNLEtBQUssa0JBQWtCO0FBQUEsTUFDN0IsZ0JBQWdCLEtBQUssY0FBYyxJQUFJLEdBQUcsS0FBSyxlQUFlO0FBQUEsTUFDOUQsWUFBWSxLQUFLLGdCQUFnQixLQUFLO0FBQUEsTUFDdEMsY0FBYyxLQUFLLGtCQUFrQjtBQUFBLElBQ3ZDLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxvQkFBb0I7QUFDbEIsUUFBSSxLQUFLLE9BQU8sTUFBTSxVQUFVLE1BQU07QUFDcEMsWUFBTSxLQUFLLFdBQVc7QUFBQSxJQUN4QjtBQUNBLFdBQU8sS0FBSyxVQUFVO0FBQUEsRUFDeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBb0JBLGtCQUFrQixTQUFTO0FBQ3pCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsWUFBUSxNQUFNLE1BQU07QUFBQSxNQUNsQixLQUFLLFVBQVU7QUFDYixlQUFPLEtBQUssVUFBVSxPQUFPO0FBQUEsTUFDL0IsS0FBSyxVQUFVO0FBQ2IsZUFBTyxLQUFLLFlBQVksT0FBTztBQUFBLE1BQ2pDLEtBQUssVUFBVTtBQUNiLGFBQUssYUFBYTtBQUNsQixlQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsVUFDdEIsTUFBTSxLQUFLO0FBQUEsVUFDWCxPQUFPLE1BQU07QUFBQSxRQUNmLENBQUM7QUFBQSxNQUNILEtBQUssVUFBVTtBQUNiLGFBQUssYUFBYTtBQUNsQixlQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsVUFDdEIsTUFBTSxLQUFLO0FBQUEsVUFDWCxPQUFPLE1BQU07QUFBQSxRQUNmLENBQUM7QUFBQSxNQUNILEtBQUssVUFBVTtBQUFBLE1BQ2YsS0FBSyxVQUFVO0FBQ2IsZUFBTyxLQUFLLG1CQUFtQjtBQUFBLE1BQ2pDLEtBQUssVUFBVTtBQUNiLGFBQUssYUFBYTtBQUNsQixnQkFBUSxNQUFNLE9BQU87QUFBQSxVQUNuQixLQUFLO0FBQ0gsbUJBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxjQUN0QixNQUFNLEtBQUs7QUFBQSxjQUNYLE9BQU87QUFBQSxZQUNULENBQUM7QUFBQSxVQUNILEtBQUs7QUFDSCxtQkFBTyxLQUFLLEtBQUssT0FBTztBQUFBLGNBQ3RCLE1BQU0sS0FBSztBQUFBLGNBQ1gsT0FBTztBQUFBLFlBQ1QsQ0FBQztBQUFBLFVBQ0gsS0FBSztBQUNILG1CQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsY0FDdEIsTUFBTSxLQUFLO0FBQUEsWUFDYixDQUFDO0FBQUEsVUFDSDtBQUNFLG1CQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsY0FDdEIsTUFBTSxLQUFLO0FBQUEsY0FDWCxPQUFPLE1BQU07QUFBQSxZQUNmLENBQUM7QUFBQSxRQUNMO0FBQUEsTUFDRixLQUFLLFVBQVU7QUFDYixZQUFJLFNBQVM7QUFDWCxlQUFLLFlBQVksVUFBVSxNQUFNO0FBQ2pDLGNBQUksS0FBSyxPQUFPLE1BQU0sU0FBUyxVQUFVLE1BQU07QUFDN0Msa0JBQU0sVUFBVSxLQUFLLE9BQU8sTUFBTTtBQUNsQyxrQkFBTTtBQUFBLGNBQ0osS0FBSyxPQUFPO0FBQUEsY0FDWixNQUFNO0FBQUEsY0FDTix5QkFBeUIsT0FBTztBQUFBLFlBQ2xDO0FBQUEsVUFDRixPQUFPO0FBQ0wsa0JBQU0sS0FBSyxXQUFXLEtBQUs7QUFBQSxVQUM3QjtBQUFBLFFBQ0Y7QUFDQSxlQUFPLEtBQUssY0FBYztBQUFBLE1BQzVCO0FBQ0UsY0FBTSxLQUFLLFdBQVc7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLHlCQUF5QjtBQUN2QixXQUFPLEtBQUssa0JBQWtCLElBQUk7QUFBQSxFQUNwQztBQUFBLEVBQ0EscUJBQXFCO0FBQ25CLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsU0FBSyxhQUFhO0FBQ2xCLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYLE9BQU8sTUFBTTtBQUFBLE1BQ2IsT0FBTyxNQUFNLFNBQVMsVUFBVTtBQUFBLElBQ2xDLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsVUFBVSxTQUFTO0FBQ2pCLFVBQU0sT0FBTyxNQUFNLEtBQUssa0JBQWtCLE9BQU87QUFDakQsV0FBTyxLQUFLLEtBQUssS0FBSyxPQUFPLE9BQU87QUFBQSxNQUNsQyxNQUFNLEtBQUs7QUFBQSxNQUNYLFFBQVEsS0FBSyxJQUFJLFVBQVUsV0FBVyxNQUFNLFVBQVUsU0FBUztBQUFBLElBQ2pFLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBLFlBQVksU0FBUztBQUNuQixVQUFNLE9BQU8sTUFBTSxLQUFLLGlCQUFpQixPQUFPO0FBQ2hELFdBQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxPQUFPO0FBQUEsTUFDbEMsTUFBTSxLQUFLO0FBQUEsTUFDWCxRQUFRLEtBQUssSUFBSSxVQUFVLFNBQVMsTUFBTSxVQUFVLE9BQU87QUFBQSxJQUM3RCxDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsaUJBQWlCLFNBQVM7QUFDeEIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFNBQUssWUFBWSxVQUFVLEtBQUs7QUFDaEMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBLE9BQU8sS0FBSyxrQkFBa0IsT0FBTztBQUFBLElBQ3ZDLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLGdCQUFnQixTQUFTO0FBQ3ZCLFVBQU0sYUFBYSxDQUFDO0FBQ3BCLFdBQU8sS0FBSyxLQUFLLFVBQVUsRUFBRSxHQUFHO0FBQzlCLGlCQUFXLEtBQUssS0FBSyxlQUFlLE9BQU8sQ0FBQztBQUFBLElBQzlDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLHVCQUF1QjtBQUNyQixXQUFPLEtBQUssZ0JBQWdCLElBQUk7QUFBQSxFQUNsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLGVBQWUsU0FBUztBQUN0QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFNBQUssWUFBWSxVQUFVLEVBQUU7QUFDN0IsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1gsTUFBTSxLQUFLLFVBQVU7QUFBQSxNQUNyQixXQUFXLEtBQUssZUFBZSxPQUFPO0FBQUEsSUFDeEMsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEscUJBQXFCO0FBQ25CLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsUUFBSTtBQUNKLFFBQUksS0FBSyxvQkFBb0IsVUFBVSxTQUFTLEdBQUc7QUFDakQsWUFBTSxZQUFZLEtBQUssbUJBQW1CO0FBQzFDLFdBQUssWUFBWSxVQUFVLFNBQVM7QUFDcEMsYUFBTyxLQUFLLEtBQUssT0FBTztBQUFBLFFBQ3RCLE1BQU0sS0FBSztBQUFBLFFBQ1gsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLGFBQU8sS0FBSyxlQUFlO0FBQUEsSUFDN0I7QUFDQSxRQUFJLEtBQUssb0JBQW9CLFVBQVUsSUFBSSxHQUFHO0FBQzVDLGFBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxRQUN0QixNQUFNLEtBQUs7QUFBQSxRQUNYO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxpQkFBaUI7QUFDZixXQUFPLEtBQUssS0FBSyxLQUFLLE9BQU8sT0FBTztBQUFBLE1BQ2xDLE1BQU0sS0FBSztBQUFBLE1BQ1gsTUFBTSxLQUFLLFVBQVU7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUEsRUFFQSxrQkFBa0I7QUFDaEIsV0FBTyxLQUFLLEtBQUssVUFBVSxNQUFNLEtBQUssS0FBSyxLQUFLLFVBQVUsWUFBWTtBQUFBLEVBQ3hFO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxtQkFBbUI7QUFDakIsUUFBSSxLQUFLLGdCQUFnQixHQUFHO0FBQzFCLGFBQU8sS0FBSyxtQkFBbUI7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSx3QkFBd0I7QUFDdEIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxpQkFBaUI7QUFDMUMsU0FBSyxjQUFjLFFBQVE7QUFDM0IsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFVBQU0saUJBQWlCLEtBQUs7QUFBQSxNQUMxQixVQUFVO0FBQUEsTUFDVixLQUFLO0FBQUEsTUFDTCxVQUFVO0FBQUEsSUFDWjtBQUNBLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSwrQkFBK0I7QUFDN0IsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLFlBQVksS0FBSyxtQkFBbUI7QUFDMUMsU0FBSyxZQUFZLFVBQVUsS0FBSztBQUNoQyxVQUFNLE9BQU8sS0FBSyxlQUFlO0FBQ2pDLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLDRCQUE0QjtBQUMxQixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxTQUFLLGNBQWMsUUFBUTtBQUMzQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLDRCQUE0QjtBQUMxQixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxTQUFLLGNBQWMsTUFBTTtBQUN6QixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLDBCQUEwQjtBQUNsRCxVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsVUFBTSxTQUFTLEtBQUssc0JBQXNCO0FBQzFDLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSw0QkFBNEI7QUFDMUIsV0FBTyxLQUFLLHNCQUFzQixZQUFZLElBQUksS0FBSyxjQUFjLFVBQVUsS0FBSyxLQUFLLGNBQWMsSUFBSSxDQUFDO0FBQUEsRUFDOUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSx3QkFBd0I7QUFDdEIsV0FBTyxLQUFLO0FBQUEsTUFDVixVQUFVO0FBQUEsTUFDVixLQUFLO0FBQUEsTUFDTCxVQUFVO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsdUJBQXVCO0FBQ3JCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsVUFBTSxjQUFjLEtBQUssaUJBQWlCO0FBQzFDLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxPQUFPLEtBQUssa0JBQWtCO0FBQ3BDLFNBQUssWUFBWSxVQUFVLEtBQUs7QUFDaEMsVUFBTSxPQUFPLEtBQUssbUJBQW1CO0FBQ3JDLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVc7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBLG9CQUFvQjtBQUNsQixXQUFPLEtBQUs7QUFBQSxNQUNWLFVBQVU7QUFBQSxNQUNWLEtBQUs7QUFBQSxNQUNMLFVBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxxQkFBcUI7QUFDbkIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxpQkFBaUI7QUFDMUMsVUFBTSxPQUFPLEtBQUssVUFBVTtBQUM1QixTQUFLLFlBQVksVUFBVSxLQUFLO0FBQ2hDLFVBQU0sT0FBTyxLQUFLLG1CQUFtQjtBQUNyQyxRQUFJO0FBQ0osUUFBSSxLQUFLLG9CQUFvQixVQUFVLE1BQU0sR0FBRztBQUM5QyxxQkFBZSxLQUFLLHVCQUF1QjtBQUFBLElBQzdDO0FBQ0EsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsK0JBQStCO0FBQzdCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsVUFBTSxjQUFjLEtBQUssaUJBQWlCO0FBQzFDLFNBQUssY0FBYyxXQUFXO0FBQzlCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxhQUFhLEtBQUssMEJBQTBCO0FBQ2xELFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFNBQVMsS0FBSyxzQkFBc0I7QUFDMUMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSwyQkFBMkI7QUFDekIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxpQkFBaUI7QUFDMUMsU0FBSyxjQUFjLE9BQU87QUFDMUIsVUFBTSxPQUFPLEtBQUssVUFBVTtBQUM1QixVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsVUFBTSxRQUFRLEtBQUssc0JBQXNCO0FBQ3pDLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLHdCQUF3QjtBQUN0QixXQUFPLEtBQUssb0JBQW9CLFVBQVUsTUFBTSxJQUFJLEtBQUssY0FBYyxVQUFVLE1BQU0sS0FBSyxjQUFjLElBQUksQ0FBQztBQUFBLEVBQ2pIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLDBCQUEwQjtBQUN4QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxTQUFLLGNBQWMsTUFBTTtBQUN6QixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFNBQVMsS0FBSywwQkFBMEI7QUFDOUMsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsNEJBQTRCO0FBQzFCLFdBQU8sS0FBSztBQUFBLE1BQ1YsVUFBVTtBQUFBLE1BQ1YsS0FBSztBQUFBLE1BQ0wsVUFBVTtBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSwyQkFBMkI7QUFDekIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxpQkFBaUI7QUFDMUMsVUFBTSxPQUFPLEtBQUssbUJBQW1CO0FBQ3JDLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEscUJBQXFCO0FBQ25CLFFBQUksS0FBSyxPQUFPLE1BQU0sVUFBVSxVQUFVLEtBQUssT0FBTyxNQUFNLFVBQVUsV0FBVyxLQUFLLE9BQU8sTUFBTSxVQUFVLFFBQVE7QUFDbkgsWUFBTTtBQUFBLFFBQ0osS0FBSyxPQUFPO0FBQUEsUUFDWixLQUFLLE9BQU8sTUFBTTtBQUFBLFFBQ2xCLEdBQUc7QUFBQSxVQUNELEtBQUssT0FBTztBQUFBLFFBQ2QsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQ0EsV0FBTyxLQUFLLFVBQVU7QUFBQSxFQUN4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxpQ0FBaUM7QUFDL0IsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLGNBQWMsS0FBSyxpQkFBaUI7QUFDMUMsU0FBSyxjQUFjLE9BQU87QUFDMUIsVUFBTSxPQUFPLEtBQUssVUFBVTtBQUM1QixVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsVUFBTSxTQUFTLEtBQUssMkJBQTJCO0FBQy9DLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLDZCQUE2QjtBQUMzQixXQUFPLEtBQUs7QUFBQSxNQUNWLFVBQVU7QUFBQSxNQUNWLEtBQUs7QUFBQSxNQUNMLFVBQVU7QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjQSwyQkFBMkI7QUFDekIsVUFBTSxlQUFlLEtBQUssT0FBTyxVQUFVO0FBQzNDLFFBQUksYUFBYSxTQUFTLFVBQVUsTUFBTTtBQUN4QyxjQUFRLGFBQWEsT0FBTztBQUFBLFFBQzFCLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHFCQUFxQjtBQUFBLFFBQ25DLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHlCQUF5QjtBQUFBLFFBQ3ZDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHlCQUF5QjtBQUFBLFFBQ3ZDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLDRCQUE0QjtBQUFBLFFBQzFDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHdCQUF3QjtBQUFBLFFBQ3RDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLHVCQUF1QjtBQUFBLFFBQ3JDLEtBQUs7QUFDSCxpQkFBTyxLQUFLLDhCQUE4QjtBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxXQUFXLFlBQVk7QUFBQSxFQUNwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSx1QkFBdUI7QUFDckIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGNBQWMsUUFBUTtBQUMzQixTQUFLLGNBQWMsUUFBUTtBQUMzQixVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsVUFBTSxpQkFBaUIsS0FBSztBQUFBLE1BQzFCLFVBQVU7QUFBQSxNQUNWLEtBQUs7QUFBQSxNQUNMLFVBQVU7QUFBQSxJQUNaO0FBQ0EsUUFBSSxXQUFXLFdBQVcsS0FBSyxlQUFlLFdBQVcsR0FBRztBQUMxRCxZQUFNLEtBQUssV0FBVztBQUFBLElBQ3hCO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSwyQkFBMkI7QUFDekIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGNBQWMsUUFBUTtBQUMzQixTQUFLLGNBQWMsUUFBUTtBQUMzQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxRQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzNCLFlBQU0sS0FBSyxXQUFXO0FBQUEsSUFDeEI7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSwyQkFBMkI7QUFDekIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGNBQWMsUUFBUTtBQUMzQixTQUFLLGNBQWMsTUFBTTtBQUN6QixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLDBCQUEwQjtBQUNsRCxVQUFNLGFBQWEsS0FBSyxxQkFBcUI7QUFDN0MsVUFBTSxTQUFTLEtBQUssc0JBQXNCO0FBQzFDLFFBQUksV0FBVyxXQUFXLEtBQUssV0FBVyxXQUFXLEtBQUssT0FBTyxXQUFXLEdBQUc7QUFDN0UsWUFBTSxLQUFLLFdBQVc7QUFBQSxJQUN4QjtBQUNBLFdBQU8sS0FBSyxLQUFLLE9BQU87QUFBQSxNQUN0QixNQUFNLEtBQUs7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsOEJBQThCO0FBQzVCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsU0FBSyxjQUFjLFFBQVE7QUFDM0IsU0FBSyxjQUFjLFdBQVc7QUFDOUIsVUFBTSxPQUFPLEtBQUssVUFBVTtBQUM1QixVQUFNLGFBQWEsS0FBSywwQkFBMEI7QUFDbEQsVUFBTSxhQUFhLEtBQUsscUJBQXFCO0FBQzdDLFVBQU0sU0FBUyxLQUFLLHNCQUFzQjtBQUMxQyxRQUFJLFdBQVcsV0FBVyxLQUFLLFdBQVcsV0FBVyxLQUFLLE9BQU8sV0FBVyxHQUFHO0FBQzdFLFlBQU0sS0FBSyxXQUFXO0FBQUEsSUFDeEI7QUFDQSxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSwwQkFBMEI7QUFDeEIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGNBQWMsUUFBUTtBQUMzQixTQUFLLGNBQWMsT0FBTztBQUMxQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFFBQVEsS0FBSyxzQkFBc0I7QUFDekMsUUFBSSxXQUFXLFdBQVcsS0FBSyxNQUFNLFdBQVcsR0FBRztBQUNqRCxZQUFNLEtBQUssV0FBVztBQUFBLElBQ3hCO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSx5QkFBeUI7QUFDdkIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGNBQWMsUUFBUTtBQUMzQixTQUFLLGNBQWMsTUFBTTtBQUN6QixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFNBQVMsS0FBSywwQkFBMEI7QUFDOUMsUUFBSSxXQUFXLFdBQVcsS0FBSyxPQUFPLFdBQVcsR0FBRztBQUNsRCxZQUFNLEtBQUssV0FBVztBQUFBLElBQ3hCO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxnQ0FBZ0M7QUFDOUIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixTQUFLLGNBQWMsUUFBUTtBQUMzQixTQUFLLGNBQWMsT0FBTztBQUMxQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFVBQU0sYUFBYSxLQUFLLHFCQUFxQjtBQUM3QyxVQUFNLFNBQVMsS0FBSywyQkFBMkI7QUFDL0MsUUFBSSxXQUFXLFdBQVcsS0FBSyxPQUFPLFdBQVcsR0FBRztBQUNsRCxZQUFNLEtBQUssV0FBVztBQUFBLElBQ3hCO0FBQ0EsV0FBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQ3RCLE1BQU0sS0FBSztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLDJCQUEyQjtBQUN6QixVQUFNLFFBQVEsS0FBSyxPQUFPO0FBQzFCLFVBQU0sY0FBYyxLQUFLLGlCQUFpQjtBQUMxQyxTQUFLLGNBQWMsV0FBVztBQUM5QixTQUFLLFlBQVksVUFBVSxFQUFFO0FBQzdCLFVBQU0sT0FBTyxLQUFLLFVBQVU7QUFDNUIsVUFBTSxPQUFPLEtBQUssa0JBQWtCO0FBQ3BDLFVBQU0sYUFBYSxLQUFLLHNCQUFzQixZQUFZO0FBQzFELFNBQUssY0FBYyxJQUFJO0FBQ3ZCLFVBQU0sWUFBWSxLQUFLLHdCQUF3QjtBQUMvQyxXQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDdEIsTUFBTSxLQUFLO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVc7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSwwQkFBMEI7QUFDeEIsV0FBTyxLQUFLLGNBQWMsVUFBVSxNQUFNLEtBQUssc0JBQXNCO0FBQUEsRUFDdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTRCQSx5QkFBeUI7QUFDdkIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixVQUFNLE9BQU8sS0FBSyxVQUFVO0FBQzVCLFFBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxtQkFBbUIsS0FBSyxLQUFLLEdBQUc7QUFDdkUsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLEtBQUssV0FBVyxLQUFLO0FBQUEsRUFDN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLEtBQUssWUFBWSxNQUFNO0FBQ3JCLFFBQUksS0FBSyxTQUFTLGVBQWUsTUFBTTtBQUNyQyxXQUFLLE1BQU0sSUFBSTtBQUFBLFFBQ2I7QUFBQSxRQUNBLEtBQUssT0FBTztBQUFBLFFBQ1osS0FBSyxPQUFPO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsS0FBSyxNQUFNO0FBQ1QsV0FBTyxLQUFLLE9BQU8sTUFBTSxTQUFTO0FBQUEsRUFDcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0EsWUFBWSxNQUFNO0FBQ2hCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsUUFBSSxNQUFNLFNBQVMsTUFBTTtBQUN2QixXQUFLLGFBQWE7QUFDbEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNO0FBQUEsTUFDSixLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU07QUFBQSxNQUNOLFlBQVksaUJBQWlCLElBQUksQ0FBQyxXQUFXLGFBQWEsS0FBSyxDQUFDO0FBQUEsSUFDbEU7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLG9CQUFvQixNQUFNO0FBQ3hCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsUUFBSSxNQUFNLFNBQVMsTUFBTTtBQUN2QixXQUFLLGFBQWE7QUFDbEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxjQUFjLE9BQU87QUFDbkIsVUFBTSxRQUFRLEtBQUssT0FBTztBQUMxQixRQUFJLE1BQU0sU0FBUyxVQUFVLFFBQVEsTUFBTSxVQUFVLE9BQU87QUFDMUQsV0FBSyxhQUFhO0FBQUEsSUFDcEIsT0FBTztBQUNMLFlBQU07QUFBQSxRQUNKLEtBQUssT0FBTztBQUFBLFFBQ1osTUFBTTtBQUFBLFFBQ04sYUFBYSxLQUFLLFlBQVksYUFBYSxLQUFLLENBQUM7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLHNCQUFzQixPQUFPO0FBQzNCLFVBQU0sUUFBUSxLQUFLLE9BQU87QUFDMUIsUUFBSSxNQUFNLFNBQVMsVUFBVSxRQUFRLE1BQU0sVUFBVSxPQUFPO0FBQzFELFdBQUssYUFBYTtBQUNsQixhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxXQUFXLFNBQVM7QUFDbEIsVUFBTSxRQUFRLFlBQVksUUFBUSxZQUFZLFNBQVMsVUFBVSxLQUFLLE9BQU87QUFDN0UsV0FBTztBQUFBLE1BQ0wsS0FBSyxPQUFPO0FBQUEsTUFDWixNQUFNO0FBQUEsTUFDTixjQUFjLGFBQWEsS0FBSyxDQUFDO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsSUFBSSxVQUFVLFNBQVMsV0FBVztBQUNoQyxTQUFLLFlBQVksUUFBUTtBQUN6QixVQUFNLFFBQVEsQ0FBQztBQUNmLFdBQU8sQ0FBQyxLQUFLLG9CQUFvQixTQUFTLEdBQUc7QUFDM0MsWUFBTSxLQUFLLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxJQUMvQjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxhQUFhLFVBQVUsU0FBUyxXQUFXO0FBQ3pDLFFBQUksS0FBSyxvQkFBb0IsUUFBUSxHQUFHO0FBQ3RDLFlBQU0sUUFBUSxDQUFDO0FBQ2YsU0FBRztBQUNELGNBQU0sS0FBSyxRQUFRLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDL0IsU0FBUyxDQUFDLEtBQUssb0JBQW9CLFNBQVM7QUFDNUMsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLENBQUM7QUFBQSxFQUNWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsS0FBSyxVQUFVLFNBQVMsV0FBVztBQUNqQyxTQUFLLFlBQVksUUFBUTtBQUN6QixVQUFNLFFBQVEsQ0FBQztBQUNmLE9BQUc7QUFDRCxZQUFNLEtBQUssUUFBUSxLQUFLLElBQUksQ0FBQztBQUFBLElBQy9CLFNBQVMsQ0FBQyxLQUFLLG9CQUFvQixTQUFTO0FBQzVDLFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsY0FBYyxlQUFlLFNBQVM7QUFDcEMsU0FBSyxvQkFBb0IsYUFBYTtBQUN0QyxVQUFNLFFBQVEsQ0FBQztBQUNmLE9BQUc7QUFDRCxZQUFNLEtBQUssUUFBUSxLQUFLLElBQUksQ0FBQztBQUFBLElBQy9CLFNBQVMsS0FBSyxvQkFBb0IsYUFBYTtBQUMvQyxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsZUFBZTtBQUNiLFVBQU0sRUFBRSxVQUFVLElBQUksS0FBSztBQUMzQixVQUFNLFFBQVEsS0FBSyxPQUFPLFFBQVE7QUFDbEMsUUFBSSxjQUFjLFVBQVUsTUFBTSxTQUFTLFVBQVUsS0FBSztBQUN4RCxRQUFFLEtBQUs7QUFDUCxVQUFJLEtBQUssZ0JBQWdCLFdBQVc7QUFDbEMsY0FBTTtBQUFBLFVBQ0osS0FBSyxPQUFPO0FBQUEsVUFDWixNQUFNO0FBQUEsVUFDTiwrQkFBK0IsU0FBUztBQUFBLFFBQzFDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsT0FBTztBQUMzQixRQUFNLFFBQVEsTUFBTTtBQUNwQixTQUFPLGlCQUFpQixNQUFNLElBQUksS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLE1BQU07QUFDekU7QUFDQSxTQUFTLGlCQUFpQixNQUFNO0FBQzlCLFNBQU8sc0JBQXNCLElBQUksSUFBSSxJQUFJLElBQUksTUFBTTtBQUNyRDtBQUdBLElBQUksa0JBQWtCO0FBQ3RCLFNBQVMsV0FBVyxVQUFVLFdBQVc7QUFDdkMsUUFBTSxDQUFDLFlBQVksY0FBYyxJQUFJLFlBQVksQ0FBQyxVQUFVLFNBQVMsSUFBSSxDQUFDLFFBQVEsUUFBUTtBQUMxRixNQUFJLFdBQVc7QUFDZixNQUFJLFlBQVk7QUFDZCxnQkFBWSxhQUFhO0FBQUEsRUFDM0I7QUFDQSxRQUFNLGNBQWMsZUFBZSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRztBQUN0RCxVQUFRLFlBQVksUUFBUTtBQUFBLElBQzFCLEtBQUs7QUFDSCxhQUFPO0FBQUEsSUFDVCxLQUFLO0FBQ0gsYUFBTyxXQUFXLFlBQVksQ0FBQyxJQUFJO0FBQUEsSUFDckMsS0FBSztBQUNILGFBQU8sV0FBVyxZQUFZLENBQUMsSUFBSSxTQUFTLFlBQVksQ0FBQyxJQUFJO0FBQUEsRUFDakU7QUFDQSxRQUFNLFdBQVcsWUFBWSxNQUFNLEdBQUcsZUFBZTtBQUNyRCxRQUFNLFdBQVcsU0FBUyxJQUFJO0FBQzlCLFNBQU8sV0FBVyxTQUFTLEtBQUssSUFBSSxJQUFJLFVBQVUsV0FBVztBQUMvRDtBQUdBLFNBQVMsYUFBYSxHQUFHO0FBQ3ZCLFNBQU87QUFDVDtBQUdBLFNBQVMsT0FBTyxNQUFNLE9BQU87QUFDM0IsUUFBTSxTQUF5Qix1QkFBTyxPQUFPLElBQUk7QUFDakQsYUFBVyxRQUFRLE1BQU07QUFDdkIsV0FBTyxNQUFNLElBQUksQ0FBQyxJQUFJO0FBQUEsRUFDeEI7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLFVBQVUsTUFBTSxPQUFPLE9BQU87QUFDckMsUUFBTSxTQUF5Qix1QkFBTyxPQUFPLElBQUk7QUFDakQsYUFBVyxRQUFRLE1BQU07QUFDdkIsV0FBTyxNQUFNLElBQUksQ0FBQyxJQUFJLE1BQU0sSUFBSTtBQUFBLEVBQ2xDO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxTQUFTLEtBQUssSUFBSTtBQUN6QixRQUFNLFNBQXlCLHVCQUFPLE9BQU8sSUFBSTtBQUNqRCxhQUFXLE9BQU8sT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNsQyxXQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUc7QUFBQSxFQUNoQztBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsZUFBZSxNQUFNLE1BQU07QUFDbEMsTUFBSSxTQUFTO0FBQ2IsTUFBSSxTQUFTO0FBQ2IsU0FBTyxTQUFTLEtBQUssVUFBVSxTQUFTLEtBQUssUUFBUTtBQUNuRCxRQUFJLFFBQVEsS0FBSyxXQUFXLE1BQU07QUFDbEMsUUFBSSxRQUFRLEtBQUssV0FBVyxNQUFNO0FBQ2xDLFFBQUksU0FBUyxLQUFLLEtBQUssU0FBUyxLQUFLLEdBQUc7QUFDdEMsVUFBSSxPQUFPO0FBQ1gsU0FBRztBQUNELFVBQUU7QUFDRixlQUFPLE9BQU8sS0FBSyxRQUFRO0FBQzNCLGdCQUFRLEtBQUssV0FBVyxNQUFNO0FBQUEsTUFDaEMsU0FBUyxTQUFTLEtBQUssS0FBSyxPQUFPO0FBQ25DLFVBQUksT0FBTztBQUNYLFNBQUc7QUFDRCxVQUFFO0FBQ0YsZUFBTyxPQUFPLEtBQUssUUFBUTtBQUMzQixnQkFBUSxLQUFLLFdBQVcsTUFBTTtBQUFBLE1BQ2hDLFNBQVMsU0FBUyxLQUFLLEtBQUssT0FBTztBQUNuQyxVQUFJLE9BQU8sTUFBTTtBQUNmLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxPQUFPLE1BQU07QUFDZixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0YsT0FBTztBQUNMLFVBQUksUUFBUSxPQUFPO0FBQ2pCLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLE9BQU87QUFDakIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxRQUFFO0FBQ0YsUUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBQ0EsU0FBTyxLQUFLLFNBQVMsS0FBSztBQUM1QjtBQUNBLElBQUksVUFBVTtBQUNkLElBQUksVUFBVTtBQUNkLFNBQVMsU0FBUyxNQUFNO0FBQ3RCLFNBQU8sQ0FBQyxNQUFNLElBQUksS0FBSyxXQUFXLFFBQVEsUUFBUTtBQUNwRDtBQUdBLFNBQVMsZUFBZSxPQUFPLFNBQVM7QUFDdEMsUUFBTSxvQkFBb0MsdUJBQU8sT0FBTyxJQUFJO0FBQzVELFFBQU0sa0JBQWtCLElBQUksZ0JBQWdCLEtBQUs7QUFDakQsUUFBTSxZQUFZLEtBQUssTUFBTSxNQUFNLFNBQVMsR0FBRyxJQUFJO0FBQ25ELGFBQVcsVUFBVSxTQUFTO0FBQzVCLFVBQU0sV0FBVyxnQkFBZ0IsUUFBUSxRQUFRLFNBQVM7QUFDMUQsUUFBSSxhQUFhLFFBQVE7QUFDdkIsd0JBQWtCLE1BQU0sSUFBSTtBQUFBLElBQzlCO0FBQUEsRUFDRjtBQUNBLFNBQU8sT0FBTyxLQUFLLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU07QUFDbkQsVUFBTSxlQUFlLGtCQUFrQixDQUFDLElBQUksa0JBQWtCLENBQUM7QUFDL0QsV0FBTyxpQkFBaUIsSUFBSSxlQUFlLGVBQWUsR0FBRyxDQUFDO0FBQUEsRUFDaEUsQ0FBQztBQUNIO0FBQ0EsSUFBSSxrQkFBa0IsTUFBTTtBQUFBLEVBQzFCLFlBQVksT0FBTztBQUNqQixTQUFLLFNBQVM7QUFDZCxTQUFLLGtCQUFrQixNQUFNLFlBQVk7QUFDekMsU0FBSyxjQUFjLGNBQWMsS0FBSyxlQUFlO0FBQ3JELFNBQUssUUFBUTtBQUFBLE1BQ1gsSUFBSSxNQUFNLE1BQU0sU0FBUyxDQUFDLEVBQUUsS0FBSyxDQUFDO0FBQUEsTUFDbEMsSUFBSSxNQUFNLE1BQU0sU0FBUyxDQUFDLEVBQUUsS0FBSyxDQUFDO0FBQUEsTUFDbEMsSUFBSSxNQUFNLE1BQU0sU0FBUyxDQUFDLEVBQUUsS0FBSyxDQUFDO0FBQUEsSUFDcEM7QUFBQSxFQUNGO0FBQUEsRUFDQSxRQUFRLFFBQVEsV0FBVztBQUN6QixRQUFJLEtBQUssV0FBVyxRQUFRO0FBQzFCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSxrQkFBa0IsT0FBTyxZQUFZO0FBQzNDLFFBQUksS0FBSyxvQkFBb0IsaUJBQWlCO0FBQzVDLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxJQUFJLGNBQWMsZUFBZTtBQUNyQyxRQUFJLElBQUksS0FBSztBQUNiLFFBQUksRUFBRSxTQUFTLEVBQUUsUUFBUTtBQUN2QixZQUFNLE1BQU07QUFDWixVQUFJO0FBQ0osVUFBSTtBQUFBLElBQ047QUFDQSxVQUFNLFVBQVUsRUFBRTtBQUNsQixVQUFNLFVBQVUsRUFBRTtBQUNsQixRQUFJLFVBQVUsVUFBVSxXQUFXO0FBQ2pDLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSxPQUFPLEtBQUs7QUFDbEIsYUFBUyxJQUFJLEdBQUcsS0FBSyxTQUFTLEtBQUs7QUFDakMsV0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJO0FBQUEsSUFDZjtBQUNBLGFBQVMsSUFBSSxHQUFHLEtBQUssU0FBUyxLQUFLO0FBQ2pDLFlBQU0sUUFBUSxNQUFNLElBQUksS0FBSyxDQUFDO0FBQzlCLFlBQU0sYUFBYSxLQUFLLElBQUksQ0FBQztBQUM3QixVQUFJLGVBQWUsV0FBVyxDQUFDLElBQUk7QUFDbkMsZUFBUyxJQUFJLEdBQUcsS0FBSyxTQUFTLEtBQUs7QUFDakMsY0FBTSxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJO0FBQ3pDLFlBQUksY0FBYyxLQUFLO0FBQUEsVUFDckIsTUFBTSxDQUFDLElBQUk7QUFBQTtBQUFBLFVBRVgsV0FBVyxJQUFJLENBQUMsSUFBSTtBQUFBO0FBQUEsVUFFcEIsTUFBTSxJQUFJLENBQUMsSUFBSTtBQUFBO0FBQUEsUUFFakI7QUFDQSxZQUFJLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsR0FBRztBQUNwRSxnQkFBTSxxQkFBcUIsTUFBTSxJQUFJLEtBQUssQ0FBQyxFQUFFLElBQUksQ0FBQztBQUNsRCx3QkFBYyxLQUFLLElBQUksYUFBYSxxQkFBcUIsQ0FBQztBQUFBLFFBQzVEO0FBQ0EsWUFBSSxjQUFjLGNBQWM7QUFDOUIseUJBQWU7QUFBQSxRQUNqQjtBQUNBLG1CQUFXLENBQUMsSUFBSTtBQUFBLE1BQ2xCO0FBQ0EsVUFBSSxlQUFlLFdBQVc7QUFDNUIsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsVUFBTSxXQUFXLEtBQUssVUFBVSxDQUFDLEVBQUUsT0FBTztBQUMxQyxXQUFPLFlBQVksWUFBWSxXQUFXO0FBQUEsRUFDNUM7QUFDRjtBQUNBLFNBQVMsY0FBYyxLQUFLO0FBQzFCLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFFBQU0sUUFBUSxJQUFJLE1BQU0sU0FBUztBQUNqQyxXQUFTLElBQUksR0FBRyxJQUFJLFdBQVcsRUFBRSxHQUFHO0FBQ2xDLFVBQU0sQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQUEsRUFDN0I7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLFNBQVMsS0FBSztBQUNyQixNQUFJLE9BQU8sTUFBTTtBQUNmLFdBQXVCLHVCQUFPLE9BQU8sSUFBSTtBQUFBLEVBQzNDO0FBQ0EsTUFBSSxPQUFPLGVBQWUsR0FBRyxNQUFNLE1BQU07QUFDdkMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE1BQXNCLHVCQUFPLE9BQU8sSUFBSTtBQUM5QyxhQUFXLENBQUMsS0FBSyxLQUFLLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUM5QyxRQUFJLEdBQUcsSUFBSTtBQUFBLEVBQ2I7QUFDQSxTQUFPO0FBQ1Q7QUFHQSxTQUFTLFlBQVksS0FBSztBQUN4QixTQUFPLElBQUksSUFBSSxRQUFRLGVBQWUsZUFBZSxDQUFDO0FBQ3hEO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEIsU0FBUyxnQkFBZ0IsS0FBSztBQUM1QixTQUFPLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxDQUFDO0FBQzFDO0FBQ0EsSUFBSSxrQkFBa0I7QUFBQSxFQUNwQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUVBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUVBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUVBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUVBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQSxFQUVBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRjtBQUdBLElBQUksUUFBUSxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQzVCLFNBQVMsTUFBTSxNQUFNLFNBQVMsY0FBYyxtQkFBbUI7QUFDN0QsUUFBTSxnQkFBZ0Msb0JBQUksSUFBSTtBQUM5QyxhQUFXLFFBQVEsT0FBTyxPQUFPLElBQUksR0FBRztBQUN0QyxrQkFBYyxJQUFJLE1BQU0scUJBQXFCLFNBQVMsSUFBSSxDQUFDO0FBQUEsRUFDN0Q7QUFDQSxNQUFJLFFBQVE7QUFDWixNQUFJLFVBQVUsTUFBTSxRQUFRLElBQUk7QUFDaEMsTUFBSSxPQUFPLENBQUMsSUFBSTtBQUNoQixNQUFJLFFBQVE7QUFDWixNQUFJLFFBQVEsQ0FBQztBQUNiLE1BQUksT0FBTztBQUNYLE1BQUksTUFBTTtBQUNWLE1BQUksU0FBUztBQUNiLFFBQU0sT0FBTyxDQUFDO0FBQ2QsUUFBTSxZQUFZLENBQUM7QUFDbkIsS0FBRztBQUNEO0FBQ0EsVUFBTSxZQUFZLFVBQVUsS0FBSztBQUNqQyxVQUFNLFdBQVcsYUFBYSxNQUFNLFdBQVc7QUFDL0MsUUFBSSxXQUFXO0FBQ2IsWUFBTSxVQUFVLFdBQVcsSUFBSSxTQUFTLEtBQUssS0FBSyxTQUFTLENBQUM7QUFDNUQsYUFBTztBQUNQLGVBQVMsVUFBVSxJQUFJO0FBQ3ZCLFVBQUksVUFBVTtBQUNaLFlBQUksU0FBUztBQUNYLGlCQUFPLEtBQUssTUFBTTtBQUNsQixjQUFJLGFBQWE7QUFDakIscUJBQVcsQ0FBQyxTQUFTLFNBQVMsS0FBSyxPQUFPO0FBQ3hDLGtCQUFNLFdBQVcsVUFBVTtBQUMzQixnQkFBSSxjQUFjLE1BQU07QUFDdEIsbUJBQUssT0FBTyxVQUFVLENBQUM7QUFDdkI7QUFBQSxZQUNGLE9BQU87QUFDTCxtQkFBSyxRQUFRLElBQUk7QUFBQSxZQUNuQjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLE9BQU87QUFDTCxpQkFBTyxPQUFPO0FBQUEsWUFDWixDQUFDO0FBQUEsWUFDRCxPQUFPLDBCQUEwQixJQUFJO0FBQUEsVUFDdkM7QUFDQSxxQkFBVyxDQUFDLFNBQVMsU0FBUyxLQUFLLE9BQU87QUFDeEMsaUJBQUssT0FBTyxJQUFJO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGNBQVEsTUFBTTtBQUNkLGFBQU8sTUFBTTtBQUNiLGNBQVEsTUFBTTtBQUNkLGdCQUFVLE1BQU07QUFDaEIsY0FBUSxNQUFNO0FBQUEsSUFDaEIsV0FBVyxRQUFRO0FBQ2pCLFlBQU0sVUFBVSxRQUFRLEtBQUssS0FBSztBQUNsQyxhQUFPLE9BQU8sR0FBRztBQUNqQixVQUFJLFNBQVMsUUFBUSxTQUFTLFFBQVE7QUFDcEM7QUFBQSxNQUNGO0FBQ0EsV0FBSyxLQUFLLEdBQUc7QUFBQSxJQUNmO0FBQ0EsUUFBSTtBQUNKLFFBQUksQ0FBQyxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3hCLFVBQUksb0JBQW9CO0FBQ3hCLGFBQU8sSUFBSSxLQUFLLFVBQVUsT0FBTyxxQkFBcUIsUUFBUSxJQUFJLENBQUMsR0FBRztBQUN0RSxZQUFNLFVBQVUsYUFBYSxxQkFBcUIsY0FBYyxJQUFJLEtBQUssSUFBSSxPQUFPLFFBQVEsdUJBQXVCLFNBQVMsU0FBUyxtQkFBbUIsU0FBUyxzQkFBc0IsY0FBYyxJQUFJLEtBQUssSUFBSSxPQUFPLFFBQVEsd0JBQXdCLFNBQVMsU0FBUyxvQkFBb0I7QUFDL1IsZUFBUyxZQUFZLFFBQVEsWUFBWSxTQUFTLFNBQVMsUUFBUSxLQUFLLFNBQVMsTUFBTSxLQUFLLFFBQVEsTUFBTSxTQUFTO0FBQ25ILFVBQUksV0FBVyxPQUFPO0FBQ3BCO0FBQUEsTUFDRjtBQUNBLFVBQUksV0FBVyxPQUFPO0FBQ3BCLFlBQUksQ0FBQyxXQUFXO0FBQ2QsZUFBSyxJQUFJO0FBQ1Q7QUFBQSxRQUNGO0FBQUEsTUFDRixXQUFXLFdBQVcsUUFBUTtBQUM1QixjQUFNLEtBQUssQ0FBQyxLQUFLLE1BQU0sQ0FBQztBQUN4QixZQUFJLENBQUMsV0FBVztBQUNkLGNBQUksT0FBTyxNQUFNLEdBQUc7QUFDbEIsbUJBQU87QUFBQSxVQUNULE9BQU87QUFDTCxpQkFBSyxJQUFJO0FBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxXQUFXLFVBQVUsVUFBVTtBQUNqQyxZQUFNLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztBQUFBLElBQ3hCO0FBQ0EsUUFBSSxXQUFXO0FBQ2IsV0FBSyxJQUFJO0FBQUEsSUFDWCxPQUFPO0FBQ0wsVUFBSTtBQUNKLGNBQVE7QUFBQSxRQUNOO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxNQUFNO0FBQUEsTUFDUjtBQUNBLGdCQUFVLE1BQU0sUUFBUSxJQUFJO0FBQzVCLGFBQU8sVUFBVSxRQUFRLGFBQWEsWUFBWSxLQUFLLElBQUksT0FBTyxRQUFRLGVBQWUsU0FBUyxhQUFhLENBQUM7QUFDaEgsY0FBUTtBQUNSLGNBQVEsQ0FBQztBQUNULFVBQUksUUFBUTtBQUNWLGtCQUFVLEtBQUssTUFBTTtBQUFBLE1BQ3ZCO0FBQ0EsZUFBUztBQUFBLElBQ1g7QUFBQSxFQUNGLFNBQVMsVUFBVTtBQUNuQixNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFdBQU8sTUFBTSxNQUFNLFNBQVMsQ0FBQyxFQUFFLENBQUM7QUFBQSxFQUNsQztBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMscUJBQXFCLFNBQVMsTUFBTTtBQUMzQyxRQUFNLGNBQWMsUUFBUSxJQUFJO0FBQ2hDLE1BQUksT0FBTyxnQkFBZ0IsVUFBVTtBQUNuQyxXQUFPO0FBQUEsRUFDVCxXQUFXLE9BQU8sZ0JBQWdCLFlBQVk7QUFDNUMsV0FBTztBQUFBLE1BQ0wsT0FBTztBQUFBLE1BQ1AsT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsT0FBTyxRQUFRO0FBQUEsSUFDZixPQUFPLFFBQVE7QUFBQSxFQUNqQjtBQUNGO0FBR0EsU0FBUyxNQUFNLEtBQUs7QUFDbEIsU0FBTyxNQUFNLEtBQUssa0JBQWtCO0FBQ3RDO0FBQ0EsSUFBSSxrQkFBa0I7QUFDdEIsSUFBSSxxQkFBcUI7QUFBQSxFQUN2QixNQUFNO0FBQUEsSUFDSixPQUFPLENBQUMsU0FBUyxLQUFLO0FBQUEsRUFDeEI7QUFBQSxFQUNBLFVBQVU7QUFBQSxJQUNSLE9BQU8sQ0FBQyxTQUFTLE1BQU0sS0FBSztBQUFBLEVBQzlCO0FBQUE7QUFBQSxFQUVBLFVBQVU7QUFBQSxJQUNSLE9BQU8sQ0FBQyxTQUFTLEtBQUssS0FBSyxhQUFhLE1BQU07QUFBQSxFQUNoRDtBQUFBLEVBQ0EscUJBQXFCO0FBQUEsSUFDbkIsTUFBTSxNQUFNO0FBQ1YsWUFBTSxVQUFVLEtBQUssS0FBSyxLQUFLLEtBQUsscUJBQXFCLElBQUksR0FBRyxHQUFHO0FBQ25FLFlBQU0sU0FBUztBQUFBLFFBQ2I7QUFBQSxVQUNFLEtBQUs7QUFBQSxVQUNMLEtBQUssQ0FBQyxLQUFLLE1BQU0sT0FBTyxDQUFDO0FBQUEsVUFDekIsS0FBSyxLQUFLLFlBQVksR0FBRztBQUFBLFFBQzNCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFDQSxjQUFRLFdBQVcsVUFBVSxLQUFLLFNBQVMsT0FBTyxLQUFLO0FBQUEsSUFDekQ7QUFBQSxFQUNGO0FBQUEsRUFDQSxvQkFBb0I7QUFBQSxJQUNsQixPQUFPLENBQUMsRUFBRSxVQUFVLE1BQU0sY0FBYyxXQUFXLE1BQU0sV0FBVyxPQUFPLE9BQU8sS0FBSyxPQUFPLFlBQVksSUFBSSxLQUFLLEtBQUssS0FBSyxZQUFZLEdBQUcsQ0FBQztBQUFBLEVBQy9JO0FBQUEsRUFDQSxjQUFjO0FBQUEsSUFDWixPQUFPLENBQUMsRUFBRSxXQUFXLE1BQU0sTUFBTSxVQUFVO0FBQUEsRUFDN0M7QUFBQSxFQUNBLE9BQU87QUFBQSxJQUNMLE1BQU0sRUFBRSxPQUFPLE1BQU0sV0FBVyxNQUFNLFlBQVksYUFBYSxHQUFHO0FBQ2hFLFlBQU0sU0FBUyxLQUFLLElBQUksT0FBTyxJQUFJLElBQUk7QUFDdkMsVUFBSSxXQUFXLFNBQVMsS0FBSyxLQUFLLEtBQUssTUFBTSxJQUFJLEdBQUcsR0FBRztBQUN2RCxVQUFJLFNBQVMsU0FBUyxpQkFBaUI7QUFDckMsbUJBQVcsU0FBUyxLQUFLLE9BQU8sT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLEdBQUcsS0FBSztBQUFBLE1BQ2pFO0FBQ0EsYUFBTyxLQUFLLENBQUMsVUFBVSxLQUFLLFlBQVksR0FBRyxHQUFHLFlBQVksR0FBRyxHQUFHO0FBQUEsSUFDbEU7QUFBQSxFQUNGO0FBQUEsRUFDQSxVQUFVO0FBQUEsSUFDUixPQUFPLENBQUMsRUFBRSxNQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU87QUFBQSxFQUM1QztBQUFBO0FBQUEsRUFFQSxnQkFBZ0I7QUFBQSxJQUNkLE9BQU8sQ0FBQyxFQUFFLE1BQU0sV0FBVyxNQUFNLFFBQVEsT0FBTyxLQUFLLEtBQUssS0FBSyxZQUFZLEdBQUcsQ0FBQztBQUFBLEVBQ2pGO0FBQUEsRUFDQSxnQkFBZ0I7QUFBQSxJQUNkLE9BQU8sQ0FBQyxFQUFFLGVBQWUsWUFBWSxhQUFhLE1BQU07QUFBQSxNQUN0RDtBQUFBLFFBQ0U7QUFBQSxRQUNBLEtBQUssT0FBTyxhQUFhO0FBQUEsUUFDekIsS0FBSyxZQUFZLEdBQUc7QUFBQSxRQUNwQjtBQUFBLE1BQ0Y7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLG9CQUFvQjtBQUFBLElBQ2xCLE9BQU8sQ0FBQyxFQUFFLE1BQU0sZUFBZSxxQkFBcUIsWUFBWSxhQUFhO0FBQUE7QUFBQSxNQUUzRSxZQUFZLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSyxxQkFBcUIsSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLGFBQWEsSUFBSSxLQUFLLElBQUksS0FBSyxZQUFZLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBSztBQUFBO0FBQUEsRUFFdkk7QUFBQTtBQUFBLEVBRUEsVUFBVTtBQUFBLElBQ1IsT0FBTyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFDeEI7QUFBQSxFQUNBLFlBQVk7QUFBQSxJQUNWLE9BQU8sQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQ3hCO0FBQUEsRUFDQSxhQUFhO0FBQUEsSUFDWCxPQUFPLENBQUMsRUFBRSxPQUFPLE9BQU8sY0FBYyxNQUFNLGdCQUFnQixpQkFBaUIsS0FBSyxJQUFJLFlBQVksS0FBSztBQUFBLEVBQ3pHO0FBQUEsRUFDQSxjQUFjO0FBQUEsSUFDWixPQUFPLENBQUMsRUFBRSxNQUFNLE1BQU0sUUFBUSxTQUFTO0FBQUEsRUFDekM7QUFBQSxFQUNBLFdBQVc7QUFBQSxJQUNULE9BQU8sTUFBTTtBQUFBLEVBQ2Y7QUFBQSxFQUNBLFdBQVc7QUFBQSxJQUNULE9BQU8sQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQ3hCO0FBQUEsRUFDQSxXQUFXO0FBQUEsSUFDVCxPQUFPLENBQUMsRUFBRSxPQUFPLE1BQU0sTUFBTSxLQUFLLFFBQVEsSUFBSSxJQUFJO0FBQUEsRUFDcEQ7QUFBQSxFQUNBLGFBQWE7QUFBQSxJQUNYLE9BQU8sQ0FBQyxFQUFFLE9BQU8sTUFBTSxNQUFNLEtBQUssUUFBUSxJQUFJLElBQUk7QUFBQSxFQUNwRDtBQUFBLEVBQ0EsYUFBYTtBQUFBLElBQ1gsT0FBTyxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPO0FBQUEsRUFDNUM7QUFBQTtBQUFBLEVBRUEsV0FBVztBQUFBLElBQ1QsT0FBTyxDQUFDLEVBQUUsTUFBTSxXQUFXLEtBQUssTUFBTSxNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUssTUFBTSxJQUFJLEdBQUcsR0FBRztBQUFBLEVBQ3BGO0FBQUE7QUFBQSxFQUVBLFdBQVc7QUFBQSxJQUNULE9BQU8sQ0FBQyxFQUFFLEtBQUssTUFBTTtBQUFBLEVBQ3ZCO0FBQUEsRUFDQSxVQUFVO0FBQUEsSUFDUixPQUFPLENBQUMsRUFBRSxLQUFLLE1BQU0sTUFBTSxPQUFPO0FBQUEsRUFDcEM7QUFBQSxFQUNBLGFBQWE7QUFBQSxJQUNYLE9BQU8sQ0FBQyxFQUFFLEtBQUssTUFBTSxPQUFPO0FBQUEsRUFDOUI7QUFBQTtBQUFBLEVBRUEsa0JBQWtCO0FBQUEsSUFDaEIsT0FBTyxDQUFDLEVBQUUsYUFBYSxZQUFZLGVBQWUsTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUksS0FBSyxDQUFDLFVBQVUsS0FBSyxZQUFZLEdBQUcsR0FBRyxNQUFNLGNBQWMsQ0FBQyxHQUFHLEdBQUc7QUFBQSxFQUMxSjtBQUFBLEVBQ0EseUJBQXlCO0FBQUEsSUFDdkIsT0FBTyxDQUFDLEVBQUUsV0FBVyxLQUFLLE1BQU0sWUFBWSxPQUFPO0FBQUEsRUFDckQ7QUFBQSxFQUNBLHNCQUFzQjtBQUFBLElBQ3BCLE9BQU8sQ0FBQyxFQUFFLGFBQWEsTUFBTSxXQUFXLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJLEtBQUssQ0FBQyxVQUFVLE1BQU0sS0FBSyxZQUFZLEdBQUcsQ0FBQyxHQUFHLEdBQUc7QUFBQSxFQUMvSDtBQUFBLEVBQ0Esc0JBQXNCO0FBQUEsSUFDcEIsT0FBTyxDQUFDLEVBQUUsYUFBYSxNQUFNLFlBQVksWUFBWSxPQUFPLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJO0FBQUEsTUFDOUY7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSyxlQUFlLEtBQUssWUFBWSxLQUFLLENBQUM7QUFBQSxRQUMzQyxLQUFLLFlBQVksR0FBRztBQUFBLFFBQ3BCLE1BQU0sTUFBTTtBQUFBLE1BQ2Q7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLGlCQUFpQjtBQUFBLElBQ2YsT0FBTyxDQUFDLEVBQUUsYUFBYSxNQUFNLFdBQVcsTUFBTSxNQUFNLFdBQVcsTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUksUUFBUSxrQkFBa0IsSUFBSSxJQUFJLEtBQUssT0FBTyxPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssTUFBTSxJQUFJLEdBQUcsR0FBRyxLQUFLLE9BQU8sT0FBTyxLQUFLLEtBQUssS0FBSyxZQUFZLEdBQUcsQ0FBQztBQUFBLEVBQ3ZRO0FBQUEsRUFDQSxzQkFBc0I7QUFBQSxJQUNwQixPQUFPLENBQUMsRUFBRSxhQUFhLE1BQU0sTUFBTSxjQUFjLFdBQVcsTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUk7QUFBQSxNQUM5RixDQUFDLE9BQU8sT0FBTyxNQUFNLEtBQUssTUFBTSxZQUFZLEdBQUcsS0FBSyxZQUFZLEdBQUcsQ0FBQztBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLHlCQUF5QjtBQUFBLElBQ3ZCLE9BQU8sQ0FBQyxFQUFFLGFBQWEsTUFBTSxZQUFZLFlBQVksT0FBTyxNQUFNLEtBQUssSUFBSSxhQUFhLElBQUksSUFBSTtBQUFBLE1BQzlGO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUssZUFBZSxLQUFLLFlBQVksS0FBSyxDQUFDO0FBQUEsUUFDM0MsS0FBSyxZQUFZLEdBQUc7QUFBQSxRQUNwQixNQUFNLE1BQU07QUFBQSxNQUNkO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxxQkFBcUI7QUFBQSxJQUNuQixPQUFPLENBQUMsRUFBRSxhQUFhLE1BQU0sWUFBWSxNQUFNLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJO0FBQUEsTUFDakYsQ0FBQyxTQUFTLE1BQU0sS0FBSyxZQUFZLEdBQUcsR0FBRyxLQUFLLE1BQU0sS0FBSyxPQUFPLEtBQUssQ0FBQyxDQUFDO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0Esb0JBQW9CO0FBQUEsSUFDbEIsT0FBTyxDQUFDLEVBQUUsYUFBYSxNQUFNLFlBQVksT0FBTyxNQUFNLEtBQUssSUFBSSxhQUFhLElBQUksSUFBSSxLQUFLLENBQUMsUUFBUSxNQUFNLEtBQUssWUFBWSxHQUFHLEdBQUcsTUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDcEo7QUFBQSxFQUNBLHFCQUFxQjtBQUFBLElBQ25CLE9BQU8sQ0FBQyxFQUFFLGFBQWEsTUFBTSxXQUFXLE1BQU0sS0FBSyxJQUFJLGFBQWEsSUFBSSxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssWUFBWSxHQUFHLENBQUMsR0FBRyxHQUFHO0FBQUEsRUFDckg7QUFBQSxFQUNBLDJCQUEyQjtBQUFBLElBQ3pCLE9BQU8sQ0FBQyxFQUFFLGFBQWEsTUFBTSxZQUFZLE9BQU8sTUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLElBQUksS0FBSyxDQUFDLFNBQVMsTUFBTSxLQUFLLFlBQVksR0FBRyxHQUFHLE1BQU0sTUFBTSxDQUFDLEdBQUcsR0FBRztBQUFBLEVBQ3JKO0FBQUEsRUFDQSxxQkFBcUI7QUFBQSxJQUNuQixPQUFPLENBQUMsRUFBRSxhQUFhLE1BQU0sV0FBVyxNQUFNLFlBQVksVUFBVSxNQUFNLEtBQUssSUFBSSxhQUFhLElBQUksSUFBSSxnQkFBZ0IsUUFBUSxrQkFBa0IsSUFBSSxJQUFJLEtBQUssT0FBTyxPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssTUFBTSxJQUFJLEdBQUcsR0FBRyxNQUFNLGFBQWEsZ0JBQWdCLE1BQU0sU0FBUyxLQUFLLFdBQVcsS0FBSztBQUFBLEVBQ2pUO0FBQUEsRUFDQSxpQkFBaUI7QUFBQSxJQUNmLE9BQU8sQ0FBQyxFQUFFLFlBQVksZUFBZSxNQUFNO0FBQUEsTUFDekMsQ0FBQyxpQkFBaUIsS0FBSyxZQUFZLEdBQUcsR0FBRyxNQUFNLGNBQWMsQ0FBQztBQUFBLE1BQzlEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLHFCQUFxQjtBQUFBLElBQ25CLE9BQU8sQ0FBQyxFQUFFLE1BQU0sV0FBVyxNQUFNLEtBQUssQ0FBQyxpQkFBaUIsTUFBTSxLQUFLLFlBQVksR0FBRyxDQUFDLEdBQUcsR0FBRztBQUFBLEVBQzNGO0FBQUEsRUFDQSxxQkFBcUI7QUFBQSxJQUNuQixPQUFPLENBQUMsRUFBRSxNQUFNLFlBQVksWUFBWSxPQUFPLE1BQU07QUFBQSxNQUNuRDtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLLGVBQWUsS0FBSyxZQUFZLEtBQUssQ0FBQztBQUFBLFFBQzNDLEtBQUssWUFBWSxHQUFHO0FBQUEsUUFDcEIsTUFBTSxNQUFNO0FBQUEsTUFDZDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBQ0Esd0JBQXdCO0FBQUEsSUFDdEIsT0FBTyxDQUFDLEVBQUUsTUFBTSxZQUFZLFlBQVksT0FBTyxNQUFNO0FBQUEsTUFDbkQ7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSyxlQUFlLEtBQUssWUFBWSxLQUFLLENBQUM7QUFBQSxRQUMzQyxLQUFLLFlBQVksR0FBRztBQUFBLFFBQ3BCLE1BQU0sTUFBTTtBQUFBLE1BQ2Q7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLG9CQUFvQjtBQUFBLElBQ2xCLE9BQU8sQ0FBQyxFQUFFLE1BQU0sWUFBWSxNQUFNLE1BQU07QUFBQSxNQUN0QztBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLLFlBQVksR0FBRztBQUFBLFFBQ3BCLEtBQUssTUFBTSxLQUFLLE9BQU8sS0FBSyxDQUFDO0FBQUEsTUFDL0I7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLG1CQUFtQjtBQUFBLElBQ2pCLE9BQU8sQ0FBQyxFQUFFLE1BQU0sWUFBWSxPQUFPLE1BQU0sS0FBSyxDQUFDLGVBQWUsTUFBTSxLQUFLLFlBQVksR0FBRyxHQUFHLE1BQU0sTUFBTSxDQUFDLEdBQUcsR0FBRztBQUFBLEVBQ2hIO0FBQUEsRUFDQSwwQkFBMEI7QUFBQSxJQUN4QixPQUFPLENBQUMsRUFBRSxNQUFNLFlBQVksT0FBTyxNQUFNLEtBQUssQ0FBQyxnQkFBZ0IsTUFBTSxLQUFLLFlBQVksR0FBRyxHQUFHLE1BQU0sTUFBTSxDQUFDLEdBQUcsR0FBRztBQUFBLEVBQ2pIO0FBQ0Y7QUFDQSxTQUFTLEtBQUssWUFBWSxZQUFZLElBQUk7QUFDeEMsTUFBSTtBQUNKLFVBQVEsd0JBQXdCLGVBQWUsUUFBUSxlQUFlLFNBQVMsU0FBUyxXQUFXLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLFNBQVMsT0FBTyxRQUFRLDBCQUEwQixTQUFTLHdCQUF3QjtBQUM5TTtBQUNBLFNBQVMsTUFBTSxPQUFPO0FBQ3BCLFNBQU8sS0FBSyxPQUFPLE9BQU8sS0FBSyxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUs7QUFDckQ7QUFDQSxTQUFTLEtBQUssT0FBTyxhQUFhLE1BQU0sSUFBSTtBQUMxQyxTQUFPLGVBQWUsUUFBUSxnQkFBZ0IsS0FBSyxRQUFRLGNBQWMsTUFBTTtBQUNqRjtBQUNBLFNBQVMsT0FBTyxLQUFLO0FBQ25CLFNBQU8sS0FBSyxNQUFNLElBQUksUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUM5QztBQUNBLFNBQVMsa0JBQWtCLFlBQVk7QUFDckMsTUFBSTtBQUNKLFVBQVEsbUJBQW1CLGVBQWUsUUFBUSxlQUFlLFNBQVMsU0FBUyxXQUFXLEtBQUssQ0FBQyxRQUFRLElBQUksU0FBUyxJQUFJLENBQUMsT0FBTyxRQUFRLHFCQUFxQixTQUFTLG1CQUFtQjtBQUNoTTtBQUdBLFNBQVMsb0JBQW9CLFdBQVcsV0FBVztBQUNqRCxVQUFRLFVBQVUsTUFBTTtBQUFBLElBQ3RCLEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxJQUNULEtBQUssS0FBSztBQUNSLGFBQU8sU0FBUyxVQUFVLE9BQU8sRUFBRTtBQUFBLElBQ3JDLEtBQUssS0FBSztBQUNSLGFBQU8sV0FBVyxVQUFVLEtBQUs7QUFBQSxJQUNuQyxLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQ1IsYUFBTyxVQUFVO0FBQUEsSUFDbkIsS0FBSyxLQUFLO0FBQ1IsYUFBTyxVQUFVLE9BQU87QUFBQSxRQUN0QixDQUFDLFNBQVMsb0JBQW9CLE1BQU0sU0FBUztBQUFBLE1BQy9DO0FBQUEsSUFDRixLQUFLLEtBQUs7QUFDUixhQUFPO0FBQUEsUUFDTCxVQUFVO0FBQUEsUUFDVixDQUFDLFVBQVUsTUFBTSxLQUFLO0FBQUEsUUFDdEIsQ0FBQyxVQUFVLG9CQUFvQixNQUFNLE9BQU8sU0FBUztBQUFBLE1BQ3ZEO0FBQUEsSUFDRixLQUFLLEtBQUs7QUFDUixhQUFPLGNBQWMsUUFBUSxjQUFjLFNBQVMsU0FBUyxVQUFVLFVBQVUsS0FBSyxLQUFLO0FBQUEsRUFDL0Y7QUFDRjtBQUdBLFNBQVMsV0FBVyxNQUFNO0FBQ3hCLFVBQVEsUUFBUSxVQUFVLE9BQU8sb0JBQW9CO0FBQ3JELFNBQU8sU0FBUyxZQUFZLFVBQVUsT0FBTywrQkFBK0I7QUFDNUUsTUFBSSxLQUFLLFdBQVcsR0FBRztBQUNyQixVQUFNLElBQUksYUFBYSx5Q0FBeUM7QUFBQSxFQUNsRTtBQUNBLFdBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEVBQUUsR0FBRztBQUNwQyxRQUFJLENBQUMsZUFBZSxLQUFLLFdBQVcsQ0FBQyxDQUFDLEdBQUc7QUFDdkMsWUFBTSxJQUFJO0FBQUEsUUFDUiw2Q0FBNkMsSUFBSTtBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsWUFBWSxLQUFLLFdBQVcsQ0FBQyxDQUFDLEdBQUc7QUFDcEMsVUFBTSxJQUFJO0FBQUEsTUFDUix3Q0FBd0MsSUFBSTtBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsb0JBQW9CLE1BQU07QUFDakMsTUFBSSxTQUFTLFVBQVUsU0FBUyxXQUFXLFNBQVMsUUFBUTtBQUMxRCxVQUFNLElBQUksYUFBYSxnQ0FBZ0MsSUFBSSxFQUFFO0FBQUEsRUFDL0Q7QUFDQSxTQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUdBLFNBQVMsT0FBTyxNQUFNO0FBQ3BCLFNBQU8sYUFBYSxJQUFJLEtBQUssYUFBYSxJQUFJLEtBQUssZ0JBQWdCLElBQUksS0FBSyxZQUFZLElBQUksS0FBSyxXQUFXLElBQUksS0FBSyxrQkFBa0IsSUFBSSxLQUFLLFdBQVcsSUFBSSxLQUFLLGNBQWMsSUFBSTtBQUN4TDtBQUNBLFNBQVMsYUFBYSxNQUFNO0FBQzFCLFNBQU8sV0FBVyxNQUFNLGlCQUFpQjtBQUMzQztBQUNBLFNBQVMsYUFBYSxNQUFNO0FBQzFCLFNBQU8sV0FBVyxNQUFNLGlCQUFpQjtBQUMzQztBQUNBLFNBQVMsZ0JBQWdCLE1BQU07QUFDN0IsU0FBTyxXQUFXLE1BQU0sb0JBQW9CO0FBQzlDO0FBQ0EsU0FBUyxZQUFZLE1BQU07QUFDekIsU0FBTyxXQUFXLE1BQU0sZ0JBQWdCO0FBQzFDO0FBQ0EsU0FBUyxXQUFXLE1BQU07QUFDeEIsU0FBTyxXQUFXLE1BQU0sZUFBZTtBQUN6QztBQUNBLFNBQVMsa0JBQWtCLE1BQU07QUFDL0IsU0FBTyxXQUFXLE1BQU0sc0JBQXNCO0FBQ2hEO0FBQ0EsU0FBUyxXQUFXLE1BQU07QUFDeEIsU0FBTyxXQUFXLE1BQU0sV0FBVztBQUNyQztBQUNBLFNBQVMsY0FBYyxNQUFNO0FBQzNCLFNBQU8sV0FBVyxNQUFNLGNBQWM7QUFDeEM7QUFDQSxTQUFTLFlBQVksTUFBTTtBQUN6QixTQUFPLGFBQWEsSUFBSSxLQUFLLFdBQVcsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEtBQUssZUFBZSxJQUFJLEtBQUssWUFBWSxLQUFLLE1BQU07QUFDN0g7QUFDQSxTQUFTLFdBQVcsTUFBTTtBQUN4QixTQUFPLGFBQWEsSUFBSSxLQUFLLFdBQVcsSUFBSTtBQUM5QztBQUNBLFNBQVMsZ0JBQWdCLE1BQU07QUFDN0IsU0FBTyxhQUFhLElBQUksS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLFlBQVksSUFBSTtBQUN4RTtBQUNBLFNBQVMsZUFBZSxNQUFNO0FBQzVCLFNBQU8sZ0JBQWdCLElBQUksS0FBSyxZQUFZLElBQUk7QUFDbEQ7QUFDQSxJQUFJLGNBQWMsTUFBTTtBQUFBLEVBQ3RCLFlBQVksUUFBUTtBQUNsQixXQUFPLE1BQU0sS0FBSyxVQUFVLE9BQU8sWUFBWSxRQUFRLE1BQU0sQ0FBQyx3QkFBd0I7QUFDdEYsU0FBSyxTQUFTO0FBQUEsRUFDaEI7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSTtBQUFBLEVBQ3JDO0FBQUEsRUFDQSxTQUFTO0FBQ1AsV0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN2QjtBQUNGO0FBQ0EsSUFBSSxpQkFBaUIsTUFBTTtBQUFBLEVBQ3pCLFlBQVksUUFBUTtBQUNsQixtQkFBZSxNQUFNLEtBQUs7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsWUFBWSxRQUFRLE1BQU0sQ0FBQztBQUFBLElBQzdCO0FBQ0EsU0FBSyxTQUFTO0FBQUEsRUFDaEI7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPLE9BQU8sS0FBSyxNQUFNLElBQUk7QUFBQSxFQUMvQjtBQUFBLEVBQ0EsU0FBUztBQUNQLFdBQU8sS0FBSyxTQUFTO0FBQUEsRUFDdkI7QUFDRjtBQUNBLFNBQVMsZUFBZSxNQUFNO0FBQzVCLFNBQU8sV0FBVyxJQUFJLEtBQUssY0FBYyxJQUFJO0FBQy9DO0FBQ0EsU0FBUyxlQUFlLE1BQU07QUFDNUIsU0FBTyxPQUFPLElBQUksS0FBSyxDQUFDLGNBQWMsSUFBSTtBQUM1QztBQUNBLFNBQVMsZ0JBQWdCLE1BQU07QUFDN0IsTUFBSSxNQUFNO0FBQ1IsV0FBTyxjQUFjLElBQUksSUFBSSxLQUFLLFNBQVM7QUFBQSxFQUM3QztBQUNGO0FBQ0EsU0FBUyxhQUFhLE1BQU07QUFDMUIsTUFBSSxNQUFNO0FBQ1IsUUFBSSxnQkFBZ0I7QUFDcEIsV0FBTyxlQUFlLGFBQWEsR0FBRztBQUNwQyxzQkFBZ0IsY0FBYztBQUFBLElBQ2hDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLFNBQVMsMEJBQTBCLE9BQU87QUFDeEMsU0FBTyxPQUFPLFVBQVUsYUFBYSxNQUFNLElBQUk7QUFDakQ7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0FBQ2pDLFNBQU8sT0FBTyxVQUFVLGFBQWEsTUFBTSxJQUFJO0FBQ2pEO0FBQ0EsSUFBSSxvQkFBb0IsTUFBTTtBQUFBLEVBQzVCLFlBQVksUUFBUTtBQUNsQixRQUFJLG9CQUFvQixtQkFBbUIsc0JBQXNCO0FBQ2pFLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxnQkFBZ0IsUUFBUSx1QkFBdUIsU0FBUyxxQkFBcUI7QUFDOUgsU0FBSyxPQUFPLFdBQVcsT0FBTyxJQUFJO0FBQ2xDLFNBQUssY0FBYyxPQUFPO0FBQzFCLFNBQUssaUJBQWlCLE9BQU87QUFDN0IsU0FBSyxhQUFhLG9CQUFvQixPQUFPLGVBQWUsUUFBUSxzQkFBc0IsU0FBUyxvQkFBb0I7QUFDdkgsU0FBSyxhQUFhO0FBQ2xCLFNBQUssZ0JBQWdCLHVCQUF1QixPQUFPLGtCQUFrQixRQUFRLHlCQUF5QixTQUFTLHVCQUF1QixDQUFDLE1BQU0sY0FBYyxZQUFZLG9CQUFvQixNQUFNLFNBQVMsQ0FBQztBQUMzTSxTQUFLLGFBQWEsU0FBUyxPQUFPLFVBQVU7QUFDNUMsU0FBSyxVQUFVLE9BQU87QUFDdEIsU0FBSyxxQkFBcUIsd0JBQXdCLE9BQU8sdUJBQXVCLFFBQVEsMEJBQTBCLFNBQVMsd0JBQXdCLENBQUM7QUFDcEosV0FBTyxrQkFBa0IsUUFBUSxPQUFPLE9BQU8sbUJBQW1CLFlBQVk7QUFBQSxNQUM1RTtBQUFBLE1BQ0EsR0FBRyxLQUFLLElBQUksd0RBQXdELFFBQVEsT0FBTyxjQUFjLENBQUM7QUFBQSxJQUNwRztBQUNBLFdBQU8sYUFBYSxRQUFRLE9BQU8sT0FBTyxjQUFjLGNBQWM7QUFBQSxNQUNwRTtBQUFBLE1BQ0EsR0FBRyxLQUFLLElBQUk7QUFBQSxJQUNkO0FBQ0EsUUFBSSxPQUFPLGNBQWM7QUFDdkIsYUFBTyxPQUFPLGVBQWUsY0FBYyxPQUFPLE9BQU8saUJBQWlCLGNBQWM7QUFBQSxRQUN0RjtBQUFBLFFBQ0EsR0FBRyxLQUFLLElBQUk7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPO0FBQUEsTUFDTCxNQUFNLEtBQUs7QUFBQSxNQUNYLGFBQWEsS0FBSztBQUFBLE1BQ2xCLGdCQUFnQixLQUFLO0FBQUEsTUFDckIsV0FBVyxLQUFLO0FBQUEsTUFDaEIsWUFBWSxLQUFLO0FBQUEsTUFDakIsY0FBYyxLQUFLO0FBQUEsTUFDbkIsWUFBWSxLQUFLO0FBQUEsTUFDakIsU0FBUyxLQUFLO0FBQUEsTUFDZCxtQkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPLEtBQUssU0FBUztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxJQUFJLG9CQUFvQixNQUFNO0FBQUEsRUFDNUIsWUFBWSxRQUFRO0FBQ2xCLFFBQUk7QUFDSixTQUFLLE9BQU8sV0FBVyxPQUFPLElBQUk7QUFDbEMsU0FBSyxjQUFjLE9BQU87QUFDMUIsU0FBSyxXQUFXLE9BQU87QUFDdkIsU0FBSyxhQUFhLFNBQVMsT0FBTyxVQUFVO0FBQzVDLFNBQUssVUFBVSxPQUFPO0FBQ3RCLFNBQUsscUJBQXFCLHlCQUF5QixPQUFPLHVCQUF1QixRQUFRLDJCQUEyQixTQUFTLHlCQUF5QixDQUFDO0FBQ3ZKLFNBQUssVUFBVSxNQUFNLGVBQWUsTUFBTTtBQUMxQyxTQUFLLGNBQWMsTUFBTSxpQkFBaUIsTUFBTTtBQUNoRCxXQUFPLFlBQVksUUFBUSxPQUFPLE9BQU8sYUFBYSxjQUFjO0FBQUEsTUFDbEU7QUFBQSxNQUNBLEdBQUcsS0FBSyxJQUFJLG9EQUFvRCxRQUFRLE9BQU8sUUFBUSxDQUFDO0FBQUEsSUFDMUY7QUFBQSxFQUNGO0FBQUEsRUFDQSxLQUFLLE9BQU8sV0FBVyxJQUFJO0FBQ3pCLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxZQUFZO0FBQ1YsUUFBSSxPQUFPLEtBQUssWUFBWSxZQUFZO0FBQ3RDLFdBQUssVUFBVSxLQUFLLFFBQVE7QUFBQSxJQUM5QjtBQUNBLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLGdCQUFnQjtBQUNkLFFBQUksT0FBTyxLQUFLLGdCQUFnQixZQUFZO0FBQzFDLFdBQUssY0FBYyxLQUFLLFlBQVk7QUFBQSxJQUN0QztBQUNBLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPO0FBQUEsTUFDTCxNQUFNLEtBQUs7QUFBQSxNQUNYLGFBQWEsS0FBSztBQUFBLE1BQ2xCLFlBQVksS0FBSyxjQUFjO0FBQUEsTUFDL0IsUUFBUSxxQkFBcUIsS0FBSyxVQUFVLENBQUM7QUFBQSxNQUM3QyxVQUFVLEtBQUs7QUFBQSxNQUNmLFlBQVksS0FBSztBQUFBLE1BQ2pCLFNBQVMsS0FBSztBQUFBLE1BQ2QsbUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxTQUFTO0FBQ1AsV0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN2QjtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUTtBQUNoQyxNQUFJO0FBQ0osUUFBTSxhQUFhO0FBQUEsS0FDaEIscUJBQXFCLE9BQU8sZ0JBQWdCLFFBQVEsdUJBQXVCLFNBQVMscUJBQXFCLENBQUM7QUFBQSxFQUM3RztBQUNBLFFBQU0sUUFBUSxVQUFVLEtBQUs7QUFBQSxJQUMzQjtBQUFBLElBQ0EsR0FBRyxPQUFPLElBQUk7QUFBQSxFQUNoQjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxRQUFRO0FBQzlCLFFBQU0sV0FBVyxtQkFBbUIsT0FBTyxNQUFNO0FBQ2pELGFBQVcsUUFBUSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxJQUNBLEdBQUcsT0FBTyxJQUFJO0FBQUEsRUFDaEI7QUFDQSxTQUFPLFNBQVMsVUFBVSxDQUFDLGFBQWEsY0FBYztBQUNwRCxRQUFJO0FBQ0osZUFBVyxXQUFXLEtBQUs7QUFBQSxNQUN6QjtBQUFBLE1BQ0EsR0FBRyxPQUFPLElBQUksSUFBSSxTQUFTO0FBQUEsSUFDN0I7QUFDQSxnQkFBWSxXQUFXLFFBQVEsT0FBTyxZQUFZLFlBQVksY0FBYztBQUFBLE1BQzFFO0FBQUEsTUFDQSxHQUFHLE9BQU8sSUFBSSxJQUFJLFNBQVMsNERBQTRELFFBQVEsWUFBWSxPQUFPLENBQUM7QUFBQSxJQUNySDtBQUNBLFVBQU0sY0FBYyxvQkFBb0IsWUFBWSxVQUFVLFFBQVEsc0JBQXNCLFNBQVMsb0JBQW9CLENBQUM7QUFDMUgsZUFBVyxVQUFVLEtBQUs7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsR0FBRyxPQUFPLElBQUksSUFBSSxTQUFTO0FBQUEsSUFDN0I7QUFDQSxXQUFPO0FBQUEsTUFDTCxNQUFNLFdBQVcsU0FBUztBQUFBLE1BQzFCLGFBQWEsWUFBWTtBQUFBLE1BQ3pCLE1BQU0sWUFBWTtBQUFBLE1BQ2xCLE1BQU0sZ0JBQWdCLFVBQVU7QUFBQSxNQUNoQyxTQUFTLFlBQVk7QUFBQSxNQUNyQixXQUFXLFlBQVk7QUFBQSxNQUN2QixtQkFBbUIsWUFBWTtBQUFBLE1BQy9CLFlBQVksU0FBUyxZQUFZLFVBQVU7QUFBQSxNQUMzQyxTQUFTLFlBQVk7QUFBQSxJQUN2QjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxnQkFBZ0IsUUFBUTtBQUMvQixTQUFPLE9BQU8sUUFBUSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUMsU0FBUyxTQUFTLE9BQU87QUFBQSxJQUMzRCxNQUFNLFdBQVcsT0FBTztBQUFBLElBQ3hCLGFBQWEsVUFBVTtBQUFBLElBQ3ZCLE1BQU0sVUFBVTtBQUFBLElBQ2hCLGNBQWMsVUFBVTtBQUFBLElBQ3hCLG1CQUFtQixVQUFVO0FBQUEsSUFDN0IsWUFBWSxTQUFTLFVBQVUsVUFBVTtBQUFBLElBQ3pDLFNBQVMsVUFBVTtBQUFBLEVBQ3JCLEVBQUU7QUFDSjtBQUNBLFNBQVMsV0FBVyxLQUFLO0FBQ3ZCLFNBQU8sYUFBYSxHQUFHLEtBQUssQ0FBQyxNQUFNLFFBQVEsR0FBRztBQUNoRDtBQUNBLFNBQVMscUJBQXFCLFFBQVE7QUFDcEMsU0FBTyxTQUFTLFFBQVEsQ0FBQyxXQUFXO0FBQUEsSUFDbEMsYUFBYSxNQUFNO0FBQUEsSUFDbkIsTUFBTSxNQUFNO0FBQUEsSUFDWixNQUFNLGlCQUFpQixNQUFNLElBQUk7QUFBQSxJQUNqQyxTQUFTLE1BQU07QUFBQSxJQUNmLFdBQVcsTUFBTTtBQUFBLElBQ2pCLG1CQUFtQixNQUFNO0FBQUEsSUFDekIsWUFBWSxNQUFNO0FBQUEsSUFDbEIsU0FBUyxNQUFNO0FBQUEsRUFDakIsRUFBRTtBQUNKO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTTtBQUM5QixTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0EsQ0FBQyxRQUFRLElBQUk7QUFBQSxJQUNiLENBQUMsU0FBUztBQUFBLE1BQ1IsYUFBYSxJQUFJO0FBQUEsTUFDakIsTUFBTSxJQUFJO0FBQUEsTUFDVixjQUFjLElBQUk7QUFBQSxNQUNsQixtQkFBbUIsSUFBSTtBQUFBLE1BQ3ZCLFlBQVksSUFBSTtBQUFBLE1BQ2hCLFNBQVMsSUFBSTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixLQUFLO0FBQy9CLFNBQU8sY0FBYyxJQUFJLElBQUksS0FBSyxJQUFJLGlCQUFpQjtBQUN6RDtBQUNBLElBQUksdUJBQXVCLE1BQU07QUFBQSxFQUMvQixZQUFZLFFBQVE7QUFDbEIsUUFBSTtBQUNKLFNBQUssT0FBTyxXQUFXLE9BQU8sSUFBSTtBQUNsQyxTQUFLLGNBQWMsT0FBTztBQUMxQixTQUFLLGNBQWMsT0FBTztBQUMxQixTQUFLLGFBQWEsU0FBUyxPQUFPLFVBQVU7QUFDNUMsU0FBSyxVQUFVLE9BQU87QUFDdEIsU0FBSyxxQkFBcUIseUJBQXlCLE9BQU8sdUJBQXVCLFFBQVEsMkJBQTJCLFNBQVMseUJBQXlCLENBQUM7QUFDdkosU0FBSyxVQUFVLGVBQWUsS0FBSyxRQUFRLE1BQU07QUFDakQsU0FBSyxjQUFjLGlCQUFpQixLQUFLLFFBQVEsTUFBTTtBQUN2RCxXQUFPLGVBQWUsUUFBUSxPQUFPLE9BQU8sZ0JBQWdCLGNBQWM7QUFBQSxNQUN4RTtBQUFBLE1BQ0EsR0FBRyxLQUFLLElBQUksdURBQXVELFFBQVEsT0FBTyxXQUFXLENBQUM7QUFBQSxJQUNoRztBQUFBLEVBQ0Y7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFlBQVk7QUFDVixRQUFJLE9BQU8sS0FBSyxZQUFZLFlBQVk7QUFDdEMsV0FBSyxVQUFVLEtBQUssUUFBUTtBQUFBLElBQzlCO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsZ0JBQWdCO0FBQ2QsUUFBSSxPQUFPLEtBQUssZ0JBQWdCLFlBQVk7QUFDMUMsV0FBSyxjQUFjLEtBQUssWUFBWTtBQUFBLElBQ3RDO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU87QUFBQSxNQUNMLE1BQU0sS0FBSztBQUFBLE1BQ1gsYUFBYSxLQUFLO0FBQUEsTUFDbEIsWUFBWSxLQUFLLGNBQWM7QUFBQSxNQUMvQixRQUFRLHFCQUFxQixLQUFLLFVBQVUsQ0FBQztBQUFBLE1BQzdDLGFBQWEsS0FBSztBQUFBLE1BQ2xCLFlBQVksS0FBSztBQUFBLE1BQ2pCLFNBQVMsS0FBSztBQUFBLE1BQ2QsbUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxTQUFTO0FBQ1AsV0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN2QjtBQUNGO0FBQ0EsSUFBSSxtQkFBbUIsTUFBTTtBQUFBLEVBQzNCLFlBQVksUUFBUTtBQUNsQixRQUFJO0FBQ0osU0FBSyxPQUFPLFdBQVcsT0FBTyxJQUFJO0FBQ2xDLFNBQUssY0FBYyxPQUFPO0FBQzFCLFNBQUssY0FBYyxPQUFPO0FBQzFCLFNBQUssYUFBYSxTQUFTLE9BQU8sVUFBVTtBQUM1QyxTQUFLLFVBQVUsT0FBTztBQUN0QixTQUFLLHFCQUFxQix5QkFBeUIsT0FBTyx1QkFBdUIsUUFBUSwyQkFBMkIsU0FBUyx5QkFBeUIsQ0FBQztBQUN2SixTQUFLLFNBQVMsWUFBWSxLQUFLLFFBQVEsTUFBTTtBQUM3QyxXQUFPLGVBQWUsUUFBUSxPQUFPLE9BQU8sZ0JBQWdCLGNBQWM7QUFBQSxNQUN4RTtBQUFBLE1BQ0EsR0FBRyxLQUFLLElBQUksdURBQXVELFFBQVEsT0FBTyxXQUFXLENBQUM7QUFBQSxJQUNoRztBQUFBLEVBQ0Y7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVc7QUFDVCxRQUFJLE9BQU8sS0FBSyxXQUFXLFlBQVk7QUFDckMsV0FBSyxTQUFTLEtBQUssT0FBTztBQUFBLElBQzVCO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU87QUFBQSxNQUNMLE1BQU0sS0FBSztBQUFBLE1BQ1gsYUFBYSxLQUFLO0FBQUEsTUFDbEIsT0FBTyxLQUFLLFNBQVM7QUFBQSxNQUNyQixhQUFhLEtBQUs7QUFBQSxNQUNsQixZQUFZLEtBQUs7QUFBQSxNQUNqQixTQUFTLEtBQUs7QUFBQSxNQUNkLG1CQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQUEsRUFDQSxXQUFXO0FBQ1QsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsU0FBUztBQUNQLFdBQU8sS0FBSyxTQUFTO0FBQUEsRUFDdkI7QUFDRjtBQUNBLFNBQVMsWUFBWSxRQUFRO0FBQzNCLFFBQU0sUUFBUSwwQkFBMEIsT0FBTyxLQUFLO0FBQ3BELFFBQU0sUUFBUSxLQUFLLEtBQUs7QUFBQSxJQUN0QjtBQUFBLElBQ0EsbUZBQW1GLE9BQU8sSUFBSTtBQUFBLEVBQ2hHO0FBQ0EsU0FBTztBQUNUO0FBQ0EsSUFBSSxrQkFBa0IsTUFBTTtBQUFBO0FBQUEsRUFFMUIsWUFBWSxRQUFRO0FBQ2xCLFFBQUk7QUFDSixTQUFLLE9BQU8sV0FBVyxPQUFPLElBQUk7QUFDbEMsU0FBSyxjQUFjLE9BQU87QUFDMUIsU0FBSyxhQUFhLFNBQVMsT0FBTyxVQUFVO0FBQzVDLFNBQUssVUFBVSxPQUFPO0FBQ3RCLFNBQUsscUJBQXFCLHlCQUF5QixPQUFPLHVCQUF1QixRQUFRLDJCQUEyQixTQUFTLHlCQUF5QixDQUFDO0FBQ3ZKLFNBQUssVUFBVSxpQkFBaUIsS0FBSyxNQUFNLE9BQU8sTUFBTTtBQUN4RCxTQUFLLGVBQWUsSUFBSTtBQUFBLE1BQ3RCLEtBQUssUUFBUSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsT0FBTyxTQUFTLENBQUM7QUFBQSxJQUM5RDtBQUNBLFNBQUssY0FBYyxPQUFPLEtBQUssU0FBUyxDQUFDLFVBQVUsTUFBTSxJQUFJO0FBQUEsRUFDL0Q7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFlBQVk7QUFDVixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxTQUFTLE1BQU07QUFDYixXQUFPLEtBQUssWUFBWSxJQUFJO0FBQUEsRUFDOUI7QUFBQSxFQUNBLFVBQVUsYUFBYTtBQUNyQixVQUFNLFlBQVksS0FBSyxhQUFhLElBQUksV0FBVztBQUNuRCxRQUFJLGNBQWMsUUFBUTtBQUN4QixZQUFNLElBQUk7QUFBQSxRQUNSLFNBQVMsS0FBSyxJQUFJLDZCQUE2QixRQUFRLFdBQVcsQ0FBQztBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUNBLFdBQU8sVUFBVTtBQUFBLEVBQ25CO0FBQUEsRUFDQSxXQUFXLFlBQVk7QUFDckIsUUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNsQyxZQUFNLFdBQVcsUUFBUSxVQUFVO0FBQ25DLFlBQU0sSUFBSTtBQUFBLFFBQ1IsU0FBUyxLQUFLLElBQUksd0NBQXdDLFFBQVEsTUFBTSxvQkFBb0IsTUFBTSxRQUFRO0FBQUEsTUFDNUc7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLEtBQUssU0FBUyxVQUFVO0FBQzFDLFFBQUksYUFBYSxNQUFNO0FBQ3JCLFlBQU0sSUFBSTtBQUFBLFFBQ1IsVUFBVSxVQUFVLHdCQUF3QixLQUFLLElBQUksWUFBWSxvQkFBb0IsTUFBTSxVQUFVO0FBQUEsTUFDdkc7QUFBQSxJQUNGO0FBQ0EsV0FBTyxVQUFVO0FBQUEsRUFDbkI7QUFBQSxFQUNBLGFBQWEsV0FBVyxZQUFZO0FBQ2xDLFFBQUksVUFBVSxTQUFTLEtBQUssTUFBTTtBQUNoQyxZQUFNLFdBQVcsTUFBTSxTQUFTO0FBQ2hDLFlBQU0sSUFBSTtBQUFBLFFBQ1IsU0FBUyxLQUFLLElBQUksc0NBQXNDLFFBQVEsTUFBTSxvQkFBb0IsTUFBTSxRQUFRO0FBQUEsUUFDeEc7QUFBQSxVQUNFLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksS0FBSyxTQUFTLFVBQVUsS0FBSztBQUMvQyxRQUFJLGFBQWEsTUFBTTtBQUNyQixZQUFNLFdBQVcsTUFBTSxTQUFTO0FBQ2hDLFlBQU0sSUFBSTtBQUFBLFFBQ1IsVUFBVSxRQUFRLHdCQUF3QixLQUFLLElBQUksWUFBWSxvQkFBb0IsTUFBTSxRQUFRO0FBQUEsUUFDakc7QUFBQSxVQUNFLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxXQUFPLFVBQVU7QUFBQSxFQUNuQjtBQUFBLEVBQ0EsV0FBVztBQUNULFVBQU0sU0FBUztBQUFBLE1BQ2IsS0FBSyxVQUFVO0FBQUEsTUFDZixDQUFDLFVBQVUsTUFBTTtBQUFBLE1BQ2pCLENBQUMsV0FBVztBQUFBLFFBQ1YsYUFBYSxNQUFNO0FBQUEsUUFDbkIsT0FBTyxNQUFNO0FBQUEsUUFDYixtQkFBbUIsTUFBTTtBQUFBLFFBQ3pCLFlBQVksTUFBTTtBQUFBLFFBQ2xCLFNBQVMsTUFBTTtBQUFBLE1BQ2pCO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxNQUNMLE1BQU0sS0FBSztBQUFBLE1BQ1gsYUFBYSxLQUFLO0FBQUEsTUFDbEI7QUFBQSxNQUNBLFlBQVksS0FBSztBQUFBLE1BQ2pCLFNBQVMsS0FBSztBQUFBLE1BQ2QsbUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFDQSxTQUFTO0FBQ1AsV0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN2QjtBQUNGO0FBQ0EsU0FBUyxvQkFBb0IsVUFBVSxpQkFBaUI7QUFDdEQsUUFBTSxXQUFXLFNBQVMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLE1BQU0sSUFBSTtBQUMvRCxRQUFNLGtCQUFrQixlQUFlLGlCQUFpQixRQUFRO0FBQ2hFLFNBQU8sV0FBVyxrQkFBa0IsZUFBZTtBQUNyRDtBQUNBLFNBQVMsaUJBQWlCLFVBQVUsVUFBVTtBQUM1QyxhQUFXLFFBQVEsS0FBSztBQUFBLElBQ3RCO0FBQUEsSUFDQSxHQUFHLFFBQVE7QUFBQSxFQUNiO0FBQ0EsU0FBTyxPQUFPLFFBQVEsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDLFdBQVcsV0FBVyxNQUFNO0FBQ2hFLGVBQVcsV0FBVyxLQUFLO0FBQUEsTUFDekI7QUFBQSxNQUNBLEdBQUcsUUFBUSxJQUFJLFNBQVMsdUZBQXVGLFFBQVEsV0FBVyxDQUFDO0FBQUEsSUFDckk7QUFDQSxXQUFPO0FBQUEsTUFDTCxNQUFNLG9CQUFvQixTQUFTO0FBQUEsTUFDbkMsYUFBYSxZQUFZO0FBQUEsTUFDekIsT0FBTyxZQUFZLFVBQVUsU0FBUyxZQUFZLFFBQVE7QUFBQSxNQUMxRCxtQkFBbUIsWUFBWTtBQUFBLE1BQy9CLFlBQVksU0FBUyxZQUFZLFVBQVU7QUFBQSxNQUMzQyxTQUFTLFlBQVk7QUFBQSxJQUN2QjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQ0EsSUFBSSx5QkFBeUIsTUFBTTtBQUFBLEVBQ2pDLFlBQVksUUFBUTtBQUNsQixRQUFJO0FBQ0osU0FBSyxPQUFPLFdBQVcsT0FBTyxJQUFJO0FBQ2xDLFNBQUssY0FBYyxPQUFPO0FBQzFCLFNBQUssYUFBYSxTQUFTLE9BQU8sVUFBVTtBQUM1QyxTQUFLLFVBQVUsT0FBTztBQUN0QixTQUFLLHFCQUFxQix5QkFBeUIsT0FBTyx1QkFBdUIsUUFBUSwyQkFBMkIsU0FBUyx5QkFBeUIsQ0FBQztBQUN2SixTQUFLLFVBQVUsb0JBQW9CLEtBQUssUUFBUSxNQUFNO0FBQUEsRUFDeEQ7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFlBQVk7QUFDVixRQUFJLE9BQU8sS0FBSyxZQUFZLFlBQVk7QUFDdEMsV0FBSyxVQUFVLEtBQUssUUFBUTtBQUFBLElBQzlCO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUFBLEVBQ0EsV0FBVztBQUNULFVBQU0sU0FBUyxTQUFTLEtBQUssVUFBVSxHQUFHLENBQUMsV0FBVztBQUFBLE1BQ3BELGFBQWEsTUFBTTtBQUFBLE1BQ25CLE1BQU0sTUFBTTtBQUFBLE1BQ1osY0FBYyxNQUFNO0FBQUEsTUFDcEIsbUJBQW1CLE1BQU07QUFBQSxNQUN6QixZQUFZLE1BQU07QUFBQSxNQUNsQixTQUFTLE1BQU07QUFBQSxJQUNqQixFQUFFO0FBQ0YsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLO0FBQUEsTUFDWCxhQUFhLEtBQUs7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsWUFBWSxLQUFLO0FBQUEsTUFDakIsU0FBUyxLQUFLO0FBQUEsTUFDZCxtQkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPLEtBQUssU0FBUztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxTQUFTLG9CQUFvQixRQUFRO0FBQ25DLFFBQU0sV0FBVyxtQkFBbUIsT0FBTyxNQUFNO0FBQ2pELGFBQVcsUUFBUSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxJQUNBLEdBQUcsT0FBTyxJQUFJO0FBQUEsRUFDaEI7QUFDQSxTQUFPLFNBQVMsVUFBVSxDQUFDLGFBQWEsY0FBYztBQUNwRCxNQUFFLGFBQWEsZ0JBQWdCO0FBQUEsTUFDN0I7QUFBQSxNQUNBLEdBQUcsT0FBTyxJQUFJLElBQUksU0FBUztBQUFBLElBQzdCO0FBQ0EsV0FBTztBQUFBLE1BQ0wsTUFBTSxXQUFXLFNBQVM7QUFBQSxNQUMxQixhQUFhLFlBQVk7QUFBQSxNQUN6QixNQUFNLFlBQVk7QUFBQSxNQUNsQixjQUFjLFlBQVk7QUFBQSxNQUMxQixtQkFBbUIsWUFBWTtBQUFBLE1BQy9CLFlBQVksU0FBUyxZQUFZLFVBQVU7QUFBQSxNQUMzQyxTQUFTLFlBQVk7QUFBQSxJQUN2QjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTztBQUNuQyxTQUFPLGNBQWMsTUFBTSxJQUFJLEtBQUssTUFBTSxpQkFBaUI7QUFDN0Q7QUFHQSxTQUFTLGdCQUFnQixRQUFRLGNBQWMsV0FBVztBQUN4RCxNQUFJLGlCQUFpQixXQUFXO0FBQzlCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxjQUFjLFNBQVMsR0FBRztBQUM1QixRQUFJLGNBQWMsWUFBWSxHQUFHO0FBQy9CLGFBQU8sZ0JBQWdCLFFBQVEsYUFBYSxRQUFRLFVBQVUsTUFBTTtBQUFBLElBQ3RFO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLGNBQWMsWUFBWSxHQUFHO0FBQy9CLFdBQU8sZ0JBQWdCLFFBQVEsYUFBYSxRQUFRLFNBQVM7QUFBQSxFQUMvRDtBQUNBLE1BQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsUUFBSSxXQUFXLFlBQVksR0FBRztBQUM1QixhQUFPLGdCQUFnQixRQUFRLGFBQWEsUUFBUSxVQUFVLE1BQU07QUFBQSxJQUN0RTtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxXQUFXLFlBQVksR0FBRztBQUM1QixXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU8sZUFBZSxTQUFTLE1BQU0sZ0JBQWdCLFlBQVksS0FBSyxhQUFhLFlBQVksTUFBTSxPQUFPLFVBQVUsV0FBVyxZQUFZO0FBQy9JO0FBQ0EsU0FBUyxlQUFlLFFBQVEsT0FBTyxPQUFPO0FBQzVDLE1BQUksVUFBVSxPQUFPO0FBQ25CLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxlQUFlLEtBQUssR0FBRztBQUN6QixRQUFJLGVBQWUsS0FBSyxHQUFHO0FBQ3pCLGFBQU8sT0FBTyxpQkFBaUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxTQUFTLE9BQU8sVUFBVSxPQUFPLElBQUksQ0FBQztBQUFBLElBQ3BGO0FBQ0EsV0FBTyxPQUFPLFVBQVUsT0FBTyxLQUFLO0FBQUEsRUFDdEM7QUFDQSxNQUFJLGVBQWUsS0FBSyxHQUFHO0FBQ3pCLFdBQU8sT0FBTyxVQUFVLE9BQU8sS0FBSztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBR0EsSUFBSSxrQkFBa0I7QUFDdEIsSUFBSSxrQkFBa0I7QUFDdEIsSUFBSSxhQUFhLElBQUksa0JBQWtCO0FBQUEsRUFDckMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsVUFBVSxhQUFhO0FBQ3JCLFVBQU0sZUFBZSxnQkFBZ0IsV0FBVztBQUNoRCxRQUFJLE9BQU8saUJBQWlCLFdBQVc7QUFDckMsYUFBTyxlQUFlLElBQUk7QUFBQSxJQUM1QjtBQUNBLFFBQUksTUFBTTtBQUNWLFFBQUksT0FBTyxpQkFBaUIsWUFBWSxpQkFBaUIsSUFBSTtBQUMzRCxZQUFNLE9BQU8sWUFBWTtBQUFBLElBQzNCO0FBQ0EsUUFBSSxPQUFPLFFBQVEsWUFBWSxDQUFDLE9BQU8sVUFBVSxHQUFHLEdBQUc7QUFDckQsWUFBTSxJQUFJO0FBQUEsUUFDUiwyQ0FBMkMsUUFBUSxZQUFZLENBQUM7QUFBQSxNQUNsRTtBQUFBLElBQ0Y7QUFDQSxRQUFJLE1BQU0sbUJBQW1CLE1BQU0saUJBQWlCO0FBQ2xELFlBQU0sSUFBSTtBQUFBLFFBQ1IsMkRBQTJELFFBQVEsWUFBWTtBQUFBLE1BQ2pGO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxXQUFXLFlBQVk7QUFDckIsUUFBSSxPQUFPLGVBQWUsWUFBWSxDQUFDLE9BQU8sVUFBVSxVQUFVLEdBQUc7QUFDbkUsWUFBTSxJQUFJO0FBQUEsUUFDUiwyQ0FBMkMsUUFBUSxVQUFVLENBQUM7QUFBQSxNQUNoRTtBQUFBLElBQ0Y7QUFDQSxRQUFJLGFBQWEsbUJBQW1CLGFBQWEsaUJBQWlCO0FBQ2hFLFlBQU0sSUFBSTtBQUFBLFFBQ1IseURBQXlELFVBQVU7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsYUFBYSxXQUFXO0FBQ3RCLFFBQUksVUFBVSxTQUFTLEtBQUssS0FBSztBQUMvQixZQUFNLElBQUk7QUFBQSxRQUNSLDJDQUEyQyxNQUFNLFNBQVMsQ0FBQztBQUFBLFFBQzNEO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsVUFBTSxNQUFNLFNBQVMsVUFBVSxPQUFPLEVBQUU7QUFDeEMsUUFBSSxNQUFNLG1CQUFtQixNQUFNLGlCQUFpQjtBQUNsRCxZQUFNLElBQUk7QUFBQSxRQUNSLHlEQUF5RCxVQUFVLEtBQUs7QUFBQSxRQUN4RTtBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0YsQ0FBQztBQUNELElBQUksZUFBZSxJQUFJLGtCQUFrQjtBQUFBLEVBQ3ZDLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFVBQVUsYUFBYTtBQUNyQixVQUFNLGVBQWUsZ0JBQWdCLFdBQVc7QUFDaEQsUUFBSSxPQUFPLGlCQUFpQixXQUFXO0FBQ3JDLGFBQU8sZUFBZSxJQUFJO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU07QUFDVixRQUFJLE9BQU8saUJBQWlCLFlBQVksaUJBQWlCLElBQUk7QUFDM0QsWUFBTSxPQUFPLFlBQVk7QUFBQSxJQUMzQjtBQUNBLFFBQUksT0FBTyxRQUFRLFlBQVksQ0FBQyxPQUFPLFNBQVMsR0FBRyxHQUFHO0FBQ3BELFlBQU0sSUFBSTtBQUFBLFFBQ1IsNkNBQTZDLFFBQVEsWUFBWSxDQUFDO0FBQUEsTUFDcEU7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVcsWUFBWTtBQUNyQixRQUFJLE9BQU8sZUFBZSxZQUFZLENBQUMsT0FBTyxTQUFTLFVBQVUsR0FBRztBQUNsRSxZQUFNLElBQUk7QUFBQSxRQUNSLDZDQUE2QyxRQUFRLFVBQVUsQ0FBQztBQUFBLE1BQ2xFO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFDQSxhQUFhLFdBQVc7QUFDdEIsUUFBSSxVQUFVLFNBQVMsS0FBSyxTQUFTLFVBQVUsU0FBUyxLQUFLLEtBQUs7QUFDaEUsWUFBTSxJQUFJO0FBQUEsUUFDUiw2Q0FBNkMsTUFBTSxTQUFTLENBQUM7QUFBQSxRQUM3RDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTyxXQUFXLFVBQVUsS0FBSztBQUFBLEVBQ25DO0FBQ0YsQ0FBQztBQUNELElBQUksZ0JBQWdCLElBQUksa0JBQWtCO0FBQUEsRUFDeEMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsVUFBVSxhQUFhO0FBQ3JCLFVBQU0sZUFBZSxnQkFBZ0IsV0FBVztBQUNoRCxRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDcEMsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLE9BQU8saUJBQWlCLFdBQVc7QUFDckMsYUFBTyxlQUFlLFNBQVM7QUFBQSxJQUNqQztBQUNBLFFBQUksT0FBTyxpQkFBaUIsWUFBWSxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ3JFLGFBQU8sYUFBYSxTQUFTO0FBQUEsSUFDL0I7QUFDQSxVQUFNLElBQUk7QUFBQSxNQUNSLGtDQUFrQyxRQUFRLFdBQVcsQ0FBQztBQUFBLElBQ3hEO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVyxZQUFZO0FBQ3JCLFFBQUksT0FBTyxlQUFlLFVBQVU7QUFDbEMsWUFBTSxJQUFJO0FBQUEsUUFDUiwrQ0FBK0MsUUFBUSxVQUFVLENBQUM7QUFBQSxNQUNwRTtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsYUFBYSxXQUFXO0FBQ3RCLFFBQUksVUFBVSxTQUFTLEtBQUssUUFBUTtBQUNsQyxZQUFNLElBQUk7QUFBQSxRQUNSLCtDQUErQyxNQUFNLFNBQVMsQ0FBQztBQUFBLFFBQy9EO0FBQUEsVUFDRSxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTyxVQUFVO0FBQUEsRUFDbkI7QUFDRixDQUFDO0FBQ0QsSUFBSSxpQkFBaUIsSUFBSSxrQkFBa0I7QUFBQSxFQUN6QyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixVQUFVLGFBQWE7QUFDckIsVUFBTSxlQUFlLGdCQUFnQixXQUFXO0FBQ2hELFFBQUksT0FBTyxpQkFBaUIsV0FBVztBQUNyQyxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksT0FBTyxTQUFTLFlBQVksR0FBRztBQUNqQyxhQUFPLGlCQUFpQjtBQUFBLElBQzFCO0FBQ0EsVUFBTSxJQUFJO0FBQUEsTUFDUixpREFBaUQsUUFBUSxZQUFZLENBQUM7QUFBQSxJQUN4RTtBQUFBLEVBQ0Y7QUFBQSxFQUNBLFdBQVcsWUFBWTtBQUNyQixRQUFJLE9BQU8sZUFBZSxXQUFXO0FBQ25DLFlBQU0sSUFBSTtBQUFBLFFBQ1IsaURBQWlELFFBQVEsVUFBVSxDQUFDO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLGFBQWEsV0FBVztBQUN0QixRQUFJLFVBQVUsU0FBUyxLQUFLLFNBQVM7QUFDbkMsWUFBTSxJQUFJO0FBQUEsUUFDUixpREFBaUQsTUFBTSxTQUFTLENBQUM7QUFBQSxRQUNqRTtBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU8sVUFBVTtBQUFBLEVBQ25CO0FBQ0YsQ0FBQztBQUNELElBQUksWUFBWSxJQUFJLGtCQUFrQjtBQUFBLEVBQ3BDLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFVBQVUsYUFBYTtBQUNyQixVQUFNLGVBQWUsZ0JBQWdCLFdBQVc7QUFDaEQsUUFBSSxPQUFPLGlCQUFpQixVQUFVO0FBQ3BDLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxPQUFPLFVBQVUsWUFBWSxHQUFHO0FBQ2xDLGFBQU8sT0FBTyxZQUFZO0FBQUEsSUFDNUI7QUFDQSxVQUFNLElBQUk7QUFBQSxNQUNSLDhCQUE4QixRQUFRLFdBQVcsQ0FBQztBQUFBLElBQ3BEO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVyxZQUFZO0FBQ3JCLFFBQUksT0FBTyxlQUFlLFVBQVU7QUFDbEMsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLE9BQU8sZUFBZSxZQUFZLE9BQU8sVUFBVSxVQUFVLEdBQUc7QUFDbEUsYUFBTyxXQUFXLFNBQVM7QUFBQSxJQUM3QjtBQUNBLFVBQU0sSUFBSSxhQUFhLDhCQUE4QixRQUFRLFVBQVUsQ0FBQyxFQUFFO0FBQUEsRUFDNUU7QUFBQSxFQUNBLGFBQWEsV0FBVztBQUN0QixRQUFJLFVBQVUsU0FBUyxLQUFLLFVBQVUsVUFBVSxTQUFTLEtBQUssS0FBSztBQUNqRSxZQUFNLElBQUk7QUFBQSxRQUNSLDZEQUE2RCxNQUFNLFNBQVM7QUFBQSxRQUM1RTtBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU8sVUFBVTtBQUFBLEVBQ25CO0FBQ0YsQ0FBQztBQUNELElBQUksdUJBQXVCLE9BQU8sT0FBTztBQUFBLEVBQ3ZDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFDRCxTQUFTLGdCQUFnQixhQUFhO0FBQ3BDLE1BQUksYUFBYSxXQUFXLEdBQUc7QUFDN0IsUUFBSSxPQUFPLFlBQVksWUFBWSxZQUFZO0FBQzdDLFlBQU0sZ0JBQWdCLFlBQVksUUFBUTtBQUMxQyxVQUFJLENBQUMsYUFBYSxhQUFhLEdBQUc7QUFDaEMsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLFlBQVksV0FBVyxZQUFZO0FBQzVDLGFBQU8sWUFBWSxPQUFPO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBR0EsSUFBSSxtQkFBbUIsTUFBTTtBQUFBLEVBQzNCLFlBQVksUUFBUTtBQUNsQixRQUFJLHNCQUFzQjtBQUMxQixTQUFLLE9BQU8sV0FBVyxPQUFPLElBQUk7QUFDbEMsU0FBSyxjQUFjLE9BQU87QUFDMUIsU0FBSyxZQUFZLE9BQU87QUFDeEIsU0FBSyxnQkFBZ0IsdUJBQXVCLE9BQU8sa0JBQWtCLFFBQVEseUJBQXlCLFNBQVMsdUJBQXVCO0FBQ3RJLFNBQUssYUFBYSxTQUFTLE9BQU8sVUFBVTtBQUM1QyxTQUFLLFVBQVUsT0FBTztBQUN0QixVQUFNLFFBQVEsT0FBTyxTQUFTLEtBQUssVUFBVSxPQUFPLElBQUksT0FBTyxJQUFJLDhCQUE4QjtBQUNqRyxVQUFNLFFBQVEsZUFBZSxPQUFPLFVBQVUsUUFBUSxpQkFBaUIsU0FBUyxlQUFlLENBQUM7QUFDaEcsaUJBQWEsSUFBSSxLQUFLLENBQUMsTUFBTSxRQUFRLElBQUksS0FBSztBQUFBLE1BQzVDO0FBQUEsTUFDQSxJQUFJLE9BQU8sSUFBSTtBQUFBLElBQ2pCO0FBQ0EsU0FBSyxPQUFPLGdCQUFnQixJQUFJO0FBQUEsRUFDbEM7QUFBQSxFQUNBLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDekIsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLFdBQVc7QUFDVCxXQUFPO0FBQUEsTUFDTCxNQUFNLEtBQUs7QUFBQSxNQUNYLGFBQWEsS0FBSztBQUFBLE1BQ2xCLFdBQVcsS0FBSztBQUFBLE1BQ2hCLE1BQU0saUJBQWlCLEtBQUssSUFBSTtBQUFBLE1BQ2hDLGNBQWMsS0FBSztBQUFBLE1BQ25CLFlBQVksS0FBSztBQUFBLE1BQ2pCLFNBQVMsS0FBSztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsV0FBVztBQUNULFdBQU8sTUFBTSxLQUFLO0FBQUEsRUFDcEI7QUFBQSxFQUNBLFNBQVM7QUFDUCxXQUFPLEtBQUssU0FBUztBQUFBLEVBQ3ZCO0FBQ0Y7QUFDQSxJQUFJLDBCQUEwQixJQUFJLGlCQUFpQjtBQUFBLEVBQ2pELE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFdBQVc7QUFBQSxJQUNULGtCQUFrQjtBQUFBLElBQ2xCLGtCQUFrQjtBQUFBLElBQ2xCLGtCQUFrQjtBQUFBLEVBQ3BCO0FBQUEsRUFDQSxNQUFNO0FBQUEsSUFDSixJQUFJO0FBQUEsTUFDRixNQUFNLElBQUksZUFBZSxjQUFjO0FBQUEsTUFDdkMsYUFBYTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUksdUJBQXVCLElBQUksaUJBQWlCO0FBQUEsRUFDOUMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsV0FBVztBQUFBLElBQ1Qsa0JBQWtCO0FBQUEsSUFDbEIsa0JBQWtCO0FBQUEsSUFDbEIsa0JBQWtCO0FBQUEsRUFDcEI7QUFBQSxFQUNBLE1BQU07QUFBQSxJQUNKLElBQUk7QUFBQSxNQUNGLE1BQU0sSUFBSSxlQUFlLGNBQWM7QUFBQSxNQUN2QyxhQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSw2QkFBNkI7QUFDakMsSUFBSSw2QkFBNkIsSUFBSSxpQkFBaUI7QUFBQSxFQUNwRCxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixXQUFXO0FBQUEsSUFDVCxrQkFBa0I7QUFBQSxJQUNsQixrQkFBa0I7QUFBQSxJQUNsQixrQkFBa0I7QUFBQSxJQUNsQixrQkFBa0I7QUFBQSxFQUNwQjtBQUFBLEVBQ0EsTUFBTTtBQUFBLElBQ0osUUFBUTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sYUFBYTtBQUFBLE1BQ2IsY0FBYztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLDhCQUE4QixJQUFJLGlCQUFpQjtBQUFBLEVBQ3JELE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFdBQVcsQ0FBQyxrQkFBa0IsTUFBTTtBQUFBLEVBQ3BDLE1BQU07QUFBQSxJQUNKLEtBQUs7QUFBQSxNQUNILE1BQU0sSUFBSSxlQUFlLGFBQWE7QUFBQSxNQUN0QyxhQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxzQkFBc0IsT0FBTyxPQUFPO0FBQUEsRUFDdEM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBR0QsU0FBUyxpQkFBaUIsZUFBZTtBQUN2QyxTQUFPLE9BQU8sa0JBQWtCLFlBQVksUUFBUSxrQkFBa0IsUUFBUSxrQkFBa0IsU0FBUyxTQUFTLGNBQWMsT0FBTyxRQUFRLE9BQU87QUFDeEo7QUFHQSxTQUFTLGFBQWEsT0FBTyxNQUFNO0FBQ2pDLE1BQUksY0FBYyxJQUFJLEdBQUc7QUFDdkIsVUFBTSxXQUFXLGFBQWEsT0FBTyxLQUFLLE1BQU07QUFDaEQsU0FBSyxhQUFhLFFBQVEsYUFBYSxTQUFTLFNBQVMsU0FBUyxVQUFVLEtBQUssTUFBTTtBQUNyRixhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxVQUFVLE1BQU07QUFDbEIsV0FBTztBQUFBLE1BQ0wsTUFBTSxLQUFLO0FBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFVBQVUsUUFBUTtBQUNwQixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksV0FBVyxJQUFJLEdBQUc7QUFDcEIsVUFBTSxXQUFXLEtBQUs7QUFDdEIsUUFBSSxpQkFBaUIsS0FBSyxHQUFHO0FBQzNCLFlBQU0sY0FBYyxDQUFDO0FBQ3JCLGlCQUFXLFFBQVEsT0FBTztBQUN4QixjQUFNLFdBQVcsYUFBYSxNQUFNLFFBQVE7QUFDNUMsWUFBSSxZQUFZLE1BQU07QUFDcEIsc0JBQVksS0FBSyxRQUFRO0FBQUEsUUFDM0I7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLFFBQ0wsTUFBTSxLQUFLO0FBQUEsUUFDWCxRQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFDQSxXQUFPLGFBQWEsT0FBTyxRQUFRO0FBQUEsRUFDckM7QUFDQSxNQUFJLGtCQUFrQixJQUFJLEdBQUc7QUFDM0IsUUFBSSxDQUFDLGFBQWEsS0FBSyxHQUFHO0FBQ3hCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTSxhQUFhLENBQUM7QUFDcEIsZUFBVyxTQUFTLE9BQU8sT0FBTyxLQUFLLFVBQVUsQ0FBQyxHQUFHO0FBQ25ELFlBQU0sYUFBYSxhQUFhLE1BQU0sTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJO0FBQzdELFVBQUksWUFBWTtBQUNkLG1CQUFXLEtBQUs7QUFBQSxVQUNkLE1BQU0sS0FBSztBQUFBLFVBQ1gsTUFBTTtBQUFBLFlBQ0osTUFBTSxLQUFLO0FBQUEsWUFDWCxPQUFPLE1BQU07QUFBQSxVQUNmO0FBQUEsVUFDQSxPQUFPO0FBQUEsUUFDVCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsTUFDTCxNQUFNLEtBQUs7QUFBQSxNQUNYLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUksV0FBVyxJQUFJLEdBQUc7QUFDcEIsVUFBTSxhQUFhLEtBQUssVUFBVSxLQUFLO0FBQ3ZDLFFBQUksY0FBYyxNQUFNO0FBQ3RCLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSxPQUFPLGVBQWUsV0FBVztBQUNuQyxhQUFPO0FBQUEsUUFDTCxNQUFNLEtBQUs7QUFBQSxRQUNYLE9BQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxlQUFlLFlBQVksT0FBTyxTQUFTLFVBQVUsR0FBRztBQUNqRSxZQUFNLFlBQVksT0FBTyxVQUFVO0FBQ25DLGFBQU8sb0JBQW9CLEtBQUssU0FBUyxJQUFJO0FBQUEsUUFDM0MsTUFBTSxLQUFLO0FBQUEsUUFDWCxPQUFPO0FBQUEsTUFDVCxJQUFJO0FBQUEsUUFDRixNQUFNLEtBQUs7QUFBQSxRQUNYLE9BQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxlQUFlLFVBQVU7QUFDbEMsVUFBSSxXQUFXLElBQUksR0FBRztBQUNwQixlQUFPO0FBQUEsVUFDTCxNQUFNLEtBQUs7QUFBQSxVQUNYLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUNBLFVBQUksU0FBUyxhQUFhLG9CQUFvQixLQUFLLFVBQVUsR0FBRztBQUM5RCxlQUFPO0FBQUEsVUFDTCxNQUFNLEtBQUs7QUFBQSxVQUNYLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxRQUNMLE1BQU0sS0FBSztBQUFBLFFBQ1gsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsVUFBTSxJQUFJLFVBQVUsZ0NBQWdDLFFBQVEsVUFBVSxDQUFDLEdBQUc7QUFBQSxFQUM1RTtBQUNBLGFBQVcsT0FBTyw0QkFBNEIsUUFBUSxJQUFJLENBQUM7QUFDN0Q7QUFDQSxJQUFJLHNCQUFzQjtBQUcxQixJQUFJLFdBQVcsSUFBSSxrQkFBa0I7QUFBQSxFQUNuQyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixRQUFRLE9BQU87QUFBQSxJQUNiLGFBQWE7QUFBQSxNQUNYLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxXQUFXLE9BQU87QUFBQSxJQUM5QjtBQUFBLElBQ0EsT0FBTztBQUFBLE1BQ0wsYUFBYTtBQUFBLE1BQ2IsTUFBTSxJQUFJLGVBQWUsSUFBSSxZQUFZLElBQUksZUFBZSxNQUFNLENBQUMsQ0FBQztBQUFBLE1BQ3BFLFFBQVEsUUFBUTtBQUNkLGVBQU8sT0FBTyxPQUFPLE9BQU8sV0FBVyxDQUFDO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQUEsSUFDQSxXQUFXO0FBQUEsTUFDVCxhQUFhO0FBQUEsTUFDYixNQUFNLElBQUksZUFBZSxNQUFNO0FBQUEsTUFDL0IsU0FBUyxDQUFDLFdBQVcsT0FBTyxhQUFhO0FBQUEsSUFDM0M7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLGFBQWE7QUFBQSxNQUNiLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxXQUFXLE9BQU8sZ0JBQWdCO0FBQUEsSUFDOUM7QUFBQSxJQUNBLGtCQUFrQjtBQUFBLE1BQ2hCLGFBQWE7QUFBQSxNQUNiLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxXQUFXLE9BQU8sb0JBQW9CO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLFlBQVk7QUFBQSxNQUNWLGFBQWE7QUFBQSxNQUNiLE1BQU0sSUFBSTtBQUFBLFFBQ1IsSUFBSSxZQUFZLElBQUksZUFBZSxXQUFXLENBQUM7QUFBQSxNQUNqRDtBQUFBLE1BQ0EsU0FBUyxDQUFDLFdBQVcsT0FBTyxjQUFjO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUksY0FBYyxJQUFJLGtCQUFrQjtBQUFBLEVBQ3RDLE1BQU07QUFBQSxFQUNOLGFBQWE7QUFBQSxFQUNiLFFBQVEsT0FBTztBQUFBLElBQ2IsTUFBTTtBQUFBLE1BQ0osTUFBTSxJQUFJLGVBQWUsYUFBYTtBQUFBLE1BQ3RDLFNBQVMsQ0FBQyxjQUFjLFVBQVU7QUFBQSxJQUNwQztBQUFBLElBQ0EsYUFBYTtBQUFBLE1BQ1gsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLGNBQWMsVUFBVTtBQUFBLElBQ3BDO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixNQUFNLElBQUksZUFBZSxjQUFjO0FBQUEsTUFDdkMsU0FBUyxDQUFDLGNBQWMsVUFBVTtBQUFBLElBQ3BDO0FBQUEsSUFDQSxXQUFXO0FBQUEsTUFDVCxNQUFNLElBQUk7QUFBQSxRQUNSLElBQUksWUFBWSxJQUFJLGVBQWUsbUJBQW1CLENBQUM7QUFBQSxNQUN6RDtBQUFBLE1BQ0EsU0FBUyxDQUFDLGNBQWMsVUFBVTtBQUFBLElBQ3BDO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixNQUFNLElBQUk7QUFBQSxRQUNSLElBQUksWUFBWSxJQUFJLGVBQWUsWUFBWSxDQUFDO0FBQUEsTUFDbEQ7QUFBQSxNQUNBLE1BQU07QUFBQSxRQUNKLG1CQUFtQjtBQUFBLFVBQ2pCLE1BQU07QUFBQSxVQUNOLGNBQWM7QUFBQSxRQUNoQjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFFBQVEsT0FBTyxFQUFFLGtCQUFrQixHQUFHO0FBQ3BDLGVBQU8sb0JBQW9CLE1BQU0sT0FBTyxNQUFNLEtBQUssT0FBTyxDQUFDLFFBQVEsSUFBSSxxQkFBcUIsSUFBSTtBQUFBLE1BQ2xHO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxzQkFBc0IsSUFBSSxnQkFBZ0I7QUFBQSxFQUM1QyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixRQUFRO0FBQUEsSUFDTixPQUFPO0FBQUEsTUFDTCxPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxVQUFVO0FBQUEsTUFDUixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxPQUFPO0FBQUEsTUFDTCxPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxxQkFBcUI7QUFBQSxNQUNuQixPQUFPLGtCQUFrQjtBQUFBLE1BQ3pCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmLE9BQU8sa0JBQWtCO0FBQUEsTUFDekIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EscUJBQXFCO0FBQUEsTUFDbkIsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ04sT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ04sT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ04sT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0Esa0JBQWtCO0FBQUEsTUFDaEIsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EscUJBQXFCO0FBQUEsTUFDbkIsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsV0FBVztBQUFBLE1BQ1QsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsT0FBTztBQUFBLE1BQ0wsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsTUFBTTtBQUFBLE1BQ0osT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0Esd0JBQXdCO0FBQUEsTUFDdEIsT0FBTyxrQkFBa0I7QUFBQSxNQUN6QixhQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxTQUFTLElBQUksa0JBQWtCO0FBQUEsRUFDakMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsUUFBUSxPQUFPO0FBQUEsSUFDYixNQUFNO0FBQUEsTUFDSixNQUFNLElBQUksZUFBZSxVQUFVO0FBQUEsTUFDbkMsUUFBUSxNQUFNO0FBQ1osWUFBSSxhQUFhLElBQUksR0FBRztBQUN0QixpQkFBTyxTQUFTO0FBQUEsUUFDbEI7QUFDQSxZQUFJLGFBQWEsSUFBSSxHQUFHO0FBQ3RCLGlCQUFPLFNBQVM7QUFBQSxRQUNsQjtBQUNBLFlBQUksZ0JBQWdCLElBQUksR0FBRztBQUN6QixpQkFBTyxTQUFTO0FBQUEsUUFDbEI7QUFDQSxZQUFJLFlBQVksSUFBSSxHQUFHO0FBQ3JCLGlCQUFPLFNBQVM7QUFBQSxRQUNsQjtBQUNBLFlBQUksV0FBVyxJQUFJLEdBQUc7QUFDcEIsaUJBQU8sU0FBUztBQUFBLFFBQ2xCO0FBQ0EsWUFBSSxrQkFBa0IsSUFBSSxHQUFHO0FBQzNCLGlCQUFPLFNBQVM7QUFBQSxRQUNsQjtBQUNBLFlBQUksV0FBVyxJQUFJLEdBQUc7QUFDcEIsaUJBQU8sU0FBUztBQUFBLFFBQ2xCO0FBQ0EsWUFBSSxjQUFjLElBQUksR0FBRztBQUN2QixpQkFBTyxTQUFTO0FBQUEsUUFDbEI7QUFDQSxtQkFBVyxPQUFPLHFCQUFxQixRQUFRLElBQUksQ0FBQyxJQUFJO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixNQUFNO0FBQUEsTUFDTixTQUFTLENBQUMsU0FBUyxVQUFVLE9BQU8sS0FBSyxPQUFPO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLGFBQWE7QUFBQSxNQUNYLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQztBQUFBO0FBQUEsUUFFUixpQkFBaUIsT0FBTyxLQUFLLGNBQWM7QUFBQTtBQUFBLElBRS9DO0FBQUEsSUFDQSxnQkFBZ0I7QUFBQSxNQUNkLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxRQUFRLG9CQUFvQixNQUFNLElBQUksaUJBQWlCO0FBQUEsSUFDbkU7QUFBQSxJQUNBLFFBQVE7QUFBQSxNQUNOLE1BQU0sSUFBSSxZQUFZLElBQUksZUFBZSxPQUFPLENBQUM7QUFBQSxNQUNqRCxNQUFNO0FBQUEsUUFDSixtQkFBbUI7QUFBQSxVQUNqQixNQUFNO0FBQUEsVUFDTixjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsTUFDQSxRQUFRLE1BQU0sRUFBRSxrQkFBa0IsR0FBRztBQUNuQyxZQUFJLGFBQWEsSUFBSSxLQUFLLGdCQUFnQixJQUFJLEdBQUc7QUFDL0MsZ0JBQU0sU0FBUyxPQUFPLE9BQU8sS0FBSyxVQUFVLENBQUM7QUFDN0MsaUJBQU8sb0JBQW9CLFNBQVMsT0FBTyxPQUFPLENBQUMsVUFBVSxNQUFNLHFCQUFxQixJQUFJO0FBQUEsUUFDOUY7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsTUFBTSxJQUFJLFlBQVksSUFBSSxlQUFlLE1BQU0sQ0FBQztBQUFBLE1BQ2hELFFBQVEsTUFBTTtBQUNaLFlBQUksYUFBYSxJQUFJLEtBQUssZ0JBQWdCLElBQUksR0FBRztBQUMvQyxpQkFBTyxLQUFLLGNBQWM7QUFBQSxRQUM1QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxlQUFlO0FBQUEsTUFDYixNQUFNLElBQUksWUFBWSxJQUFJLGVBQWUsTUFBTSxDQUFDO0FBQUEsTUFDaEQsUUFBUSxNQUFNLE9BQU8sVUFBVSxFQUFFLE9BQU8sR0FBRztBQUN6QyxZQUFJLGVBQWUsSUFBSSxHQUFHO0FBQ3hCLGlCQUFPLE9BQU8saUJBQWlCLElBQUk7QUFBQSxRQUNyQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixNQUFNLElBQUksWUFBWSxJQUFJLGVBQWUsV0FBVyxDQUFDO0FBQUEsTUFDckQsTUFBTTtBQUFBLFFBQ0osbUJBQW1CO0FBQUEsVUFDakIsTUFBTTtBQUFBLFVBQ04sY0FBYztBQUFBLFFBQ2hCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsUUFBUSxNQUFNLEVBQUUsa0JBQWtCLEdBQUc7QUFDbkMsWUFBSSxXQUFXLElBQUksR0FBRztBQUNwQixnQkFBTSxTQUFTLEtBQUssVUFBVTtBQUM5QixpQkFBTyxvQkFBb0IsU0FBUyxPQUFPLE9BQU8sQ0FBQyxVQUFVLE1BQU0scUJBQXFCLElBQUk7QUFBQSxRQUM5RjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxhQUFhO0FBQUEsTUFDWCxNQUFNLElBQUksWUFBWSxJQUFJLGVBQWUsWUFBWSxDQUFDO0FBQUEsTUFDdEQsTUFBTTtBQUFBLFFBQ0osbUJBQW1CO0FBQUEsVUFDakIsTUFBTTtBQUFBLFVBQ04sY0FBYztBQUFBLFFBQ2hCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsUUFBUSxNQUFNLEVBQUUsa0JBQWtCLEdBQUc7QUFDbkMsWUFBSSxrQkFBa0IsSUFBSSxHQUFHO0FBQzNCLGdCQUFNLFNBQVMsT0FBTyxPQUFPLEtBQUssVUFBVSxDQUFDO0FBQzdDLGlCQUFPLG9CQUFvQixTQUFTLE9BQU8sT0FBTyxDQUFDLFVBQVUsTUFBTSxxQkFBcUIsSUFBSTtBQUFBLFFBQzlGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFFBQVE7QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxTQUFTLFlBQVksT0FBTyxLQUFLLFNBQVM7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSSxVQUFVLElBQUksa0JBQWtCO0FBQUEsRUFDbEMsTUFBTTtBQUFBLEVBQ04sYUFBYTtBQUFBLEVBQ2IsUUFBUSxPQUFPO0FBQUEsSUFDYixNQUFNO0FBQUEsTUFDSixNQUFNLElBQUksZUFBZSxhQUFhO0FBQUEsTUFDdEMsU0FBUyxDQUFDLFVBQVUsTUFBTTtBQUFBLElBQzVCO0FBQUEsSUFDQSxhQUFhO0FBQUEsTUFDWCxNQUFNO0FBQUEsTUFDTixTQUFTLENBQUMsVUFBVSxNQUFNO0FBQUEsSUFDNUI7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLE1BQU0sSUFBSTtBQUFBLFFBQ1IsSUFBSSxZQUFZLElBQUksZUFBZSxZQUFZLENBQUM7QUFBQSxNQUNsRDtBQUFBLE1BQ0EsTUFBTTtBQUFBLFFBQ0osbUJBQW1CO0FBQUEsVUFDakIsTUFBTTtBQUFBLFVBQ04sY0FBYztBQUFBLFFBQ2hCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsUUFBUSxPQUFPLEVBQUUsa0JBQWtCLEdBQUc7QUFDcEMsZUFBTyxvQkFBb0IsTUFBTSxPQUFPLE1BQU0sS0FBSyxPQUFPLENBQUMsUUFBUSxJQUFJLHFCQUFxQixJQUFJO0FBQUEsTUFDbEc7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixNQUFNLElBQUksZUFBZSxNQUFNO0FBQUEsTUFDL0IsU0FBUyxDQUFDLFVBQVUsTUFBTTtBQUFBLElBQzVCO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixNQUFNLElBQUksZUFBZSxjQUFjO0FBQUEsTUFDdkMsU0FBUyxDQUFDLFVBQVUsTUFBTSxxQkFBcUI7QUFBQSxJQUNqRDtBQUFBLElBQ0EsbUJBQW1CO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLFVBQVUsTUFBTTtBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLGVBQWUsSUFBSSxrQkFBa0I7QUFBQSxFQUN2QyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixRQUFRLE9BQU87QUFBQSxJQUNiLE1BQU07QUFBQSxNQUNKLE1BQU0sSUFBSSxlQUFlLGFBQWE7QUFBQSxNQUN0QyxTQUFTLENBQUMsZUFBZSxXQUFXO0FBQUEsSUFDdEM7QUFBQSxJQUNBLGFBQWE7QUFBQSxNQUNYLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxlQUFlLFdBQVc7QUFBQSxJQUN0QztBQUFBLElBQ0EsTUFBTTtBQUFBLE1BQ0osTUFBTSxJQUFJLGVBQWUsTUFBTTtBQUFBLE1BQy9CLFNBQVMsQ0FBQyxlQUFlLFdBQVc7QUFBQSxJQUN0QztBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osTUFBTTtBQUFBLE1BQ04sYUFBYTtBQUFBLE1BQ2IsUUFBUSxZQUFZO0FBQ2xCLGNBQU0sRUFBRSxNQUFNLGFBQWEsSUFBSTtBQUMvQixjQUFNLFdBQVcsYUFBYSxjQUFjLElBQUk7QUFDaEQsZUFBTyxXQUFXLE1BQU0sUUFBUSxJQUFJO0FBQUEsTUFDdEM7QUFBQSxJQUNGO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixNQUFNLElBQUksZUFBZSxjQUFjO0FBQUEsTUFDdkMsU0FBUyxDQUFDLFVBQVUsTUFBTSxxQkFBcUI7QUFBQSxJQUNqRDtBQUFBLElBQ0EsbUJBQW1CO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sU0FBUyxDQUFDLFFBQVEsSUFBSTtBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFDRCxJQUFJLGNBQWMsSUFBSSxrQkFBa0I7QUFBQSxFQUN0QyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixRQUFRLE9BQU87QUFBQSxJQUNiLE1BQU07QUFBQSxNQUNKLE1BQU0sSUFBSSxlQUFlLGFBQWE7QUFBQSxNQUN0QyxTQUFTLENBQUMsY0FBYyxVQUFVO0FBQUEsSUFDcEM7QUFBQSxJQUNBLGFBQWE7QUFBQSxNQUNYLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxjQUFjLFVBQVU7QUFBQSxJQUNwQztBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osTUFBTSxJQUFJLGVBQWUsY0FBYztBQUFBLE1BQ3ZDLFNBQVMsQ0FBQyxjQUFjLFVBQVUscUJBQXFCO0FBQUEsSUFDekQ7QUFBQSxJQUNBLG1CQUFtQjtBQUFBLE1BQ2pCLE1BQU07QUFBQSxNQUNOLFNBQVMsQ0FBQyxjQUFjLFVBQVU7QUFBQSxJQUNwQztBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBQ0QsSUFBSTtBQUFBLENBQ0gsU0FBUyxXQUFXO0FBQ25CLFlBQVUsUUFBUSxJQUFJO0FBQ3RCLFlBQVUsUUFBUSxJQUFJO0FBQ3RCLFlBQVUsV0FBVyxJQUFJO0FBQ3pCLFlBQVUsT0FBTyxJQUFJO0FBQ3JCLFlBQVUsTUFBTSxJQUFJO0FBQ3BCLFlBQVUsY0FBYyxJQUFJO0FBQzVCLFlBQVUsTUFBTSxJQUFJO0FBQ3BCLFlBQVUsVUFBVSxJQUFJO0FBQzFCLEdBQUcsYUFBYSxXQUFXLENBQUMsRUFBRTtBQUM5QixJQUFJLGFBQWEsSUFBSSxnQkFBZ0I7QUFBQSxFQUNuQyxNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixRQUFRO0FBQUEsSUFDTixRQUFRO0FBQUEsTUFDTixPQUFPLFNBQVM7QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ04sT0FBTyxTQUFTO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLFdBQVc7QUFBQSxNQUNULE9BQU8sU0FBUztBQUFBLE1BQ2hCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxPQUFPO0FBQUEsTUFDTCxPQUFPLFNBQVM7QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsTUFBTTtBQUFBLE1BQ0osT0FBTyxTQUFTO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE9BQU8sU0FBUztBQUFBLE1BQ2hCLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixPQUFPLFNBQVM7QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFDZjtBQUFBLElBQ0EsVUFBVTtBQUFBLE1BQ1IsT0FBTyxTQUFTO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUNELElBQUkscUJBQXFCO0FBQUEsRUFDdkIsTUFBTTtBQUFBLEVBQ04sTUFBTSxJQUFJLGVBQWUsUUFBUTtBQUFBLEVBQ2pDLGFBQWE7QUFBQSxFQUNiLE1BQU0sQ0FBQztBQUFBLEVBQ1AsU0FBUyxDQUFDLFNBQVMsT0FBTyxVQUFVLEVBQUUsT0FBTyxNQUFNO0FBQUEsRUFDbkQsbUJBQW1CO0FBQUEsRUFDbkIsWUFBNEIsdUJBQU8sT0FBTyxJQUFJO0FBQUEsRUFDOUMsU0FBUztBQUNYO0FBQ0EsSUFBSSxtQkFBbUI7QUFBQSxFQUNyQixNQUFNO0FBQUEsRUFDTixNQUFNO0FBQUEsRUFDTixhQUFhO0FBQUEsRUFDYixNQUFNO0FBQUEsSUFDSjtBQUFBLE1BQ0UsTUFBTTtBQUFBLE1BQ04sYUFBYTtBQUFBLE1BQ2IsTUFBTSxJQUFJLGVBQWUsYUFBYTtBQUFBLE1BQ3RDLGNBQWM7QUFBQSxNQUNkLG1CQUFtQjtBQUFBLE1BQ25CLFlBQTRCLHVCQUFPLE9BQU8sSUFBSTtBQUFBLE1BQzlDLFNBQVM7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUFBLEVBQ0EsU0FBUyxDQUFDLFNBQVMsRUFBRSxLQUFLLEdBQUcsVUFBVSxFQUFFLE9BQU8sTUFBTSxPQUFPLFFBQVEsSUFBSTtBQUFBLEVBQ3pFLG1CQUFtQjtBQUFBLEVBQ25CLFlBQTRCLHVCQUFPLE9BQU8sSUFBSTtBQUFBLEVBQzlDLFNBQVM7QUFDWDtBQUNBLElBQUksdUJBQXVCO0FBQUEsRUFDekIsTUFBTTtBQUFBLEVBQ04sTUFBTSxJQUFJLGVBQWUsYUFBYTtBQUFBLEVBQ3RDLGFBQWE7QUFBQSxFQUNiLE1BQU0sQ0FBQztBQUFBLEVBQ1AsU0FBUyxDQUFDLFNBQVMsT0FBTyxVQUFVLEVBQUUsV0FBVyxNQUFNLFdBQVc7QUFBQSxFQUNsRSxtQkFBbUI7QUFBQSxFQUNuQixZQUE0Qix1QkFBTyxPQUFPLElBQUk7QUFBQSxFQUM5QyxTQUFTO0FBQ1g7QUFDQSxJQUFJLHFCQUFxQixPQUFPLE9BQU87QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBR0QsU0FBUyxZQUFZLFFBQVEsVUFBVTtBQUNyQyxVQUFRLFNBQVMsTUFBTTtBQUFBLElBQ3JCLEtBQUssS0FBSyxXQUFXO0FBQ25CLFlBQU0sWUFBWSxZQUFZLFFBQVEsU0FBUyxJQUFJO0FBQ25ELGFBQU8sYUFBYSxJQUFJLFlBQVksU0FBUztBQUFBLElBQy9DO0FBQUEsSUFDQSxLQUFLLEtBQUssZUFBZTtBQUN2QixZQUFNLFlBQVksWUFBWSxRQUFRLFNBQVMsSUFBSTtBQUNuRCxhQUFPLGFBQWEsSUFBSSxlQUFlLFNBQVM7QUFBQSxJQUNsRDtBQUFBLElBQ0EsS0FBSyxLQUFLO0FBQ1IsYUFBTyxPQUFPLFFBQVEsU0FBUyxLQUFLLEtBQUs7QUFBQSxFQUM3QztBQUNGO0FBR0EsU0FBUywyQkFBMkIsTUFBTTtBQUN4QyxTQUFPLEtBQUssU0FBUyxLQUFLLHdCQUF3QixLQUFLLFNBQVMsS0FBSztBQUN2RTtBQUNBLFNBQVMsMkJBQTJCLE1BQU07QUFDeEMsU0FBTyxLQUFLLFNBQVMsS0FBSyxxQkFBcUIscUJBQXFCLElBQUksS0FBSyxLQUFLLFNBQVMsS0FBSztBQUNsRztBQUNBLFNBQVMscUJBQXFCLE1BQU07QUFDbEMsU0FBTyxLQUFLLFNBQVMsS0FBSywwQkFBMEIsS0FBSyxTQUFTLEtBQUssMEJBQTBCLEtBQUssU0FBUyxLQUFLLDZCQUE2QixLQUFLLFNBQVMsS0FBSyx5QkFBeUIsS0FBSyxTQUFTLEtBQUssd0JBQXdCLEtBQUssU0FBUyxLQUFLO0FBQzdQO0FBQ0EsU0FBUywwQkFBMEIsTUFBTTtBQUN2QyxTQUFPLEtBQUssU0FBUyxLQUFLLG9CQUFvQixvQkFBb0IsSUFBSTtBQUN4RTtBQUNBLFNBQVMsb0JBQW9CLE1BQU07QUFDakMsU0FBTyxLQUFLLFNBQVMsS0FBSyx5QkFBeUIsS0FBSyxTQUFTLEtBQUsseUJBQXlCLEtBQUssU0FBUyxLQUFLLDRCQUE0QixLQUFLLFNBQVMsS0FBSyx3QkFBd0IsS0FBSyxTQUFTLEtBQUssdUJBQXVCLEtBQUssU0FBUyxLQUFLO0FBQ3hQO0FBR0EsU0FBUywwQkFBMEIsU0FBUztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTLE1BQU07QUFDYixpQkFBVyxjQUFjLEtBQUssYUFBYTtBQUN6QyxZQUFJLENBQUMsMkJBQTJCLFVBQVUsR0FBRztBQUMzQyxnQkFBTSxVQUFVLFdBQVcsU0FBUyxLQUFLLHFCQUFxQixXQUFXLFNBQVMsS0FBSyxtQkFBbUIsV0FBVyxNQUFNLFdBQVcsS0FBSyxRQUFRO0FBQ25KLGtCQUFRO0FBQUEsWUFDTixJQUFJLGFBQWEsT0FBTyxPQUFPLGtDQUFrQztBQUFBLGNBQy9ELE9BQU87QUFBQSxZQUNULENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsd0JBQXdCLFNBQVM7QUFDeEMsU0FBTztBQUFBLElBQ0wsTUFBTSxNQUFNO0FBQ1YsWUFBTSxPQUFPLFFBQVEsY0FBYztBQUNuQyxVQUFJLE1BQU07QUFDUixjQUFNLFdBQVcsUUFBUSxZQUFZO0FBQ3JDLFlBQUksQ0FBQyxVQUFVO0FBQ2IsZ0JBQU0sU0FBUyxRQUFRLFVBQVU7QUFDakMsZ0JBQU0sWUFBWSxLQUFLLEtBQUs7QUFDNUIsY0FBSSxhQUFhO0FBQUEsWUFDZjtBQUFBLFlBQ0Esc0JBQXNCLFFBQVEsTUFBTSxTQUFTO0FBQUEsVUFDL0M7QUFDQSxjQUFJLGVBQWUsSUFBSTtBQUNyQix5QkFBYSxXQUFXLHVCQUF1QixNQUFNLFNBQVMsQ0FBQztBQUFBLFVBQ2pFO0FBQ0Esa0JBQVE7QUFBQSxZQUNOLElBQUk7QUFBQSxjQUNGLHVCQUF1QixTQUFTLGNBQWMsS0FBSyxJQUFJLE9BQU87QUFBQSxjQUM5RDtBQUFBLGdCQUNFLE9BQU87QUFBQSxjQUNUO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQixRQUFRLE1BQU0sV0FBVztBQUN0RCxNQUFJLENBQUMsZUFBZSxJQUFJLEdBQUc7QUFDekIsV0FBTyxDQUFDO0FBQUEsRUFDVjtBQUNBLFFBQU0saUJBQWlDLG9CQUFJLElBQUk7QUFDL0MsUUFBTSxhQUE2Qix1QkFBTyxPQUFPLElBQUk7QUFDckQsYUFBVyxnQkFBZ0IsT0FBTyxpQkFBaUIsSUFBSSxHQUFHO0FBQ3hELFFBQUksQ0FBQyxhQUFhLFVBQVUsRUFBRSxTQUFTLEdBQUc7QUFDeEM7QUFBQSxJQUNGO0FBQ0EsbUJBQWUsSUFBSSxZQUFZO0FBQy9CLGVBQVcsYUFBYSxJQUFJLElBQUk7QUFDaEMsZUFBVyxxQkFBcUIsYUFBYSxjQUFjLEdBQUc7QUFDNUQsVUFBSTtBQUNKLFVBQUksQ0FBQyxrQkFBa0IsVUFBVSxFQUFFLFNBQVMsR0FBRztBQUM3QztBQUFBLE1BQ0Y7QUFDQSxxQkFBZSxJQUFJLGlCQUFpQjtBQUNwQyxpQkFBVyxrQkFBa0IsSUFBSSxNQUFNLHdCQUF3QixXQUFXLGtCQUFrQixJQUFJLE9BQU8sUUFBUSwwQkFBMEIsU0FBUyx3QkFBd0IsS0FBSztBQUFBLElBQ2pMO0FBQUEsRUFDRjtBQUNBLFNBQU8sQ0FBQyxHQUFHLGNBQWMsRUFBRSxLQUFLLENBQUMsT0FBTyxVQUFVO0FBQ2hELFVBQU0saUJBQWlCLFdBQVcsTUFBTSxJQUFJLElBQUksV0FBVyxNQUFNLElBQUk7QUFDckUsUUFBSSxtQkFBbUIsR0FBRztBQUN4QixhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUksZ0JBQWdCLEtBQUssS0FBSyxPQUFPLFVBQVUsT0FBTyxLQUFLLEdBQUc7QUFDNUQsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLGdCQUFnQixLQUFLLEtBQUssT0FBTyxVQUFVLE9BQU8sS0FBSyxHQUFHO0FBQzVELGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTyxlQUFlLE1BQU0sTUFBTSxNQUFNLElBQUk7QUFBQSxFQUM5QyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJO0FBQ3RCO0FBQ0EsU0FBUyx1QkFBdUIsTUFBTSxXQUFXO0FBQy9DLE1BQUksYUFBYSxJQUFJLEtBQUssZ0JBQWdCLElBQUksR0FBRztBQUMvQyxVQUFNLHFCQUFxQixPQUFPLEtBQUssS0FBSyxVQUFVLENBQUM7QUFDdkQsV0FBTyxlQUFlLFdBQVcsa0JBQWtCO0FBQUEsRUFDckQ7QUFDQSxTQUFPLENBQUM7QUFDVjtBQUdBLFNBQVMsOEJBQThCLFNBQVM7QUFDOUMsU0FBTztBQUFBLElBQ0wsZUFBZSxNQUFNO0FBQ25CLFlBQU0sZ0JBQWdCLEtBQUs7QUFDM0IsVUFBSSxlQUFlO0FBQ2pCLGNBQU0sT0FBTyxZQUFZLFFBQVEsVUFBVSxHQUFHLGFBQWE7QUFDM0QsWUFBSSxRQUFRLENBQUMsZ0JBQWdCLElBQUksR0FBRztBQUNsQyxnQkFBTSxVQUFVLE1BQU0sYUFBYTtBQUNuQyxrQkFBUTtBQUFBLFlBQ04sSUFBSTtBQUFBLGNBQ0Ysb0RBQW9ELE9BQU87QUFBQSxjQUMzRDtBQUFBLGdCQUNFLE9BQU87QUFBQSxjQUNUO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLG1CQUFtQixNQUFNO0FBQ3ZCLFlBQU0sT0FBTyxZQUFZLFFBQVEsVUFBVSxHQUFHLEtBQUssYUFBYTtBQUNoRSxVQUFJLFFBQVEsQ0FBQyxnQkFBZ0IsSUFBSSxHQUFHO0FBQ2xDLGNBQU0sVUFBVSxNQUFNLEtBQUssYUFBYTtBQUN4QyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsYUFBYSxLQUFLLEtBQUssS0FBSyw2Q0FBNkMsT0FBTztBQUFBLFlBQ2hGO0FBQUEsY0FDRSxPQUFPLEtBQUs7QUFBQSxZQUNkO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsdUJBQXVCLFNBQVM7QUFDdkMsU0FBTztBQUFBO0FBQUEsSUFFTCxHQUFHLG1DQUFtQyxPQUFPO0FBQUEsSUFDN0MsU0FBUyxTQUFTO0FBQ2hCLFlBQU0sU0FBUyxRQUFRLFlBQVk7QUFDbkMsWUFBTSxXQUFXLFFBQVEsWUFBWTtBQUNyQyxZQUFNLGFBQWEsUUFBUSxjQUFjO0FBQ3pDLFVBQUksQ0FBQyxVQUFVLFlBQVksWUFBWTtBQUNyQyxjQUFNLFVBQVUsUUFBUSxLQUFLO0FBQzdCLGNBQU0saUJBQWlCLFNBQVMsS0FBSyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUk7QUFDMUQsY0FBTSxjQUFjLGVBQWUsU0FBUyxjQUFjO0FBQzFELGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixxQkFBcUIsT0FBTyxlQUFlLFdBQVcsSUFBSSxJQUFJLFNBQVMsSUFBSSxPQUFPLFdBQVcsV0FBVztBQUFBLFlBQ3hHO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLG1DQUFtQyxTQUFTO0FBQ25ELFFBQU0sZ0JBQWdDLHVCQUFPLE9BQU8sSUFBSTtBQUN4RCxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFFBQU0sb0JBQW9CLFNBQVMsT0FBTyxjQUFjLElBQUk7QUFDNUQsYUFBVyxhQUFhLG1CQUFtQjtBQUN6QyxrQkFBYyxVQUFVLElBQUksSUFBSSxVQUFVLEtBQUssSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJO0FBQUEsRUFDdEU7QUFDQSxRQUFNLGlCQUFpQixRQUFRLFlBQVksRUFBRTtBQUM3QyxhQUFXLE9BQU8sZ0JBQWdCO0FBQ2hDLFFBQUksSUFBSSxTQUFTLEtBQUssc0JBQXNCO0FBQzFDLFVBQUk7QUFDSixZQUFNLGFBQWEsaUJBQWlCLElBQUksZUFBZSxRQUFRLG1CQUFtQixTQUFTLGlCQUFpQixDQUFDO0FBQzdHLG9CQUFjLElBQUksS0FBSyxLQUFLLElBQUksVUFBVSxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssS0FBSztBQUFBLElBQ3ZFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLFVBQVUsZUFBZTtBQUN2QixZQUFNLGdCQUFnQixjQUFjLEtBQUs7QUFDekMsWUFBTSxZQUFZLGNBQWMsYUFBYTtBQUM3QyxVQUFJLGNBQWMsYUFBYSxXQUFXO0FBQ3hDLG1CQUFXLFdBQVcsY0FBYyxXQUFXO0FBQzdDLGdCQUFNLFVBQVUsUUFBUSxLQUFLO0FBQzdCLGNBQUksQ0FBQyxVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQ2hDLGtCQUFNLGNBQWMsZUFBZSxTQUFTLFNBQVM7QUFDckQsb0JBQVE7QUFBQSxjQUNOLElBQUk7QUFBQSxnQkFDRixxQkFBcUIsT0FBTyxvQkFBb0IsYUFBYSxPQUFPLFdBQVcsV0FBVztBQUFBLGdCQUMxRjtBQUFBLGtCQUNFLE9BQU87QUFBQSxnQkFDVDtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLG9CQUFvQixTQUFTO0FBQ3BDLFFBQU0sZUFBK0IsdUJBQU8sT0FBTyxJQUFJO0FBQ3ZELFFBQU0sU0FBUyxRQUFRLFVBQVU7QUFDakMsUUFBTSxvQkFBb0IsU0FBUyxPQUFPLGNBQWMsSUFBSTtBQUM1RCxhQUFXLGFBQWEsbUJBQW1CO0FBQ3pDLGlCQUFhLFVBQVUsSUFBSSxJQUFJLFVBQVU7QUFBQSxFQUMzQztBQUNBLFFBQU0saUJBQWlCLFFBQVEsWUFBWSxFQUFFO0FBQzdDLGFBQVcsT0FBTyxnQkFBZ0I7QUFDaEMsUUFBSSxJQUFJLFNBQVMsS0FBSyxzQkFBc0I7QUFDMUMsbUJBQWEsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFVBQVUsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLO0FBQUEsSUFDdkU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsVUFBVSxNQUFNLE1BQU0sU0FBUyxPQUFPLFdBQVc7QUFDL0MsWUFBTSxPQUFPLEtBQUssS0FBSztBQUN2QixZQUFNLFlBQVksYUFBYSxJQUFJO0FBQ25DLFVBQUksQ0FBQyxXQUFXO0FBQ2QsZ0JBQVE7QUFBQSxVQUNOLElBQUksYUFBYSx1QkFBdUIsSUFBSSxNQUFNO0FBQUEsWUFDaEQsT0FBTztBQUFBLFVBQ1QsQ0FBQztBQUFBLFFBQ0g7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxZQUFNLG9CQUFvQiwrQkFBK0IsU0FBUztBQUNsRSxVQUFJLHFCQUFxQixDQUFDLFVBQVUsU0FBUyxpQkFBaUIsR0FBRztBQUMvRCxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsZUFBZSxJQUFJLHdCQUF3QixpQkFBaUI7QUFBQSxZQUM1RDtBQUFBLGNBQ0UsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUywrQkFBK0IsV0FBVztBQUNqRCxRQUFNLFlBQVksVUFBVSxVQUFVLFNBQVMsQ0FBQztBQUNoRCxZQUFVLGFBQWEsV0FBVyxLQUFLO0FBQ3ZDLFVBQVEsVUFBVSxNQUFNO0FBQUEsSUFDdEIsS0FBSyxLQUFLO0FBQ1IsYUFBTyxpQ0FBaUMsVUFBVSxTQUFTO0FBQUEsSUFDN0QsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFDUixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLO0FBQ1IsYUFBTyxrQkFBa0I7QUFBQSxJQUMzQixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUNSLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxLQUFLLHdCQUF3QjtBQUNoQyxZQUFNLGFBQWEsVUFBVSxVQUFVLFNBQVMsQ0FBQztBQUNqRCxnQkFBVSxjQUFjLFdBQVcsS0FBSztBQUN4QyxhQUFPLFdBQVcsU0FBUyxLQUFLLCtCQUErQixrQkFBa0IseUJBQXlCLGtCQUFrQjtBQUFBLElBQzlIO0FBQUEsSUFDQTtBQUNFLGlCQUFXLE9BQU8sc0JBQXNCLFFBQVEsVUFBVSxJQUFJLENBQUM7QUFBQSxFQUNuRTtBQUNGO0FBQ0EsU0FBUyxpQ0FBaUMsV0FBVztBQUNuRCxVQUFRLFdBQVc7QUFBQSxJQUNqQixLQUFLLGtCQUFrQjtBQUNyQixhQUFPLGtCQUFrQjtBQUFBLElBQzNCLEtBQUssa0JBQWtCO0FBQ3JCLGFBQU8sa0JBQWtCO0FBQUEsSUFDM0IsS0FBSyxrQkFBa0I7QUFDckIsYUFBTyxrQkFBa0I7QUFBQSxFQUM3QjtBQUNGO0FBR0EsU0FBUyx1QkFBdUIsU0FBUztBQUN2QyxTQUFPO0FBQUEsSUFDTCxlQUFlLE1BQU07QUFDbkIsWUFBTSxlQUFlLEtBQUssS0FBSztBQUMvQixZQUFNLFdBQVcsUUFBUSxZQUFZLFlBQVk7QUFDakQsVUFBSSxDQUFDLFVBQVU7QUFDYixnQkFBUTtBQUFBLFVBQ04sSUFBSSxhQUFhLHFCQUFxQixZQUFZLE1BQU07QUFBQSxZQUN0RCxPQUFPLEtBQUs7QUFBQSxVQUNkLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLG1CQUFtQixTQUFTO0FBQ25DLFFBQU0sU0FBUyxRQUFRLFVBQVU7QUFDakMsUUFBTSxtQkFBbUIsU0FBUyxPQUFPLFdBQVcsSUFBb0IsdUJBQU8sT0FBTyxJQUFJO0FBQzFGLFFBQU0sZUFBK0IsdUJBQU8sT0FBTyxJQUFJO0FBQ3ZELGFBQVcsT0FBTyxRQUFRLFlBQVksRUFBRSxhQUFhO0FBQ25ELFFBQUkscUJBQXFCLEdBQUcsR0FBRztBQUM3QixtQkFBYSxJQUFJLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDakM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZO0FBQUEsSUFDaEIsR0FBRyxPQUFPLEtBQUssZ0JBQWdCO0FBQUEsSUFDL0IsR0FBRyxPQUFPLEtBQUssWUFBWTtBQUFBLEVBQzdCO0FBQ0EsU0FBTztBQUFBLElBQ0wsVUFBVSxNQUFNLElBQUksUUFBUSxJQUFJLFdBQVc7QUFDekMsWUFBTSxXQUFXLEtBQUssS0FBSztBQUMzQixVQUFJLENBQUMsaUJBQWlCLFFBQVEsS0FBSyxDQUFDLGFBQWEsUUFBUSxHQUFHO0FBQzFELFlBQUk7QUFDSixjQUFNLGtCQUFrQixjQUFjLFVBQVUsQ0FBQyxPQUFPLFFBQVEsZ0JBQWdCLFNBQVMsY0FBYztBQUN2RyxjQUFNLFFBQVEsa0JBQWtCLFFBQVEsVUFBVSxjQUFjO0FBQ2hFLFlBQUksU0FBUyxrQkFBa0IsU0FBUyxRQUFRLEdBQUc7QUFDakQ7QUFBQSxRQUNGO0FBQ0EsY0FBTSxpQkFBaUI7QUFBQSxVQUNyQjtBQUFBLFVBQ0EsUUFBUSxrQkFBa0IsT0FBTyxTQUFTLElBQUk7QUFBQSxRQUNoRDtBQUNBLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixpQkFBaUIsUUFBUSxPQUFPLFdBQVcsY0FBYztBQUFBLFlBQ3pEO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxJQUFJLG9CQUFvQixDQUFDLEdBQUcsc0JBQXNCLEdBQUcsa0JBQWtCLEVBQUU7QUFBQSxFQUN2RSxDQUFDLFNBQVMsS0FBSztBQUNqQjtBQUNBLFNBQVMsVUFBVSxPQUFPO0FBQ3hCLFNBQU8sVUFBVSxVQUFVLDJCQUEyQixLQUFLLEtBQUssMEJBQTBCLEtBQUs7QUFDakc7QUFHQSxTQUFTLDJCQUEyQixTQUFTO0FBQzNDLE1BQUksaUJBQWlCO0FBQ3JCLFNBQU87QUFBQSxJQUNMLFNBQVMsTUFBTTtBQUNiLHVCQUFpQixLQUFLLFlBQVk7QUFBQSxRQUNoQyxDQUFDLGVBQWUsV0FBVyxTQUFTLEtBQUs7QUFBQSxNQUMzQyxFQUFFO0FBQUEsSUFDSjtBQUFBLElBQ0Esb0JBQW9CLE1BQU07QUFDeEIsVUFBSSxDQUFDLEtBQUssUUFBUSxpQkFBaUIsR0FBRztBQUNwQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0Y7QUFBQSxZQUNBO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLHlCQUF5QixTQUFTO0FBQ3pDLE1BQUksTUFBTSxPQUFPO0FBQ2pCLFFBQU0sWUFBWSxRQUFRLFVBQVU7QUFDcEMsUUFBTSxrQkFBa0IsUUFBUSxTQUFTLHFCQUFxQixjQUFjLFFBQVEsY0FBYyxTQUFTLFNBQVMsVUFBVSxhQUFhLFFBQVEsdUJBQXVCLFNBQVMscUJBQXFCLGNBQWMsUUFBUSxjQUFjLFNBQVMsU0FBUyxVQUFVLGFBQWEsT0FBTyxRQUFRLFVBQVUsU0FBUyxRQUFRLGNBQWMsUUFBUSxjQUFjLFNBQVMsU0FBUyxVQUFVLGdCQUFnQixPQUFPLFFBQVEsU0FBUyxTQUFTLE9BQU8sY0FBYyxRQUFRLGNBQWMsU0FBUyxTQUFTLFVBQVUsb0JBQW9CO0FBQzNnQixNQUFJLHlCQUF5QjtBQUM3QixTQUFPO0FBQUEsSUFDTCxpQkFBaUIsTUFBTTtBQUNyQixVQUFJLGdCQUFnQjtBQUNsQixnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0Y7QUFBQSxZQUNBO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsVUFBSSx5QkFBeUIsR0FBRztBQUM5QixnQkFBUTtBQUFBLFVBQ04sSUFBSSxhQUFhLDRDQUE0QztBQUFBLFlBQzNELE9BQU87QUFBQSxVQUNULENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUNBLFFBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyxxQkFBcUIsU0FBUztBQUNyQyxRQUFNLGVBQStCLHVCQUFPLE9BQU8sSUFBSTtBQUN2RCxRQUFNLGFBQWEsQ0FBQztBQUNwQixRQUFNLHdCQUF3Qyx1QkFBTyxPQUFPLElBQUk7QUFDaEUsU0FBTztBQUFBLElBQ0wscUJBQXFCLE1BQU07QUFBQSxJQUMzQixtQkFBbUIsTUFBTTtBQUN2QiwyQkFBcUIsSUFBSTtBQUN6QixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxXQUFTLHFCQUFxQixVQUFVO0FBQ3RDLFFBQUksYUFBYSxTQUFTLEtBQUssS0FBSyxHQUFHO0FBQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sZUFBZSxTQUFTLEtBQUs7QUFDbkMsaUJBQWEsWUFBWSxJQUFJO0FBQzdCLFVBQU0sY0FBYyxRQUFRLG1CQUFtQixTQUFTLFlBQVk7QUFDcEUsUUFBSSxZQUFZLFdBQVcsR0FBRztBQUM1QjtBQUFBLElBQ0Y7QUFDQSwwQkFBc0IsWUFBWSxJQUFJLFdBQVc7QUFDakQsZUFBVyxjQUFjLGFBQWE7QUFDcEMsWUFBTSxhQUFhLFdBQVcsS0FBSztBQUNuQyxZQUFNLGFBQWEsc0JBQXNCLFVBQVU7QUFDbkQsaUJBQVcsS0FBSyxVQUFVO0FBQzFCLFVBQUksZUFBZSxRQUFRO0FBQ3pCLGNBQU0saUJBQWlCLFFBQVEsWUFBWSxVQUFVO0FBQ3JELFlBQUksZ0JBQWdCO0FBQ2xCLCtCQUFxQixjQUFjO0FBQUEsUUFDckM7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLFlBQVksV0FBVyxNQUFNLFVBQVU7QUFDN0MsY0FBTSxVQUFVLFVBQVUsTUFBTSxHQUFHLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxNQUFNLEVBQUUsS0FBSyxRQUFRLEdBQUcsRUFBRSxLQUFLLElBQUk7QUFDckYsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLDJCQUEyQixVQUFVLHFCQUFxQixZQUFZLEtBQUssUUFBUSxPQUFPLE1BQU07QUFBQSxZQUNoRztBQUFBLGNBQ0UsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxJQUFJO0FBQUEsSUFDakI7QUFDQSwwQkFBc0IsWUFBWSxJQUFJO0FBQUEsRUFDeEM7QUFDRjtBQUdBLFNBQVMseUJBQXlCLFNBQVM7QUFDekMsTUFBSSxzQkFBc0MsdUJBQU8sT0FBTyxJQUFJO0FBQzVELFNBQU87QUFBQSxJQUNMLHFCQUFxQjtBQUFBLE1BQ25CLFFBQVE7QUFDTiw4QkFBc0MsdUJBQU8sT0FBTyxJQUFJO0FBQUEsTUFDMUQ7QUFBQSxNQUNBLE1BQU0sV0FBVztBQUNmLGNBQU0sU0FBUyxRQUFRLDJCQUEyQixTQUFTO0FBQzNELG1CQUFXLEVBQUUsS0FBSyxLQUFLLFFBQVE7QUFDN0IsZ0JBQU0sVUFBVSxLQUFLLEtBQUs7QUFDMUIsY0FBSSxvQkFBb0IsT0FBTyxNQUFNLE1BQU07QUFDekMsb0JBQVE7QUFBQSxjQUNOLElBQUk7QUFBQSxnQkFDRixVQUFVLE9BQU8sY0FBYyxPQUFPLGtDQUFrQyxVQUFVLEtBQUssS0FBSyxPQUFPLGNBQWMsT0FBTztBQUFBLGdCQUN4SDtBQUFBLGtCQUNFLE9BQU8sQ0FBQyxNQUFNLFNBQVM7QUFBQSxnQkFDekI7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLG1CQUFtQixNQUFNO0FBQ3ZCLDBCQUFvQixLQUFLLFNBQVMsS0FBSyxLQUFLLElBQUk7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsc0JBQXNCLFNBQVM7QUFDdEMsUUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixRQUFNLGVBQWUsQ0FBQztBQUN0QixTQUFPO0FBQUEsSUFDTCxvQkFBb0IsTUFBTTtBQUN4QixvQkFBYyxLQUFLLElBQUk7QUFDdkIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLG1CQUFtQixNQUFNO0FBQ3ZCLG1CQUFhLEtBQUssSUFBSTtBQUN0QixhQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsVUFBVTtBQUFBLE1BQ1IsUUFBUTtBQUNOLGNBQU0sbUJBQW1DLHVCQUFPLE9BQU8sSUFBSTtBQUMzRCxtQkFBVyxhQUFhLGVBQWU7QUFDckMscUJBQVcsWUFBWSxRQUFRO0FBQUEsWUFDN0I7QUFBQSxVQUNGLEdBQUc7QUFDRCw2QkFBaUIsU0FBUyxLQUFLLEtBQUssSUFBSTtBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUNBLG1CQUFXLGVBQWUsY0FBYztBQUN0QyxnQkFBTSxXQUFXLFlBQVksS0FBSztBQUNsQyxjQUFJLGlCQUFpQixRQUFRLE1BQU0sTUFBTTtBQUN2QyxvQkFBUTtBQUFBLGNBQ04sSUFBSSxhQUFhLGFBQWEsUUFBUSxvQkFBb0I7QUFBQSxnQkFDeEQsT0FBTztBQUFBLGNBQ1QsQ0FBQztBQUFBLFlBQ0g7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyxzQkFBc0IsU0FBUztBQUN0QyxNQUFJLGVBQWUsQ0FBQztBQUNwQixTQUFPO0FBQUEsSUFDTCxxQkFBcUI7QUFBQSxNQUNuQixRQUFRO0FBQ04sdUJBQWUsQ0FBQztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxNQUFNLFdBQVc7QUFDZixjQUFNLG1CQUFtQyx1QkFBTyxPQUFPLElBQUk7QUFDM0QsY0FBTSxTQUFTLFFBQVEsMkJBQTJCLFNBQVM7QUFDM0QsbUJBQVcsRUFBRSxLQUFLLEtBQUssUUFBUTtBQUM3QiwyQkFBaUIsS0FBSyxLQUFLLEtBQUssSUFBSTtBQUFBLFFBQ3RDO0FBQ0EsbUJBQVcsZUFBZSxjQUFjO0FBQ3RDLGdCQUFNLGVBQWUsWUFBWSxTQUFTLEtBQUs7QUFDL0MsY0FBSSxpQkFBaUIsWUFBWSxNQUFNLE1BQU07QUFDM0Msb0JBQVE7QUFBQSxjQUNOLElBQUk7QUFBQSxnQkFDRixVQUFVLE9BQU8sY0FBYyxZQUFZLGlDQUFpQyxVQUFVLEtBQUssS0FBSyxPQUFPLGNBQWMsWUFBWTtBQUFBLGdCQUNqSTtBQUFBLGtCQUNFLE9BQU87QUFBQSxnQkFDVDtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsbUJBQW1CLEtBQUs7QUFDdEIsbUJBQWEsS0FBSyxHQUFHO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLGNBQWMsV0FBVztBQUNoQyxVQUFRLFVBQVUsTUFBTTtBQUFBLElBQ3RCLEtBQUssS0FBSztBQUNSLGFBQU8sRUFBRSxHQUFHLFdBQVcsUUFBUSxXQUFXLFVBQVUsTUFBTSxFQUFFO0FBQUEsSUFDOUQsS0FBSyxLQUFLO0FBQ1IsYUFBTyxFQUFFLEdBQUcsV0FBVyxRQUFRLFVBQVUsT0FBTyxJQUFJLGFBQWEsRUFBRTtBQUFBLElBQ3JFLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUFBLElBQ1YsS0FBSyxLQUFLO0FBQUEsSUFDVixLQUFLLEtBQUs7QUFBQSxJQUNWLEtBQUssS0FBSztBQUNSLGFBQU87QUFBQSxFQUNYO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsUUFBUTtBQUMxQixTQUFPLE9BQU8sSUFBSSxDQUFDLGVBQWU7QUFBQSxJQUNoQyxHQUFHO0FBQUEsSUFDSCxPQUFPLGNBQWMsVUFBVSxLQUFLO0FBQUEsRUFDdEMsRUFBRSxFQUFFO0FBQUEsSUFDRixDQUFDLFFBQVEsV0FBVyxlQUFlLE9BQU8sS0FBSyxPQUFPLE9BQU8sS0FBSyxLQUFLO0FBQUEsRUFDekU7QUFDRjtBQUdBLFNBQVMsY0FBYyxRQUFRO0FBQzdCLE1BQUksTUFBTSxRQUFRLE1BQU0sR0FBRztBQUN6QixXQUFPLE9BQU87QUFBQSxNQUNaLENBQUMsQ0FBQyxjQUFjLFNBQVMsTUFBTSxjQUFjLFlBQVksd0JBQXdCLGNBQWMsU0FBUztBQUFBLElBQzFHLEVBQUUsS0FBSyxPQUFPO0FBQUEsRUFDaEI7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLGlDQUFpQyxTQUFTO0FBQ2pELFFBQU0sd0JBQXdCLElBQUksUUFBUTtBQUMxQyxRQUFNLCtCQUErQyxvQkFBSSxJQUFJO0FBQzdELFNBQU87QUFBQSxJQUNMLGFBQWEsY0FBYztBQUN6QixZQUFNLFlBQVk7QUFBQSxRQUNoQjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxRQUFRLGNBQWM7QUFBQSxRQUN0QjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxDQUFDLENBQUMsY0FBYyxNQUFNLEdBQUcsU0FBUyxPQUFPLEtBQUssV0FBVztBQUNsRSxjQUFNLFlBQVksY0FBYyxNQUFNO0FBQ3RDLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixXQUFXLFlBQVksc0JBQXNCLFNBQVM7QUFBQSxZQUN0RDtBQUFBLGNBQ0UsT0FBTyxRQUFRLE9BQU8sT0FBTztBQUFBLFlBQy9CO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsZ0NBQWdDLFNBQVMsOEJBQThCLHVCQUF1QixZQUFZLGNBQWM7QUFDL0gsUUFBTSxZQUFZLENBQUM7QUFDbkIsUUFBTSxDQUFDLFVBQVUsYUFBYSxJQUFJO0FBQUEsSUFDaEM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGNBQWMsV0FBVyxHQUFHO0FBQzlCLGFBQVMsSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQUs7QUFDN0M7QUFBQSxRQUNFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLGNBQWMsQ0FBQztBQUFBLE1BQ2pCO0FBQ0EsZUFBUyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUFLO0FBQ2pEO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBLGNBQWMsQ0FBQztBQUFBLFVBQ2YsY0FBYyxDQUFDO0FBQUEsUUFDakI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLHlDQUF5QyxTQUFTLFdBQVcsOEJBQThCLHVCQUF1QixzQkFBc0IsVUFBVSxjQUFjO0FBQ3ZLLFFBQU0sV0FBVyxRQUFRLFlBQVksWUFBWTtBQUNqRCxNQUFJLENBQUMsVUFBVTtBQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sQ0FBQyxXQUFXLHVCQUF1QixJQUFJO0FBQUEsSUFDM0M7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGFBQWEsV0FBVztBQUMxQjtBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0U7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsYUFBVywwQkFBMEIseUJBQXlCO0FBQzVELFFBQUksc0JBQXNCO0FBQUEsTUFDeEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsR0FBRztBQUNEO0FBQUEsSUFDRjtBQUNBLDBCQUFzQjtBQUFBLE1BQ3BCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0E7QUFBQSxNQUNFO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsaUNBQWlDLFNBQVMsV0FBVyw4QkFBOEIsdUJBQXVCLHNCQUFzQixlQUFlLGVBQWU7QUFDckssTUFBSSxrQkFBa0IsZUFBZTtBQUNuQztBQUFBLEVBQ0Y7QUFDQSxNQUFJLHNCQUFzQjtBQUFBLElBQ3hCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGLEdBQUc7QUFDRDtBQUFBLEVBQ0Y7QUFDQSx3QkFBc0IsSUFBSSxlQUFlLGVBQWUsb0JBQW9CO0FBQzVFLFFBQU0sWUFBWSxRQUFRLFlBQVksYUFBYTtBQUNuRCxRQUFNLFlBQVksUUFBUSxZQUFZLGFBQWE7QUFDbkQsTUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXO0FBQzVCO0FBQUEsRUFDRjtBQUNBLFFBQU0sQ0FBQyxXQUFXLHdCQUF3QixJQUFJO0FBQUEsSUFDNUM7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLENBQUMsV0FBVyx3QkFBd0IsSUFBSTtBQUFBLElBQzVDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0E7QUFBQSxJQUNFO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLGFBQVcsMkJBQTJCLDBCQUEwQjtBQUM5RDtBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLGFBQVcsMkJBQTJCLDBCQUEwQjtBQUM5RDtBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxxQ0FBcUMsU0FBUyw4QkFBOEIsdUJBQXVCLHNCQUFzQixhQUFhLGVBQWUsYUFBYSxlQUFlO0FBQ3hMLFFBQU0sWUFBWSxDQUFDO0FBQ25CLFFBQU0sQ0FBQyxXQUFXLGNBQWMsSUFBSTtBQUFBLElBQ2xDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBLFFBQU0sQ0FBQyxXQUFXLGNBQWMsSUFBSTtBQUFBLElBQ2xDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNBO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxhQUFXLGlCQUFpQixnQkFBZ0I7QUFDMUM7QUFBQSxNQUNFO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLGlCQUFpQixnQkFBZ0I7QUFDMUM7QUFBQSxNQUNFO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLGlCQUFpQixnQkFBZ0I7QUFDMUMsZUFBVyxpQkFBaUIsZ0JBQWdCO0FBQzFDO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsdUJBQXVCLFNBQVMsV0FBVyw4QkFBOEIsdUJBQXVCLFVBQVU7QUFDakgsYUFBVyxDQUFDLGNBQWMsTUFBTSxLQUFLLE9BQU8sUUFBUSxRQUFRLEdBQUc7QUFDN0QsUUFBSSxPQUFPLFNBQVMsR0FBRztBQUNyQixlQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLO0FBQ3RDLGlCQUFTLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7QUFDMUMsZ0JBQU0sV0FBVztBQUFBLFlBQ2Y7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQTtBQUFBLFlBRUE7QUFBQSxZQUNBLE9BQU8sQ0FBQztBQUFBLFlBQ1IsT0FBTyxDQUFDO0FBQUEsVUFDVjtBQUNBLGNBQUksVUFBVTtBQUNaLHNCQUFVLEtBQUssUUFBUTtBQUFBLFVBQ3pCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyx3QkFBd0IsU0FBUyxXQUFXLDhCQUE4Qix1QkFBdUIsa0NBQWtDLFdBQVcsV0FBVztBQUNoSyxhQUFXLENBQUMsY0FBYyxPQUFPLEtBQUssT0FBTyxRQUFRLFNBQVMsR0FBRztBQUMvRCxVQUFNLFVBQVUsVUFBVSxZQUFZO0FBQ3RDLFFBQUksU0FBUztBQUNYLGlCQUFXLFVBQVUsU0FBUztBQUM1QixtQkFBVyxVQUFVLFNBQVM7QUFDNUIsZ0JBQU0sV0FBVztBQUFBLFlBQ2Y7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsY0FBSSxVQUFVO0FBQ1osc0JBQVUsS0FBSyxRQUFRO0FBQUEsVUFDekI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsU0FBUyw4QkFBOEIsdUJBQXVCLGtDQUFrQyxjQUFjLFFBQVEsUUFBUTtBQUNsSixRQUFNLENBQUMsYUFBYSxPQUFPLElBQUksSUFBSTtBQUNuQyxRQUFNLENBQUMsYUFBYSxPQUFPLElBQUksSUFBSTtBQUNuQyxRQUFNLHVCQUF1QixvQ0FBb0MsZ0JBQWdCLGVBQWUsYUFBYSxXQUFXLEtBQUssYUFBYSxXQUFXO0FBQ3JKLE1BQUksQ0FBQyxzQkFBc0I7QUFDekIsVUFBTSxRQUFRLE1BQU0sS0FBSztBQUN6QixVQUFNLFFBQVEsTUFBTSxLQUFLO0FBQ3pCLFFBQUksVUFBVSxPQUFPO0FBQ25CLGFBQU87QUFBQSxRQUNMLENBQUMsY0FBYyxJQUFJLEtBQUssVUFBVSxLQUFLLHdCQUF3QjtBQUFBLFFBQy9ELENBQUMsS0FBSztBQUFBLFFBQ04sQ0FBQyxLQUFLO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsY0FBYyxPQUFPLEtBQUssR0FBRztBQUNoQyxhQUFPO0FBQUEsUUFDTCxDQUFDLGNBQWMsK0JBQStCO0FBQUEsUUFDOUMsQ0FBQyxLQUFLO0FBQUEsUUFDTixDQUFDLEtBQUs7QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFFBQVEsU0FBUyxRQUFRLFNBQVMsU0FBUyxTQUFTLEtBQUs7QUFDL0QsUUFBTSxRQUFRLFNBQVMsUUFBUSxTQUFTLFNBQVMsU0FBUyxLQUFLO0FBQy9ELE1BQUksU0FBUyxTQUFTLGdCQUFnQixPQUFPLEtBQUssR0FBRztBQUNuRCxXQUFPO0FBQUEsTUFDTDtBQUFBLFFBQ0U7QUFBQSxRQUNBLGtDQUFrQyxRQUFRLEtBQUssQ0FBQyxVQUFVO0FBQUEsVUFDeEQ7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsTUFDQSxDQUFDLEtBQUs7QUFBQSxNQUNOLENBQUMsS0FBSztBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxnQkFBZ0IsTUFBTTtBQUM1QixRQUFNLGdCQUFnQixNQUFNO0FBQzVCLE1BQUksaUJBQWlCLGVBQWU7QUFDbEMsVUFBTSxZQUFZO0FBQUEsTUFDaEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLGFBQWEsS0FBSztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxhQUFhLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFDQSxXQUFPLGtCQUFrQixXQUFXLGNBQWMsT0FBTyxLQUFLO0FBQUEsRUFDaEU7QUFDRjtBQUNBLFNBQVMsY0FBYyxPQUFPLE9BQU87QUFDbkMsUUFBTSxRQUFRLE1BQU07QUFDcEIsUUFBTSxRQUFRLE1BQU07QUFDcEIsTUFBSSxVQUFVLFVBQVUsTUFBTSxXQUFXLEdBQUc7QUFDMUMsV0FBTyxVQUFVLFVBQVUsTUFBTSxXQUFXO0FBQUEsRUFDOUM7QUFDQSxNQUFJLFVBQVUsVUFBVSxNQUFNLFdBQVcsR0FBRztBQUMxQyxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksTUFBTSxXQUFXLE1BQU0sUUFBUTtBQUNqQyxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sVUFBVSxJQUFJLElBQUksTUFBTSxJQUFJLENBQUMsRUFBRSxNQUFNLE1BQU0sTUFBTSxDQUFDLEtBQUssT0FBTyxLQUFLLENBQUMsQ0FBQztBQUMzRSxTQUFPLE1BQU0sTUFBTSxDQUFDLFNBQVM7QUFDM0IsVUFBTSxTQUFTLEtBQUs7QUFDcEIsVUFBTSxTQUFTLFFBQVEsSUFBSSxLQUFLLEtBQUssS0FBSztBQUMxQyxRQUFJLFdBQVcsUUFBUTtBQUNyQixhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU8sZUFBZSxNQUFNLE1BQU0sZUFBZSxNQUFNO0FBQUEsRUFDekQsQ0FBQztBQUNIO0FBQ0EsU0FBUyxlQUFlLE9BQU87QUFDN0IsU0FBTyxNQUFNLGNBQWMsS0FBSyxDQUFDO0FBQ25DO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTyxPQUFPO0FBQ3JDLE1BQUksV0FBVyxLQUFLLEdBQUc7QUFDckIsV0FBTyxXQUFXLEtBQUssSUFBSSxnQkFBZ0IsTUFBTSxRQUFRLE1BQU0sTUFBTSxJQUFJO0FBQUEsRUFDM0U7QUFDQSxNQUFJLFdBQVcsS0FBSyxHQUFHO0FBQ3JCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxjQUFjLEtBQUssR0FBRztBQUN4QixXQUFPLGNBQWMsS0FBSyxJQUFJLGdCQUFnQixNQUFNLFFBQVEsTUFBTSxNQUFNLElBQUk7QUFBQSxFQUM5RTtBQUNBLE1BQUksY0FBYyxLQUFLLEdBQUc7QUFDeEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFdBQVcsS0FBSyxLQUFLLFdBQVcsS0FBSyxHQUFHO0FBQzFDLFdBQU8sVUFBVTtBQUFBLEVBQ25CO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUywwQkFBMEIsU0FBUyw4QkFBOEIsWUFBWSxjQUFjO0FBQ2xHLFFBQU0sU0FBUyw2QkFBNkIsSUFBSSxZQUFZO0FBQzVELE1BQUksUUFBUTtBQUNWLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxjQUE4Qix1QkFBTyxPQUFPLElBQUk7QUFDdEQsUUFBTSxnQkFBZ0MsdUJBQU8sT0FBTyxJQUFJO0FBQ3hEO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLENBQUMsYUFBYSxPQUFPLEtBQUssYUFBYSxDQUFDO0FBQ3ZELCtCQUE2QixJQUFJLGNBQWMsTUFBTTtBQUNyRCxTQUFPO0FBQ1Q7QUFDQSxTQUFTLG9DQUFvQyxTQUFTLDhCQUE4QixVQUFVO0FBQzVGLFFBQU0sU0FBUyw2QkFBNkIsSUFBSSxTQUFTLFlBQVk7QUFDckUsTUFBSSxRQUFRO0FBQ1YsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLGVBQWUsWUFBWSxRQUFRLFVBQVUsR0FBRyxTQUFTLGFBQWE7QUFDNUUsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsU0FBUztBQUFBLEVBQ1g7QUFDRjtBQUNBLFNBQVMsK0JBQStCLFNBQVMsWUFBWSxjQUFjLGFBQWEsZUFBZTtBQUNyRyxhQUFXLGFBQWEsYUFBYSxZQUFZO0FBQy9DLFlBQVEsVUFBVSxNQUFNO0FBQUEsTUFDdEIsS0FBSyxLQUFLLE9BQU87QUFDZixjQUFNLFlBQVksVUFBVSxLQUFLO0FBQ2pDLFlBQUk7QUFDSixZQUFJLGFBQWEsVUFBVSxLQUFLLGdCQUFnQixVQUFVLEdBQUc7QUFDM0QscUJBQVcsV0FBVyxVQUFVLEVBQUUsU0FBUztBQUFBLFFBQzdDO0FBQ0EsY0FBTSxlQUFlLFVBQVUsUUFBUSxVQUFVLE1BQU0sUUFBUTtBQUMvRCxZQUFJLENBQUMsWUFBWSxZQUFZLEdBQUc7QUFDOUIsc0JBQVksWUFBWSxJQUFJLENBQUM7QUFBQSxRQUMvQjtBQUNBLG9CQUFZLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWSxXQUFXLFFBQVEsQ0FBQztBQUNoRTtBQUFBLE1BQ0Y7QUFBQSxNQUNBLEtBQUssS0FBSztBQUNSLHNCQUFjLFVBQVUsS0FBSyxLQUFLLElBQUk7QUFDdEM7QUFBQSxNQUNGLEtBQUssS0FBSyxpQkFBaUI7QUFDekIsY0FBTSxnQkFBZ0IsVUFBVTtBQUNoQyxjQUFNLHFCQUFxQixnQkFBZ0IsWUFBWSxRQUFRLFVBQVUsR0FBRyxhQUFhLElBQUk7QUFDN0Y7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0EsVUFBVTtBQUFBLFVBQ1Y7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixXQUFXLGNBQWMsT0FBTyxPQUFPO0FBQ2hFLE1BQUksVUFBVSxTQUFTLEdBQUc7QUFDeEIsV0FBTztBQUFBLE1BQ0wsQ0FBQyxjQUFjLFVBQVUsSUFBSSxDQUFDLENBQUMsTUFBTSxNQUFNLE1BQU0sQ0FBQztBQUFBLE1BQ2xELENBQUMsT0FBTyxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQUMsRUFBRSxPQUFPLE1BQU0sT0FBTyxFQUFFLEtBQUssQ0FBQztBQUFBLE1BQ3pELENBQUMsT0FBTyxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sTUFBTSxPQUFPLEVBQUUsS0FBSyxDQUFDO0FBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxJQUFJLFVBQVUsTUFBTTtBQUFBLEVBQ2xCLGNBQWM7QUFDWixTQUFLLFFBQXdCLG9CQUFJLElBQUk7QUFBQSxFQUN2QztBQUFBLEVBQ0EsSUFBSSxHQUFHLEdBQUcsc0JBQXNCO0FBQzlCLFFBQUk7QUFDSixVQUFNLENBQUMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDM0MsVUFBTSxVQUFVLGtCQUFrQixLQUFLLE1BQU0sSUFBSSxJQUFJLE9BQU8sUUFBUSxvQkFBb0IsU0FBUyxTQUFTLGdCQUFnQixJQUFJLElBQUk7QUFDbEksUUFBSSxXQUFXLFFBQVE7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPLHVCQUF1QixPQUFPLHlCQUF5QjtBQUFBLEVBQ2hFO0FBQUEsRUFDQSxJQUFJLEdBQUcsR0FBRyxzQkFBc0I7QUFDOUIsVUFBTSxDQUFDLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzNDLFVBQU0sTUFBTSxLQUFLLE1BQU0sSUFBSSxJQUFJO0FBQy9CLFFBQUksUUFBUSxRQUFRO0FBQ2xCLFdBQUssTUFBTSxJQUFJLE1BQXNCLG9CQUFJLElBQUksQ0FBQyxDQUFDLE1BQU0sb0JBQW9CLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDOUUsT0FBTztBQUNMLFVBQUksSUFBSSxNQUFNLG9CQUFvQjtBQUFBLElBQ3BDO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyw0QkFBNEIsU0FBUztBQUM1QyxTQUFPO0FBQUEsSUFDTCxlQUFlLE1BQU07QUFDbkIsWUFBTSxXQUFXLFFBQVEsUUFBUTtBQUNqQyxZQUFNLGFBQWEsUUFBUSxjQUFjO0FBQ3pDLFVBQUksZ0JBQWdCLFFBQVEsS0FBSyxnQkFBZ0IsVUFBVSxLQUFLLENBQUMsZUFBZSxRQUFRLFVBQVUsR0FBRyxVQUFVLFVBQVUsR0FBRztBQUMxSCxjQUFNLGdCQUFnQixRQUFRLFVBQVU7QUFDeEMsY0FBTSxjQUFjLFFBQVEsUUFBUTtBQUNwQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0Ysc0RBQXNELGFBQWEsMkJBQTJCLFdBQVc7QUFBQSxZQUN6RztBQUFBLGNBQ0UsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxlQUFlLE1BQU07QUFDbkIsWUFBTSxXQUFXLEtBQUssS0FBSztBQUMzQixZQUFNLFdBQVcsZ0JBQWdCLFNBQVMsUUFBUTtBQUNsRCxZQUFNLGFBQWEsUUFBUSxjQUFjO0FBQ3pDLFVBQUksWUFBWSxjQUFjLENBQUMsZUFBZSxRQUFRLFVBQVUsR0FBRyxVQUFVLFVBQVUsR0FBRztBQUN4RixjQUFNLGdCQUFnQixRQUFRLFVBQVU7QUFDeEMsY0FBTSxjQUFjLFFBQVEsUUFBUTtBQUNwQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsYUFBYSxRQUFRLCtDQUErQyxhQUFhLDJCQUEyQixXQUFXO0FBQUEsWUFDdkg7QUFBQSxjQUNFLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLFNBQVMsTUFBTTtBQUN0QyxRQUFNLE9BQU8sUUFBUSxZQUFZLElBQUk7QUFDckMsTUFBSSxNQUFNO0FBQ1IsVUFBTSxPQUFPLFlBQVksUUFBUSxVQUFVLEdBQUcsS0FBSyxhQUFhO0FBQ2hFLFFBQUksZ0JBQWdCLElBQUksR0FBRztBQUN6QixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsMkJBQTJCLFNBQVM7QUFDM0MsUUFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxRQUFNLGVBQStCLHVCQUFPLE9BQU8sSUFBSTtBQUN2RCxhQUFXLE9BQU8sUUFBUSxZQUFZLEVBQUUsYUFBYTtBQUNuRCxRQUFJLHFCQUFxQixHQUFHLEdBQUc7QUFDN0IsbUJBQWEsSUFBSSxLQUFLLEtBQUssSUFBSTtBQUFBLElBQ2pDO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLHFCQUFxQjtBQUFBLElBQ3JCLHFCQUFxQjtBQUFBLElBQ3JCLHdCQUF3QjtBQUFBLElBQ3hCLG9CQUFvQjtBQUFBLElBQ3BCLG1CQUFtQjtBQUFBLElBQ25CLDBCQUEwQjtBQUFBLEVBQzVCO0FBQ0EsV0FBUyxlQUFlLE1BQU07QUFDNUIsVUFBTSxXQUFXLEtBQUssS0FBSztBQUMzQixVQUFNLFVBQVUsYUFBYSxRQUFRO0FBQ3JDLFVBQU0sZUFBZSxXQUFXLFFBQVEsV0FBVyxTQUFTLFNBQVMsT0FBTyxRQUFRLFFBQVE7QUFDNUYsUUFBSTtBQUNKLFFBQUksU0FBUztBQUNYLHFCQUFlLGlCQUFpQixRQUFRLElBQUk7QUFBQSxJQUM5QyxXQUFXLGNBQWM7QUFDdkIscUJBQWUsY0FBYyxZQUFZO0FBQUEsSUFDM0M7QUFDQSxRQUFJLGNBQWM7QUFDaEIsVUFBSSxpQkFBaUIsS0FBSyxNQUFNO0FBQzlCLGNBQU0sVUFBVSx3QkFBd0IsS0FBSyxJQUFJO0FBQ2pELGdCQUFRO0FBQUEsVUFDTixJQUFJLGFBQWEscUJBQXFCLE9BQU8sVUFBVSxRQUFRLE1BQU07QUFBQSxZQUNuRSxPQUFPLFVBQVUsQ0FBQyxTQUFTLElBQUksSUFBSTtBQUFBLFVBQ3JDLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMLFlBQU0sZUFBZSxPQUFPLEtBQUs7QUFBQSxRQUMvQixHQUFHO0FBQUEsUUFDSCxHQUFHLFdBQVcsUUFBUSxXQUFXLFNBQVMsU0FBUyxPQUFPLFdBQVc7QUFBQSxNQUN2RSxDQUFDO0FBQ0QsWUFBTSxpQkFBaUIsZUFBZSxVQUFVLFlBQVk7QUFDNUQsY0FBUTtBQUFBLFFBQ04sSUFBSTtBQUFBLFVBQ0YsdUJBQXVCLFFBQVEsaUNBQWlDLFdBQVcsY0FBYztBQUFBLFVBQ3pGO0FBQUEsWUFDRSxPQUFPLEtBQUs7QUFBQSxVQUNkO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBQ0EsSUFBSSxtQkFBbUI7QUFBQSxFQUNyQixDQUFDLEtBQUssc0JBQXNCLEdBQUcsS0FBSztBQUFBLEVBQ3BDLENBQUMsS0FBSyxzQkFBc0IsR0FBRyxLQUFLO0FBQUEsRUFDcEMsQ0FBQyxLQUFLLHlCQUF5QixHQUFHLEtBQUs7QUFBQSxFQUN2QyxDQUFDLEtBQUsscUJBQXFCLEdBQUcsS0FBSztBQUFBLEVBQ25DLENBQUMsS0FBSyxvQkFBb0IsR0FBRyxLQUFLO0FBQUEsRUFDbEMsQ0FBQyxLQUFLLDRCQUE0QixHQUFHLEtBQUs7QUFDNUM7QUFDQSxTQUFTLGNBQWMsTUFBTTtBQUMzQixNQUFJLGFBQWEsSUFBSSxHQUFHO0FBQ3RCLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxNQUFJLGFBQWEsSUFBSSxHQUFHO0FBQ3RCLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxNQUFJLGdCQUFnQixJQUFJLEdBQUc7QUFDekIsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLE1BQUksWUFBWSxJQUFJLEdBQUc7QUFDckIsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLE1BQUksV0FBVyxJQUFJLEdBQUc7QUFDcEIsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLE1BQUksa0JBQWtCLElBQUksR0FBRztBQUMzQixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsYUFBVyxPQUFPLHNCQUFzQixRQUFRLElBQUksQ0FBQztBQUN2RDtBQUNBLFNBQVMsd0JBQXdCLE1BQU07QUFDckMsVUFBUSxNQUFNO0FBQUEsSUFDWixLQUFLLEtBQUs7QUFDUixhQUFPO0FBQUEsSUFDVCxLQUFLLEtBQUs7QUFDUixhQUFPO0FBQUEsSUFDVCxLQUFLLEtBQUs7QUFDUixhQUFPO0FBQUEsSUFDVCxLQUFLLEtBQUs7QUFDUixhQUFPO0FBQUEsSUFDVCxLQUFLLEtBQUs7QUFDUixhQUFPO0FBQUEsSUFDVCxLQUFLLEtBQUs7QUFDUixhQUFPO0FBQUEsSUFDVDtBQUNFLGlCQUFXLE9BQU8sc0JBQXNCLFFBQVEsSUFBSSxDQUFDO0FBQUEsRUFDekQ7QUFDRjtBQUdBLFNBQVMsOEJBQThCLFNBQVM7QUFDOUMsU0FBTztBQUFBO0FBQUEsSUFFTCxHQUFHLDBDQUEwQyxPQUFPO0FBQUEsSUFDcEQsT0FBTztBQUFBO0FBQUEsTUFFTCxNQUFNLFdBQVc7QUFDZixZQUFJO0FBQ0osY0FBTSxXQUFXLFFBQVEsWUFBWTtBQUNyQyxZQUFJLENBQUMsVUFBVTtBQUNiLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGNBQU0sZUFBZSxJQUFJO0FBQUE7QUFBQTtBQUFBLFdBR3RCLHVCQUF1QixVQUFVLGVBQWUsUUFBUSx5QkFBeUIsU0FBUyxTQUFTLHFCQUFxQixJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssS0FBSztBQUFBLFFBQ3RKO0FBQ0EsbUJBQVcsVUFBVSxTQUFTLE1BQU07QUFDbEMsY0FBSSxDQUFDLGFBQWEsSUFBSSxPQUFPLElBQUksS0FBSyxtQkFBbUIsTUFBTSxHQUFHO0FBQ2hFLGtCQUFNLGFBQWEsUUFBUSxPQUFPLElBQUk7QUFDdEMsb0JBQVE7QUFBQSxjQUNOLElBQUk7QUFBQSxnQkFDRixVQUFVLFNBQVMsSUFBSSxlQUFlLE9BQU8sSUFBSSxjQUFjLFVBQVU7QUFBQSxnQkFDekU7QUFBQSxrQkFDRSxPQUFPO0FBQUEsZ0JBQ1Q7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFDQSxTQUFTLDBDQUEwQyxTQUFTO0FBQzFELE1BQUk7QUFDSixRQUFNLGtCQUFrQyx1QkFBTyxPQUFPLElBQUk7QUFDMUQsUUFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxRQUFNLHFCQUFxQix3QkFBd0IsV0FBVyxRQUFRLFdBQVcsU0FBUyxTQUFTLE9BQU8sY0FBYyxPQUFPLFFBQVEsMEJBQTBCLFNBQVMsd0JBQXdCO0FBQ2xNLGFBQVcsYUFBYSxtQkFBbUI7QUFDekMsb0JBQWdCLFVBQVUsSUFBSSxJQUFJO0FBQUEsTUFDaEMsVUFBVSxLQUFLLE9BQU8sa0JBQWtCO0FBQUEsTUFDeEMsQ0FBQyxRQUFRLElBQUk7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFFBQU0saUJBQWlCLFFBQVEsWUFBWSxFQUFFO0FBQzdDLGFBQVcsT0FBTyxnQkFBZ0I7QUFDaEMsUUFBSSxJQUFJLFNBQVMsS0FBSyxzQkFBc0I7QUFDMUMsVUFBSTtBQUNKLFlBQU0sWUFBWSxpQkFBaUIsSUFBSSxlQUFlLFFBQVEsbUJBQW1CLFNBQVMsaUJBQWlCLENBQUM7QUFDNUcsc0JBQWdCLElBQUksS0FBSyxLQUFLLElBQUk7QUFBQSxRQUNoQyxTQUFTLE9BQU8sc0JBQXNCO0FBQUEsUUFDdEMsQ0FBQyxRQUFRLElBQUksS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQUEsSUFDTCxXQUFXO0FBQUE7QUFBQSxNQUVULE1BQU0sZUFBZTtBQUNuQixjQUFNLGdCQUFnQixjQUFjLEtBQUs7QUFDekMsY0FBTSxlQUFlLGdCQUFnQixhQUFhO0FBQ2xELFlBQUksY0FBYztBQUNoQixjQUFJO0FBQ0osZ0JBQU0sWUFBWSx3QkFBd0IsY0FBYyxlQUFlLFFBQVEsMEJBQTBCLFNBQVMsd0JBQXdCLENBQUM7QUFDM0ksZ0JBQU0sYUFBYSxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssS0FBSyxDQUFDO0FBQ2hFLHFCQUFXLENBQUMsU0FBUyxNQUFNLEtBQUssT0FBTyxRQUFRLFlBQVksR0FBRztBQUM1RCxnQkFBSSxDQUFDLFdBQVcsSUFBSSxPQUFPLEdBQUc7QUFDNUIsb0JBQU0sVUFBVSxPQUFPLE9BQU8sSUFBSSxJQUFJLFFBQVEsT0FBTyxJQUFJLElBQUksTUFBTSxPQUFPLElBQUk7QUFDOUUsc0JBQVE7QUFBQSxnQkFDTixJQUFJO0FBQUEsa0JBQ0YsZUFBZSxhQUFhLGVBQWUsT0FBTyxjQUFjLE9BQU87QUFBQSxrQkFDdkU7QUFBQSxvQkFDRSxPQUFPO0FBQUEsa0JBQ1Q7QUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsdUJBQXVCLEtBQUs7QUFDbkMsU0FBTyxJQUFJLEtBQUssU0FBUyxLQUFLLGlCQUFpQixJQUFJLGdCQUFnQjtBQUNyRTtBQUdBLFNBQVMsZ0JBQWdCLFNBQVM7QUFDaEMsU0FBTztBQUFBLElBQ0wsTUFBTSxNQUFNO0FBQ1YsWUFBTSxPQUFPLFFBQVEsUUFBUTtBQUM3QixZQUFNLGVBQWUsS0FBSztBQUMxQixVQUFJLE1BQU07QUFDUixZQUFJLFdBQVcsYUFBYSxJQUFJLENBQUMsR0FBRztBQUNsQyxjQUFJLGNBQWM7QUFDaEIsa0JBQU0sWUFBWSxLQUFLLEtBQUs7QUFDNUIsa0JBQU0sVUFBVSxRQUFRLElBQUk7QUFDNUIsb0JBQVE7QUFBQSxjQUNOLElBQUk7QUFBQSxnQkFDRixVQUFVLFNBQVMsMkNBQTJDLE9BQU87QUFBQSxnQkFDckU7QUFBQSxrQkFDRSxPQUFPO0FBQUEsZ0JBQ1Q7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsQ0FBQyxjQUFjO0FBQ3hCLGdCQUFNLFlBQVksS0FBSyxLQUFLO0FBQzVCLGdCQUFNLFVBQVUsUUFBUSxJQUFJO0FBQzVCLGtCQUFRO0FBQUEsWUFDTixJQUFJO0FBQUEsY0FDRixVQUFVLFNBQVMsY0FBYyxPQUFPLHVEQUF1RCxTQUFTO0FBQUEsY0FDeEc7QUFBQSxnQkFDRSxPQUFPO0FBQUEsY0FDVDtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyxhQUFhLFdBQVcsTUFBTSxXQUFXO0FBQ2hELE1BQUksQ0FBQyxXQUFXO0FBQ2Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxVQUFVLFNBQVMsS0FBSyxVQUFVO0FBQ3BDLFVBQU0sZUFBZSxVQUFVLEtBQUs7QUFDcEMsUUFBSSxhQUFhLFFBQVEsVUFBVSxZQUFZLE1BQU0sUUFBUTtBQUMzRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixVQUFVLFlBQVk7QUFDNUMsUUFBSSxrQkFBa0IsUUFBUSxjQUFjLElBQUksR0FBRztBQUNqRDtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksY0FBYyxJQUFJLEdBQUc7QUFDdkIsUUFBSSxVQUFVLFNBQVMsS0FBSyxNQUFNO0FBQ2hDO0FBQUEsSUFDRjtBQUNBLFdBQU8sYUFBYSxXQUFXLEtBQUssUUFBUSxTQUFTO0FBQUEsRUFDdkQ7QUFDQSxNQUFJLFVBQVUsU0FBUyxLQUFLLE1BQU07QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFdBQVcsSUFBSSxHQUFHO0FBQ3BCLFVBQU0sV0FBVyxLQUFLO0FBQ3RCLFFBQUksVUFBVSxTQUFTLEtBQUssTUFBTTtBQUNoQyxZQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLGlCQUFXLFlBQVksVUFBVSxRQUFRO0FBQ3ZDLFlBQUksa0JBQWtCLFVBQVUsU0FBUyxHQUFHO0FBQzFDLGNBQUksY0FBYyxRQUFRLEdBQUc7QUFDM0I7QUFBQSxVQUNGO0FBQ0Esd0JBQWMsS0FBSyxJQUFJO0FBQUEsUUFDekIsT0FBTztBQUNMLGdCQUFNLFlBQVksYUFBYSxVQUFVLFVBQVUsU0FBUztBQUM1RCxjQUFJLGNBQWMsUUFBUTtBQUN4QjtBQUFBLFVBQ0Y7QUFDQSx3QkFBYyxLQUFLLFNBQVM7QUFBQSxRQUM5QjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sZUFBZSxhQUFhLFdBQVcsVUFBVSxTQUFTO0FBQ2hFLFFBQUksaUJBQWlCLFFBQVE7QUFDM0I7QUFBQSxJQUNGO0FBQ0EsV0FBTyxDQUFDLFlBQVk7QUFBQSxFQUN0QjtBQUNBLE1BQUksa0JBQWtCLElBQUksR0FBRztBQUMzQixRQUFJLFVBQVUsU0FBUyxLQUFLLFFBQVE7QUFDbEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUE2Qix1QkFBTyxPQUFPLElBQUk7QUFDckQsVUFBTSxhQUFhLE9BQU8sVUFBVSxRQUFRLENBQUMsVUFBVSxNQUFNLEtBQUssS0FBSztBQUN2RSxlQUFXLFNBQVMsT0FBTyxPQUFPLEtBQUssVUFBVSxDQUFDLEdBQUc7QUFDbkQsWUFBTSxZQUFZLFdBQVcsTUFBTSxJQUFJO0FBQ3ZDLFVBQUksQ0FBQyxhQUFhLGtCQUFrQixVQUFVLE9BQU8sU0FBUyxHQUFHO0FBQy9ELFlBQUksTUFBTSxpQkFBaUIsUUFBUTtBQUNqQyxxQkFBVyxNQUFNLElBQUksSUFBSSxNQUFNO0FBQUEsUUFDakMsV0FBVyxjQUFjLE1BQU0sSUFBSSxHQUFHO0FBQ3BDO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUNBLFlBQU0sYUFBYSxhQUFhLFVBQVUsT0FBTyxNQUFNLE1BQU0sU0FBUztBQUN0RSxVQUFJLGVBQWUsUUFBUTtBQUN6QjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxNQUFNLElBQUksSUFBSTtBQUFBLElBQzNCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJLFdBQVcsSUFBSSxHQUFHO0FBQ3BCLFFBQUk7QUFDSixRQUFJO0FBQ0YsZUFBUyxLQUFLLGFBQWEsV0FBVyxTQUFTO0FBQUEsSUFDakQsU0FBUyxRQUFRO0FBQ2Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxXQUFXLFFBQVE7QUFDckI7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDQSxhQUFXLE9BQU8sNEJBQTRCLFFBQVEsSUFBSSxDQUFDO0FBQzdEO0FBQ0EsU0FBUyxrQkFBa0IsV0FBVyxXQUFXO0FBQy9DLFNBQU8sVUFBVSxTQUFTLEtBQUssYUFBYSxhQUFhLFFBQVEsVUFBVSxVQUFVLEtBQUssS0FBSyxNQUFNO0FBQ3ZHO0FBR0EsU0FBUyxrQkFBa0IsS0FBSyxNQUFNLGdCQUFnQjtBQUNwRCxNQUFJO0FBQ0osUUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixRQUFNLGlCQUFpQixrQkFBa0IsS0FBSyxlQUFlLFFBQVEsb0JBQW9CLFNBQVMsa0JBQWtCLENBQUM7QUFDckgsUUFBTSxhQUFhLE9BQU8sZUFBZSxDQUFDLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDaEUsYUFBVyxVQUFVLElBQUksTUFBTTtBQUM3QixVQUFNLE9BQU8sT0FBTztBQUNwQixVQUFNLFVBQVUsT0FBTztBQUN2QixVQUFNLGVBQWUsV0FBVyxJQUFJO0FBQ3BDLFFBQUksQ0FBQyxjQUFjO0FBQ2pCLFVBQUksT0FBTyxpQkFBaUIsUUFBUTtBQUNsQyxzQkFBYyxJQUFJLElBQUksT0FBTztBQUFBLE1BQy9CLFdBQVcsY0FBYyxPQUFPLEdBQUc7QUFDakMsY0FBTSxJQUFJO0FBQUEsVUFDUixhQUFhLElBQUksdUJBQXVCLFFBQVEsT0FBTyxDQUFDO0FBQUEsVUFDeEQ7QUFBQSxZQUNFLE9BQU87QUFBQSxVQUNUO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksYUFBYTtBQUMvQixRQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUs7QUFDckMsUUFBSSxVQUFVLFNBQVMsS0FBSyxVQUFVO0FBQ3BDLFlBQU0sZUFBZSxVQUFVLEtBQUs7QUFDcEMsVUFBSSxrQkFBa0IsUUFBUSxDQUFDLGVBQWUsZ0JBQWdCLFlBQVksR0FBRztBQUMzRSxZQUFJLE9BQU8saUJBQWlCLFFBQVE7QUFDbEMsd0JBQWMsSUFBSSxJQUFJLE9BQU87QUFBQSxRQUMvQixXQUFXLGNBQWMsT0FBTyxHQUFHO0FBQ2pDLGdCQUFNLElBQUk7QUFBQSxZQUNSLGFBQWEsSUFBSSx1QkFBdUIsUUFBUSxPQUFPLENBQUMsaUNBQWlDLFlBQVk7QUFBQSxZQUNyRztBQUFBLGNBQ0UsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUNBLGVBQVMsZUFBZSxZQUFZLEtBQUs7QUFBQSxJQUMzQztBQUNBLFFBQUksVUFBVSxjQUFjLE9BQU8sR0FBRztBQUNwQyxZQUFNLElBQUk7QUFBQSxRQUNSLGFBQWEsSUFBSSx1QkFBdUIsUUFBUSxPQUFPLENBQUM7QUFBQSxRQUN4RDtBQUFBLFVBQ0UsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU0sZUFBZSxhQUFhLFdBQVcsU0FBUyxjQUFjO0FBQ3BFLFFBQUksaUJBQWlCLFFBQVE7QUFDM0IsWUFBTSxJQUFJO0FBQUEsUUFDUixhQUFhLElBQUksdUJBQXVCLE1BQU0sU0FBUyxDQUFDO0FBQUEsUUFDeEQ7QUFBQSxVQUNFLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxrQkFBYyxJQUFJLElBQUk7QUFBQSxFQUN4QjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsbUJBQW1CLGNBQWMsTUFBTSxnQkFBZ0I7QUFDOUQsTUFBSTtBQUNKLFFBQU0saUJBQWlCLG1CQUFtQixLQUFLLGdCQUFnQixRQUFRLHFCQUFxQixTQUFTLFNBQVMsaUJBQWlCO0FBQUEsSUFDN0gsQ0FBQyxjQUFjLFVBQVUsS0FBSyxVQUFVLGFBQWE7QUFBQSxFQUN2RDtBQUNBLE1BQUksZUFBZTtBQUNqQixXQUFPLGtCQUFrQixjQUFjLGVBQWUsY0FBYztBQUFBLEVBQ3RFO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsS0FBSyxNQUFNO0FBQ2pDLFNBQU8sT0FBTyxVQUFVLGVBQWUsS0FBSyxLQUFLLElBQUk7QUFDdkQ7QUFHQSxTQUFTLGNBQWMsUUFBUSxXQUFXLGdCQUFnQixhQUFhLGNBQWM7QUFDbkYsUUFBTSxTQUF5QixvQkFBSSxJQUFJO0FBQ3ZDO0FBQUEsSUFDRTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDZ0Isb0JBQUksSUFBSTtBQUFBLEVBQzFCO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxXQUFXLGdCQUFnQixZQUFZLFlBQVk7QUFDbkYsUUFBTSxnQkFBZ0Msb0JBQUksSUFBSTtBQUM5QyxRQUFNLHVCQUF1QyxvQkFBSSxJQUFJO0FBQ3JELGFBQVcsUUFBUSxZQUFZO0FBQzdCLFFBQUksS0FBSyxjQUFjO0FBQ3JCO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0w7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUSxXQUFXLGdCQUFnQixhQUFhLGNBQWMsUUFBUSxzQkFBc0I7QUFDckgsYUFBVyxhQUFhLGFBQWEsWUFBWTtBQUMvQyxZQUFRLFVBQVUsTUFBTTtBQUFBLE1BQ3RCLEtBQUssS0FBSyxPQUFPO0FBQ2YsWUFBSSxDQUFDLGtCQUFrQixnQkFBZ0IsU0FBUyxHQUFHO0FBQ2pEO0FBQUEsUUFDRjtBQUNBLGNBQU0sT0FBTyxpQkFBaUIsU0FBUztBQUN2QyxjQUFNLFlBQVksT0FBTyxJQUFJLElBQUk7QUFDakMsWUFBSSxjQUFjLFFBQVE7QUFDeEIsb0JBQVUsS0FBSyxTQUFTO0FBQUEsUUFDMUIsT0FBTztBQUNMLGlCQUFPLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQztBQUFBLFFBQzlCO0FBQ0E7QUFBQSxNQUNGO0FBQUEsTUFDQSxLQUFLLEtBQUssaUJBQWlCO0FBQ3pCLFlBQUksQ0FBQyxrQkFBa0IsZ0JBQWdCLFNBQVMsS0FBSyxDQUFDLDJCQUEyQixRQUFRLFdBQVcsV0FBVyxHQUFHO0FBQ2hIO0FBQUEsUUFDRjtBQUNBO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsVUFBVTtBQUFBLFVBQ1Y7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxLQUFLLGlCQUFpQjtBQUN6QixjQUFNLFdBQVcsVUFBVSxLQUFLO0FBQ2hDLFlBQUkscUJBQXFCLElBQUksUUFBUSxLQUFLLENBQUMsa0JBQWtCLGdCQUFnQixTQUFTLEdBQUc7QUFDdkY7QUFBQSxRQUNGO0FBQ0EsNkJBQXFCLElBQUksUUFBUTtBQUNqQyxjQUFNLFdBQVcsVUFBVSxRQUFRO0FBQ25DLFlBQUksQ0FBQyxZQUFZLENBQUMsMkJBQTJCLFFBQVEsVUFBVSxXQUFXLEdBQUc7QUFDM0U7QUFBQSxRQUNGO0FBQ0E7QUFBQSxVQUNFO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQSxTQUFTO0FBQUEsVUFDVDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLGdCQUFnQixNQUFNO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsc0JBQXNCLE1BQU0sY0FBYztBQUMxRSxPQUFLLFNBQVMsUUFBUSxTQUFTLFNBQVMsU0FBUyxLQUFLLFFBQVEsTUFBTTtBQUNsRSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sVUFBVTtBQUFBLElBQ2Q7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxPQUFLLFlBQVksUUFBUSxZQUFZLFNBQVMsU0FBUyxRQUFRLFFBQVEsT0FBTztBQUM1RSxXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsMkJBQTJCLFFBQVEsVUFBVSxNQUFNO0FBQzFELFFBQU0sb0JBQW9CLFNBQVM7QUFDbkMsTUFBSSxDQUFDLG1CQUFtQjtBQUN0QixXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sa0JBQWtCLFlBQVksUUFBUSxpQkFBaUI7QUFDN0QsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksZUFBZSxlQUFlLEdBQUc7QUFDbkMsV0FBTyxPQUFPLFVBQVUsaUJBQWlCLElBQUk7QUFBQSxFQUMvQztBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLE1BQU07QUFDOUIsU0FBTyxLQUFLLFFBQVEsS0FBSyxNQUFNLFFBQVEsS0FBSyxLQUFLO0FBQ25EO0FBR0EsU0FBUyw2QkFBNkIsU0FBUztBQUM3QyxTQUFPO0FBQUEsSUFDTCxvQkFBb0IsTUFBTTtBQUN4QixVQUFJLEtBQUssY0FBYyxnQkFBZ0I7QUFDckMsY0FBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxjQUFNLG1CQUFtQixPQUFPLG9CQUFvQjtBQUNwRCxZQUFJLGtCQUFrQjtBQUNwQixnQkFBTSxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssS0FBSyxRQUFRO0FBQ3BELGdCQUFNLGlCQUFpQyx1QkFBTyxPQUFPLElBQUk7QUFDekQsZ0JBQU0sWUFBWSxRQUFRLFlBQVk7QUFDdEMsZ0JBQU0sWUFBNEIsdUJBQU8sT0FBTyxJQUFJO0FBQ3BELHFCQUFXLGNBQWMsVUFBVSxhQUFhO0FBQzlDLGdCQUFJLFdBQVcsU0FBUyxLQUFLLHFCQUFxQjtBQUNoRCx3QkFBVSxXQUFXLEtBQUssS0FBSyxJQUFJO0FBQUEsWUFDckM7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sU0FBUztBQUFBLFlBQ2I7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLEtBQUs7QUFBQSxVQUNQO0FBQ0EsY0FBSSxPQUFPLE9BQU8sR0FBRztBQUNuQixrQkFBTSxzQkFBc0IsQ0FBQyxHQUFHLE9BQU8sT0FBTyxDQUFDO0FBQy9DLGtCQUFNLDJCQUEyQixvQkFBb0IsTUFBTSxDQUFDO0FBQzVELGtCQUFNLHVCQUF1Qix5QkFBeUIsS0FBSztBQUMzRCxvQkFBUTtBQUFBLGNBQ04sSUFBSTtBQUFBLGdCQUNGLGlCQUFpQixPQUFPLGlCQUFpQixhQUFhLDRDQUE0QztBQUFBLGdCQUNsRztBQUFBLGtCQUNFLE9BQU87QUFBQSxnQkFDVDtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLHFCQUFXLGNBQWMsT0FBTyxPQUFPLEdBQUc7QUFDeEMsa0JBQU0sUUFBUSxXQUFXLENBQUM7QUFDMUIsa0JBQU0sWUFBWSxNQUFNLEtBQUs7QUFDN0IsZ0JBQUksVUFBVSxXQUFXLElBQUksR0FBRztBQUM5QixzQkFBUTtBQUFBLGdCQUNOLElBQUk7QUFBQSxrQkFDRixpQkFBaUIsT0FBTyxpQkFBaUIsYUFBYSx3REFBd0Q7QUFBQSxrQkFDOUc7QUFBQSxvQkFDRSxPQUFPO0FBQUEsa0JBQ1Q7QUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsUUFBUSxNQUFNLE9BQU87QUFDNUIsUUFBTSxTQUF5QixvQkFBSSxJQUFJO0FBQ3ZDLGFBQVcsUUFBUSxNQUFNO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsVUFBTSxRQUFRLE9BQU8sSUFBSSxHQUFHO0FBQzVCLFFBQUksVUFBVSxRQUFRO0FBQ3BCLGFBQU8sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDO0FBQUEsSUFDeEIsT0FBTztBQUNMLFlBQU0sS0FBSyxJQUFJO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxrQ0FBa0MsU0FBUztBQUNsRCxTQUFPO0FBQUEsSUFDTCxvQkFBb0IsZUFBZTtBQUNqQyxVQUFJO0FBQ0osWUFBTSxpQkFBaUIsd0JBQXdCLGNBQWMsZUFBZSxRQUFRLDBCQUEwQixTQUFTLHdCQUF3QixDQUFDO0FBQ2hKLGFBQU8sbUJBQW1CLElBQUksY0FBYyxLQUFLLEtBQUssSUFBSSxhQUFhO0FBQUEsSUFDekU7QUFBQSxJQUNBLHlCQUF5QjtBQUFBLElBQ3pCLHdCQUF3QjtBQUFBLElBQ3hCLHNCQUFzQjtBQUFBLElBQ3RCLHFCQUFxQjtBQUFBLEVBQ3ZCO0FBQ0EsV0FBUywyQkFBMkIsVUFBVTtBQUM1QyxRQUFJO0FBQ0osVUFBTSxXQUFXLFNBQVMsS0FBSztBQUMvQixVQUFNLGNBQWMsbUJBQW1CLFNBQVMsWUFBWSxRQUFRLHFCQUFxQixTQUFTLG1CQUFtQixDQUFDO0FBQ3RILGVBQVcsWUFBWSxZQUFZO0FBQ2pDLFVBQUk7QUFDSixZQUFNLFlBQVksU0FBUyxLQUFLO0FBQ2hDLFlBQU0saUJBQWlCLHNCQUFzQixTQUFTLGVBQWUsUUFBUSx3QkFBd0IsU0FBUyxzQkFBc0IsQ0FBQztBQUNySSx5QkFBbUIsR0FBRyxRQUFRLElBQUksU0FBUyxJQUFJLGFBQWE7QUFBQSxJQUM5RDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxtQkFBbUIsWUFBWSxlQUFlO0FBQ3JELFVBQU0sV0FBVyxRQUFRLGVBQWUsQ0FBQyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQy9ELGVBQVcsQ0FBQyxTQUFTLFFBQVEsS0FBSyxVQUFVO0FBQzFDLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLGFBQWEsVUFBVSxJQUFJLE9BQU87QUFBQSxZQUNsQztBQUFBLGNBQ0UsT0FBTyxTQUFTLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSTtBQUFBLFlBQ3pDO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFHQSxTQUFTLHdCQUF3QixTQUFTO0FBQ3hDLFNBQU87QUFBQSxJQUNMLE9BQU87QUFBQSxJQUNQLFdBQVc7QUFBQSxFQUNiO0FBQ0EsV0FBUyxtQkFBbUIsWUFBWTtBQUN0QyxRQUFJO0FBQ0osVUFBTSxpQkFBaUIsd0JBQXdCLFdBQVcsZUFBZSxRQUFRLDBCQUEwQixTQUFTLHdCQUF3QixDQUFDO0FBQzdJLFVBQU0sV0FBVyxRQUFRLGVBQWUsQ0FBQyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQy9ELGVBQVcsQ0FBQyxTQUFTLFFBQVEsS0FBSyxVQUFVO0FBQzFDLFVBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLHlDQUF5QyxPQUFPO0FBQUEsWUFDaEQ7QUFBQSxjQUNFLE9BQU8sU0FBUyxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUk7QUFBQSxZQUN6QztBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLHlCQUF5QixTQUFTO0FBQ3pDLFFBQU0sc0JBQXNDLHVCQUFPLE9BQU8sSUFBSTtBQUM5RCxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFNBQU87QUFBQSxJQUNMLG9CQUFvQixNQUFNO0FBQ3hCLFlBQU0sZ0JBQWdCLEtBQUssS0FBSztBQUNoQyxVQUFJLFdBQVcsUUFBUSxXQUFXLFVBQVUsT0FBTyxhQUFhLGFBQWEsR0FBRztBQUM5RSxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsZUFBZSxhQUFhO0FBQUEsWUFDNUI7QUFBQSxjQUNFLE9BQU8sS0FBSztBQUFBLFlBQ2Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBO0FBQUEsTUFDRjtBQUNBLFVBQUksb0JBQW9CLGFBQWEsR0FBRztBQUN0QyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsMkNBQTJDLGFBQWE7QUFBQSxZQUN4RDtBQUFBLGNBQ0UsT0FBTyxDQUFDLG9CQUFvQixhQUFhLEdBQUcsS0FBSyxJQUFJO0FBQUEsWUFDdkQ7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLDRCQUFvQixhQUFhLElBQUksS0FBSztBQUFBLE1BQzVDO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLGdDQUFnQyxTQUFTO0FBQ2hELFFBQU0scUJBQXFDLHVCQUFPLE9BQU8sSUFBSTtBQUM3RCxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFFBQU0sb0JBQW9CLFNBQVMsT0FBTyxjQUFjLElBQUk7QUFDNUQsYUFBVyxhQUFhLG1CQUFtQjtBQUN6Qyx1QkFBbUIsVUFBVSxJQUFJLElBQUksQ0FBQyxVQUFVO0FBQUEsRUFDbEQ7QUFDQSxRQUFNLGlCQUFpQixRQUFRLFlBQVksRUFBRTtBQUM3QyxhQUFXLE9BQU8sZ0JBQWdCO0FBQ2hDLFFBQUksSUFBSSxTQUFTLEtBQUssc0JBQXNCO0FBQzFDLHlCQUFtQixJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsSUFBSTtBQUFBLElBQzVDO0FBQUEsRUFDRjtBQUNBLFFBQU0sbUJBQW1DLHVCQUFPLE9BQU8sSUFBSTtBQUMzRCxRQUFNLG9CQUFvQyx1QkFBTyxPQUFPLElBQUk7QUFDNUQsU0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLElBSUwsTUFBTSxNQUFNO0FBQ1YsVUFBSSxFQUFFLGdCQUFnQixTQUFTLENBQUMsS0FBSyxZQUFZO0FBQy9DO0FBQUEsTUFDRjtBQUNBLFVBQUk7QUFDSixVQUFJLEtBQUssU0FBUyxLQUFLLHFCQUFxQixLQUFLLFNBQVMsS0FBSyxrQkFBa0I7QUFDL0UseUJBQWlCO0FBQUEsTUFDbkIsV0FBVyxxQkFBcUIsSUFBSSxLQUFLLG9CQUFvQixJQUFJLEdBQUc7QUFDbEUsY0FBTSxXQUFXLEtBQUssS0FBSztBQUMzQix5QkFBaUIsa0JBQWtCLFFBQVE7QUFDM0MsWUFBSSxtQkFBbUIsUUFBUTtBQUM3Qiw0QkFBa0IsUUFBUSxJQUFJLGlCQUFpQyx1QkFBTyxPQUFPLElBQUk7QUFBQSxRQUNuRjtBQUFBLE1BQ0YsT0FBTztBQUNMLHlCQUFpQyx1QkFBTyxPQUFPLElBQUk7QUFBQSxNQUNyRDtBQUNBLGlCQUFXLGFBQWEsS0FBSyxZQUFZO0FBQ3ZDLGNBQU0sZ0JBQWdCLFVBQVUsS0FBSztBQUNyQyxZQUFJLG1CQUFtQixhQUFhLEdBQUc7QUFDckMsY0FBSSxlQUFlLGFBQWEsR0FBRztBQUNqQyxvQkFBUTtBQUFBLGNBQ04sSUFBSTtBQUFBLGdCQUNGLG1CQUFtQixhQUFhO0FBQUEsZ0JBQ2hDO0FBQUEsa0JBQ0UsT0FBTyxDQUFDLGVBQWUsYUFBYSxHQUFHLFNBQVM7QUFBQSxnQkFDbEQ7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0YsT0FBTztBQUNMLDJCQUFlLGFBQWEsSUFBSTtBQUFBLFVBQ2xDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUyx5QkFBeUIsU0FBUztBQUN6QyxRQUFNLFNBQVMsUUFBUSxVQUFVO0FBQ2pDLFFBQU0sa0JBQWtCLFNBQVMsT0FBTyxXQUFXLElBQW9CLHVCQUFPLE9BQU8sSUFBSTtBQUN6RixRQUFNLGtCQUFrQyx1QkFBTyxPQUFPLElBQUk7QUFDMUQsU0FBTztBQUFBLElBQ0wsb0JBQW9CO0FBQUEsSUFDcEIsbUJBQW1CO0FBQUEsRUFDckI7QUFDQSxXQUFTLHFCQUFxQixNQUFNO0FBQ2xDLFFBQUk7QUFDSixVQUFNLFdBQVcsS0FBSyxLQUFLO0FBQzNCLFFBQUksQ0FBQyxnQkFBZ0IsUUFBUSxHQUFHO0FBQzlCLHNCQUFnQixRQUFRLElBQW9CLHVCQUFPLE9BQU8sSUFBSTtBQUFBLElBQ2hFO0FBQ0EsVUFBTSxjQUFjLGVBQWUsS0FBSyxZQUFZLFFBQVEsaUJBQWlCLFNBQVMsZUFBZSxDQUFDO0FBQ3RHLFVBQU0sYUFBYSxnQkFBZ0IsUUFBUTtBQUMzQyxlQUFXLFlBQVksWUFBWTtBQUNqQyxZQUFNLFlBQVksU0FBUyxLQUFLO0FBQ2hDLFlBQU0sZUFBZSxnQkFBZ0IsUUFBUTtBQUM3QyxVQUFJLFdBQVcsWUFBWSxLQUFLLGFBQWEsU0FBUyxTQUFTLEdBQUc7QUFDaEUsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLGVBQWUsUUFBUSxJQUFJLFNBQVM7QUFBQSxZQUNwQztBQUFBLGNBQ0UsT0FBTyxTQUFTO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsV0FBVyxXQUFXLFNBQVMsR0FBRztBQUNoQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsZUFBZSxRQUFRLElBQUksU0FBUztBQUFBLFlBQ3BDO0FBQUEsY0FDRSxPQUFPLENBQUMsV0FBVyxTQUFTLEdBQUcsU0FBUyxJQUFJO0FBQUEsWUFDOUM7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLG1CQUFXLFNBQVMsSUFBSSxTQUFTO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLFNBQVMsK0JBQStCLFNBQVM7QUFDL0MsUUFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxRQUFNLGtCQUFrQixTQUFTLE9BQU8sV0FBVyxJQUFvQix1QkFBTyxPQUFPLElBQUk7QUFDekYsUUFBTSxrQkFBa0MsdUJBQU8sT0FBTyxJQUFJO0FBQzFELFNBQU87QUFBQSxJQUNMLDJCQUEyQjtBQUFBLElBQzNCLDBCQUEwQjtBQUFBLElBQzFCLHlCQUF5QjtBQUFBLElBQ3pCLHdCQUF3QjtBQUFBLElBQ3hCLHNCQUFzQjtBQUFBLElBQ3RCLHFCQUFxQjtBQUFBLEVBQ3ZCO0FBQ0EsV0FBUyxxQkFBcUIsTUFBTTtBQUNsQyxRQUFJO0FBQ0osVUFBTSxXQUFXLEtBQUssS0FBSztBQUMzQixRQUFJLENBQUMsZ0JBQWdCLFFBQVEsR0FBRztBQUM5QixzQkFBZ0IsUUFBUSxJQUFvQix1QkFBTyxPQUFPLElBQUk7QUFBQSxJQUNoRTtBQUNBLFVBQU0sY0FBYyxlQUFlLEtBQUssWUFBWSxRQUFRLGlCQUFpQixTQUFTLGVBQWUsQ0FBQztBQUN0RyxVQUFNLGFBQWEsZ0JBQWdCLFFBQVE7QUFDM0MsZUFBVyxZQUFZLFlBQVk7QUFDakMsWUFBTSxZQUFZLFNBQVMsS0FBSztBQUNoQyxVQUFJLFNBQVMsZ0JBQWdCLFFBQVEsR0FBRyxTQUFTLEdBQUc7QUFDbEQsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLFVBQVUsUUFBUSxJQUFJLFNBQVM7QUFBQSxZQUMvQjtBQUFBLGNBQ0UsT0FBTyxTQUFTO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsV0FBVyxXQUFXLFNBQVMsR0FBRztBQUNoQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsVUFBVSxRQUFRLElBQUksU0FBUztBQUFBLFlBQy9CO0FBQUEsY0FDRSxPQUFPLENBQUMsV0FBVyxTQUFTLEdBQUcsU0FBUyxJQUFJO0FBQUEsWUFDOUM7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLG1CQUFXLFNBQVMsSUFBSSxTQUFTO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLFNBQVMsU0FBUyxNQUFNLFdBQVc7QUFDakMsTUFBSSxhQUFhLElBQUksS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQUc7QUFDMUUsV0FBTyxLQUFLLFVBQVUsRUFBRSxTQUFTLEtBQUs7QUFBQSxFQUN4QztBQUNBLFNBQU87QUFDVDtBQUdBLFNBQVMsd0JBQXdCLFNBQVM7QUFDeEMsUUFBTSxxQkFBcUMsdUJBQU8sT0FBTyxJQUFJO0FBQzdELFNBQU87QUFBQSxJQUNMLHFCQUFxQixNQUFNO0FBQUEsSUFDM0IsbUJBQW1CLE1BQU07QUFDdkIsWUFBTSxlQUFlLEtBQUssS0FBSztBQUMvQixVQUFJLG1CQUFtQixZQUFZLEdBQUc7QUFDcEMsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLHlDQUF5QyxZQUFZO0FBQUEsWUFDckQ7QUFBQSxjQUNFLE9BQU8sQ0FBQyxtQkFBbUIsWUFBWSxHQUFHLEtBQUssSUFBSTtBQUFBLFlBQ3JEO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTCwyQkFBbUIsWUFBWSxJQUFJLEtBQUs7QUFBQSxNQUMxQztBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUywwQkFBMEIsU0FBUztBQUMxQyxRQUFNLGlCQUFpQixDQUFDO0FBQ3hCLE1BQUksYUFBNkIsdUJBQU8sT0FBTyxJQUFJO0FBQ25ELFNBQU87QUFBQSxJQUNMLGFBQWE7QUFBQSxNQUNYLFFBQVE7QUFDTix1QkFBZSxLQUFLLFVBQVU7QUFDOUIscUJBQTZCLHVCQUFPLE9BQU8sSUFBSTtBQUFBLE1BQ2pEO0FBQUEsTUFDQSxRQUFRO0FBQ04sY0FBTSxpQkFBaUIsZUFBZSxJQUFJO0FBQzFDLDBCQUFrQixXQUFXLEtBQUs7QUFDbEMscUJBQWE7QUFBQSxNQUNmO0FBQUEsSUFDRjtBQUFBLElBQ0EsWUFBWSxNQUFNO0FBQ2hCLFlBQU0sWUFBWSxLQUFLLEtBQUs7QUFDNUIsVUFBSSxXQUFXLFNBQVMsR0FBRztBQUN6QixnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsNENBQTRDLFNBQVM7QUFBQSxZQUNyRDtBQUFBLGNBQ0UsT0FBTyxDQUFDLFdBQVcsU0FBUyxHQUFHLEtBQUssSUFBSTtBQUFBLFlBQzFDO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTCxtQkFBVyxTQUFTLElBQUksS0FBSztBQUFBLE1BQy9CO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMseUJBQXlCLFNBQVM7QUFDekMsUUFBTSxzQkFBc0MsdUJBQU8sT0FBTyxJQUFJO0FBQzlELFNBQU87QUFBQSxJQUNMLG9CQUFvQixNQUFNO0FBQ3hCLFlBQU0sZ0JBQWdCLEtBQUs7QUFDM0IsVUFBSSxlQUFlO0FBQ2pCLFlBQUksb0JBQW9CLGNBQWMsS0FBSyxHQUFHO0FBQzVDLGtCQUFRO0FBQUEsWUFDTixJQUFJO0FBQUEsY0FDRiwwQ0FBMEMsY0FBYyxLQUFLO0FBQUEsY0FDN0Q7QUFBQSxnQkFDRSxPQUFPO0FBQUEsa0JBQ0wsb0JBQW9CLGNBQWMsS0FBSztBQUFBLGtCQUN2QztBQUFBLGdCQUNGO0FBQUEsY0FDRjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRixPQUFPO0FBQ0wsOEJBQW9CLGNBQWMsS0FBSyxJQUFJO0FBQUEsUUFDN0M7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLG9CQUFvQixNQUFNO0FBQUEsRUFDNUI7QUFDRjtBQUdBLFNBQVMseUJBQXlCLFNBQVM7QUFDekMsUUFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxRQUFNLHdCQUF3Qyx1QkFBTyxPQUFPLElBQUk7QUFDaEUsUUFBTSx5QkFBeUIsU0FBUztBQUFBLElBQ3RDLE9BQU8sT0FBTyxhQUFhO0FBQUEsSUFDM0IsVUFBVSxPQUFPLGdCQUFnQjtBQUFBLElBQ2pDLGNBQWMsT0FBTyxvQkFBb0I7QUFBQSxFQUMzQyxJQUFJLENBQUM7QUFDTCxTQUFPO0FBQUEsSUFDTCxrQkFBa0I7QUFBQSxJQUNsQixpQkFBaUI7QUFBQSxFQUNuQjtBQUNBLFdBQVMsb0JBQW9CLE1BQU07QUFDakMsUUFBSTtBQUNKLFVBQU0sdUJBQXVCLHVCQUF1QixLQUFLLG9CQUFvQixRQUFRLHlCQUF5QixTQUFTLHVCQUF1QixDQUFDO0FBQy9JLGVBQVcsaUJBQWlCLHFCQUFxQjtBQUMvQyxZQUFNLFlBQVksY0FBYztBQUNoQyxZQUFNLDhCQUE4QixzQkFBc0IsU0FBUztBQUNuRSxVQUFJLHVCQUF1QixTQUFTLEdBQUc7QUFDckMsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLFlBQVksU0FBUztBQUFBLFlBQ3JCO0FBQUEsY0FDRSxPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixXQUFXLDZCQUE2QjtBQUN0QyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YseUJBQXlCLFNBQVM7QUFBQSxZQUNsQztBQUFBLGNBQ0UsT0FBTyxDQUFDLDZCQUE2QixhQUFhO0FBQUEsWUFDcEQ7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLDhCQUFzQixTQUFTLElBQUk7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBR0EsU0FBUyxvQkFBb0IsU0FBUztBQUNwQyxRQUFNLGlCQUFpQyx1QkFBTyxPQUFPLElBQUk7QUFDekQsUUFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxTQUFPO0FBQUEsSUFDTCxzQkFBc0I7QUFBQSxJQUN0QixzQkFBc0I7QUFBQSxJQUN0Qix5QkFBeUI7QUFBQSxJQUN6QixxQkFBcUI7QUFBQSxJQUNyQixvQkFBb0I7QUFBQSxJQUNwQiwyQkFBMkI7QUFBQSxFQUM3QjtBQUNBLFdBQVMsY0FBYyxNQUFNO0FBQzNCLFVBQU0sV0FBVyxLQUFLLEtBQUs7QUFDM0IsUUFBSSxXQUFXLFFBQVEsV0FBVyxVQUFVLE9BQU8sUUFBUSxRQUFRLEdBQUc7QUFDcEUsY0FBUTtBQUFBLFFBQ04sSUFBSTtBQUFBLFVBQ0YsU0FBUyxRQUFRO0FBQUEsVUFDakI7QUFBQSxZQUNFLE9BQU8sS0FBSztBQUFBLFVBQ2Q7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksZUFBZSxRQUFRLEdBQUc7QUFDNUIsY0FBUTtBQUFBLFFBQ04sSUFBSSxhQUFhLHFDQUFxQyxRQUFRLE1BQU07QUFBQSxVQUNsRSxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUcsS0FBSyxJQUFJO0FBQUEsUUFDN0MsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLE9BQU87QUFDTCxxQkFBZSxRQUFRLElBQUksS0FBSztBQUFBLElBQ2xDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLFNBQVMsd0JBQXdCLFNBQVM7QUFDeEMsU0FBTztBQUFBLElBQ0wsb0JBQW9CLGVBQWU7QUFDakMsVUFBSTtBQUNKLFlBQU0sdUJBQXVCLHdCQUF3QixjQUFjLHlCQUF5QixRQUFRLDBCQUEwQixTQUFTLHdCQUF3QixDQUFDO0FBQ2hLLFlBQU0sMEJBQTBCO0FBQUEsUUFDOUI7QUFBQSxRQUNBLENBQUMsU0FBUyxLQUFLLFNBQVMsS0FBSztBQUFBLE1BQy9CO0FBQ0EsaUJBQVcsQ0FBQyxjQUFjLGFBQWEsS0FBSyx5QkFBeUI7QUFDbkUsWUFBSSxjQUFjLFNBQVMsR0FBRztBQUM1QixrQkFBUTtBQUFBLFlBQ04sSUFBSTtBQUFBLGNBQ0YsMENBQTBDLFlBQVk7QUFBQSxjQUN0RDtBQUFBLGdCQUNFLE9BQU8sY0FBYyxJQUFJLENBQUMsU0FBUyxLQUFLLFNBQVMsSUFBSTtBQUFBLGNBQ3ZEO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLHdCQUF3QixTQUFTO0FBQ3hDLFNBQU87QUFBQSxJQUNMLFVBQVUsTUFBTTtBQUNkLFlBQU0sT0FBTyxnQkFBZ0IsUUFBUSxtQkFBbUIsQ0FBQztBQUN6RCxVQUFJLENBQUMsV0FBVyxJQUFJLEdBQUc7QUFDckIseUJBQWlCLFNBQVMsSUFBSTtBQUM5QixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxJQUNBLFlBQVksTUFBTTtBQUNoQixZQUFNLE9BQU8sYUFBYSxRQUFRLGFBQWEsQ0FBQztBQUNoRCxVQUFJLENBQUMsa0JBQWtCLElBQUksR0FBRztBQUM1Qix5QkFBaUIsU0FBUyxJQUFJO0FBQzlCLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxlQUFlLE9BQU8sS0FBSyxRQUFRLENBQUMsVUFBVSxNQUFNLEtBQUssS0FBSztBQUNwRSxpQkFBVyxZQUFZLE9BQU8sT0FBTyxLQUFLLFVBQVUsQ0FBQyxHQUFHO0FBQ3RELGNBQU0sWUFBWSxhQUFhLFNBQVMsSUFBSTtBQUM1QyxZQUFJLENBQUMsYUFBYSxxQkFBcUIsUUFBUSxHQUFHO0FBQ2hELGdCQUFNLFVBQVUsUUFBUSxTQUFTLElBQUk7QUFDckMsa0JBQVE7QUFBQSxZQUNOLElBQUk7QUFBQSxjQUNGLFVBQVUsS0FBSyxJQUFJLElBQUksU0FBUyxJQUFJLHVCQUF1QixPQUFPO0FBQUEsY0FDbEU7QUFBQSxnQkFDRSxPQUFPO0FBQUEsY0FDVDtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxZQUFZLE1BQU07QUFDaEIsWUFBTSxhQUFhLGFBQWEsUUFBUSxtQkFBbUIsQ0FBQztBQUM1RCxZQUFNLFlBQVksUUFBUSxhQUFhO0FBQ3ZDLFVBQUksQ0FBQyxhQUFhLGtCQUFrQixVQUFVLEdBQUc7QUFDL0MsY0FBTSxjQUFjO0FBQUEsVUFDbEIsS0FBSyxLQUFLO0FBQUEsVUFDVixPQUFPLEtBQUssV0FBVyxVQUFVLENBQUM7QUFBQSxRQUNwQztBQUNBLGdCQUFRO0FBQUEsVUFDTixJQUFJO0FBQUEsWUFDRixVQUFVLEtBQUssS0FBSyxLQUFLLDZCQUE2QixXQUFXLElBQUksT0FBTyxXQUFXLFdBQVc7QUFBQSxZQUNsRztBQUFBLGNBQ0UsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxVQUFVLE1BQU07QUFDZCxZQUFNLE9BQU8sUUFBUSxhQUFhO0FBQ2xDLFVBQUksY0FBYyxJQUFJLEdBQUc7QUFDdkIsZ0JBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxZQUNGLDJCQUEyQixRQUFRLElBQUksQ0FBQyxZQUFZLE1BQU0sSUFBSSxDQUFDO0FBQUEsWUFDL0Q7QUFBQSxjQUNFLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsV0FBVyxDQUFDLFNBQVMsaUJBQWlCLFNBQVMsSUFBSTtBQUFBLElBQ25ELFVBQVUsQ0FBQyxTQUFTLGlCQUFpQixTQUFTLElBQUk7QUFBQSxJQUNsRCxZQUFZLENBQUMsU0FBUyxpQkFBaUIsU0FBUyxJQUFJO0FBQUEsSUFDcEQsYUFBYSxDQUFDLFNBQVMsaUJBQWlCLFNBQVMsSUFBSTtBQUFBLElBQ3JELGNBQWMsQ0FBQyxTQUFTLGlCQUFpQixTQUFTLElBQUk7QUFBQSxFQUN4RDtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3ZDLFFBQU0sZUFBZSxRQUFRLGFBQWE7QUFDMUMsTUFBSSxDQUFDLGNBQWM7QUFDakI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGFBQWEsWUFBWTtBQUN0QyxNQUFJLENBQUMsV0FBVyxJQUFJLEdBQUc7QUFDckIsVUFBTSxVQUFVLFFBQVEsWUFBWTtBQUNwQyxZQUFRO0FBQUEsTUFDTixJQUFJO0FBQUEsUUFDRiwyQkFBMkIsT0FBTyxZQUFZLE1BQU0sSUFBSSxDQUFDO0FBQUEsUUFDekQ7QUFBQSxVQUNFLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxjQUFjLEtBQUs7QUFBQSxNQUN2QjtBQUFBLE1BQ0E7QUFBQTtBQUFBLElBRUY7QUFDQSxRQUFJLGdCQUFnQixRQUFRO0FBQzFCLFlBQU0sVUFBVSxRQUFRLFlBQVk7QUFDcEMsY0FBUTtBQUFBLFFBQ04sSUFBSTtBQUFBLFVBQ0YsMkJBQTJCLE9BQU8sWUFBWSxNQUFNLElBQUksQ0FBQztBQUFBLFVBQ3pEO0FBQUEsWUFDRSxPQUFPO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsU0FBUyxPQUFPO0FBQ2QsVUFBTSxVQUFVLFFBQVEsWUFBWTtBQUNwQyxRQUFJLGlCQUFpQixjQUFjO0FBQ2pDLGNBQVEsWUFBWSxLQUFLO0FBQUEsSUFDM0IsT0FBTztBQUNMLGNBQVE7QUFBQSxRQUNOLElBQUk7QUFBQSxVQUNGLDJCQUEyQixPQUFPLFlBQVksTUFBTSxJQUFJLENBQUMsT0FBTyxNQUFNO0FBQUEsVUFDdEU7QUFBQSxZQUNFLE9BQU87QUFBQSxZQUNQLGVBQWU7QUFBQSxVQUNqQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLFNBQVMsMkJBQTJCLFNBQVM7QUFDM0MsU0FBTztBQUFBLElBQ0wsbUJBQW1CLE1BQU07QUFDdkIsWUFBTSxPQUFPLFlBQVksUUFBUSxVQUFVLEdBQUcsS0FBSyxJQUFJO0FBQ3ZELFVBQUksU0FBUyxVQUFVLENBQUMsWUFBWSxJQUFJLEdBQUc7QUFDekMsY0FBTSxlQUFlLEtBQUssU0FBUyxLQUFLO0FBQ3hDLGNBQU0sV0FBVyxNQUFNLEtBQUssSUFBSTtBQUNoQyxnQkFBUTtBQUFBLFVBQ04sSUFBSTtBQUFBLFlBQ0YsY0FBYyxZQUFZLCtCQUErQixRQUFRO0FBQUEsWUFDakU7QUFBQSxjQUNFLE9BQU8sS0FBSztBQUFBLFlBQ2Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBR0EsU0FBUywrQkFBK0IsU0FBUztBQUMvQyxNQUFJLFlBQTRCLHVCQUFPLE9BQU8sSUFBSTtBQUNsRCxTQUFPO0FBQUEsSUFDTCxxQkFBcUI7QUFBQSxNQUNuQixRQUFRO0FBQ04sb0JBQTRCLHVCQUFPLE9BQU8sSUFBSTtBQUFBLE1BQ2hEO0FBQUEsTUFDQSxNQUFNLFdBQVc7QUFDZixjQUFNLFNBQVMsUUFBUSwyQkFBMkIsU0FBUztBQUMzRCxtQkFBVyxFQUFFLE1BQU0sTUFBTSxhQUFhLEtBQUssUUFBUTtBQUNqRCxnQkFBTSxVQUFVLEtBQUssS0FBSztBQUMxQixnQkFBTSxTQUFTLFVBQVUsT0FBTztBQUNoQyxjQUFJLFVBQVUsTUFBTTtBQUNsQixrQkFBTSxTQUFTLFFBQVEsVUFBVTtBQUNqQyxrQkFBTSxVQUFVLFlBQVksUUFBUSxPQUFPLElBQUk7QUFDL0MsZ0JBQUksV0FBVyxDQUFDO0FBQUEsY0FDZDtBQUFBLGNBQ0E7QUFBQSxjQUNBLE9BQU87QUFBQSxjQUNQO0FBQUEsY0FDQTtBQUFBLFlBQ0YsR0FBRztBQUNELG9CQUFNLGFBQWEsUUFBUSxPQUFPO0FBQ2xDLG9CQUFNLFVBQVUsUUFBUSxJQUFJO0FBQzVCLHNCQUFRO0FBQUEsZ0JBQ04sSUFBSTtBQUFBLGtCQUNGLGNBQWMsT0FBTyxjQUFjLFVBQVUsc0NBQXNDLE9BQU87QUFBQSxrQkFDMUY7QUFBQSxvQkFDRSxPQUFPLENBQUMsUUFBUSxJQUFJO0FBQUEsa0JBQ3RCO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLG1CQUFtQixNQUFNO0FBQ3ZCLGdCQUFVLEtBQUssU0FBUyxLQUFLLEtBQUssSUFBSTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsUUFBUSxTQUFTLGlCQUFpQixjQUFjLHNCQUFzQjtBQUNsRyxNQUFJLGNBQWMsWUFBWSxLQUFLLENBQUMsY0FBYyxPQUFPLEdBQUc7QUFDMUQsVUFBTSxpQ0FBaUMsbUJBQW1CLFFBQVEsZ0JBQWdCLFNBQVMsS0FBSztBQUNoRyxVQUFNLDBCQUEwQix5QkFBeUI7QUFDekQsUUFBSSxDQUFDLGtDQUFrQyxDQUFDLHlCQUF5QjtBQUMvRCxhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sdUJBQXVCLGFBQWE7QUFDMUMsV0FBTyxnQkFBZ0IsUUFBUSxTQUFTLG9CQUFvQjtBQUFBLEVBQzlEO0FBQ0EsU0FBTyxnQkFBZ0IsUUFBUSxTQUFTLFlBQVk7QUFDdEQ7QUFHQSxJQUFJLGlCQUFpQixPQUFPLE9BQU87QUFBQSxFQUNqQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBQ0QsSUFBSSxvQkFBb0IsT0FBTyxPQUFPO0FBQUEsRUFDcEM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFHRCxTQUFTLFNBQVMsSUFBSTtBQUNwQixNQUFJO0FBQ0osU0FBTyxTQUFTLFNBQVMsSUFBSSxJQUFJLElBQUk7QUFDbkMsUUFBSSxXQUFXLFFBQVE7QUFDckIsZUFBeUIsb0JBQUksUUFBUTtBQUFBLElBQ3ZDO0FBQ0EsUUFBSSxTQUFTLE9BQU8sSUFBSSxFQUFFO0FBQzFCLFFBQUksV0FBVyxRQUFRO0FBQ3JCLGVBQXlCLG9CQUFJLFFBQVE7QUFDckMsYUFBTyxJQUFJLElBQUksTUFBTTtBQUFBLElBQ3ZCO0FBQ0EsUUFBSSxTQUFTLE9BQU8sSUFBSSxFQUFFO0FBQzFCLFFBQUksV0FBVyxRQUFRO0FBQ3JCLGVBQXlCLG9CQUFJLFFBQVE7QUFDckMsYUFBTyxJQUFJLElBQUksTUFBTTtBQUFBLElBQ3ZCO0FBQ0EsUUFBSSxXQUFXLE9BQU8sSUFBSSxFQUFFO0FBQzVCLFFBQUksYUFBYSxRQUFRO0FBQ3ZCLGlCQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUU7QUFDeEIsYUFBTyxJQUFJLElBQUksUUFBUTtBQUFBLElBQ3pCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLElBQUksb0JBQW9CO0FBQUEsRUFDdEIsQ0FBQyxZQUFZLFlBQVksZUFBZTtBQUFBLElBQ3RDLFdBQVc7QUFBQSxJQUNYLFdBQVc7QUFBQSxJQUNYLFdBQVc7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUdBLElBQUksYUFBYTtBQUFBLEVBQ2YsQ0FBQyxHQUFHLHNCQUFzQixHQUFHLGtCQUFrQjtBQUFBLEVBQy9DLENBQUMsU0FBUyxLQUFLO0FBQ2pCO0FBR0EsSUFBSTtBQUFBLENBQ0gsU0FBUyxxQkFBcUI7QUFDN0Isc0JBQW9CLGNBQWMsSUFBSTtBQUN0QyxzQkFBb0IsbUJBQW1CLElBQUk7QUFDM0Msc0JBQW9CLHlCQUF5QixJQUFJO0FBQ2pELHNCQUFvQix5QkFBeUIsSUFBSTtBQUNqRCxzQkFBb0IsNEJBQTRCLElBQUk7QUFDcEQsc0JBQW9CLCtCQUErQixJQUFJO0FBQ3ZELHNCQUFvQixlQUFlLElBQUk7QUFDdkMsc0JBQW9CLG9CQUFvQixJQUFJO0FBQzVDLHNCQUFvQixvQkFBb0IsSUFBSTtBQUM1QyxzQkFBb0IsYUFBYSxJQUFJO0FBQ3JDLHNCQUFvQixrQkFBa0IsSUFBSTtBQUMxQyxzQkFBb0IsbUJBQW1CLElBQUk7QUFDM0Msc0JBQW9CLHVCQUF1QixJQUFJO0FBQy9DLHNCQUFvQiw4QkFBOEIsSUFBSTtBQUN0RCxzQkFBb0IsOEJBQThCLElBQUk7QUFDdEQsc0JBQW9CLDRCQUE0QixJQUFJO0FBQ3RELEdBQUcsdUJBQXVCLHFCQUFxQixDQUFDLEVBQUU7QUFDbEQsSUFBSTtBQUFBLENBQ0gsU0FBUyxzQkFBc0I7QUFDOUIsdUJBQXFCLHFCQUFxQixJQUFJO0FBQzlDLHVCQUFxQixxQkFBcUIsSUFBSTtBQUM5Qyx1QkFBcUIsNEJBQTRCLElBQUk7QUFDckQsdUJBQXFCLG9CQUFvQixJQUFJO0FBQzdDLHVCQUFxQiw2QkFBNkIsSUFBSTtBQUN0RCx1QkFBcUIsMEJBQTBCLElBQUk7QUFDckQsR0FBRyx3QkFBd0Isc0JBQXNCLENBQUMsRUFBRTtBQUdwRCxTQUFTLFVBQVUsT0FBTztBQUN4QixNQUFJO0FBQ0YsV0FBTyxLQUFLLE1BQU0sS0FBSztBQUFBLEVBQ3pCLFNBQVMsT0FBTztBQUNkLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFHQSxJQUFJLFlBQVksT0FBTztBQUN2QixJQUFJLGFBQWEsT0FBTztBQUN4QixJQUFJLG9CQUFvQixPQUFPO0FBQy9CLElBQUkscUJBQXFCLE9BQU87QUFDaEMsSUFBSSxnQkFBZ0IsT0FBTztBQUMzQixJQUFJLGdCQUFnQixPQUFPLFVBQVU7QUFDckMsSUFBSSxjQUFjLENBQUMsSUFBSSxRQUFRLFNBQVMsWUFBWTtBQUNsRCxTQUFPLFFBQVEsR0FBRyxHQUFHLG1CQUFtQixFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTSxFQUFFLFNBQVMsQ0FBQyxFQUFFLEdBQUcsU0FBUyxHQUFHLEdBQUcsSUFBSTtBQUM5RjtBQUNBLElBQUksZUFBZSxDQUFDLElBQUksTUFBTSxRQUFRLFNBQVM7QUFDN0MsTUFBSSxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sU0FBUyxZQUFZO0FBQ2xFLGFBQVMsT0FBTyxtQkFBbUIsSUFBSTtBQUNyQyxVQUFJLENBQUMsY0FBYyxLQUFLLElBQUksR0FBRyxLQUFLLFFBQVE7QUFDMUMsbUJBQVcsSUFBSSxLQUFLLEVBQUUsS0FBSyxNQUFNLEtBQUssR0FBRyxHQUFHLFlBQVksRUFBRSxPQUFPLGtCQUFrQixNQUFNLEdBQUcsTUFBTSxLQUFLLFdBQVcsQ0FBQztBQUFBLEVBQ3pIO0FBQ0EsU0FBTztBQUNUO0FBQ0EsSUFBSSxXQUFXLENBQUMsS0FBSyxZQUFZLFlBQVksU0FBUyxPQUFPLE9BQU8sVUFBVSxjQUFjLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLdEcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLGFBQWEsV0FBVyxRQUFRLFdBQVcsRUFBRSxPQUFPLEtBQUssWUFBWSxLQUFLLENBQUMsSUFBSTtBQUFBLEVBQzFHO0FBQ0Y7QUFDQSxJQUFJLHFCQUFxQixZQUFZO0FBQUEsRUFDbkMsbURBQW1ELFNBQVMsUUFBUTtBQUNsRTtBQUNBLFFBQUksc0JBQXNCO0FBQUEsTUFDeEIsY0FBYztBQUFBLE1BQ2QsS0FBSztBQUFBLE1BQ0wsUUFBUTtBQUFBLElBQ1Y7QUFDQSxhQUFTLGlCQUFpQixLQUFLO0FBQzdCLGFBQU8sT0FBTyxRQUFRLFlBQVksQ0FBQyxDQUFDLElBQUksS0FBSztBQUFBLElBQy9DO0FBQ0EsYUFBUyxZQUFZLGdCQUFnQixTQUFTO0FBQzVDLFVBQUksUUFBUSxlQUFlLE1BQU0sR0FBRyxFQUFFLE9BQU8sZ0JBQWdCO0FBQzdELFVBQUksbUJBQW1CLE1BQU0sTUFBTTtBQUNuQyxVQUFJLFNBQVMsbUJBQW1CLGdCQUFnQjtBQUNoRCxVQUFJLE9BQU8sT0FBTztBQUNsQixVQUFJLFFBQVEsT0FBTztBQUNuQixnQkFBVSxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcscUJBQXFCLE9BQU8sSUFBSTtBQUN0RSxVQUFJO0FBQ0YsZ0JBQVEsUUFBUSxlQUFlLG1CQUFtQixLQUFLLElBQUk7QUFBQSxNQUM3RCxTQUFTLEdBQUc7QUFDVixnQkFBUTtBQUFBLFVBQ04sZ0ZBQWdGLFFBQVE7QUFBQSxVQUN4RjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxTQUFTO0FBQUEsUUFDWDtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsWUFBTSxRQUFRLFNBQVMsTUFBTTtBQUMzQixZQUFJLFFBQVEsS0FBSyxNQUFNLEdBQUc7QUFDMUIsWUFBSSxNQUFNLE1BQU0sTUFBTSxFQUFFLFNBQVMsRUFBRSxZQUFZO0FBQy9DLFlBQUksU0FBUyxNQUFNLEtBQUssR0FBRztBQUMzQixZQUFJLFFBQVEsV0FBVztBQUNyQixpQkFBTyxVQUFVLElBQUksS0FBSyxNQUFNO0FBQUEsUUFDbEMsV0FBVyxRQUFRLFdBQVc7QUFDNUIsaUJBQU8sU0FBUyxTQUFTLFFBQVEsRUFBRTtBQUFBLFFBQ3JDLFdBQVcsUUFBUSxVQUFVO0FBQzNCLGlCQUFPLFNBQVM7QUFBQSxRQUNsQixXQUFXLFFBQVEsWUFBWTtBQUM3QixpQkFBTyxXQUFXO0FBQUEsUUFDcEIsV0FBVyxRQUFRLFlBQVk7QUFDN0IsaUJBQU8sV0FBVztBQUFBLFFBQ3BCLE9BQU87QUFDTCxpQkFBTyxHQUFHLElBQUk7QUFBQSxRQUNoQjtBQUFBLE1BQ0YsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQ0EsYUFBUyxtQkFBbUIsa0JBQWtCO0FBQzVDLFVBQUksT0FBTztBQUNYLFVBQUksUUFBUTtBQUNaLFVBQUksZUFBZSxpQkFBaUIsTUFBTSxHQUFHO0FBQzdDLFVBQUksYUFBYSxTQUFTLEdBQUc7QUFDM0IsZUFBTyxhQUFhLE1BQU07QUFDMUIsZ0JBQVEsYUFBYSxLQUFLLEdBQUc7QUFBQSxNQUMvQixPQUFPO0FBQ0wsZ0JBQVE7QUFBQSxNQUNWO0FBQ0EsYUFBTyxFQUFFLE1BQU0sTUFBTTtBQUFBLElBQ3ZCO0FBQ0EsYUFBUyxPQUFPLE9BQU8sU0FBUztBQUM5QixnQkFBVSxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcscUJBQXFCLE9BQU8sSUFBSTtBQUN0RSxVQUFJLENBQUMsT0FBTztBQUNWLFlBQUksQ0FBQyxRQUFRLEtBQUs7QUFDaEIsaUJBQU8sQ0FBQztBQUFBLFFBQ1YsT0FBTztBQUNMLGlCQUFPLENBQUM7QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUNBLFVBQUksTUFBTSxTQUFTO0FBQ2pCLFlBQUksT0FBTyxNQUFNLFFBQVEsaUJBQWlCLFlBQVk7QUFDcEQsa0JBQVEsTUFBTSxRQUFRLGFBQWE7QUFBQSxRQUNyQyxXQUFXLE1BQU0sUUFBUSxZQUFZLEdBQUc7QUFDdEMsa0JBQVEsTUFBTSxRQUFRLFlBQVk7QUFBQSxRQUNwQyxPQUFPO0FBQ0wsY0FBSSxNQUFNLE1BQU0sUUFBUSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUUsS0FBSyxTQUFTLEtBQUs7QUFDcEUsbUJBQU8sSUFBSSxZQUFZLE1BQU07QUFBQSxVQUMvQixDQUFDLENBQUM7QUFDRixjQUFJLENBQUMsT0FBTyxNQUFNLFFBQVEsVUFBVSxDQUFDLFFBQVEsUUFBUTtBQUNuRCxvQkFBUTtBQUFBLGNBQ047QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGtCQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssR0FBRztBQUN6QixnQkFBUSxDQUFDLEtBQUs7QUFBQSxNQUNoQjtBQUNBLGdCQUFVLFVBQVUsT0FBTyxPQUFPLENBQUMsR0FBRyxxQkFBcUIsT0FBTyxJQUFJO0FBQ3RFLFVBQUksQ0FBQyxRQUFRLEtBQUs7QUFDaEIsZUFBTyxNQUFNLE9BQU8sZ0JBQWdCLEVBQUUsSUFBSSxTQUFTLEtBQUs7QUFDdEQsaUJBQU8sWUFBWSxLQUFLLE9BQU87QUFBQSxRQUNqQyxDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0wsWUFBSSxVQUFVLENBQUM7QUFDZixlQUFPLE1BQU0sT0FBTyxnQkFBZ0IsRUFBRSxPQUFPLFNBQVMsVUFBVSxLQUFLO0FBQ25FLGNBQUksU0FBUyxZQUFZLEtBQUssT0FBTztBQUNyQyxtQkFBUyxPQUFPLElBQUksSUFBSTtBQUN4QixpQkFBTztBQUFBLFFBQ1QsR0FBRyxPQUFPO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFDQSxhQUFTLG9CQUFvQixlQUFlO0FBQzFDLFVBQUksTUFBTSxRQUFRLGFBQWEsR0FBRztBQUNoQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksT0FBTyxrQkFBa0IsVUFBVTtBQUNyQyxlQUFPLENBQUM7QUFBQSxNQUNWO0FBQ0EsVUFBSSxpQkFBaUIsQ0FBQztBQUN0QixVQUFJLE1BQU07QUFDVixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSTtBQUNKLGVBQVMsaUJBQWlCO0FBQ3hCLGVBQU8sTUFBTSxjQUFjLFVBQVUsS0FBSyxLQUFLLGNBQWMsT0FBTyxHQUFHLENBQUMsR0FBRztBQUN6RSxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxlQUFPLE1BQU0sY0FBYztBQUFBLE1BQzdCO0FBQ0EsZUFBUyxpQkFBaUI7QUFDeEIsYUFBSyxjQUFjLE9BQU8sR0FBRztBQUM3QixlQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTztBQUFBLE1BQzVDO0FBQ0EsYUFBTyxNQUFNLGNBQWMsUUFBUTtBQUNqQyxnQkFBUTtBQUNSLGdDQUF3QjtBQUN4QixlQUFPLGVBQWUsR0FBRztBQUN2QixlQUFLLGNBQWMsT0FBTyxHQUFHO0FBQzdCLGNBQUksT0FBTyxLQUFLO0FBQ2Qsd0JBQVk7QUFDWixtQkFBTztBQUNQLDJCQUFlO0FBQ2Ysd0JBQVk7QUFDWixtQkFBTyxNQUFNLGNBQWMsVUFBVSxlQUFlLEdBQUc7QUFDckQscUJBQU87QUFBQSxZQUNUO0FBQ0EsZ0JBQUksTUFBTSxjQUFjLFVBQVUsY0FBYyxPQUFPLEdBQUcsTUFBTSxLQUFLO0FBQ25FLHNDQUF3QjtBQUN4QixvQkFBTTtBQUNOLDZCQUFlLEtBQUssY0FBYyxVQUFVLE9BQU8sU0FBUyxDQUFDO0FBQzdELHNCQUFRO0FBQUEsWUFDVixPQUFPO0FBQ0wsb0JBQU0sWUFBWTtBQUFBLFlBQ3BCO0FBQUEsVUFDRixPQUFPO0FBQ0wsbUJBQU87QUFBQSxVQUNUO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyx5QkFBeUIsT0FBTyxjQUFjLFFBQVE7QUFDekQseUJBQWUsS0FBSyxjQUFjLFVBQVUsT0FBTyxjQUFjLE1BQU0sQ0FBQztBQUFBLFFBQzFFO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsV0FBTyxVQUFVO0FBQ2pCLFdBQU8sUUFBUSxRQUFRO0FBQ3ZCLFdBQU8sUUFBUSxjQUFjO0FBQzdCLFdBQU8sUUFBUSxxQkFBcUI7QUFBQSxFQUN0QztBQUNGLENBQUM7QUFDRCxJQUFJLDJCQUEyQixTQUFTLG1CQUFtQixDQUFDO0FBQzVELElBQUksNkJBQTZCO0FBQ2pDLFNBQVMsb0JBQW9CLE1BQU07QUFDakMsTUFBSSwyQkFBMkIsS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sSUFBSTtBQUMvRCxVQUFNLElBQUksVUFBVSx3Q0FBd0M7QUFBQSxFQUM5RDtBQUNBLFNBQU8sS0FBSyxLQUFLLEVBQUUsWUFBWTtBQUNqQztBQUNBLElBQUksb0JBQW9CO0FBQUEsRUFDdEIsT0FBTyxhQUFhLEVBQUU7QUFBQSxFQUN0QixPQUFPLGFBQWEsRUFBRTtBQUFBLEVBQ3RCLE9BQU8sYUFBYSxDQUFDO0FBQUEsRUFDckIsT0FBTyxhQUFhLEVBQUU7QUFDeEI7QUFDQSxJQUFJLDZCQUE2QixJQUFJO0FBQUEsRUFDbkMsTUFBTSxrQkFBa0IsS0FBSyxFQUFFLENBQUMsT0FBTyxrQkFBa0IsS0FBSyxFQUFFLENBQUM7QUFBQSxFQUNqRTtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTztBQUNuQyxRQUFNLFlBQVksTUFBTSxRQUFRLDRCQUE0QixFQUFFO0FBQzlELFNBQU87QUFDVDtBQUNBLFNBQVMsa0JBQWtCLE9BQU87QUFDaEMsTUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM3QixXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLFVBQU0sWUFBWSxNQUFNLFdBQVcsQ0FBQztBQUNwQyxRQUFJLFlBQVksT0FBTyxDQUFDLFFBQVEsU0FBUyxHQUFHO0FBQzFDLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsUUFBUSxPQUFPO0FBQ3RCLFNBQU8sQ0FBQztBQUFBLElBQ047QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGLEVBQUUsU0FBUyxLQUFLO0FBQ2xCO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTztBQUNqQyxNQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLFdBQU87QUFBQSxFQUNUO0FBQ0EsTUFBSSxNQUFNLEtBQUssTUFBTSxPQUFPO0FBQzFCLFdBQU87QUFBQSxFQUNUO0FBQ0EsV0FBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQyxVQUFNLFlBQVksTUFBTSxXQUFXLENBQUM7QUFDcEM7QUFBQTtBQUFBLE1BRUUsY0FBYztBQUFBLE1BQ2QsY0FBYyxNQUFNLGNBQWM7QUFBQSxNQUNsQztBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLElBQUkscUJBQXFCLE9BQU8sbUJBQW1CO0FBQ25ELElBQUksbUJBQW1CLE9BQU8sZ0JBQWdCO0FBQzlDLElBQUkseUJBQXlCO0FBQzdCLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBSTtBQUNKLElBQUksV0FBVyxNQUFNLFNBQVM7QUFBQSxFQUM1QixZQUFZLE1BQU07QUFDaEIsU0FBSyxFQUFFLElBQUksQ0FBQztBQUNaLFNBQUssRUFBRSxJQUFvQixvQkFBSSxJQUFJO0FBQ25DLFNBQUssRUFBRSxJQUFJO0FBQ1gsUUFBSSxDQUFDLFdBQVcsaUJBQWlCLEVBQUUsU0FBUyxRQUFRLE9BQU8sU0FBUyxLQUFLLFlBQVksSUFBSSxLQUFLLGdCQUFnQixZQUFZLE9BQU8sV0FBVyxZQUFZLGVBQWUsZ0JBQWdCLFdBQVcsU0FBUztBQUN6TSxZQUFNLGlCQUFpQjtBQUN2QixxQkFBZSxRQUFRLENBQUMsT0FBTyxTQUFTO0FBQ3RDLGFBQUssT0FBTyxNQUFNLEtBQUs7QUFBQSxNQUN6QixHQUFHLElBQUk7QUFBQSxJQUNULFdBQVcsTUFBTSxRQUFRLElBQUksR0FBRztBQUM5QixXQUFLLFFBQVEsQ0FBQyxDQUFDLE1BQU0sS0FBSyxNQUFNO0FBQzlCLGFBQUs7QUFBQSxVQUNIO0FBQUEsVUFDQSxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxzQkFBc0IsSUFBSTtBQUFBLFFBQzlEO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxXQUFXLE1BQU07QUFDZixhQUFPLG9CQUFvQixJQUFJLEVBQUUsUUFBUSxDQUFDLFNBQVM7QUFDakQsY0FBTSxRQUFRLEtBQUssSUFBSTtBQUN2QixhQUFLO0FBQUEsVUFDSDtBQUFBLFVBQ0EsTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssc0JBQXNCLElBQUk7QUFBQSxRQUM5RDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQUEsRUFDQSxFQUFFLEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssT0FBTyxhQUFhLE9BQU8sU0FBUyxJQUFJO0FBQzdGLFdBQU8sS0FBSyxRQUFRO0FBQUEsRUFDdEI7QUFBQSxFQUNBLENBQUMsT0FBTztBQUNOLGVBQVcsQ0FBQyxJQUFJLEtBQUssS0FBSyxRQUFRLEdBQUc7QUFDbkMsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUEsRUFDQSxDQUFDLFNBQVM7QUFDUixlQUFXLENBQUMsRUFBRSxLQUFLLEtBQUssS0FBSyxRQUFRLEdBQUc7QUFDdEMsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUEsRUFDQSxDQUFDLFVBQVU7QUFDVCxRQUFJLGFBQWEsT0FBTyxLQUFLLEtBQUssa0JBQWtCLENBQUMsRUFBRTtBQUFBLE1BQ3JELENBQUMsR0FBRyxNQUFNLEVBQUUsY0FBYyxDQUFDO0FBQUEsSUFDN0I7QUFDQSxlQUFXLFFBQVEsWUFBWTtBQUM3QixVQUFJLFNBQVMsY0FBYztBQUN6QixtQkFBVyxTQUFTLEtBQUssYUFBYSxHQUFHO0FBQ3ZDLGdCQUFNLENBQUMsTUFBTSxLQUFLO0FBQUEsUUFDcEI7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLENBQUMsTUFBTSxLQUFLLElBQUksSUFBSSxDQUFDO0FBQUEsTUFDN0I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsSUFBSSxNQUFNO0FBQ1IsUUFBSSxDQUFDLGtCQUFrQixJQUFJLEdBQUc7QUFDNUIsWUFBTSxJQUFJLFVBQVUsd0JBQXdCLElBQUksR0FBRztBQUFBLElBQ3JEO0FBQ0EsV0FBTyxLQUFLLGtCQUFrQixFQUFFLGVBQWUsb0JBQW9CLElBQUksQ0FBQztBQUFBLEVBQzFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxJQUFJLE1BQU07QUFDUixRQUFJLENBQUMsa0JBQWtCLElBQUksR0FBRztBQUM1QixZQUFNLFVBQVUsd0JBQXdCLElBQUksR0FBRztBQUFBLElBQ2pEO0FBQ0EsV0FBTyxLQUFLLGtCQUFrQixFQUFFLG9CQUFvQixJQUFJLENBQUMsS0FBSztBQUFBLEVBQ2hFO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQSxJQUFJLE1BQU0sT0FBTztBQUNmLFFBQUksQ0FBQyxrQkFBa0IsSUFBSSxLQUFLLENBQUMsbUJBQW1CLEtBQUssR0FBRztBQUMxRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGlCQUFpQixvQkFBb0IsSUFBSTtBQUMvQyxVQUFNLGtCQUFrQixxQkFBcUIsS0FBSztBQUNsRCxTQUFLLGtCQUFrQixFQUFFLGNBQWMsSUFBSSxxQkFBcUIsZUFBZTtBQUMvRSxTQUFLLGdCQUFnQixFQUFFLElBQUksZ0JBQWdCLElBQUk7QUFBQSxFQUNqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxNQUFNLE9BQU87QUFDbEIsUUFBSSxDQUFDLGtCQUFrQixJQUFJLEtBQUssQ0FBQyxtQkFBbUIsS0FBSyxHQUFHO0FBQzFEO0FBQUEsSUFDRjtBQUNBLFVBQU0saUJBQWlCLG9CQUFvQixJQUFJO0FBQy9DLFVBQU0sa0JBQWtCLHFCQUFxQixLQUFLO0FBQ2xELFFBQUksZ0JBQWdCLEtBQUssSUFBSSxjQUFjLElBQUksR0FBRyxLQUFLLElBQUksY0FBYyxDQUFDLEtBQUssZUFBZSxLQUFLO0FBQ25HLFNBQUssSUFBSSxNQUFNLGFBQWE7QUFBQSxFQUM5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUEsT0FBTyxNQUFNO0FBQ1gsUUFBSSxDQUFDLGtCQUFrQixJQUFJLEdBQUc7QUFDNUI7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLEdBQUc7QUFDbkI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxpQkFBaUIsb0JBQW9CLElBQUk7QUFDL0MsV0FBTyxLQUFLLGtCQUFrQixFQUFFLGNBQWM7QUFDOUMsU0FBSyxnQkFBZ0IsRUFBRSxPQUFPLGNBQWM7QUFBQSxFQUM5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxRQUFRLFVBQVUsU0FBUztBQUN6QixlQUFXLENBQUMsTUFBTSxLQUFLLEtBQUssS0FBSyxRQUFRLEdBQUc7QUFDMUMsZUFBUyxLQUFLLFNBQVMsT0FBTyxNQUFNLElBQUk7QUFBQSxJQUMxQztBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxlQUFlO0FBQ2IsVUFBTSxrQkFBa0IsS0FBSyxJQUFJLFlBQVk7QUFDN0MsUUFBSSxvQkFBb0IsTUFBTTtBQUM1QixhQUFPLENBQUM7QUFBQSxJQUNWO0FBQ0EsUUFBSSxvQkFBb0IsSUFBSTtBQUMxQixhQUFPLENBQUMsRUFBRTtBQUFBLElBQ1o7QUFDQSxZQUFRLEdBQUcseUJBQXlCLG9CQUFvQixlQUFlO0FBQUEsRUFDekU7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLEtBQUs7QUFDNUIsUUFBTSxRQUFRLElBQUksS0FBSyxFQUFFLE1BQU0sU0FBUztBQUN4QyxTQUFPLE1BQU0sT0FBTyxDQUFDLFNBQVMsU0FBUztBQUNyQyxRQUFJLEtBQUssS0FBSyxNQUFNLElBQUk7QUFDdEIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLFFBQVEsS0FBSyxNQUFNLElBQUk7QUFDN0IsVUFBTSxPQUFPLE1BQU0sTUFBTTtBQUN6QixVQUFNLFFBQVEsTUFBTSxLQUFLLElBQUk7QUFDN0IsWUFBUSxPQUFPLE1BQU0sS0FBSztBQUMxQixXQUFPO0FBQUEsRUFDVCxHQUFHLElBQUksU0FBUyxDQUFDO0FBQ25CO0FBR0EsU0FBUyxvQkFBb0IsZUFBZTtBQUMxQyxNQUFJLEtBQUs7QUFDVCxRQUFNLFVBQVUsZ0JBQWdCLGFBQWE7QUFDN0MsUUFBTSxjQUFjLFFBQVEsSUFBSSxjQUFjLEtBQUs7QUFDbkQsUUFBTSxjQUFjLFFBQVEsSUFBSSxxQkFBcUI7QUFDckQsTUFBSSxDQUFDLGFBQWE7QUFDaEIsVUFBTSxJQUFJLE1BQU0sMkNBQTJDO0FBQUEsRUFDN0Q7QUFDQSxRQUFNLGFBQWEsWUFBWSxNQUFNLEdBQUcsRUFBRSxPQUFPLENBQUMsS0FBSyxVQUFVO0FBQy9ELFVBQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLE1BQU0sS0FBSyxFQUFFLE1BQU0sR0FBRztBQUMvQyxRQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssR0FBRztBQUMxQixXQUFPO0FBQUEsRUFDVCxHQUFHLENBQUMsQ0FBQztBQUNMLFFBQU0sUUFBUSxNQUFNLFdBQVcsU0FBUyxPQUFPLFNBQVMsSUFBSSxNQUFNLEdBQUcsRUFBRTtBQUN2RSxRQUFNLFlBQVksTUFBTSxXQUFXLGFBQWEsT0FBTyxTQUFTLElBQUksTUFBTSxHQUFHLEVBQUU7QUFDL0UsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLE1BQU0sU0FBUztBQUN6QyxRQUFNLGNBQWMsV0FBVyxPQUFPLFNBQVMsUUFBUSxJQUFJLGNBQWM7QUFDekUsTUFBSSxDQUFDLGFBQWE7QUFDaEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLENBQUMsRUFBRSxHQUFHLFVBQVUsSUFBSSxZQUFZLE1BQU0sS0FBSztBQUNqRCxRQUFNLFdBQVcsV0FBVyxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsV0FBVyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxRQUFRLGNBQWMsRUFBRSxDQUFDLEVBQUUsQ0FBQztBQUM5RyxNQUFJLENBQUMsVUFBVTtBQUNiLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxpQkFBaUIsSUFBSSxPQUFPLE1BQU0sUUFBUSxFQUFFO0FBQ2xELFFBQU0sU0FBUyxLQUFLLE1BQU0sY0FBYyxFQUFFLE9BQU8sQ0FBQyxVQUFVLE1BQU0sV0FBVyxNQUFNLEtBQUssTUFBTSxTQUFTLE1BQU0sQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLE1BQU0sVUFBVSxFQUFFLFFBQVEsU0FBUyxFQUFFLENBQUM7QUFDckssTUFBSSxDQUFDLE9BQU8sUUFBUTtBQUNsQixXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sYUFBYSxDQUFDO0FBQ3BCLE1BQUk7QUFDRixlQUFXLFNBQVMsUUFBUTtBQUMxQixZQUFNLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxJQUFJLE1BQU0sTUFBTSxVQUFVO0FBQ3hELFlBQU0sY0FBYyxLQUFLLEtBQUssVUFBVTtBQUN4QyxZQUFNLEVBQUUsYUFBYSxjQUFjLFVBQVUsS0FBSyxJQUFJLG9CQUFvQixjQUFjO0FBQ3hGLFlBQU0sUUFBUSxhQUFhLFNBQVMsY0FBYyxJQUFJLEtBQUssQ0FBQyxXQUFXLEdBQUcsVUFBVSxFQUFFLE1BQU0sYUFBYSxDQUFDO0FBQzFHLFlBQU0sY0FBYyxXQUFXLElBQUk7QUFDbkMsVUFBSSxnQkFBZ0IsUUFBUTtBQUMxQixtQkFBVyxJQUFJLElBQUk7QUFBQSxNQUNyQixXQUFXLE1BQU0sUUFBUSxXQUFXLEdBQUc7QUFDckMsbUJBQVcsSUFBSSxJQUFJLENBQUMsR0FBRyxhQUFhLEtBQUs7QUFBQSxNQUMzQyxPQUFPO0FBQ0wsbUJBQVcsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1QsU0FBUyxPQUFPO0FBQ2QsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLFNBQVMsa0JBQWtCLE1BQU07QUFDL0IsTUFBSTtBQUNKLFFBQU0sZUFBZSxLQUFLLFlBQVksS0FBSyxDQUFDLGVBQWU7QUFDekQsV0FBTyxXQUFXLFNBQVM7QUFBQSxFQUM3QixDQUFDO0FBQ0QsU0FBTztBQUFBLElBQ0wsZUFBZSxnQkFBZ0IsT0FBTyxTQUFTLGFBQWE7QUFBQSxJQUM1RCxnQkFBZ0IsTUFBTSxnQkFBZ0IsT0FBTyxTQUFTLGFBQWEsU0FBUyxPQUFPLFNBQVMsSUFBSTtBQUFBLEVBQ2xHO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsT0FBTztBQUN6QixNQUFJO0FBQ0YsVUFBTSxNQUFNLE9BQU8sS0FBSztBQUN4QixXQUFPLGtCQUFrQixHQUFHO0FBQUEsRUFDOUIsU0FBUyxPQUFPO0FBQ2QsV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUNBLFNBQVMsMEJBQTBCLFdBQVcsS0FBSyxPQUFPO0FBQ3hELFFBQU0sYUFBYSxFQUFFLFVBQVU7QUFDL0IsYUFBVyxDQUFDLEtBQUssU0FBUyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDbEQsUUFBSSxFQUFFLE9BQU8sUUFBUTtBQUNuQixZQUFNLElBQUksTUFBTSxrQ0FBa0MsR0FBRyxLQUFLO0FBQUEsSUFDNUQ7QUFDQSxlQUFXLFdBQVcsV0FBVztBQUMvQixZQUFNLENBQUMsVUFBVSxHQUFHLGFBQWEsSUFBSSxRQUFRLE1BQU0sR0FBRyxFQUFFLFFBQVE7QUFDaEUsWUFBTSxRQUFRLGNBQWMsUUFBUTtBQUNwQyxVQUFJLFNBQVM7QUFDYixpQkFBVyxRQUFRLE9BQU87QUFDeEIsWUFBSSxFQUFFLFFBQVEsU0FBUztBQUNyQixnQkFBTSxJQUFJLE1BQU0sYUFBYSxLQUFLLHlCQUF5QjtBQUFBLFFBQzdEO0FBQ0EsaUJBQVMsT0FBTyxJQUFJO0FBQUEsTUFDdEI7QUFDQSxhQUFPLFFBQVEsSUFBSSxNQUFNLEdBQUc7QUFBQSxJQUM5QjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLFdBQVc7QUFDcEI7QUFDQSxlQUFlLGdCQUFnQixTQUFTO0FBQ3RDLE1BQUk7QUFDSixVQUFRLFFBQVEsUUFBUTtBQUFBLElBQ3RCLEtBQUssT0FBTztBQUNWLFlBQU0sTUFBTSxJQUFJLElBQUksUUFBUSxHQUFHO0FBQy9CLFlBQU0sUUFBUSxJQUFJLGFBQWEsSUFBSSxPQUFPO0FBQzFDLFlBQU0sWUFBWSxJQUFJLGFBQWEsSUFBSSxXQUFXLEtBQUs7QUFDdkQsYUFBTztBQUFBLFFBQ0w7QUFBQSxRQUNBLFdBQVcsVUFBVSxTQUFTO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLFFBQVE7QUFDWCxZQUFNLGVBQWUsUUFBUSxNQUFNO0FBQ25DLFdBQUssTUFBTSxRQUFRLFFBQVEsSUFBSSxjQUFjLE1BQU0sT0FBTyxTQUFTLElBQUksU0FBUyxxQkFBcUIsR0FBRztBQUN0RyxjQUFNLGVBQWU7QUFBQSxVQUNuQixNQUFNLGFBQWEsS0FBSztBQUFBLFVBQ3hCLFFBQVE7QUFBQSxRQUNWO0FBQ0EsWUFBSSxDQUFDLGNBQWM7QUFDakIsaUJBQU87QUFBQSxRQUNUO0FBQ0EsY0FBTSxFQUFFLFlBQVksS0FBSyxHQUFHLE1BQU0sSUFBSTtBQUN0QyxjQUFNLG1CQUFtQjtBQUFBLFVBQ3ZCO0FBQUEsUUFDRixLQUFLLENBQUM7QUFDTixZQUFJLENBQUMsaUJBQWlCLE9BQU87QUFDM0IsaUJBQU87QUFBQSxRQUNUO0FBQ0EsY0FBTSxZQUFZLFVBQVUsT0FBTyxFQUFFLEtBQUssQ0FBQztBQUMzQyxjQUFNLFlBQVksaUJBQWlCLFlBQVk7QUFBQSxVQUM3QyxpQkFBaUI7QUFBQSxVQUNqQjtBQUFBLFVBQ0E7QUFBQSxRQUNGLElBQUksQ0FBQztBQUNMLGVBQU87QUFBQSxVQUNMLE9BQU8saUJBQWlCO0FBQUEsVUFDeEI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFlBQU0sY0FBYyxNQUFNLGFBQWEsS0FBSyxFQUFFLE1BQU0sTUFBTSxJQUFJO0FBQzlELFVBQUksZUFBZSxPQUFPLFNBQVMsWUFBWSxPQUFPO0FBQ3BELGNBQU0sRUFBRSxPQUFPLFVBQVUsSUFBSTtBQUM3QixlQUFPO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQ0UsYUFBTztBQUFBLEVBQ1g7QUFDRjtBQUNBLGVBQWUsb0JBQW9CLFNBQVM7QUFDMUMsUUFBTSxRQUFRLE1BQU0sZ0JBQWdCLE9BQU87QUFDM0MsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLE9BQU87QUFDMUI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxFQUFFLE9BQU8sVUFBVSxJQUFJO0FBQzdCLFFBQU0sZUFBZSxXQUFXLEtBQUs7QUFDckMsTUFBSSx3QkFBd0IsT0FBTztBQUNqQyxVQUFNLG1CQUFtQixZQUFZLFFBQVEsR0FBRztBQUNoRCxVQUFNLElBQUk7QUFBQSxNQUNSLFNBQVM7QUFBQSxRQUNQO0FBQUEsUUFDQSxRQUFRO0FBQUEsUUFDUjtBQUFBLFFBQ0EsYUFBYTtBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLE9BQU8sTUFBTTtBQUFBLElBQ2IsZUFBZSxhQUFhO0FBQUEsSUFDNUIsZUFBZSxhQUFhO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxTQUFTLGVBQWUsT0FBTztBQUM3QixNQUFJLFNBQVMsTUFBTTtBQUNqQixXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU8sT0FBTyxVQUFVLFlBQVksVUFBVSxTQUFTLGlCQUFpQjtBQUMxRTtBQUNBLElBQUksa0JBQWtCLE1BQU1BLHlCQUF3QixlQUFlO0FBQUEsRUFDakUsWUFBWSxlQUFlLGVBQWUsVUFBVSxVQUFVLFNBQVM7QUFDckUsUUFBSSx3QkFBd0I7QUFDNUIsUUFBSSxlQUFlLGFBQWEsR0FBRztBQUNqQyxZQUFNLGFBQWEsa0JBQWtCLGFBQWE7QUFDbEQsVUFBSSxXQUFXLGtCQUFrQixlQUFlO0FBQzlDLGNBQU0sSUFBSTtBQUFBLFVBQ1IsMkdBQTJHLGFBQWEsZUFBZSxXQUFXLGFBQWE7QUFBQSxRQUNqSztBQUFBLE1BQ0Y7QUFDQSxVQUFJLENBQUMsV0FBVyxlQUFlO0FBQzdCLGNBQU0sSUFBSTtBQUFBLFVBQ1I7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLDhCQUF3QixXQUFXO0FBQUEsSUFDckM7QUFDQSxVQUFNLFNBQVMsa0JBQWtCLFFBQVEsR0FBRyxhQUFhLGFBQWEsU0FBUyxTQUFTLENBQUMsTUFBTSxHQUFHLGFBQWEsSUFBSSxxQkFBcUIsYUFBYSxTQUFTLFNBQVMsQ0FBQztBQUN4SyxVQUFNO0FBQUEsTUFDSixNQUFNO0FBQUEsUUFDSjtBQUFBLFFBQ0E7QUFBQSxRQUNBLGVBQWU7QUFBQSxNQUNqQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQ0Qsa0JBQWMsTUFBTSxVQUFVO0FBQzlCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxrQ0FBa0MsU0FBUztBQUMvQyxRQUFJLENBQUNBLGlCQUFnQixtQkFBbUIsSUFBSSxPQUFPLEdBQUc7QUFDcEQsTUFBQUEsaUJBQWdCLG1CQUFtQjtBQUFBLFFBQ2pDO0FBQUEsUUFDQSxNQUFNLG9CQUFvQixPQUFPLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDbEQsa0JBQVEsTUFBTSxLQUFLO0FBQ25CLGlCQUFPO0FBQUEsUUFDVCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFDQSxXQUFPQSxpQkFBZ0IsbUJBQW1CLElBQUksT0FBTztBQUFBLEVBQ3ZEO0FBQUEsRUFDQSxNQUFNLE1BQU0sTUFBTTtBQUNoQixVQUFNLFNBQVMsZ0JBQWdCLElBQUksSUFBSSxLQUFLLFFBQVEsR0FBRyxHQUFHLEtBQUssUUFBUTtBQUN2RSxVQUFNLFVBQVUscUJBQXFCLEtBQUssT0FBTztBQUNqRCxRQUFJLENBQUMsT0FBTyxTQUFTO0FBQ25CLGFBQU8sRUFBRSxPQUFPLFFBQVEsUUFBUTtBQUFBLElBQ2xDO0FBQ0EsVUFBTSxlQUFlLE1BQU0sS0FBSztBQUFBLE1BQzlCLEtBQUs7QUFBQSxJQUNQO0FBQ0EsUUFBSSxPQUFPLGlCQUFpQixhQUFhO0FBQ3ZDLGFBQU8sRUFBRSxPQUFPLFFBQVEsUUFBUTtBQUFBLElBQ2xDO0FBQ0EsV0FBTztBQUFBLE1BQ0wsT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLE9BQU8sYUFBYTtBQUFBLE1BQ3BCLGVBQWUsYUFBYTtBQUFBLE1BQzVCLGVBQWUsYUFBYTtBQUFBLE1BQzVCLFdBQVcsYUFBYTtBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsVUFBVSxNQUFNO0FBQ2QsUUFBSSxLQUFLLGFBQWEsa0JBQWtCLFFBQVE7QUFDOUMsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLENBQUMsS0FBSyxhQUFhLGlCQUFpQixLQUFLLEtBQUssa0JBQWtCLE9BQU87QUFDekUsWUFBTSxZQUFZLFlBQVksS0FBSyxRQUFRLEdBQUc7QUFDOUMsZUFBUyxLQUFLLDZDQUE2QyxLQUFLLFFBQVEsTUFBTSxJQUFJLFNBQVM7QUFBQTtBQUFBLDROQUUySDtBQUN0TixhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sMkJBQTJCLEtBQUssS0FBSyxrQkFBa0IsU0FBUyxLQUFLLGFBQWEsa0JBQWtCLEtBQUssS0FBSztBQUNwSCxVQUFNLDJCQUEyQixLQUFLLEtBQUsseUJBQXlCLFNBQVMsS0FBSyxLQUFLLGNBQWMsS0FBSyxLQUFLLGFBQWEsaUJBQWlCLEVBQUUsSUFBSSxLQUFLLGFBQWEsa0JBQWtCLEtBQUssS0FBSztBQUNqTSxXQUFPLEtBQUssYUFBYSxNQUFNLFdBQVcsNEJBQTRCO0FBQUEsRUFDeEU7QUFBQSxFQUNBLG1CQUFtQixNQUFNO0FBQ3ZCLFdBQU87QUFBQSxNQUNMLE9BQU8sS0FBSyxhQUFhLFNBQVM7QUFBQSxNQUNsQyxlQUFlLEtBQUssYUFBYSxpQkFBaUI7QUFBQSxNQUNsRCxXQUFXLEtBQUssYUFBYSxhQUFhLENBQUM7QUFBQSxNQUMzQyxTQUFTLEtBQUssYUFBYTtBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsTUFBTSxJQUFJLE1BQU07QUFDZCxVQUFNLGdCQUFnQixNQUFNLGlCQUFpQixLQUFLLE9BQU87QUFDekQsVUFBTSxpQkFBaUIsTUFBTSxrQkFBa0IsS0FBSyxRQUFRO0FBQzVELFVBQU0sY0FBYyxtQkFBbUIsZUFBZSxNQUFNO0FBQzVELFVBQU0sY0FBYyxLQUFLLGFBQWEsZ0JBQWdCLEdBQUcsS0FBSyxhQUFhLGFBQWEsSUFBSSxLQUFLLGFBQWEsYUFBYSxLQUFLLGFBQWEsS0FBSyxhQUFhLGFBQWE7QUFDNUssWUFBUTtBQUFBLE1BQ04sU0FBUztBQUFBLFFBQ1AsR0FBRyxhQUFhLENBQUMsSUFBSSxXQUFXLE9BQU8sZUFBZSxNQUFNLElBQUksZUFBZSxVQUFVO0FBQUEsTUFDM0Y7QUFBQSxNQUNBLFNBQVMsV0FBVztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBLFlBQVEsSUFBSSxZQUFZLGFBQWE7QUFDckMsWUFBUSxJQUFJLFlBQVksSUFBSTtBQUM1QixZQUFRLElBQUksYUFBYSxjQUFjO0FBQ3ZDLFlBQVEsU0FBUztBQUFBLEVBQ25CO0FBQ0Y7QUFDQSxjQUFjLGlCQUFpQixzQkFBc0Msb0JBQUksUUFBUSxDQUFDO0FBQ2xGLElBQUksaUJBQWlCO0FBR3JCLFNBQVMsMkJBQTJCLGVBQWUsS0FBSztBQUN0RCxTQUFPLENBQUMsZUFBZSxVQUFVLFVBQVUsQ0FBQyxNQUFNO0FBQ2hELFdBQU8sSUFBSTtBQUFBLE1BQ1Q7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsOEJBQThCLEtBQUs7QUFDMUMsU0FBTyxDQUFDLGFBQWE7QUFDbkIsV0FBTyxJQUFJLGVBQWUsT0FBTyxJQUFJLE9BQU8sSUFBSSxHQUFHLEtBQUssUUFBUTtBQUFBLEVBQ2xFO0FBQ0Y7QUFDQSxJQUFJLDBCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXNUIsT0FBTywyQkFBMkIsU0FBUyxHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWTlDLFVBQVUsMkJBQTJCLFlBQVksR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXcEQsV0FBVyw4QkFBOEIsR0FBRztBQUM5QztBQUNBLFNBQVMsa0JBQWtCLEtBQUs7QUFDOUIsU0FBTztBQUFBLElBQ0wsV0FBVyw4QkFBOEIsR0FBRztBQUFBLElBQzVDLE9BQU8sMkJBQTJCLFNBQVMsR0FBRztBQUFBLElBQzlDLFVBQVUsMkJBQTJCLFlBQVksR0FBRztBQUFBLEVBQ3REO0FBQ0Y7QUFDQSxJQUFJLFdBQVc7QUFBQSxFQUNiLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVILE1BQU07QUFDUjtBQUdBLElBQUksY0FBYyxPQUFPLFVBQVUsWUFBWTtBQUM3QyxRQUFNLFNBQVMsTUFBTSxnQkFBZ0I7QUFBQSxJQUNuQztBQUFBLElBQ0EsV0FBVyxnQkFBZ0I7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsQ0FBQztBQUNELFNBQU8sVUFBVSxPQUFPLFNBQVMsT0FBTztBQUMxQztBQUdBLElBQUksRUFBRSxTQUFTLFNBQVMsSUFBSTtBQUM1QixTQUFTLHNCQUFzQixPQUFPLENBQUMsR0FBRztBQUN4QyxRQUFNLFVBQVUsUUFBUSxPQUFPLFNBQVMsS0FBSyxXQUFXO0FBQ3hELFFBQU0sY0FBYyxRQUFRLE9BQU8sU0FBUyxLQUFLLGVBQWUsU0FBUyxNQUFNLEtBQUs7QUFDcEYsUUFBTSxVQUFVLElBQUksUUFBUSxRQUFRLE9BQU8sU0FBUyxLQUFLLE9BQU87QUFDaEUsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0g7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLFVBQVUsTUFBTTtBQUN4QyxNQUFJLEtBQUssTUFBTTtBQUNiLFdBQU8sZUFBZSxVQUFVLFFBQVE7QUFBQSxNQUN0QyxPQUFPLEtBQUs7QUFBQSxNQUNaLFlBQVk7QUFBQSxNQUNaLFVBQVU7QUFBQSxJQUNaLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxPQUFPLGFBQWEsYUFBYTtBQUNuQyxVQUFNLGtCQUFrQixTQUFTLFVBQVUsYUFBYTtBQUFBLE1BQ3RELEtBQUs7QUFBQSxJQUNQO0FBQ0EsZUFBVyxnQkFBZ0IsaUJBQWlCO0FBQzFDLGVBQVMsU0FBUztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUdBLElBQUksZUFBZSxNQUFNLHNCQUFzQixTQUFTO0FBQUEsRUFDdEQsWUFBWSxNQUFNLE1BQU07QUFDdEIsVUFBTSxlQUFlLHNCQUFzQixJQUFJO0FBQy9DLFVBQU0sTUFBTSxZQUFZO0FBQ3hCLHFCQUFpQixNQUFNLFlBQVk7QUFBQSxFQUNyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsT0FBTyxLQUFLLE1BQU0sTUFBTTtBQUN0QixVQUFNLGVBQWUsc0JBQXNCLElBQUk7QUFDL0MsUUFBSSxDQUFDLGFBQWEsUUFBUSxJQUFJLGNBQWMsR0FBRztBQUM3QyxtQkFBYSxRQUFRLElBQUksZ0JBQWdCLFlBQVk7QUFBQSxJQUN2RDtBQUNBLFFBQUksQ0FBQyxhQUFhLFFBQVEsSUFBSSxnQkFBZ0IsR0FBRztBQUMvQyxtQkFBYSxRQUFRO0FBQUEsUUFDbkI7QUFBQSxRQUNBLE9BQU8sSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxTQUFTLElBQUk7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUksY0FBYyxNQUFNLFlBQVk7QUFBQSxFQUM3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsT0FBTyxLQUFLLE1BQU0sTUFBTTtBQUN0QixVQUFNLGVBQWUsc0JBQXNCLElBQUk7QUFDL0MsUUFBSSxDQUFDLGFBQWEsUUFBUSxJQUFJLGNBQWMsR0FBRztBQUM3QyxtQkFBYSxRQUFRLElBQUksZ0JBQWdCLGtCQUFrQjtBQUFBLElBQzdEO0FBQ0EsVUFBTSxlQUFlLEtBQUssVUFBVSxJQUFJO0FBQ3hDLFFBQUksQ0FBQyxhQUFhLFFBQVEsSUFBSSxnQkFBZ0IsR0FBRztBQUMvQyxtQkFBYSxRQUFRO0FBQUEsUUFDbkI7QUFBQSxRQUNBLGVBQWUsSUFBSSxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsS0FBSyxTQUFTLElBQUk7QUFBQSxNQUM1RDtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUk7QUFBQSxNQUNUO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxPQUFPLElBQUksTUFBTSxNQUFNO0FBQ3JCLFVBQU0sZUFBZSxzQkFBc0IsSUFBSTtBQUMvQyxRQUFJLENBQUMsYUFBYSxRQUFRLElBQUksY0FBYyxHQUFHO0FBQzdDLG1CQUFhLFFBQVEsSUFBSSxnQkFBZ0IsVUFBVTtBQUFBLElBQ3JEO0FBQ0EsV0FBTyxJQUFJLGNBQWMsTUFBTSxZQUFZO0FBQUEsRUFDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBLE9BQU8sWUFBWSxNQUFNLE1BQU07QUFDN0IsVUFBTSxlQUFlLHNCQUFzQixJQUFJO0FBQy9DLFFBQUksTUFBTTtBQUNSLG1CQUFhLFFBQVEsSUFBSSxrQkFBa0IsS0FBSyxXQUFXLFNBQVMsQ0FBQztBQUFBLElBQ3ZFO0FBQ0EsV0FBTyxJQUFJLGNBQWMsTUFBTSxZQUFZO0FBQUEsRUFDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxPQUFPLFNBQVMsTUFBTSxNQUFNO0FBQzFCLFdBQU8sSUFBSSxjQUFjLE1BQU0sc0JBQXNCLElBQUksQ0FBQztBQUFBLEVBQzVEO0FBQ0Y7QUFHQSxJQUFJLDhCQUE4QjtBQUNsQyxJQUFJLDJCQUEyQjtBQUMvQixJQUFJLDJCQUEyQjtBQUMvQixJQUFJLDRCQUE0QjtBQUNoQyxTQUFTLDJCQUEyQjtBQUNsQyxNQUFJLGNBQWMsR0FBRztBQUNuQixXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU8sS0FBSztBQUFBLElBQ1YsS0FBSyxPQUFPLEtBQUssMkJBQTJCLDRCQUE0QjtBQUFBLEVBQzFFO0FBQ0Y7QUFDQSxlQUFlLE1BQU0sZ0JBQWdCO0FBQ25DLE1BQUk7QUFDSixNQUFJLE9BQU8sbUJBQW1CLFVBQVU7QUFDdEMsWUFBUSxnQkFBZ0I7QUFBQSxNQUN0QixLQUFLLFlBQVk7QUFDZixvQkFBWTtBQUNaO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxRQUFRO0FBQ1gsb0JBQVkseUJBQXlCO0FBQ3JDO0FBQUEsTUFDRjtBQUFBLE1BQ0EsU0FBUztBQUNQLGNBQU0sSUFBSTtBQUFBLFVBQ1IsbURBQW1ELGNBQWM7QUFBQSxRQUNuRTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixXQUFXLE9BQU8sbUJBQW1CLGFBQWE7QUFDaEQsZ0JBQVkseUJBQXlCO0FBQUEsRUFDdkMsT0FBTztBQUNMLFFBQUksaUJBQWlCLDZCQUE2QjtBQUNoRCxZQUFNLElBQUk7QUFBQSxRQUNSLHdEQUF3RCxjQUFjLDREQUE0RCwyQkFBMkI7QUFBQSxNQUMvSjtBQUFBLElBQ0Y7QUFDQSxnQkFBWTtBQUFBLEVBQ2Q7QUFDQSxTQUFPLElBQUksUUFBUSxDQUFDLFlBQVksV0FBVyxTQUFTLFNBQVMsQ0FBQztBQUNoRTtBQUdBLFNBQVMsT0FBTyxPQUFPLE1BQU07QUFDM0IsUUFBTSxVQUFVLElBQUk7QUFBQTtBQUFBO0FBQUEsSUFHbEIsaUJBQWlCLFVBQVUsTUFBTSxNQUFNLElBQUk7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDQTtBQUFBLElBQ0UsQ0FBQyxRQUFRO0FBQUEsSUFDVDtBQUFBLElBQ0EsUUFBUTtBQUFBLElBQ1IsUUFBUTtBQUFBLEVBQ1Y7QUFDQSxRQUFNLGVBQWUsUUFBUSxNQUFNO0FBQ25DLGVBQWEsUUFBUSxJQUFJLG1CQUFtQixRQUFRO0FBQ3BELFNBQU87QUFDVDtBQUdBLFNBQVMsY0FBYztBQUNyQixTQUFPLElBQUksU0FBUyxNQUFNO0FBQUEsSUFDeEIsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osU0FBUztBQUFBLE1BQ1AsbUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUdBLGFBQWE7QUFDYjtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQSxZQUFZO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBO0FBRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTsiLCJuYW1lcyI6WyJfR3JhcGhRTEhhbmRsZXIiXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==