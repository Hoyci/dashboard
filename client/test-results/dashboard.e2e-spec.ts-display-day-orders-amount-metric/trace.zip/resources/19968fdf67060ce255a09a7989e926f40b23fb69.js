import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/month-revenue-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { DollarSign } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { getMonthRevenue } from "/src/api/get-month-revenue.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function MonthRevenueCard() {
  _s();
  const { data: monthRevenue } = useQuery({
    queryFn: getMonthRevenue,
    queryKey: ["metrics", "month-revenue"]
  });
  return /* @__PURE__ */ jsxDEV(Card, { className: "bg-text-muted-foreground", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Receita total (mês)" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DollarSign, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: monthRevenue ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold tracking-tight", children: monthRevenue.receipt.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
      }) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs- text-muted-foreground", children: monthRevenue.diffFromLastMonth >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-500 dark:text-emerald-400", children: [
          "+",
          monthRevenue.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
          lineNumber: 35,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 34,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500 dark:text-rose-400", children: [
          monthRevenue.diffFromLastMonth,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
          lineNumber: 42,
          columnNumber: 19
        }, this),
        " ",
        "em relação ao mês passado"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 41,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
        lineNumber: 32,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 25,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 51,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(MonthRevenueCard, "vHFdS1Bl/vEHA2FAT0QNigAEQXc=", false, function() {
  return [useQuery];
});
_c = MonthRevenueCard;
var _c;
$RefreshReg$(_c, "MonthRevenueCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/month-revenue-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRLFNBZ0JRLFVBaEJSOzJCQWpCUjtBQUFpQixNQUFRLHFCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNoRCxTQUFTQSxrQkFBa0I7QUFFM0IsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLE1BQU1DLGFBQWFDLFlBQVlDLGlCQUFpQjtBQUV6RCxTQUFTQywwQkFBMEI7QUFFNUIsZ0JBQVNDLG1CQUFtQjtBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sRUFBRUMsTUFBTUMsYUFBYSxJQUFJQyxTQUFTO0FBQUEsSUFDdENDLFNBQVNYO0FBQUFBLElBQ1RZLFVBQVUsQ0FBQyxXQUFXLGVBQWU7QUFBQSxFQUN2QyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxRQUFLLFdBQVUsNEJBQ2Q7QUFBQSwyQkFBQyxjQUFXLFdBQVUsd0RBQ3BCO0FBQUEsNkJBQUMsYUFBVSxXQUFVLDJCQUF5QixtQ0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxjQUFXLFdBQVUsbUNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQ7QUFBQSxTQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGVBQVksV0FBVSxhQUNwQkgseUJBQ0MsbUNBQ0U7QUFBQSw2QkFBQyxVQUFLLFdBQVUscUNBQ2JBLHVCQUFhSSxRQUFRQyxlQUFlLFNBQVM7QUFBQSxRQUM1Q0MsT0FBTztBQUFBLFFBQ1BDLFVBQVU7QUFBQSxNQUNaLENBQUMsS0FKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVlAsdUJBQWFRLHFCQUFxQixJQUNqQyxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSwwQ0FBd0M7QUFBQTtBQUFBLFVBQ3BEUixhQUFhUTtBQUFBQSxVQUFrQjtBQUFBLGFBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSxvQ0FDYlI7QUFBQUEsdUJBQWFRO0FBQUFBLFVBQWtCO0FBQUEsYUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFBUTtBQUFBLFFBQUc7QUFBQSxXQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBLElBRUEsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQixLQTVCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFDVixHQS9DZUQsa0JBQWdCO0FBQUEsVUFDQ0ksUUFBUTtBQUFBO0FBQUFRLEtBRHpCWjtBQUFnQixJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRG9sbGFyU2lnbiIsImdldE1vbnRoUmV2ZW51ZSIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJNZXRyaWNDYXJkU2tlbGV0b24iLCJNb250aFJldmVudWVDYXJkIiwiX3MiLCJkYXRhIiwibW9udGhSZXZlbnVlIiwidXNlUXVlcnkiLCJxdWVyeUZuIiwicXVlcnlLZXkiLCJyZWNlaXB0IiwidG9Mb2NhbGVTdHJpbmciLCJzdHlsZSIsImN1cnJlbmN5IiwiZGlmZkZyb21MYXN0TW9udGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm1vbnRoLXJldmVudWUtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBEb2xsYXJTaWduIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbXBvcnQgeyBnZXRNb250aFJldmVudWUgfSBmcm9tICdAL2FwaS9nZXQtbW9udGgtcmV2ZW51ZSdcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcblxuaW1wb3J0IHsgTWV0cmljQ2FyZFNrZWxldG9uIH0gZnJvbSAnLi9tZXRyaWMtY2FyZC1za2VsZXRvbidcblxuZXhwb3J0IGZ1bmN0aW9uIE1vbnRoUmV2ZW51ZUNhcmQoKSB7XG4gIGNvbnN0IHsgZGF0YTogbW9udGhSZXZlbnVlIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlGbjogZ2V0TW9udGhSZXZlbnVlLFxuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnbW9udGgtcmV2ZW51ZSddLFxuICB9KVxuXG4gIHJldHVybiAoXG4gICAgPENhcmQgY2xhc3NOYW1lPVwiYmctdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktMCBwYi0yXCI+XG4gICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICBSZWNlaXRhIHRvdGFsIChtw6pzKVxuICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgPERvbGxhclNpZ24gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICB7bW9udGhSZXZlbnVlID8gKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAge21vbnRoUmV2ZW51ZS5yZWNlaXB0LnRvTG9jYWxlU3RyaW5nKCdwdC1CUicsIHtcbiAgICAgICAgICAgICAgICBzdHlsZTogJ2N1cnJlbmN5JyxcbiAgICAgICAgICAgICAgICBjdXJyZW5jeTogJ0JSTCcsXG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cy0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHttb250aFJldmVudWUuZGlmZkZyb21MYXN0TW9udGggPj0gMCA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTUwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgK3ttb250aFJldmVudWUuZGlmZkZyb21MYXN0TW9udGh9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYW8gbcOqcyBwYXNzYWRvXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHttb250aFJldmVudWUuZGlmZkZyb21MYXN0TW9udGh9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYW8gbcOqcyBwYXNzYWRvXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPE1ldHJpY0NhcmRTa2VsZXRvbiAvPlxuICAgICAgICApfVxuICAgICAgPC9DYXJkQ29udGVudD5cbiAgICA8L0NhcmQ+XG4gIClcbn1cbiJdLCJmaWxlIjoiL2hvbWUvcnVhbnBhYmxvL2lnbml0ZS9yZWFjdGpzL2Rhc2hib2FyZC9zcmMvcGFnZXMvYXBwL2Rhc2hib2FyZC9tb250aC1yZXZlbnVlLWNhcmQudHN4In0=