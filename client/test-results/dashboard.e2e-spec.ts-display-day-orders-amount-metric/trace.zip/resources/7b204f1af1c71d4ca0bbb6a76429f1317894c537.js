import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/app/dashboard/daily-orders-amount-card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { Utensils } from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { getDayOrdersAmount } from "/src/api/get-day-orders-amount.ts";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { MetricCardSkeleton } from "/src/pages/app/dashboard/metric-card-skeleton.tsx";
export function DailyOrdersAmountCard() {
  _s();
  const { data: dayOrdersAmount } = useQuery({
    queryFn: getDayOrdersAmount,
    queryKey: ["metrics", "day-orders-amount"]
  });
  return /* @__PURE__ */ jsxDEV(Card, { className: "bg-text-muted-foreground", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { className: "flex-row items-center justify-between space-y-0 pb-2", children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-semibold", children: "Pedidos (dia)" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Utensils, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { className: "space-y-1", children: dayOrdersAmount ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold tracking-tight", children: dayOrdersAmount.amount.toLocaleString("pt-BR") }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
        lineNumber: 24,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs- text-muted-foreground", children: dayOrdersAmount.diffFromYesterday >= 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-500 dark:text-emerald-400", children: [
          "+",
          dayOrdersAmount.diffFromYesterday,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
          lineNumber: 30,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
        lineNumber: 29,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500 dark:text-rose-400", children: [
          dayOrdersAmount.diffFromYesterday,
          "%"
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
          lineNumber: 37,
          columnNumber: 19
        }, this),
        " ",
        "em relação a ontem"
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
        lineNumber: 36,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
        lineNumber: 27,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(MetricCardSkeleton, {}, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
      lineNumber: 46,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
}
_s(DailyOrdersAmountCard, "X4ooPoWX1BlcuKkrK9Waaxl5Cfg=", false, function() {
  return [useQuery];
});
_c = DailyOrdersAmountCard;
var _c;
$RefreshReg$(_c, "DailyOrdersAmountCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/app/dashboard/daily-orders-amount-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJRLFNBV1EsVUFYUjsyQkFqQlI7QUFBaUIsTUFBUSxxQkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEQsU0FBU0EsZ0JBQWdCO0FBRXpCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxpQkFBaUI7QUFFekQsU0FBU0MsMEJBQTBCO0FBRTVCLGdCQUFTQyx3QkFBd0I7QUFBQUMsS0FBQTtBQUN0QyxRQUFNLEVBQUVDLE1BQU1DLGdCQUFnQixJQUFJQyxTQUFTO0FBQUEsSUFDekNDLFNBQVNYO0FBQUFBLElBQ1RZLFVBQVUsQ0FBQyxXQUFXLG1CQUFtQjtBQUFBLEVBQzNDLENBQUM7QUFFRCxTQUNFLHVCQUFDLFFBQUssV0FBVSw0QkFDZDtBQUFBLDJCQUFDLGNBQVcsV0FBVSx3REFDcEI7QUFBQSw2QkFBQyxhQUFVLFdBQVUsMkJBQTBCLDZCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsTUFDNUQsdUJBQUMsWUFBUyxXQUFVLG1DQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsU0FGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxlQUFZLFdBQVUsYUFDcEJILDRCQUNDLG1DQUNFO0FBQUEsNkJBQUMsVUFBSyxXQUFVLHFDQUNiQSwwQkFBZ0JJLE9BQU9DLGVBQWUsT0FBTyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVkwsMEJBQWdCTSxxQkFBcUIsSUFDcEMsbUNBQ0U7QUFBQSwrQkFBQyxVQUFLLFdBQVUsMENBQXdDO0FBQUE7QUFBQSxVQUNwRE4sZ0JBQWdCTTtBQUFBQSxVQUFrQjtBQUFBLGFBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsSUFFQSxtQ0FDRTtBQUFBLCtCQUFDLFVBQUssV0FBVSxvQ0FDYk47QUFBQUEsMEJBQWdCTTtBQUFBQSxVQUFrQjtBQUFBLGFBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFHO0FBQUEsV0FIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQSxJQUVBLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUIsS0F6QnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyQkE7QUFBQSxPQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUNBO0FBRUo7QUFBQ1IsR0ExQ2VELHVCQUFxQjtBQUFBLFVBQ0RJLFFBQVE7QUFBQTtBQUFBTSxLQUQ1QlY7QUFBcUIsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlV0ZW5zaWxzIiwiZ2V0RGF5T3JkZXJzQW1vdW50IiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsIk1ldHJpY0NhcmRTa2VsZXRvbiIsIkRhaWx5T3JkZXJzQW1vdW50Q2FyZCIsIl9zIiwiZGF0YSIsImRheU9yZGVyc0Ftb3VudCIsInVzZVF1ZXJ5IiwicXVlcnlGbiIsInF1ZXJ5S2V5IiwiYW1vdW50IiwidG9Mb2NhbGVTdHJpbmciLCJkaWZmRnJvbVllc3RlcmRheSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiZGFpbHktb3JkZXJzLWFtb3VudC1jYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IFV0ZW5zaWxzIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5pbXBvcnQgeyBnZXREYXlPcmRlcnNBbW91bnQgfSBmcm9tICdAL2FwaS9nZXQtZGF5LW9yZGVycy1hbW91bnQnXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5cbmltcG9ydCB7IE1ldHJpY0NhcmRTa2VsZXRvbiB9IGZyb20gJy4vbWV0cmljLWNhcmQtc2tlbGV0b24nXG5cbmV4cG9ydCBmdW5jdGlvbiBEYWlseU9yZGVyc0Ftb3VudENhcmQoKSB7XG4gIGNvbnN0IHsgZGF0YTogZGF5T3JkZXJzQW1vdW50IH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlGbjogZ2V0RGF5T3JkZXJzQW1vdW50LFxuICAgIHF1ZXJ5S2V5OiBbJ21ldHJpY3MnLCAnZGF5LW9yZGVycy1hbW91bnQnXSxcbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLXRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBzcGFjZS15LTAgcGItMlwiPlxuICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkXCI+UGVkaWRvcyAoZGlhKTwvQ2FyZFRpdGxlPlxuICAgICAgICA8VXRlbnNpbHMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICB7ZGF5T3JkZXJzQW1vdW50ID8gKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAge2RheU9yZGVyc0Ftb3VudC5hbW91bnQudG9Mb2NhbGVTdHJpbmcoJ3B0LUJSJyl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzLSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge2RheU9yZGVyc0Ftb3VudC5kaWZmRnJvbVllc3RlcmRheSA+PSAwID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAre2RheU9yZGVyc0Ftb3VudC5kaWZmRnJvbVllc3RlcmRheX0lXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+eycgJ31cbiAgICAgICAgICAgICAgICAgIGVtIHJlbGHDp8OjbyBhIG9udGVtXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtkYXlPcmRlcnNBbW91bnQuZGlmZkZyb21ZZXN0ZXJkYXl9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgICAgICBlbSByZWxhw6fDo28gYSBvbnRlbVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxNZXRyaWNDYXJkU2tlbGV0b24gLz5cbiAgICAgICAgKX1cbiAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgPC9DYXJkPlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL3BhZ2VzL2FwcC9kYXNoYm9hcmQvZGFpbHktb3JkZXJzLWFtb3VudC1jYXJkLnRzeCJ9