import { http, HttpResponse } from "/node_modules/.vite/deps/msw.js?v=cab43493";
export const approveOrderMock = http.patch(
  "/orders/:orderId/approve",
  async ({ params }) => {
    console.log("oi");
    if (params.orderId === "error-oder-id") {
      return new HttpResponse(null, { status: 400 });
    }
    return new HttpResponse(null, { status: 204 });
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcHJvdmUtb3JkZXItbW9jay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBodHRwLCBIdHRwUmVzcG9uc2UgfSBmcm9tICdtc3cnXG5cbmltcG9ydCB7IEFwcHJvdmVPcmRlclBhcmFtcyB9IGZyb20gJy4uL2FwcHJvdmUtb3JkZXInXG5cbmV4cG9ydCBjb25zdCBhcHByb3ZlT3JkZXJNb2NrID0gaHR0cC5wYXRjaDxBcHByb3ZlT3JkZXJQYXJhbXMsIG5ldmVyLCBuZXZlcj4oXG4gICcvb3JkZXJzLzpvcmRlcklkL2FwcHJvdmUnLFxuICBhc3luYyAoeyBwYXJhbXMgfSkgPT4ge1xuICAgIGNvbnNvbGUubG9nKCdvaScpXG4gICAgaWYgKHBhcmFtcy5vcmRlcklkID09PSAnZXJyb3Itb2Rlci1pZCcpIHtcbiAgICAgIHJldHVybiBuZXcgSHR0cFJlc3BvbnNlKG51bGwsIHsgc3RhdHVzOiA0MDAgfSlcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBIdHRwUmVzcG9uc2UobnVsbCwgeyBzdGF0dXM6IDIwNCB9KVxuICB9LFxuKVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLE1BQU0sb0JBQW9CO0FBSTVCLGFBQU0sbUJBQW1CLEtBQUs7QUFBQSxFQUNuQztBQUFBLEVBQ0EsT0FBTyxFQUFFLE9BQU8sTUFBTTtBQUNwQixZQUFRLElBQUksSUFBSTtBQUNoQixRQUFJLE9BQU8sWUFBWSxpQkFBaUI7QUFDdEMsYUFBTyxJQUFJLGFBQWEsTUFBTSxFQUFFLFFBQVEsSUFBSSxDQUFDO0FBQUEsSUFDL0M7QUFDQSxXQUFPLElBQUksYUFBYSxNQUFNLEVBQUUsUUFBUSxJQUFJLENBQUM7QUFBQSxFQUMvQztBQUNGOyIsIm5hbWVzIjpbXX0=