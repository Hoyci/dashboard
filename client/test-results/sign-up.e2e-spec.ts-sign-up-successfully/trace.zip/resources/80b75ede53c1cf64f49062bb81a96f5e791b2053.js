import {
  clsx,
  clsx_default
} from "/node_modules/.vite/deps/chunk-ZHRGLJTE.js?v=cab43493";
import "/node_modules/.vite/deps/chunk-TIUEEL27.js?v=cab43493";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
