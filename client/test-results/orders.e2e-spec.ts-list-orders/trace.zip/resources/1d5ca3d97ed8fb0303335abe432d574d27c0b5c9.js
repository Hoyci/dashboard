import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/auth/sign-in.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMutation } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=cab43493";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=cab43493";
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=cab43493";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=cab43493";
import { z } from "/node_modules/.vite/deps/zod.js?v=cab43493";
import { signIn } from "/src/api/sign-in.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
const signInForm = z.object({
  email: z.string().email()
});
export function SignIn() {
  _s();
  const [searchParams] = useSearchParams();
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm({
    defaultValues: {
      email: searchParams.get("email") ?? ""
    }
  });
  const { mutateAsync: authenticate } = useMutation({
    mutationFn: signIn
  });
  const handleSignIn = async (data) => {
    try {
      await authenticate({ email: data.email });
      console.log(data);
      toast.success("Enviamos um link de autenticação para seu e-mail", {
        action: { label: "Reenviar", onClick: () => handleSignIn(data) }
      });
    } catch (error) {
      toast.error("Credenciais inválidas.");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Helmet, { title: "login" }, void 0, false, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
      /* @__PURE__ */ jsxDEV(Button, { asChild: true, className: "absolute right-8 top-8", children: /* @__PURE__ */ jsxDEV(Link, { to: "/sign-up", children: "Novo estabelecimento" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
        lineNumber: 53,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex w-[350px] flex-col justify-center gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 text-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "tracking-title text-2xl font-semibold", children: "Acessar painel" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
            lineNumber: 57,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: "Acompanhe suas vendas pelo painel do parceiro" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
            lineNumber: 60,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
          lineNumber: 56,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleSubmit(handleSignIn), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Seu e-mail" }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
              lineNumber: 66,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { id: "email", type: "email", ...register("email") }, void 0, false, {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
              lineNumber: 67,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
            lineNumber: 65,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { disabled: isSubmitting, className: "w-full", type: "submit", children: "Acessar painel" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
            lineNumber: 69,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
          lineNumber: 64,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
}
_s(SignIn, "l6gBc5MjCmq4qlusf52YI0BJ7b4=", false, function() {
  return [useSearchParams, useForm, useMutation];
});
_c = SignIn;
var _c;
$RefreshReg$(_c, "SignIn");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/pages/auth/sign-in.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RJLG1CQUNFLGNBREY7MkJBaERKO0FBQW9CLG9CQUFRLDZCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNuRCxTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsTUFBTUMsdUJBQXVCO0FBQ3RDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsU0FBUztBQUVsQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxhQUFhO0FBRXRCLE1BQU1DLGFBQWFMLEVBQUVNLE9BQU87QUFBQSxFQUMxQkMsT0FBT1AsRUFBRVEsT0FBTyxFQUFFRCxNQUFNO0FBQzFCLENBQUM7QUFJTSxnQkFBU0UsU0FBUztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsWUFBWSxJQUFJYixnQkFBZ0I7QUFFdkMsUUFBTTtBQUFBLElBQ0pjO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLFdBQVcsRUFBRUMsYUFBYTtBQUFBLEVBQzVCLElBQUluQixRQUFvQjtBQUFBLElBQ3RCb0IsZUFBZTtBQUFBLE1BQ2JULE9BQU9JLGFBQWFNLElBQUksT0FBTyxLQUFLO0FBQUEsSUFDdEM7QUFBQSxFQUNGLENBQUM7QUFFRCxRQUFNLEVBQUVDLGFBQWFDLGFBQWEsSUFBSUMsWUFBWTtBQUFBLElBQ2hEQyxZQUFZcEI7QUFBQUEsRUFDZCxDQUFDO0FBRUQsUUFBTXFCLGVBQWUsT0FBT0MsU0FBcUI7QUFDL0MsUUFBSTtBQUNGLFlBQU1KLGFBQWEsRUFBRVosT0FBT2dCLEtBQUtoQixNQUFNLENBQUM7QUFDeENpQixjQUFRQyxJQUFJRixJQUFJO0FBQ2hCeEIsWUFBTTJCLFFBQVEsb0RBQW9EO0FBQUEsUUFDaEVDLFFBQVEsRUFBRUMsT0FBTyxZQUFZQyxTQUFTQSxNQUFNUCxhQUFhQyxJQUFJLEVBQUU7QUFBQSxNQUNqRSxDQUFDO0FBQUEsSUFDSCxTQUFTTyxPQUFPO0FBQ2QvQixZQUFNK0IsTUFBTSx3QkFBd0I7QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsVUFBTyxPQUFNLFdBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQ3JCLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsNkJBQUMsVUFBTyxTQUFPLE1BQUMsV0FBVSwwQkFDeEIsaUNBQUMsUUFBSyxJQUFHLFlBQVcsb0NBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUseUNBQXVDLDhCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQStCLDZEQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVqQixhQUFhUyxZQUFZLEdBQzdEO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFNLFNBQVEsU0FBUSwwQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxTQUFNLElBQUcsU0FBUSxNQUFLLFNBQVEsR0FBSVYsU0FBUyxPQUFPLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsZUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxVQUFVRyxjQUFjLFdBQVUsVUFBUyxNQUFLLFVBQVEsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsT0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBCQTtBQUVKO0FBQUNMLEdBMURlRCxRQUFNO0FBQUEsVUFDR1gsaUJBTW5CRixTQU1rQ3dCLFdBQVc7QUFBQTtBQUFBVyxLQWJuQ3RCO0FBQU0sSUFBQXNCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJIZWxtZXQiLCJ1c2VGb3JtIiwiTGluayIsInVzZVNlYXJjaFBhcmFtcyIsInRvYXN0IiwieiIsInNpZ25JbiIsIkJ1dHRvbiIsIklucHV0IiwiTGFiZWwiLCJzaWduSW5Gb3JtIiwib2JqZWN0IiwiZW1haWwiLCJzdHJpbmciLCJTaWduSW4iLCJfcyIsInNlYXJjaFBhcmFtcyIsInJlZ2lzdGVyIiwiaGFuZGxlU3VibWl0IiwiZm9ybVN0YXRlIiwiaXNTdWJtaXR0aW5nIiwiZGVmYXVsdFZhbHVlcyIsImdldCIsIm11dGF0ZUFzeW5jIiwiYXV0aGVudGljYXRlIiwidXNlTXV0YXRpb24iLCJtdXRhdGlvbkZuIiwiaGFuZGxlU2lnbkluIiwiZGF0YSIsImNvbnNvbGUiLCJsb2ciLCJzdWNjZXNzIiwiYWN0aW9uIiwibGFiZWwiLCJvbkNsaWNrIiwiZXJyb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInNpZ24taW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSAncmVhY3QtaGVsbWV0LWFzeW5jJ1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcbmltcG9ydCB7IExpbmssIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcidcbmltcG9ydCB7IHogfSBmcm9tICd6b2QnXG5cbmltcG9ydCB7IHNpZ25JbiB9IGZyb20gJ0AvYXBpL3NpZ24taW4nXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnXG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9sYWJlbCdcblxuY29uc3Qgc2lnbkluRm9ybSA9IHoub2JqZWN0KHtcbiAgZW1haWw6IHouc3RyaW5nKCkuZW1haWwoKSxcbn0pXG5cbnR5cGUgU2lnbkluRm9ybSA9IHouaW5mZXI8dHlwZW9mIHNpZ25JbkZvcm0+XG5cbmV4cG9ydCBmdW5jdGlvbiBTaWduSW4oKSB7XG4gIGNvbnN0IFtzZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKClcblxuICBjb25zdCB7XG4gICAgcmVnaXN0ZXIsXG4gICAgaGFuZGxlU3VibWl0LFxuICAgIGZvcm1TdGF0ZTogeyBpc1N1Ym1pdHRpbmcgfSxcbiAgfSA9IHVzZUZvcm08U2lnbkluRm9ybT4oe1xuICAgIGRlZmF1bHRWYWx1ZXM6IHtcbiAgICAgIGVtYWlsOiBzZWFyY2hQYXJhbXMuZ2V0KCdlbWFpbCcpID8/ICcnLFxuICAgIH0sXG4gIH0pXG5cbiAgY29uc3QgeyBtdXRhdGVBc3luYzogYXV0aGVudGljYXRlIH0gPSB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25Gbjogc2lnbkluLFxuICB9KVxuXG4gIGNvbnN0IGhhbmRsZVNpZ25JbiA9IGFzeW5jIChkYXRhOiBTaWduSW5Gb3JtKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGF1dGhlbnRpY2F0ZSh7IGVtYWlsOiBkYXRhLmVtYWlsIH0pXG4gICAgICBjb25zb2xlLmxvZyhkYXRhKVxuICAgICAgdG9hc3Quc3VjY2VzcygnRW52aWFtb3MgdW0gbGluayBkZSBhdXRlbnRpY2HDp8OjbyBwYXJhIHNldSBlLW1haWwnLCB7XG4gICAgICAgIGFjdGlvbjogeyBsYWJlbDogJ1JlZW52aWFyJywgb25DbGljazogKCkgPT4gaGFuZGxlU2lnbkluKGRhdGEpIH0sXG4gICAgICB9KVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0b2FzdC5lcnJvcignQ3JlZGVuY2lhaXMgaW52w6FsaWRhcy4nKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxIZWxtZXQgdGl0bGU9XCJsb2dpblwiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOFwiPlxuICAgICAgICA8QnV0dG9uIGFzQ2hpbGQgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtOCB0b3AtOFwiPlxuICAgICAgICAgIDxMaW5rIHRvPVwiL3NpZ24tdXBcIj5Ob3ZvIGVzdGFiZWxlY2ltZW50bzwvTGluaz5cbiAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LVszNTBweF0gZmxleC1jb2wganVzdGlmeS1jZW50ZXIgZ2FwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0cmFja2luZy10aXRsZSB0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgIEFjZXNzYXIgcGFpbmVsXG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgQWNvbXBhbmhlIHN1YXMgdmVuZGFzIHBlbG8gcGFpbmVsIGRvIHBhcmNlaXJvXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChoYW5kbGVTaWduSW4pfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwiZW1haWxcIj5TZXUgZS1tYWlsPC9MYWJlbD5cbiAgICAgICAgICAgICAgPElucHV0IGlkPVwiZW1haWxcIiB0eXBlPVwiZW1haWxcIiB7Li4ucmVnaXN0ZXIoJ2VtYWlsJyl9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxCdXR0b24gZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30gY2xhc3NOYW1lPVwidy1mdWxsXCIgdHlwZT1cInN1Ym1pdFwiPlxuICAgICAgICAgICAgICBBY2Vzc2FyIHBhaW5lbFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL3BhZ2VzL2F1dGgvc2lnbi1pbi50c3gifQ==