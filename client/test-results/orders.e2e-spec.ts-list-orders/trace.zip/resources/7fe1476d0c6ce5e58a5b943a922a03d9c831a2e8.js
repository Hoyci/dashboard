import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/pagination.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight
} from "/node_modules/.vite/deps/lucide-react.js?v=cab43493";
import { Button } from "/src/components/ui/button.tsx";
export function Pagination({
  pageIndex,
  totalCount,
  perPage,
  onPageChange
}) {
  const pages = Math.ceil(totalCount / perPage) || 1;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-muted-foreground", children: [
      "Total de ",
      totalCount,
      " item(s)"
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 lg:gap-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium", children: [
        "Página ",
        pageIndex + 1,
        " de ",
        pages
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(0),
            className: "h-8",
            variant: "outline",
            disabled: pageIndex === 0,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronsLeft, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 42,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Primeira página" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 43,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
            lineNumber: 36,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(pageIndex - 1),
            className: "h-8",
            variant: "outline",
            disabled: pageIndex === 0,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 51,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Página anterior" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 52,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
            lineNumber: 45,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(pageIndex + 1),
            className: "h-8",
            variant: "outline",
            disabled: pages <= pageIndex + 1,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 60,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Próxima página" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 61,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
            lineNumber: 54,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => onPageChange(pages - 1),
            className: "h-8",
            variant: "outline",
            disabled: pages <= pageIndex + 1,
            children: [
              /* @__PURE__ */ jsxDEV(ChevronsRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 69,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Última página" }, void 0, false, {
                fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
                lineNumber: 70,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
            lineNumber: 63,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
}
_c = Pagination;
var _c;
$RefreshReg$(_c, "Pagination");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/components/pagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEJNO0FBMUJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLGNBQWM7QUFTaEIsZ0JBQVNDLFdBQVc7QUFBQSxFQUN6QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDZSxHQUFHO0FBQ2xCLFFBQU1DLFFBQVFDLEtBQUtDLEtBQUtMLGFBQWFDLE9BQU8sS0FBSztBQUVqRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDJCQUFDLFVBQUssV0FBVSxpQ0FBK0I7QUFBQTtBQUFBLE1BQ25DRDtBQUFBQSxNQUFXO0FBQUEsU0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUJBQXFCO0FBQUE7QUFBQSxRQUMxQkQsWUFBWTtBQUFBLFFBQUU7QUFBQSxRQUFLSTtBQUFBQSxXQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1ELGFBQWEsQ0FBQztBQUFBLFlBQzdCLFdBQVU7QUFBQSxZQUNWLFNBQVE7QUFBQSxZQUNSLFVBQVVILGNBQWM7QUFBQSxZQUV4QjtBQUFBLHFDQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxjQUNqQyx1QkFBQyxVQUFLLFdBQVUsV0FBVSwrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQTtBQUFBO0FBQUEsVUFQM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1HLGFBQWFILFlBQVksQ0FBQztBQUFBLFlBQ3pDLFdBQVU7QUFBQSxZQUNWLFNBQVE7QUFBQSxZQUNSLFVBQVVBLGNBQWM7QUFBQSxZQUV4QjtBQUFBLHFDQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGNBQ2hDLHVCQUFDLFVBQUssV0FBVSxXQUFVLCtCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBO0FBQUE7QUFBQSxVQVAzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUcsYUFBYUgsWUFBWSxDQUFDO0FBQUEsWUFDekMsV0FBVTtBQUFBLFlBQ1YsU0FBUTtBQUFBLFlBQ1IsVUFBVUksU0FBU0osWUFBWTtBQUFBLFlBRS9CO0FBQUEscUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGNBQ2pDLHVCQUFDLFVBQUssV0FBVSxXQUFVLDhCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBO0FBQUE7QUFBQSxVQVAxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUcsYUFBYUMsUUFBUSxDQUFDO0FBQUEsWUFDckMsV0FBVTtBQUFBLFlBQ1YsU0FBUTtBQUFBLFlBQ1IsVUFBVUEsU0FBU0osWUFBWTtBQUFBLFlBRS9CO0FBQUEscUNBQUMsaUJBQWMsV0FBVSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBLGNBQ2xDLHVCQUFDLFVBQUssV0FBVSxXQUFVLDZCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBO0FBQUE7QUFBQSxVQVB6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFdBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0E7QUFBQSxTQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBO0FBQUEsT0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdEQTtBQUVKO0FBQUNPLEtBM0RlUjtBQUFVLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDaGV2cm9uTGVmdCIsIkNoZXZyb25SaWdodCIsIkNoZXZyb25zTGVmdCIsIkNoZXZyb25zUmlnaHQiLCJCdXR0b24iLCJQYWdpbmF0aW9uIiwicGFnZUluZGV4IiwidG90YWxDb3VudCIsInBlclBhZ2UiLCJvblBhZ2VDaGFuZ2UiLCJwYWdlcyIsIk1hdGgiLCJjZWlsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJwYWdpbmF0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBDaGV2cm9uTGVmdCxcbiAgQ2hldnJvblJpZ2h0LFxuICBDaGV2cm9uc0xlZnQsXG4gIENoZXZyb25zUmlnaHQsXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi91aS9idXR0b24nXG5cbmV4cG9ydCBpbnRlcmZhY2UgUGFnaW5hdGlvblByb3BzIHtcbiAgcGFnZUluZGV4OiBudW1iZXJcbiAgdG90YWxDb3VudDogbnVtYmVyXG4gIHBlclBhZ2U6IG51bWJlclxuICBvblBhZ2VDaGFuZ2U6IChwYWdlSW5kZXg6IG51bWJlcikgPT4gUHJvbWlzZTx2b2lkPiB8IHZvaWRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFBhZ2luYXRpb24oe1xuICBwYWdlSW5kZXgsXG4gIHRvdGFsQ291bnQsXG4gIHBlclBhZ2UsXG4gIG9uUGFnZUNoYW5nZSxcbn06IFBhZ2luYXRpb25Qcm9wcykge1xuICBjb25zdCBwYWdlcyA9IE1hdGguY2VpbCh0b3RhbENvdW50IC8gcGVyUGFnZSkgfHwgMVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgIFRvdGFsIGRlIHt0b3RhbENvdW50fSBpdGVtKHMpXG4gICAgICA8L3NwYW4+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTYgbGc6Z2FwLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgUMOhZ2luYSB7cGFnZUluZGV4ICsgMX0gZGUge3BhZ2VzfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZSgwKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOFwiXG4gICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICBkaXNhYmxlZD17cGFnZUluZGV4ID09PSAwfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDaGV2cm9uc0xlZnQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+UHJpbWVpcmEgcMOhZ2luYTwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UocGFnZUluZGV4IC0gMSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLThcIlxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2VJbmRleCA9PT0gMH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+UMOhZ2luYSBhbnRlcmlvcjwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblBhZ2VDaGFuZ2UocGFnZUluZGV4ICsgMSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLThcIlxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2VzIDw9IHBhZ2VJbmRleCArIDF9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5QcsOzeGltYSBww6FnaW5hPC9zcGFuPlxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZShwYWdlcyAtIDEpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04XCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlcyA8PSBwYWdlSW5kZXggKyAxfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDaGV2cm9uc1JpZ2h0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPsOabHRpbWEgcMOhZ2luYTwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiIvaG9tZS9ydWFucGFibG8vaWduaXRlL3JlYWN0anMvZGFzaGJvYXJkL3NyYy9jb21wb25lbnRzL3BhZ2luYXRpb24udHN4In0=