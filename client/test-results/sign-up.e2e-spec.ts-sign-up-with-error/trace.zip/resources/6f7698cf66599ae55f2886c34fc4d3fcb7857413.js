import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/store-profile-dialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cab43493"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=cab43493";
import { DialogClose } from "/node_modules/.vite/deps/@radix-ui_react-dialog.js?v=cab43493";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=cab43493";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=cab43493";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=cab43493";
import { z } from "/node_modules/.vite/deps/zod.js?v=cab43493";
import {
  getManagedRestaurant
} from "/src/api/get-managed-restaurant.ts";
import { updateProfile } from "/src/api/update-profile.ts";
import { Button } from "/src/components/ui/button.tsx";
import {
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "/src/components/ui/dialog.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
const storeProfileSchema = z.object({
  name: z.string().min(1),
  description: z.string().nullable()
});
export default function StoreProfileDialog() {
  _s();
  const queryClient = useQueryClient();
  const { data: managedRestaurant } = useQuery({
    queryKey: ["managed-restaurant"],
    queryFn: getManagedRestaurant,
    staleTime: Infinity
  });
  const {
    register,
    handleSubmit,
    formState: { isSubmitting }
  } = useForm({
    resolver: zodResolver(storeProfileSchema),
    values: {
      name: managedRestaurant?.name ?? "",
      description: managedRestaurant?.description ?? ""
    }
  });
  function updateManagedRestaurantCache({
    name,
    description
  }) {
    const cached = queryClient.getQueryData(
      [
        "managed-restaurant"
      ]
    );
    if (cached) {
      queryClient.setQueryData(
        ["managed-restaurant"],
        {
          ...cached,
          name,
          description
        }
      );
    }
    return { cached };
  }
  const { mutateAsync: updateProfileFn } = useMutation({
    mutationFn: updateProfile,
    onMutate({ name, description }) {
      const { cached } = updateManagedRestaurantCache({ name, description });
      return { previousProfile: cached };
    },
    onError(_, __, context) {
      if (context?.previousProfile) {
        updateManagedRestaurantCache(context.previousProfile);
      }
    }
  });
  const handleUpdateProfile = async (data) => {
    try {
      await updateProfileFn({ name: data.name, description: data.description });
      toast.success("Perfil atualizado com sucesso!");
    } catch {
      toast.error("Falha ao atualizar o perfil, tente novamente!");
    }
  };
  return /* @__PURE__ */ jsxDEV(DialogContent, { children: [
    /* @__PURE__ */ jsxDEV(DialogHeader, { children: [
      /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Perfil da loja" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogDescription, { children: "Atualize as informações do seu estabelecimento visíveis ao seu cliente" }, void 0, false, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
        lineNumber: 103,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit(handleUpdateProfile), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 py-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-right", htmlFor: "name", children: "Nome" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
            lineNumber: 111,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { className: "col-span-3", id: "name", ...register("name") }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
            lineNumber: 114,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
          lineNumber: 110,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(Label, { className: "text-right", htmlFor: "description", children: "Descrição" }, void 0, false, {
            fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
            lineNumber: 117,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Textarea,
            {
              className: "col-span-3",
              id: "description",
              ...register("description")
            },
            void 0,
            false,
            {
              fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
              lineNumber: 120,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
        lineNumber: 109,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DialogFooter, { children: [
        /* @__PURE__ */ jsxDEV(DialogClose, { asChild: true, children: /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", type: "button", children: "Cancelar" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
          lineNumber: 130,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "success", disabled: isSubmitting, children: "Salvar" }, void 0, false, {
          fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
          lineNumber: 134,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
        lineNumber: 128,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
      lineNumber: 108,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx",
    lineNumber: 100,
    columnNumber: 5
  }, this);
}
_s(StoreProfileDialog, "jK6TgGd2ajBFfdSbR3yGKWsI/nw=", false, function() {
  return [useQueryClient, useQuery, useForm, useMutation];
});
_c = StoreProfileDialog;
var _c;
$RefreshReg$(_c, "StoreProfileDialog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ruanpablo/ignite/reactjs/dashboard/src/components/store-profile-dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdROzJCQXJHUjtBQUFvQixvQkFBUSw2QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDckQsU0FBU0EsbUJBQW1CO0FBQzVCLFNBQVNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUN0RCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsU0FBUztBQUVsQjtBQUFBLEVBQ0VDO0FBQUFBLE9BRUs7QUFDUCxTQUFTQyxxQkFBcUI7QUFFOUIsU0FBU0MsY0FBYztBQUN2QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLHFCQUFxQlosRUFBRWEsT0FBTztBQUFBLEVBQ2xDQyxNQUFNZCxFQUFFZSxPQUFPLEVBQUVDLElBQUksQ0FBQztBQUFBLEVBQ3RCQyxhQUFhakIsRUFBRWUsT0FBTyxFQUFFRyxTQUFTO0FBQ25DLENBQUM7QUFJRCx3QkFBd0JDLHFCQUFxQjtBQUFBQyxLQUFBO0FBQzNDLFFBQU1DLGNBQWN4QixlQUFlO0FBRW5DLFFBQU0sRUFBRXlCLE1BQU1DLGtCQUFrQixJQUFJM0IsU0FBUztBQUFBLElBQzNDNEIsVUFBVSxDQUFDLG9CQUFvQjtBQUFBLElBQy9CQyxTQUFTeEI7QUFBQUEsSUFDVHlCLFdBQVdDO0FBQUFBLEVBQ2IsQ0FBQztBQUVELFFBQU07QUFBQSxJQUNKQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQyxXQUFXLEVBQUVDLGFBQWE7QUFBQSxFQUM1QixJQUFJakMsUUFBNEI7QUFBQSxJQUM5QmtDLFVBQVVDLFlBQVlyQixrQkFBa0I7QUFBQSxJQUN4Q3NCLFFBQVE7QUFBQSxNQUNOcEIsTUFBTVMsbUJBQW1CVCxRQUFRO0FBQUEsTUFDakNHLGFBQWFNLG1CQUFtQk4sZUFBZTtBQUFBLElBQ2pEO0FBQUEsRUFDRixDQUFDO0FBRUQsV0FBU2tCLDZCQUE2QjtBQUFBLElBQ3BDckI7QUFBQUEsSUFDQUc7QUFBQUEsRUFDa0IsR0FBRztBQUNyQixVQUFNbUIsU0FBU2YsWUFBWWdCO0FBQUFBLE1BQTJDO0FBQUEsUUFDcEU7QUFBQSxNQUFvQjtBQUFBLElBQ3JCO0FBRUQsUUFBSUQsUUFBUTtBQUNWZixrQkFBWWlCO0FBQUFBLFFBQ1YsQ0FBQyxvQkFBb0I7QUFBQSxRQUNyQjtBQUFBLFVBQ0UsR0FBR0Y7QUFBQUEsVUFDSHRCO0FBQUFBLFVBQ0FHO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFdBQU8sRUFBRW1CLE9BQU87QUFBQSxFQUNsQjtBQUVBLFFBQU0sRUFBRUcsYUFBYUMsZ0JBQWdCLElBQUk3QyxZQUFZO0FBQUEsSUFDbkQ4QyxZQUFZdkM7QUFBQUEsSUFDWndDLFNBQVMsRUFBRTVCLE1BQU1HLFlBQVksR0FBRztBQUM5QixZQUFNLEVBQUVtQixPQUFPLElBQUlELDZCQUE2QixFQUFFckIsTUFBTUcsWUFBWSxDQUFDO0FBRXJFLGFBQU8sRUFBRTBCLGlCQUFpQlAsT0FBTztBQUFBLElBQ25DO0FBQUEsSUFDQVEsUUFBUUMsR0FBR0MsSUFBSUMsU0FBUztBQUN0QixVQUFJQSxTQUFTSixpQkFBaUI7QUFDNUJSLHFDQUE2QlksUUFBUUosZUFBZTtBQUFBLE1BQ3REO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU1LLHNCQUFzQixPQUFPMUIsU0FBNkI7QUFDOUQsUUFBSTtBQUNGLFlBQU1rQixnQkFBZ0IsRUFBRTFCLE1BQU1RLEtBQUtSLE1BQU1HLGFBQWFLLEtBQUtMLFlBQVksQ0FBQztBQUN4RWxCLFlBQU1rRCxRQUFRLGdDQUFnQztBQUFBLElBQ2hELFFBQVE7QUFDTmxELFlBQU1tRCxNQUFNLCtDQUErQztBQUFBLElBQzdEO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsaUJBQ0M7QUFBQSwyQkFBQyxnQkFDQztBQUFBLDZCQUFDLGVBQVksOEJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLE1BQzNCLHVCQUFDLHFCQUFpQixzRkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUVBLHVCQUFDLFVBQUssVUFBVXJCLGFBQWFtQixtQkFBbUIsR0FDOUM7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsY0FBYSxTQUFRLFFBQU0sb0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQU0sV0FBVSxjQUFhLElBQUcsUUFBTyxHQUFJcEIsU0FBUyxNQUFNLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsYUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsY0FBYSxTQUFRLGVBQWEseUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxHQUFJQSxTQUFTLGFBQWE7QUFBQTtBQUFBLFlBSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUc4QjtBQUFBLGFBUGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUVBLHVCQUFDLGdCQUNDO0FBQUEsK0JBQUMsZUFBWSxTQUFPLE1BQ2xCLGlDQUFDLFVBQU8sU0FBUSxTQUFRLE1BQUssVUFBUSx3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFRLFdBQVUsVUFBVUcsY0FBYSxzQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsT0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVDQTtBQUVKO0FBQUNYLEdBNUd1QkQsb0JBQWtCO0FBQUEsVUFDcEJ0QixnQkFFZ0JELFVBVWhDRSxTQThCcUNILFdBQVc7QUFBQTtBQUFBd0QsS0EzQzlCaEM7QUFBa0IsSUFBQWdDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJEaWFsb2dDbG9zZSIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsInVzZUZvcm0iLCJ0b2FzdCIsInoiLCJnZXRNYW5hZ2VkUmVzdGF1cmFudCIsInVwZGF0ZVByb2ZpbGUiLCJCdXR0b24iLCJEaWFsb2dDb250ZW50IiwiRGlhbG9nRGVzY3JpcHRpb24iLCJEaWFsb2dGb290ZXIiLCJEaWFsb2dIZWFkZXIiLCJEaWFsb2dUaXRsZSIsIklucHV0IiwiTGFiZWwiLCJUZXh0YXJlYSIsInN0b3JlUHJvZmlsZVNjaGVtYSIsIm9iamVjdCIsIm5hbWUiLCJzdHJpbmciLCJtaW4iLCJkZXNjcmlwdGlvbiIsIm51bGxhYmxlIiwiU3RvcmVQcm9maWxlRGlhbG9nIiwiX3MiLCJxdWVyeUNsaWVudCIsImRhdGEiLCJtYW5hZ2VkUmVzdGF1cmFudCIsInF1ZXJ5S2V5IiwicXVlcnlGbiIsInN0YWxlVGltZSIsIkluZmluaXR5IiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJmb3JtU3RhdGUiLCJpc1N1Ym1pdHRpbmciLCJyZXNvbHZlciIsInpvZFJlc29sdmVyIiwidmFsdWVzIiwidXBkYXRlTWFuYWdlZFJlc3RhdXJhbnRDYWNoZSIsImNhY2hlZCIsImdldFF1ZXJ5RGF0YSIsInNldFF1ZXJ5RGF0YSIsIm11dGF0ZUFzeW5jIiwidXBkYXRlUHJvZmlsZUZuIiwibXV0YXRpb25GbiIsIm9uTXV0YXRlIiwicHJldmlvdXNQcm9maWxlIiwib25FcnJvciIsIl8iLCJfXyIsImNvbnRleHQiLCJoYW5kbGVVcGRhdGVQcm9maWxlIiwic3VjY2VzcyIsImVycm9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJzdG9yZS1wcm9maWxlLWRpYWxvZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCdcbmltcG9ydCB7IERpYWxvZ0Nsb3NlIH0gZnJvbSAnQHJhZGl4LXVpL3JlYWN0LWRpYWxvZydcbmltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInXG5pbXBvcnQgeyB6IH0gZnJvbSAnem9kJ1xuXG5pbXBvcnQge1xuICBnZXRNYW5hZ2VkUmVzdGF1cmFudCxcbiAgR2V0TWFuYWdlZFJlc3RhdXJhbnRSZXNwb25zZSxcbn0gZnJvbSAnQC9hcGkvZ2V0LW1hbmFnZWQtcmVzdGF1cmFudCdcbmltcG9ydCB7IHVwZGF0ZVByb2ZpbGUgfSBmcm9tICdAL2FwaS91cGRhdGUtcHJvZmlsZSdcblxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi91aS9idXR0b24nXG5pbXBvcnQge1xuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nRm9vdGVyLFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxufSBmcm9tICcuL3VpL2RpYWxvZydcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnLi91aS9pbnB1dCdcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnLi91aS9sYWJlbCdcbmltcG9ydCB7IFRleHRhcmVhIH0gZnJvbSAnLi91aS90ZXh0YXJlYSdcblxuY29uc3Qgc3RvcmVQcm9maWxlU2NoZW1hID0gei5vYmplY3Qoe1xuICBuYW1lOiB6LnN0cmluZygpLm1pbigxKSxcbiAgZGVzY3JpcHRpb246IHouc3RyaW5nKCkubnVsbGFibGUoKSxcbn0pXG5cbnR5cGUgU3RvcmVQcm9maWxlU2NoZW1hID0gei5pbmZlcjx0eXBlb2Ygc3RvcmVQcm9maWxlU2NoZW1hPlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdG9yZVByb2ZpbGVEaWFsb2coKSB7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuXG4gIGNvbnN0IHsgZGF0YTogbWFuYWdlZFJlc3RhdXJhbnQgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogWydtYW5hZ2VkLXJlc3RhdXJhbnQnXSxcbiAgICBxdWVyeUZuOiBnZXRNYW5hZ2VkUmVzdGF1cmFudCxcbiAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuICB9KVxuXG4gIGNvbnN0IHtcbiAgICByZWdpc3RlcixcbiAgICBoYW5kbGVTdWJtaXQsXG4gICAgZm9ybVN0YXRlOiB7IGlzU3VibWl0dGluZyB9LFxuICB9ID0gdXNlRm9ybTxTdG9yZVByb2ZpbGVTY2hlbWE+KHtcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIoc3RvcmVQcm9maWxlU2NoZW1hKSxcbiAgICB2YWx1ZXM6IHtcbiAgICAgIG5hbWU6IG1hbmFnZWRSZXN0YXVyYW50Py5uYW1lID8/ICcnLFxuICAgICAgZGVzY3JpcHRpb246IG1hbmFnZWRSZXN0YXVyYW50Py5kZXNjcmlwdGlvbiA/PyAnJyxcbiAgICB9LFxuICB9KVxuXG4gIGZ1bmN0aW9uIHVwZGF0ZU1hbmFnZWRSZXN0YXVyYW50Q2FjaGUoe1xuICAgIG5hbWUsXG4gICAgZGVzY3JpcHRpb24sXG4gIH06IFN0b3JlUHJvZmlsZVNjaGVtYSkge1xuICAgIGNvbnN0IGNhY2hlZCA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxHZXRNYW5hZ2VkUmVzdGF1cmFudFJlc3BvbnNlPihbXG4gICAgICAnbWFuYWdlZC1yZXN0YXVyYW50JyxcbiAgICBdKVxuXG4gICAgaWYgKGNhY2hlZCkge1xuICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhPEdldE1hbmFnZWRSZXN0YXVyYW50UmVzcG9uc2U+KFxuICAgICAgICBbJ21hbmFnZWQtcmVzdGF1cmFudCddLFxuICAgICAgICB7XG4gICAgICAgICAgLi4uY2FjaGVkLFxuICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgZGVzY3JpcHRpb24sXG4gICAgICAgIH0sXG4gICAgICApXG4gICAgfVxuXG4gICAgcmV0dXJuIHsgY2FjaGVkIH1cbiAgfVxuXG4gIGNvbnN0IHsgbXV0YXRlQXN5bmM6IHVwZGF0ZVByb2ZpbGVGbiB9ID0gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IHVwZGF0ZVByb2ZpbGUsXG4gICAgb25NdXRhdGUoeyBuYW1lLCBkZXNjcmlwdGlvbiB9KSB7XG4gICAgICBjb25zdCB7IGNhY2hlZCB9ID0gdXBkYXRlTWFuYWdlZFJlc3RhdXJhbnRDYWNoZSh7IG5hbWUsIGRlc2NyaXB0aW9uIH0pXG5cbiAgICAgIHJldHVybiB7IHByZXZpb3VzUHJvZmlsZTogY2FjaGVkIH1cbiAgICB9LFxuICAgIG9uRXJyb3IoXywgX18sIGNvbnRleHQpIHtcbiAgICAgIGlmIChjb250ZXh0Py5wcmV2aW91c1Byb2ZpbGUpIHtcbiAgICAgICAgdXBkYXRlTWFuYWdlZFJlc3RhdXJhbnRDYWNoZShjb250ZXh0LnByZXZpb3VzUHJvZmlsZSlcbiAgICAgIH1cbiAgICB9LFxuICB9KVxuXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZVByb2ZpbGUgPSBhc3luYyAoZGF0YTogU3RvcmVQcm9maWxlU2NoZW1hKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHVwZGF0ZVByb2ZpbGVGbih7IG5hbWU6IGRhdGEubmFtZSwgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24gfSlcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoJ1BlcmZpbCBhdHVhbGl6YWRvIGNvbSBzdWNlc3NvIScpXG4gICAgfSBjYXRjaCB7XG4gICAgICB0b2FzdC5lcnJvcignRmFsaGEgYW8gYXR1YWxpemFyIG8gcGVyZmlsLCB0ZW50ZSBub3ZhbWVudGUhJylcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxEaWFsb2dDb250ZW50PlxuICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgPERpYWxvZ1RpdGxlPlBlcmZpbCBkYSBsb2phPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgIEF0dWFsaXplIGFzIGluZm9ybWHDp8O1ZXMgZG8gc2V1IGVzdGFiZWxlY2ltZW50byB2aXPDrXZlaXMgYW8gc2V1IGNsaWVudGVcbiAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KGhhbmRsZVVwZGF0ZVByb2ZpbGUpfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcHktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCIgaHRtbEZvcj1cIm5hbWVcIj5cbiAgICAgICAgICAgICAgTm9tZVxuICAgICAgICAgICAgPC9MYWJlbD5cbiAgICAgICAgICAgIDxJbnB1dCBjbGFzc05hbWU9XCJjb2wtc3Bhbi0zXCIgaWQ9XCJuYW1lXCIgey4uLnJlZ2lzdGVyKCduYW1lJyl9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPExhYmVsIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIiBodG1sRm9yPVwiZGVzY3JpcHRpb25cIj5cbiAgICAgICAgICAgICAgRGVzY3Jpw6fDo29cbiAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICA8VGV4dGFyZWFcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sLXNwYW4tM1wiXG4gICAgICAgICAgICAgIGlkPVwiZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ2Rlc2NyaXB0aW9uJyl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8RGlhbG9nRm9vdGVyPlxuICAgICAgICAgIDxEaWFsb2dDbG9zZSBhc0NoaWxkPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZ2hvc3RcIiB0eXBlPVwiYnV0dG9uXCI+XG4gICAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L0RpYWxvZ0Nsb3NlPlxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHZhcmlhbnQ9XCJzdWNjZXNzXCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30+XG4gICAgICAgICAgICBTYWx2YXJcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9EaWFsb2dDb250ZW50PlxuICApXG59XG4iXSwiZmlsZSI6Ii9ob21lL3J1YW5wYWJsby9pZ25pdGUvcmVhY3Rqcy9kYXNoYm9hcmQvc3JjL2NvbXBvbmVudHMvc3RvcmUtcHJvZmlsZS1kaWFsb2cudHN4In0=